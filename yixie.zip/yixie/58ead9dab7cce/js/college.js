function footer() {
	var nav = "<div class='footer-navbar'>\
					<ul>\
						<li><a href='college-index.html' data-ajax='false'><span class='ico icon-index'></span>首页</a></li>\
						<li><a href='college-release.html' data-ajax='false'><div class='release'><span class='ico icon-add'></span></div><span class='ico icon-add opacity'></span>校招信息</a></li>\
						<li><a href='college-my.html' data-ajax='false'><span class='ico icon-mine'></span>我的</a></li>\
					</ul>\
				</div>"
	$('.warper').append(nav);
};

function checkMustLogin(type, next) {
	$.get('/fontuser/checkMustLogin', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
            window.location.href = "../login.html"
			return false;
		}
		if(data.data.type != type) {
            window.location.href = "../login.html"
			return false;
		}
		window.sessionStorage.setItem('fontUser', JSON.stringify(data.data.info))
		window.sessionStorage.setItem('detail', JSON.stringify(data.data.detail))
		next();
	});
}

function GetQueryString(name){
     var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
     var r = window.location.search.substr(1).match(reg);
     if(r!=null)return unescape(r[2]); return '';
}

function getAllSchool(){
	$.get('/fontuser/getAllSchool',function(data) {
		var data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var allSchool=data.data
		window.sessionStorage.setItem('allSchool', JSON.stringify(allSchool))
		console.log(allSchool)
		var html = ""
		$.each(allSchool, function(index, val) {
			var x = val.star;
		    var y = String(x).indexOf(".") + 1;//获取小数点的位置
		    var count = String(x).length - y;//获取小数点后的个数
		    if(count > 1) {
		        var star = parseFloat(x).toFixed(1)
		    } else {
				var star = val.star
		    }
		    var integer = Math.floor(star/5*100)
			var width = integer+"%"
			
			console.log("医械",x,y,count,star,integer,width)
			
			html += '<a class="item" href="college-detail.html?fontUserId='+val.fontUserId+'" data-ajax="false">\
						<i style="background-image: url('+val.logo+');"></i>\
						<div class="comemnt">\
							<p>'+val.name+'</p>\
							<div class="c-stars">\
								<div class="c-stars-up" style="width:'+width+'"></div>\
							</div>\
							<div class="college-bottom">\
								<div class="pingfen"><span id="star">'+star+'分</span></div>\
								<p>评价（'+ val.comemntNum +'）</p>\
							</div>\
						</div>\
					</a>'
		})
		$(".ranking").append(html);
	})
}


function getComment(id){
	$.get('/schoolcomment/getCommentBySchoolId',{schoolId:id},function(data) {
		var data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var comment=data.data

		console.log(comment)
		$("#len").text(comment.length)
		var html = ""
		$.each(comment, function(index,val) {
			if(val.headImgUrl==""||val.headImgUrl==null){
				var url = "../images/picture-loading02.jpg"
			}else{
				var url = val.headImgUrl
			}
			var time = val.createTime.substring(0,10)
			var degree = val.degree
			console.log(degree)
			var star = ""
			for (var i = 0;i < degree;i++) {
				star += '<i class="star_open"></i>'
			}
			html += '<li>\
						<div class="li-top">\
							<img src="'+url+'" />\
							<div class="li-info">\
								<h3>'+val.name+'</h3>\
								<div class="star">\
								'+star+'\
								</div>\
							</div>\
						</div>\
						<p>'+val.content+'</p>\
						<span>'+time+'</span>\
					</li>'
		});
		$(".c-comment ul").append(html)
	})
}

//图片上传
function imgUrl(obj,imgBox){
	$("#"+obj).change(function() {
		var length=$(this).parent(".img-item").prev(".result").find("img").length
		console.log(length)
		if(length>=2){
			$(this).parent(".img-item").hide()
		}
		var result=document.getElementById(imgBox);
		var file = document.getElementById(obj).files[0];   
		//判断浏览器是否支持FileReader接口  
		if(typeof FileReader == 'undefined'){  
		    result.InnerHTML="<p>你的浏览器不支持FileReader接口！</p>";  
		    //使选择控件不可操作  
		    file.setAttribute("disabled","disabled");  
		}
		function readAsDataURL(){
		    if(!/image\/\w+/.test(file.type)){  
		        alert("看清楚，这个需要图片！");  
		        return false;  
		    }  
		    var reader = new FileReader();  
		    //将文件以Data URL形式读入页面  
		    reader.readAsDataURL(file);  
		    reader.onload=function(e){
		        dealImage(this.result, {
					 width : 200
					}, function(base){
					 this.result = base;
					 var data=base
					 console.log("压缩后：" + data);
					//显示文件  
		        	result.innerHTML += '<div class="img-fill">\
			        						<img src="' + data +'" alt="" />\
			        						<i class="del-fill"></i>\
		        						</div>';
				})
		    }
		}
		readAsDataURL();
	});
};
function dealImage(path, obj, callback) {
	var img = new Image();
	img.src = path;
	img.onload = function() {
		var that = this; 
		// 默认按比例压缩  
		var w = that.width
		,	h = that.height
		,   scale = w / h;
		w = obj.width || w;   
		h = obj.height || (w / scale);
		var quality = 0.7;  
		// 默认图片质量为0.7  
		//生成canvas  
		var canvas = document.createElement('canvas');  
		var ctx = canvas.getContext('2d');  
		// 创建属性节点  
		var anw = document.createAttribute("width");  
		anw.nodeValue = w;  var anh = document.createAttribute("height");  
		anh.nodeValue = h;  canvas.setAttributeNode(anw);  canvas.setAttributeNode(anh);
		ctx.drawImage(that, 0, 0, w, h);  
		// 图像质量
		if(obj.quality && obj.quality <= 1 && obj.quality > 0){   
			quality = obj.quality;
		}
		// quality值越小，所绘制出的图像越模糊  
		var base64 = canvas.toDataURL('image/jpeg', quality );  
		// 回调函数返回base64的值  
		callback(base64); 
	}
};

//删除图片
$("body").on("click",".del-fill",function(){
	var fuji = $(this).parent(".img-fill")
	fuji.parent(".result").next(".img-item").show();
	fuji.remove();
})


//在校成长记录列表
function getList(){
	$.get('/imgcv/getList',function(data) {
		var data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log("噢耶",data)
		var html = ""
		var list = data.data
		if(data.data.length==0){
			$(".hint_p").show();
		}
		$.each(list, function(index,val) {
			html += '<li>\
						<i class="i-delete" cvId='+val.cvId+' style="background-image: url(../images/icon06.png);"></i>\
						<div class="info">\
							<div class="top">\
								<h3>'+val.school+'</h3>\
							</div>\
							<h4 class="grade">年级：<span>'+val.degree+'</span></h4>\
							<p>专业：<span>'+val.profession+'</span></p>\
							<p>班级：<span>'+val.className+'</span></p>\
						</div>\
						<div class="btn">\
							<a class="s-red" href="school-fill.html?cvId='+val.cvId+'">编辑</a>\
							<a class="s-blue" href="school-show.html?cvId='+val.cvId+'">预览</a>\
						</div>\
					</li>'
		})
		$(".school-record ul").append(html)
	})
}

$("body").on("click",".i-delete",function(){
	var cvId = $(this).attr("cvid")
	if(confirm("你确定提交吗？")){
	   	$.get('/imgcv/delCv',{cvId:cvId},function(data) {
			var data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
		})
	   	window.location.reload();
	}
})

function moreResumes(next){
	var fontUserId = GetQueryString('fontUserId')
	$.get('/offer/getByFontUserId', {fontUserId:fontUserId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data.data,"啊哈哈哈哈哈哈哈哈哈")
		var moreResumesData = data.data
		var moreResumesDataName = moreResumesData.name
		var html="";
		$.each(moreResumesData.list, function(index, val) {
			var money = ""
			,	href = "recruit-details.html"
			,	url = "<div class='portrait bg-center' style='background-image: url(../images/picture-loading02.jpg);'></div>"
			var modifyTime = val.modifyTime.substring(0,10)
			html += "<li>\
						<a href='"+href+"?offerId="+val.offerId+"' data-ajax='false' data-role='none'>\
							"+url+"\
							"+money+"\
							<div class='info'>\
								<div class='first-column'>\
									<span class='title'>"+val.positionName+"</span>\
									<span class='monthly-pay'>"+val.pay+"</span>\
								</div>\
								<div class='second-column'>\
									<span class='name'></span>\
								</div>\
								<div class='third-column'>\
									<span class='jobs'>"+val.onfferClassifyTitle+"</span>\
									<span class='welfare'>"+val.offerWelfareName+"</span>\
								</div>\
								<div class='bottom'>\
									<span class='city'>"+val.offerWelfareName+"</span>\
									<span class='date'>"+modifyTime+"</span>\
								</div>\
							</div>\
						</a>\
					</li>"
		});
		$('.recruit-list').find('ul').append(html);
		next();
	})
}
function moreResumesInfo(){
	var offerId = GetQueryString('offerId')
	$.get('/offer/getAllDetail', {offerId:offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data.data,"呜啦啦啦啦啦啦啦")
		$.each(data.data, function(index, val) {
			if(index == 'sizeTitle') {
				$('#sizeTitle').text("规模："+val+"人")
			}else if(index == 'naturelTitle') {
				$('#naturelTitle').text("性质："+val);
				if($('#naturelTitle').text()=="性质：null" || $('#naturelTitle').text()=="性质：undefined"){
					$('#naturelTitle').hide();
				}
			}else if(index == 'tradeTitle') {
				$('#tradeTitle').text("行业："+val);
				if($('#tradeTitle').text()=="行业：null" || $('#tradeTitle').text()=="性质：undefined"){
					$('#tradeTitle').hide();
				}
			}else {
				$("#"+index).text(val)
			}
		});
			var member = data.data.member
			if(member=="1"){
				$(".moreTitle span").hide();
			}else if(member=="2"){
				$(".moreTitle span").show();
			}
		var businessName = data.data.businessName
		$("body").find(".name").text(businessName)
	})
}
