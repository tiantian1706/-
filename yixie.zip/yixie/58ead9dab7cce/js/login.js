function checkAndGetData(fontUserType) {
	var div = $('div[fontUserType='+fontUserType+']')
	,	phone = div.find('input[name=phone]').val()
	,	password = div.find('input[name=password]').val()
	,	myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/
	,	error = 0;

	// if(!myreg.test(phone)) {
	// 	alert('请输入有效的手机号码')
	// 	error = 1
	// 	return error;
	// }
	if(!password) {
		alert('密码不能为空')
		error = 1
		return error;
	}

	if(error == 0) {
		return {
			phone: phone,
			password: password,
		}
	}else {
		return error;
	}
}

$(".submit").click(function() {
	var fontUserType = $(this).parents('.login-form').attr('fontUserType')
	,	result = checkAndGetData(fontUserType)

	$.post('/fontuser/login', {type: fontUserType, data: result}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(data.data == 1) {
			window.location.href = "job-seeker/index.html"
		}else if(data.data == 2) {
			window.location.href = "enterprise/index.html"
		}else if(data.data == 3) {
			window.location.href = "hr/job-list.html"
		}else if(data.data == 4) {
			window.location.href = "college/college-index.html"
		}
		
	});
});