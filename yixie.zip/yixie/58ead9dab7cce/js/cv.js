var cvObj = {}
,	allExperience = []
,	mod = -1
,	cvId = GetQueryString('cvId')
,	modCvId = 0
,	cvInfo = {}
,	allData = {}
,	wahtNum = 0
,	wahtNumOne = 0
,	wahtNumTwo = 1
,	wahtNumThree = 0
,	wahtNumFour = 0
,	wahtNumFive = 0;

$('.add-button').click(function() {
	$('.editor-box-popup').addClass('pop-show');
	
	$("#deleteSave").hide();
	
	$('body').addClass('disable-scrolling')
	$('html').addClass('disable-scrolling')
	$('.work-experience-editor').show()
	$('.job-intention-editor,.self-description-editor').hide()

	$('.work-experience-editor').find('input').val(null)
	$('.work-experience-editor').find('textarea').val(null)
	mod = -1
	initDate()
});

$('body').on('click', '.editor-button', function() {
	$('.editor-box-popup').addClass('pop-show')
	$('body').addClass('disable-scrolling')
	$('html').addClass('disable-scrolling')
});

$('body').on('click', '.yx-button1', function() {
	$('.editor-box-popup').removeClass('pop-show')
	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
});

$('body').on('click', '.wee-button', function() {

	var index = $(this).parents('li').index()
	,	obj = allExperience[index]

	$("#deleteSave").show();
	$("#secondSave").text("修改");

	console.log(cvId)

	if(cvId) {
		obj = JSON.parse(window.sessionStorage.getItem('cvInfo')).experience[index];
		
		console.log(obj)
		
		$('#exWorkName').val(obj.exWorkName)
		$('#startTime').val(obj.startTime)
		$('#endTime').val(obj.endTime)
		$('#exPosition').val(obj.exPosition)
		$('#exDescription').val(obj.exDescription)
	}

	mod = index
	secondApply(obj)

	$('.work-experience-editor').show()
	$('.job-intention-editor,.self-description-editor').hide()
})

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return '';
}

function initDate() {
	//初始化配置参数      
    $('#startTime').mobiscroll().date({
        theme: "mobiscroll",  
        lang: "zh",  
        cancelText: null,
        dateFormat: 'yy-mm', //返回结果格式化为年月格式 
    });
		
	var currYear = (new Date()).getFullYear();
	$("#endTime").mobiscroll().date({//这里是date，还有time，datetime不在本文范围。
	    theme: "mobiscroll",//样式，可根据操作系统不同设置不一样的样式
	    lang: "zh",
	    setText: '确定',
	    cancelText: "至今",
	    dateFormat: 'yyyy-mm',
	    onBeforeShow: function (inst) { },
	    onSelect: function (valueText, inst) {//选择时事件（点击确定后），valueText 为选择的时间，
	        var selectedDate = valueText;
	        console.log(valueText);
	    },
	    onCancel:function(){
	    	console.log("点击取消");
	    	$("#endTime").val("在职")
		},
		            
	});
}

function initDateFabu() {
	//初始化配置参数      
    $('#fabuTime').mobiscroll().date({
        theme: "mobiscroll",  
        lang: "zh",  
        cancelText: null,  
        dateFormat: 'yy-mm-dd', //返回结果格式化为年月格式 
		endYear: 3000,
    });
}

function getOfferClassify(next) {
	$.get('/offerclassify/getOfferClassify', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		data = data.data;
		console.log(data)
		var html = ""
		$.each(data, function(index, val) {
			var list = "";
			if(val._child) {
				$.each(val._child, function(i, v) {
					list += "<a data-ajax='false' data-role='none'><span offerClassifyId='"+v.offerClassifyId+"'>"+v.title+"</span></a>"
				});
			}
			html += "<div class='list-box'>\
						<div class='title'>\
							<span class='ico icon-collection1'></span>\
							<span class='text'>"+val.title+"</span>\
						</div>\
						<div class='list list-margin'>\
							"+list+"\
						</div>\
					</div>"
		});
		$('.re-job-list').append(html)
		
		var tickling = ""
		$.each(data, function(index, val) {
			var list = "";
			if(val._child) {
				$.each(val._child, function(i, v) {
					list += "<a data-ajax='false' data-role='none'><span offerClassifyId='"+v.offerClassifyId+"'>"+v.title+"</span></a>"
				});
			}
			html += "<div class='list-box'>\
						<div class='title'>\
							<span class='ico icon-collection1'></span>\
							<span class='text'>"+val.title+"</span>\
						</div>\
						<div class='list list-margin'>\
							"+list+"\
						</div>\
					</div>"
		});
		$('.re-job-list').append(tickling)
		
		next();
	});
}

//获取企业提供的所有职位
function getAllPosition(next) {
	$.get('/offer/getAllPosition', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#position').append("<option value='"+val.positionName+"'>"+val.positionName+"</option>")
		});
		next()
	});
}

function getMyCv(next) {
	$.get('/offercv/getMyCv', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		cvInfo = data.data;
		console.log(cvInfo);
		var html = ""
		,	radio = ""
		,	btn = ""

		if(typeof next == 'function') {
			radio = "<a class='radio'><span class='ico'></span></a>"
		}else {
			btn = "<div class='btn'>\
    				<a data-role='none' saveData='1' option='preview' data-ajax='false'><span class='ico icon-view'></span> <span class='text'>预览</span></a>\
    				<a data-role='none' name='top' data-ajax='false'><span class='ico icon-top'></span> <span class='text'>置顶</span></a>\
    				<a href='javascript:;' saveData='1' option='edit' data-role='none' data-ajax='false'><span class='ico icon-modify'></span> <span class='text'>编辑</span></a>\
    				<a data-role='none' data-ajax='false' class='more-btn'><span class='ico icon-more'></span> <span class='text'>更多</span></a>\
    			</div>"
		}
		
		$.each(cvInfo, function(index, val) {

			if(val.open == 1) {
				var open = '公开'
			}else {
				var open = '不公开'
			}

			if(val.recommend == 1) {
				var recommend = '同意被推荐'
			}else {
				var recommend = '不同意被推荐'
			}

			var wahtNum = 0;
			var percentage = "";
			if(val.wahtNum>0){
				if(val.threeD==0){
					if(val.wahtNum==1){
						wahtNum = 60
					}
					if(val.wahtNum==2){
						wahtNum = 80
					}
					if(val.wahtNum==3){
						wahtNum = 100
					}
				}else if(val.threeD==1){
					wahtNum = val.wahtNum*20
				}
				percentage = "<span style='display:none' class='percentage'>简历完成度："+wahtNum+"%</span>"	
			}
			html += "<div class='list' cvId='"+val.cvId+"' threeD='"+val.threeD+"'>\
		    			<div class='title'>\
		    				<span class='job'>"+val.position+"</span>\
							<span class='monthly-pay orange'>"+val.will+"</span>\
		    			</div>\
		    			<div class='prompt'>\
		    				<span class='browse-times' text='浏览次数：'>"+val.browse+"</span>\
							<span class='state' name='open'>"+open+"</span>\
							"+percentage+"\
							<span class='state' name='recommend'>"+recommend+"</span>\
		    			</div>\
		    			"+btn+"\
		    			"+radio+"\
		    		</div>"
		});
		
		if(typeof next == 'function' && cvInfo.length==0){
			html="<p style='text-align: center;line-height: 5rem;font-size: .6rem;color: #333;margin-bottom:5rem;'>您还没有创建简历</p>";
			$("#sureBtn").hide();
			$("#bottomBtn").show();
		}
		$('.rl-box').append(html)

		if(typeof next == 'function') {
			console.log("投递简历")
			next()
		}
	});
}

function hideEditor() {
	$('.editor-box-popup').removeClass('pop-show')
	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
}

function firstApply(object) {
	$("p[name=position]").text(object.position)
	$("p[name=address]").text(object.address)
	$("span[name=will]").text(object.will)
	$("span[name=workAge]").text(object.workAge+"/")
	$("span[name=offerClassifyName]").text($("span[offerClassifyId='"+object.offerClassifyId+"']").text()+"/")

	if(cvId) {
		$('#position').val(object.position)
		$('#city').val(object.address)
		$('#will').val(object.will)
		$('#workAge').val(object.workAge)
		$('#offerClassifyId').attr('offerClassifyId', object.offerClassifyId)
		$('#offerClassifyId').val($("span[offerClassifyId='"+object.offerClassifyId+"']").text())
	}
}

function secondApply(object) {
	var html =  "<li>\
					<div class='left'>\
						<div class='line'></div>\
						<div class='circular'></div>\
					</div>\
					<div class='info'>\
						<p class='min-text'><span>"+object.startTime+"</span> - <span>"+object.endTime+"</span></p>\
						<p class='name'>"+object.exWorkName+"</p>\
						<p><span class='job'>"+object.exPosition+"</span> <span class='job-description'>"+object.exDescription+"</span></p>\
					</div>\
					<a class='editor-button main-tone wee-button'><span class='ico icon-modify'></span>编辑</a>\
				</li>"

	if(mod == -1) {
		$('#jobWork ul').append(html)
	}else {
		$('#jobWork ul').find('li').eq(mod).replaceWith(html)
	}
}

function thirdApply(object) {
	$("p[name=description]").text(object.description)

	if(cvId) {
		$('#description').val(object.description)
	}
}

//第一部分编辑框
$('a[name=firstSave]').click(function() {
	var position = $('#position').val()
	,	address = $('#city').val()
	,	will = $('#will').val()
	,	offerClassifyId = $('#offerClassifyId').attr('offerClassifyId')
	,	workAge = $('#workAge').val()

	cvObj.position = position
	cvObj.address = address
	cvObj.will = will
	cvObj.offerClassifyId = offerClassifyId
	cvObj.workAge = workAge



	if($('#offerClassifyId').val().length == 0 || position.length == 0 || address.length == 0 || will.length == 0 || workAge.length == 0){
		alert("请完善简历！");
		return false;
	}else{
		hideEditor()
	}
	
	firstApply(cvObj)
	
	var work = $("#work").html()
	if(work == "18/" || work == "18"){
		$("#work").html("应届毕业生/")
	}
});

//第二部分编辑
$('a[name=secondSave]').click(function() {
	var exWorkName = $('#exWorkName').val()
	,	startTime = $('#startTime').val()
	,	endTime = $('#endTime').val()
	,	exPosition = $('#exPosition').val()
	,	exDescription = $('#exDescription').val()
	,	experience = {}

	experience.exWorkName = exWorkName
	experience.startTime = startTime
	experience.endTime = endTime
	experience.exPosition = exPosition
	experience.exDescription = exDescription

	if(mod == -1) {
		allExperience.push(experience)
	}else {
		allExperience[mod] = experience
	}

	if(exWorkName.length == 0 || startTime.length == 0 || endTime.length == 0 || exPosition.length == 0 || exDescription.length == 0){
		alert("请完善工作经验！")
		return false;
	}else{
		secondApply(experience)
		hideEditor()
	}	
});

//第二部分删除键
$('a[name=deleteSave]').click(function() {
	hideEditor()
	$('ul').find('li').eq(mod).remove()
});

//第三部分编辑框
$('a[name=thirdSave]').click(function() {
	var description = $('#description').val()

	cvObj.description = description

	hideEditor()

	thirdApply(cvObj)
});

function getAllExperience() {
	var list = $('#jobWork').find('ul').find('li')
	,	experienceObj = []
	$.each(list, function(index, val) {
		var e = {}

		var startTime = $(this).find('.info').find('p').eq(0).find('span').eq(0).text()
		,	endTime = $(this).find('.info').find('p').eq(0).find('span').eq(1).text()
		,	exWorkName = $(this).find('.info').find('p').eq(1).text()
		,	exPosition = $(this).find('.info').find('p').eq(2).find('span').eq(0).text()
		,	exDescription = $(this).find('.info').find('p').eq(2).find('span').eq(1).text()

		e.startTime = startTime;
		e.endTime = endTime;
		e.exWorkName = exWorkName;
		e.exPosition = exPosition;
		e.exDescription = exDescription;
		experienceObj.push(e)
	});

	return experienceObj
}

$('#save').click(function() {
	allExperience = getAllExperience()
	cvObj.experience = allExperience
	
	console.log(cvObj)
	
	if(!allExperience.length) cvObj.experience = '';	
	var have = $("body").find("#personal").length;
	var vcrBox = ""
	var threeD = "0"
	if(have == 1){
		var haveSon = $("body").find("#must").length;
		vcrBox = $("#vcrBox").val();
		threeD = "1";

//		cvObj.schoolImg     = allData.schoolImg;
		var oneLength = $("#must ul li").eq(0).find(".imgBox img").length
		var twoLength = $("#must ul li").eq(1).find(".imgBox img").length
		var threeLength = $("#must ul li").eq(2).find(".imgBox img").length
		var fourLength = $("#must ul li").eq(3).find(".imgBox img").length
		var oneImg = [];
		var twoImg = [];
		var threeImg = [];
		var fourImg = [];
		for (var i=0;i<oneLength;i++) {
			oneImg.push($("#must ul li").eq(0).find(".imgBox img").eq(i).attr("src"))
		}
		for (var i=0;i<twoLength;i++) {
			twoImg.push($("#must ul li").eq(1).find(".imgBox img").eq(i).attr("src"))
		}
		for (var i=0;i<threeLength;i++) {
			threeImg.push($("#must ul li").eq(2).find(".imgBox img").eq(i).attr("src"))
		}
		for (var i=0;i<fourLength;i++) {
			fourImg.push($("#must ul li").eq(3).find(".imgBox img").eq(i).attr("src"))
		}
		cvObj.schoolImg     = oneImg;
		cvObj.societyImg    = twoImg;
		cvObj.worksImg      = threeImg;
		cvObj.prizeImg      = fourImg;
		cvObj.schoolRemark  = allData.schoolRemark;
		cvObj.societyRemark = allData.societyRemark;
		cvObj.worksRemark   = allData.worksRemark;
		cvObj.prizeRemark   = allData.prizeRemark;
//		if (vcrBox.length == 0) {
//			alert("请填写个人VCR视频网址");
//			return false;
//		}
//		if (haveSon == 0) {
//			alert("请填写个人经历");
//			return false;
//		}

//		3D简历判断
		if (vcrBox.length > 0) {
			wahtNumOne = 1
		}

		if (cvObj.schoolRemark != "") {
			wahtNumThree = 1
		}
	}

	if(cvObj.experience.length>0){
		wahtNumFour = 1
	}
	if("description" in cvObj){
		wahtNumFive = 1
	}
	
	cvObj.urlLink = vcrBox
	cvObj.threeD = threeD

	wahtNum = wahtNumOne+wahtNumTwo+wahtNumThree+wahtNumFour+wahtNumFive

	console.log("保存数据",wahtNum)	
	if(cvId) {
		console.log("完成度",wahtNum)
		$.post('/offercv/modCv', {cvId: cvId, data: cvObj,wahtNum:wahtNum}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			window.location.href = "resume-list.html"
		});
	}else {
		console.log("完成度",wahtNum)
		$.post('/offercv/addCv', {data: cvObj,wahtNum:wahtNum}, function(data) {
			data = JSON.parse(data)
			console.log(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			window.location.href = "resume-list.html"
		});
	}
});

//简历列表更多按钮
$('body').on('click', '.more-btn', function(){
	modCvId = $(this).parents('.list').attr('cvId')
	$('.more').css('bottom','0')
	$('.popupBg').show()
})
$('body').on('click', '.operation a', function() {
	var filed = $(this).attr('filed')
	,	data = $(this).attr('data')
	,	text = $(this).text()
	,	list = $(".list[cvId='"+modCvId+"']");

	if(!modCvId) {
		alert('请选择操作的简历')
		return false;
	}

	if(filed == 'delete') {
		if(window.confirm('你确定删除该简历吗？')) {
			$.get('/offercv/operationCv', {filed: filed, data: data, cvId: modCvId}, function(data) {
				data = JSON.parse(data)
				if(data.code != 0) {
					alert(data.msg)
					return false;
				}
				console.log(list)
				$('.more').css('bottom','-100%')
				$('.popupBg').hide()
				list.remove()
			});
		}
	}else {
		$.get('/offercv/operationCv', {filed: filed, data: data, cvId: modCvId}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			console.log(list)
			$('.more').css('bottom','-100%')
			$('.popupBg').hide()
			list.find("span[name='"+filed+"']").text(text)
		});
	}


});
$('body').on('click', '.more .close', function(){
	$('.more').css('bottom','-100%')
	$('.popupBg').hide()
})

$('body').on('click', '.btn a[saveData=1]', function() {
	var option = $(this).attr('option')
	,	cvId = $(this).parents('.list').attr('cvId')
	,	threeD = $(this).parents('.list').attr('threeD')
	,	index = $(this).parents('.list').index() - 1
	,	sessionCv = cvInfo[index]

	window.sessionStorage.setItem('cvInfo', JSON.stringify(sessionCv))
	
	console.log(cvInfo)
	if(option == 'edit') {
		if(threeD == "1"){
			var href = "resume-editor-three.html?cvId="+cvId
			
		}else{
			var href = "resume-editor.html?cvId="+cvId
		}
	}else {
		var href = "resume-preview.html?cvId"+cvId
	}
	window.location.href = href;
});

//简历置顶
function topCv(cvId) {
	$.get('/offercv/topCv', {cvId: cvId}, function(data) {
	});
}

function preview(userType) {
	var cvInfo = JSON.parse(window.sessionStorage.getItem('cvInfo'))
	,	detailInfo = JSON.parse(window.sessionStorage.getItem('detail'))
	
	console.log(cvInfo.sex,cvInfo)

	if(!cvInfo) {
		alert('请选择简历进行预览')
		return false;
	}

	$.each(cvInfo, function(index, val) {
		if(index == 'experience') {
			var html = ""
			console.log(val)
			if(val){
				$.each(val, function(i, v) {
					html += "<li>\
	    						<div class='left'>\
	    							<div class='line'></div>\
	    							<div class='circular'></div>\
	    						</div>\
	    						<div class='info'>\
	    							<p class='min-text'><span>"+v.startTime+"</span> - <span>"+v.endTime+"</span></p>\
	    							<p class='name'>"+v.exWorkName+"</p>\
	    							<p><span class='job'>"+v.exPosition+"</span> <span class='job-description'>"+v.exDescription+"</span></p>\
	    						</div>\
	    					</li>"
				});
				$('ul').append(html)
			}
		}else if(index == 'sex') {
			if(val == 1 || val == "男") {
				$('#sex').text('男')
				$('.portrait').css({backgroundImage:'url(../images/portrait.png)'})
			}else if(val == 2 || val == "女"){
				$('#sex').text('女')
				$('.portrait').css({backgroundImage:'url(../images/portrait02.png)'})
			}
		}else {
			$("#"+index).text(val)
		}
	});
	
	if(!userType) {
		$.each(detailInfo, function(index, val) {
			if(index == 'sex') {
				if(val == 1 || val == "男") {
					$('#sex').text('男')
					$('.portrait').css({backgroundImage:'url(../images/portrait.png)'})
				}else if(val == 2 || val == "女"){
					$('#sex').text('女')
					$('.portrait').css({backgroundImage:'url(../images/portrait02.png)'})
				}
			}else {
				$("#"+index).text(val)
			}
		});
	}
	
	resume(cvInfo);
	
}

function resume(cvInfo){
	if(cvInfo.threeD=="1"){
		console.log("3d简历");
		$('.resume-collection').hide();
		
//		$("#threeVideo video").attr("src",cvInfo.urlLink);
		
		console.log("threeVideo",cvInfo.urlLink)
		
		
		var videoHtml = cvInfo.urlLink
		$("#threeVideo").append(cvInfo.urlLink)
		
		$("#threeVideo").show();
		
		
		var schoolImg = cvInfo.schoolImg
		var societyImg = cvInfo.societyImg
		var worksImg = cvInfo.worksImg
		var prizeImg = cvInfo.prizeImg
		function tongyong(data,num){
			var arr = [];
			var dataDohao = (data.split(',')).length-1;
			var imgHtml = "";
			if(dataDohao == 0 && data.length>0){
				imgHtml = '<img src="'+data+'"/>'
			}
			if(dataDohao >= 1){
				var one=data.split(",")
				arr.push(one);
				for(var i=0;i<arr[0].length;i++){
					imgHtml += '<img src="'+arr[0][i]+'"/>'
				};
			}
			$("#personal .personalUl .li").eq(num).find(".imgBox").append(imgHtml);
		}
		var dianhtml = '<div class="li">\
						<h3>在校活动</h3>\
						<pre>'+cvInfo.schoolRemark+'</pre>\
						<div class="imgBox"></div>\
					</div>\
					<div class="li">\
						<h3>社会活动</h3>\
						<pre>'+cvInfo.societyRemark+'</pre>\
						<div class="imgBox"></div>\
					</div>\
					<div class="li">\
						<h3>作品展示</h3>\
						<pre>'+cvInfo.worksRemark+'</pre>\
						<div class="imgBox"></div>\
					</div>\
					<div class="li">\
						<h3>获奖情况</h3>\
						<pre>'+cvInfo.prizeRemark+'</pre>\
						<div class="imgBox"></div>\
					</div>';
		$("#personal .personalUl").append(dianhtml);
		tongyong(schoolImg,0);
		tongyong(societyImg,1);
		tongyong(worksImg,2);
		tongyong(prizeImg,3);
		$("#personal").show();
	}

}

function getCvCopy(cvCopyId) {
	$.get('/offercvcopy/getCvCopy', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		previewCv = data.data
		console.log(previewCv);
		//			3D简历渲染
			resume(previewCv);
		
		$.each(previewCv, function(index, val) {
			if(index == 'experience') {
				var html = ""
				if(val){
					$.each(val, function(i, v) {
						html += "<li>\
		    						<div class='left'>\
		    							<div class='line'></div>\
		    							<div class='circular'></div>\
		    						</div>\
		    						<div class='info'>\
		    							<p class='min-text'><span>"+v.startTime+"</span> - <span>"+v.endTime+"</span></p>\
		    							<p class='name'>"+v.exWorkName+"</p>\
		    							<p><span class='job'>"+v.exPosition+"</span> <span class='job-description'>"+v.exDescription+"</span></p>\
		    						</div>\
		    					</li>"
					});
				}
				$('#jobWork ul').append(html)
			}else if(index == 'sex') {
				if(val == 1 || val == "男") {
					$('#sex').text('男')
					$('.portrait').css({backgroundImage:'url(../images/portrait.png)'})
				}else if(val == 2 || val == "女"){
					$('#sex').text('女')
					$('.portrait').css({backgroundImage:'url(../images/portrait02.png)'})
				}
			}else if(index == 'pay') {
				if(val == 2) {
					var  html = "<div class='rp-box'>\
						    		<div class='title'><i></i><span>联系方式</span><i></i></div>\
						    		<span class='info-text' text='联系电话：' id='contact'>"+data.data.contact+"</span>\
						    		<span class='info-text' text='联系邮箱：' id='email'>"+data.data.email+"</span>\
						    	</div> "
					$('.rp-box:last').after(html)
					// $('.ci-button').hide();
					$('.ci-button').remove();
				}
			}else {
				$("#"+index).text(val)
			}
		});
	});
}

function payInfo(cvCopyId) {
	$.get('/offercvcopy/payInfo', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			window.location.href = 'view-resume.html'
			return false;
		}
		data = data.data
		$('#needPay').val(data.needPay)
		$('#balance').text(data.balance)
		$('#payNum').text(data.payNum)
	});
}

//查看原本简历
function searchOriContact(contact, email) {
	$.get('/offercvcopy/searchOriContact', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var	html = "<div class='rp-box'>\
			    		<div class='title'><i></i><span>联系方式</span><i></i></div>\
			    		<span class='info-text' text='联系电话：' id='contact'>"+contact+"</span>\
			    		<span class='info-text' text='联系邮箱：' id='email'>"+email+"</span>\
			    	</div> "
		$('.rp-box:last').after(html)
	})
}

//查看副本简历
function searchContact(cvCopyId, jump) {
	$.get('/offercvcopy/searchContact', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			if(data.code == 999) {
				window.location.href = 'recharge.html'
			}
			return false;
		}
		var email = data.data.email
		,	contact = data.data.contact
		,	html = "<div class='rp-box'>\
			    		<div class='title'>联系电话</div>\
			    		<span class='info-text' text='联系电话：' id='contact'>"+contact+"</span>\
			    		<span class='info-text' text='联系邮箱：' id='email'>"+email+"</span>\
			    	</div> "
		$('.rp-box:last').after(html)

		if(jump == 1) {
			window.location.href = "e-resume-preview.html?cvCopyId="+cvCopyId
		}
	});
}

function commentCondition(cvCopyId) {
	if(!cvCopyId) {
		alert('请选择评论的简历')
		return false;
	}
	$.get('/offercvcopy/commentCondition', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#'+index).text(val)
		});
		var url = data.data.headImgUrl
		if(url.length==0){
			$('.portrait').css({'backgroundImage':'url(../images/picture-loading02.jpg)'});	
		}else{
			$('.portrait').css({'backgroundImage':'url('+url+')'});	
		}
	});
}

//收藏简历
function collectCv(cvId) {
	$.get('/offercvcopy/collectCv', {cvId: cvId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('已经收藏到关联的hr帐号中')
	});
}

function threeDInit(){
	function init(){
		$("#addThree").click(function(){
			$(".school-fil").slideDown();
		})
		$("#allDelete").click(function(){
			$(".school-fil").slideUp();
		})
		$("body").on("click","#musA",function(){
			$(".school-fil").slideDown();
		})
	}
	function up(){
		$(".editor-box-three").each(function(){
			var index = $(this).index();
			$(this).find("a").click(function(){
				var item = $(".item").eq(index)
				item.addClass("item-show");
				item.attr("index",index);
			})
		})
	}
	function fillRun(){
		init();
		up();

		$(".delete").click(function(){
			$(this).parents(".item").removeClass("item-show")
		})
		
		//后四个保存数据
		$(".save").click(function(){
			var text = $(this).parents(".button").siblings("h3").text()
			var val = $(this).parents(".button").siblings("textarea").val()
			console.log(val);
			if(val == ""){
				alert("请填写"+text+"的内容！")
				return false;
			}else{
				var item = $(this).parents(".item")
				var index = item.attr("index")
				var allImg = item.find(".img-fill")
				var length = allImg.length
				var url = [];
				var content = $(".editor-box-three").eq(index).find(".content")
				var contentBox = content.find(".content-box");
				contentBox.remove();
				for (var i=0;i<length;i++) {
					var src = allImg.eq(i).find("img").attr("src")
					url.push(src)
				}
				console.log("那些图片路径",url)
				$.post('/imgcv/uploadImg',{data:url}, function(data) {
					var data = JSON.parse(data)
					if(data.code != 0) {
						alert(data.msg)
						return false;
					}
					console.log("返回的东西",data.data)
					if(index==1){
						allData['schoolRemark']=val
						allData['schoolImg']=data.data;
						var srcAll = data.data
					}
					if(index==2){
						allData['societyRemark']=val
						allData['societyImg']=data.data
						var srcAll = data.data
					}
					if(index==3){
						allData['worksRemark']=val
						allData['worksImg']=data.data
						var srcAll = data.data
					}
					if(index==4){
						allData['prizeRemark']=val
						allData['prizeImg']=data.data
						var srcAll = data.data
					}
					if(length){
						var img = ""
						for (var i=0;i<length;i++) {
							img += '<img src="'+srcAll[i]+'"/>'
						}
						var image = '<div class="img">\
										'+img+'\
									</div>'
					}else{
						var image = ''
					}
					
					var html = '<div class="content-box">\
						<pre>'+val+'</pre>\
						'+image+'\
	    				<a class="main-tone jie-button"><span class="ico icon-modify"></span>编辑</a>\
					</div>'
					
					content.append(html);
					content.find(".add-button-three").remove();
					item.removeClass("item-show");
					up();
				})
			}
		})

		var cvId = GetQueryString("cvId");
		console.log(cvId)
		
		function guanbi(data){
			var panduanOne = [];
			var panduanTwo= [];
			$(".school-fil .editor-box-three").each(function(){
				var index = $(this).index();
				var have = $(this).find(".content-box").length;
				panduanOne.push(have);
				console.log(panduanOne);
				if(have == 0 && index >=1){
					var text = $(".editor-box-three").eq(index).find(".title span").eq(0).text();
					alert("请填写"+text);
					return false;
				}
			})
			for (var i=1;i<panduanOne.length;i++) {
				panduanTwo.push(panduanOne[i]);
			}
			console.log("panduanTwo",panduanTwo);
			if($.inArray(0,panduanTwo)==-1){
				$(".addThree").find(".content").remove();
				console.log("执行到这里了吗?")
				personal(data);
				$(".school-fil").slideUp();		
			}
		}
		
		if(cvId==''){
			$("#allBtn").click(function(){
				var length = $("body").find(".item-box").length;
				console.log("新的所有数据",allData);
				guanbi(allData);
			})
		}else{
			$("#allBtn").click(function(){
				var newData = {};
				var length = $("body").find(".item-box").length;
				newData
				var boxOne = $(".editor-box-three").eq(1)
				var boxTwo = $(".editor-box-three").eq(2)
				var boxThree = $(".editor-box-three").eq(3)
				var boxFour = $(".editor-box-three").eq(4)
				newData['school'] = $("#school").text();
				newData['degree'] = $("#degree").text();
				newData['profession'] = $("#profession").text();
				newData['className'] = $("#className").text();
				newData['schoolRemark']=boxOne.find("pre").text();
				newData['societyRemark']=boxTwo.find("pre").text();
				newData['worksRemark']=boxThree.find("pre").text();
				newData['prizeRemark']=boxFour.find("pre").text();
				var urlOne = [];
				var urlTwo = [];
				var urlThree = [];
				var urlFour = [];
				var imgOne = boxOne.find(".img img")
				var imgTwo = boxTwo.find(".img img")
				var imgThree = boxThree.find(".img img")
				var imgFour = boxFour.find(".img img")
				var lengthOne = imgOne.length
				var lengthTwo = imgTwo.length
				var lengthThree = imgThree.length
				var lengthFour = imgFour.length
				for(var i=0;i<lengthOne;i++){
					urlOne.push(imgOne.eq(i).attr("src"))
				}
				for(var i=0;i<lengthTwo;i++){
					urlTwo.push(imgTwo.eq(i).attr("src"))
				}
				for(var i=0;i<lengthThree;i++){
					urlThree.push(imgThree.eq(i).attr("src"))
				}
				for(var i=0;i<lengthFour;i++){
					urlFour.push(imgFour.eq(i).attr("src"))
				}
				newData['schoolImg']=urlOne;
				newData['societyImg']=urlTwo;
				newData['worksImg']=urlThree;
				newData['prizeImg']=urlFour;
				
				console.log("diyige",newData);
//					return false;

				console.log("新数据",newData);
				allData = newData
				guanbi(allData);
			})
			$.get('/offercv/getMyCv',function(data) {
				var data = JSON.parse(data)
				if(data.code != 0) {
					alert(data.msg)
					return false;
				};
				console.log("hahaha",data);
				var getMyCvDataAll = data.data;
				$.each(getMyCvDataAll, function(index, val) {
					if(val.cvId == cvId){
						var getData = val
						if(getData.schoolRemark==""){
							console.log("没填写个人经历");
						}else{
							$(".addThree .content").eq(0).remove();
							var boxTwo = $(".editor-box-three").eq(1)
							var boxThree = $(".editor-box-three").eq(2)
							var boxFour = $(".editor-box-three").eq(3)
							var boxFive = $(".editor-box-three").eq(4)
							$.each(getData, function(index, val) {
								$('#'+index).text(val)
							});
							$("#vcrBox").val(val.urlLink);
							function ifLength(remark,data,boxWho,sum){
								var item = $(".item").eq(sum)
								var arr = [];
								var dataDohao = (data.split(',')).length-1;
								var imgHtml = "";
								var imgTwo = "";
								
								if(dataDohao == 0 && data.length>0){
									imgHtml = '<img src="'+data+'"/>';
									arr.push(data)
								}
								if(dataDohao >= 1){
									var one=data.split(",")
									arr.push(one);
									arr = arr[0];
									for(var i=0;i<arr.length;i++){
										imgHtml += '<img src="'+arr[i]+'"/>'
									};
	
								}
								var length = arr.length;
								var html = '<div class="content-box">\
												<pre>'+remark+'</pre>\
												<div class="img">\
													'+imgHtml+'\
												</div>\
							    				<a class="main-tone jie-button"><span class="ico icon-modify"></span>编辑</a>\
											</div>'
								for(var i=0;i<length;i++){
									imgTwo += '<div class="img-fill">\
				        						<img src="'+arr[i]+'">\
				        						<i class="del-fill"></i>\
			        						</div>'
								}
								console.log("什么情况",length,imgTwo);
								if(length==3){
									item.find(".img-item").hide();
								}
	
								boxWho.find(".content").append(html);
								item.find(".result").append(imgTwo)
								boxWho.find(".add-button-three").remove();
								up();
							}
							
							ifLength(getData.schoolRemark,getData.schoolImg,boxTwo,1);
							ifLength(getData.societyRemark,getData.societyImg,boxThree,2);
							ifLength(getData.worksRemark,getData.worksImg,boxFour,3);
							ifLength(getData.prizeRemark,getData.prizeImg,boxFive,4);
							
							console.log("执行到这里了吗?")
							personal(getData)
						}
					}
				})
			});
		}
	};
	
	//渲染个人经历
	function personal(allData){
		var imgBoxOne = "";
		var imgBoxTwo = "";
		var imgBoxThree = "";
		var imgBoxFour = "";
		function isArray(obj){ 
			return (typeof obj=='object')&&obj.constructor==Array; 
		} 
		console.log("替换",allData);
		if(isArray(allData.schoolImg)){
			console.log("数组");
			for (var i = 0;i<allData.schoolImg.length;i++) {
				imgBoxOne += '<img src="'+allData.schoolImg[i]+'"/>'
			}
			for (var i = 0;i<allData.societyImg.length;i++) {
				imgBoxTwo += '<img src="'+allData.societyImg[i]+'"/>'
			}
			for (var i = 0;i<allData.worksImg.length;i++) {
				imgBoxThree += '<img src="'+allData.worksImg[i]+'"/>'
			}
			for (var i = 0;i<allData.prizeImg.length;i++) {
				imgBoxFour += '<img src="'+allData.prizeImg[i]+'"/>'
			}
		}else{
			console.log("字符串");
			var arrOne = [];
			var arrTwo = [];
			var arrThree = [];
			var arrFour = [];
			var dataDohaoOne = (allData.schoolImg.split(',')).length-1;
			var dataDohaoTwo = (allData.societyImg.split(',')).length-1;
			var dataDohaoThree = (allData.worksImg.split(',')).length-1;
			var dataDohaoFour = (allData.prizeImg.split(',')).length-1;
			//在校活动
			if(dataDohaoOne == 0 && allData.schoolImg.length>0){
				imgBoxOne = '<img src="'+allData.schoolImg+'"/>';
				arrOne.push(allData.schoolImg)
			}
			if(dataDohaoOne >= 1){
				var one=allData.schoolImg.split(",")
				arrOne.push(one);
				arrOne = arrOne[0];
				for(var i=0;i<arrOne.length;i++){
					imgBoxOne += '<img src="'+arrOne[i]+'"/>'
				};
			}
			//社会活动
			if(dataDohaoTwo == 0 && allData.societyImg.length>0){
				imgBoxTwo = '<img src="'+allData.societyImg+'"/>';
				arrTwo.push(allData.schoolImg)
			}
			if(dataDohaoTwo >= 1){
				var one=allData.societyImg.split(",")
				arrTwo.push(one);
				arrTwo = arrTwo[0];
				for(var i=0;i<arrTwo.length;i++){
					imgBoxTwo += '<img src="'+arrTwo[i]+'"/>'
				};
			}
			//作品展示
			if(dataDohaoThree == 0 && allData.worksImg.length>0){
				imgBoxThree = '<img src="'+allData.worksImg+'"/>';
				arrThree.push(allData.worksImg)
			}
			if(dataDohaoThree >= 1){
				var one=allData.worksImg.split(",")
				arrThree.push(one);
				arrThree = arrThree[0];
				for(var i=0;i<arrThree.length;i++){
					imgBoxThree += '<img src="'+arrThree[i]+'"/>'
				};
			}
			//获奖情况
			if(dataDohaoFour == 0 && allData.prizeImg.length>0){
				imgBoxFour = '<img src="'+allData.prizeImg+'"/>';
				arrFour.push(allData.prizeImg)
			}
			if(dataDohaoFour >= 1){
				var one=allData.prizeImg.split(",")
				arrFour.push(one);
				arrFour = arrFour[0];
				for(var i=0;i<arrFour.length;i++){
					imgBoxFour += '<img src="'+arrFour[i]+'"/>'
				};
			}
		}
		
		var html = '<div class="content">\
						<div class="three-jianli" id="must">\
					    	<a class="editor-button-three"  id="musA"><span class="ico icon-modify"></span>编辑</a>\
					    	<ul>\
					    		<li style="padding-bottom:0;">\
					    			<div class="left">\
					    				<div class="line"></div>\
					    				<div class="circular"></div>\
					    			</div>\
					    			<div class="info">\
					    				<span class="name" style="font-size:.38rem;">在校活动</span>\
					    				<pre>'+allData.schoolRemark+'</p>\
					    				<div class="imgBox">'+imgBoxOne+'</div>\
					    			</div>\
					    		</li>\
					    		<li style="padding-bottom:0;">\
					    			<div class="left">\
					    				<div class="line"></div>\
					    				<div class="circular"></div>\
					    			</div>\
					    			<div class="info">\
					    				<span class="name" style="font-size:.38rem;">社会活动</span>\
					    				<pre>'+allData.societyRemark+'</p>\
					    				<div class="imgBox">'+imgBoxTwo+'</div>\
					    			</div>\
					    		</li>\
					    		<li style="padding-bottom:0;">\
					    			<div class="left">\
					    				<div class="line"></div>\
					    				<div class="circular"></div>\
					    			</div>\
					    			<div class="info">\
					    				<span class="name" style="font-size:.38rem;">作品展示</span>\
					    				<pre>'+allData.worksRemark+'</p>\
					    				<div class="imgBox">'+imgBoxThree+'</div>\
					    			</div>\
					    		</li>\
					    		<li style="padding-bottom:0;">\
					    			<div class="left">\
					    				<div class="line"></div>\
					    				<div class="circular"></div>\
					    			</div>\
					    			<div class="info">\
					    				<span class="name" style="font-size:.38rem;">获奖情况</span>\
					    				<pre>'+allData.prizeRemark+'</p>\
					    				<div class="imgBox">'+imgBoxFour+'</div>\
					    			</div>\
					    		</li>\
					    	</ul>\
					    </div>\
					</div>'
		$(".addThree").append(html);
	}
	fillRun();
}
