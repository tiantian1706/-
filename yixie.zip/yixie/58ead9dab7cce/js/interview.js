var cvId = GetQueryString('cvId')

function getInterviewRemark(next) {
	$.get('/offerinterviewremark/getAll', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('.rr-box').append("<a>"+val.title+"</a>")
		});
		next();
	});
}

function sendInterview() {
	var cvCopyId = GetQueryString('cvId')
	,	name = $('#name').val()
	,	phone = $('#phone').val()
	,	address = $('#address').val()
	,	interviewTime = $('#interviewTime').val()
	,	remark = []
	,	remarkCurrent = $('.current')
	,	dataObj = {}

	if(!name) {
		alert('联系人不能为空')
		return false;
	}
	if(!phone) {
		alert('联系方式不能为空')
		return false;
	}

	if(!address) {
		alert('面试地址不能为空')
		return false;
	}

	if(!interviewTime) {
		alert('面试时间不能为空')
		return false;
	}

	if(remarkCurrent.length > 0 ) {
		$.each(remarkCurrent, function(index, val) {
			remark.push($(this).text())
		});
	}

	dataObj.name = name;
	dataObj.phone = phone;
	dataObj.interviewTime = interviewTime;
	dataObj.address = address;
	dataObj.remark = remark;

	console.log(dataObj)
	
	var detailInfo = JSON.parse(window.sessionStorage.getItem('detail'));
	var previewCv = JSON.parse(window.sessionStorage.getItem('cvInfo'))
	var companyName = detailInfo.businessName;
	var userId = previewCv.userId;
	var name = previewCv.name;
	var phone = previewCv.contact;
	
	function faduanxing(){
		$.get('/fontuser/sendInterview', {userId:userId, name:name, companyName:companyName, phone:phone,}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
		});	
	}
	$.post('/offerinterview/sendInterview', {cvCopyId: cvCopyId, data: dataObj}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		faduanxing();
		alert('发送邀请成功');
		window.location.href = "view-resume.html"
	});
}

//我的申请记录
function myApplicationRecord() {
	$.get('/offercvcopy/myApplicationRecord', {}, function(data) {
		data = JSON.parse(data)
		console.log(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			if(val.look == 1) {
				//未查看
				applyAppliciotnRecord($('#ar-not-view').find('ul'), val)
			}else {
				if(val.interview == 2) {
					data['data'][index]['publishDate'] = val.interviewDate
					applyAppliciotnRecord($('#ar-invite-interview').find('ul'), val)
				}else if(val.interview == 4) {
					applyAppliciotnRecord($('#ar-inappropriate').find('ul'), val)
				}else {
					applyAppliciotnRecord($('#ar-already-view').find('ul'), val)
				}
			}
			applyAppliciotnRecord($('#ar-all').find('ul'), val)
		});
		$('.ar-inside .len').text(data.data.length)
	});
}

function applyAppliciotnRecord(jqueryObj, object) {
	console.log("111")
	console.log(object)
	var look = ""
	,	interview = ""
	if(object.look == 1) {
		look = "<span class='text'>未查看</span>"
	}else {
		if(object.interview == 2) {
			var name = encodeURI(encodeURI(object.name))
			look = "<span class='text'>邀面试</span>"
			interview = "<a href='interview-invitation.html?cvId="+object.cvCopyId+"&name="+name+"' data-role='none' data-ajax='false' class='vi-button'>查看邀请</a>"
		}else if(object.interview == 3) {
			var name = encodeURI(encodeURI(object.name))
			look = "<span class='text'>接受面试</span>"
			interview = "<a href='interview-invitation.html?cvId="+object.cvCopyId+"&name="+name+"' data-role='none' data-ajax='false' class='vi-button'>查看邀请</a>"
		}else if(object.interview == 4) {
			look = "<span class='text'>不合适</span>"
		}else {
			look = "<span class='text'>已查看</span>"
		}
	}
	$(".more .text").each(function(){
		if($(this).text()=="接受面试"){
			$(this).next(".vi-button").text("已查看")
		}
	})
	var html = "<li>\
					<a data-ajax='false' data-role='none'>\
						<div class='portrait bg-center' style='background-image: url(../images/picture-loading02.jpg);'></div>\
						<div class='info'>\
							<div class='first-column'>\
								<span class='title'>"+object.positionName+"</span>\
								<span class='monthly-pay'>"+object.pay+"</span>\
							</div>\
							<div class='second-column'>\
								<span class='name'>"+object.businessName+"</span>\
							</div>\
							<div class='third-column'>\
								<span class='jobs'>"+object.position+"</span>\
								<span class='welfare'>"+object.offerWelfareName+"</span>\
							</div>\
							<span class='date'>"+object.publishDate+"</span>\
						</div>\
					</a>\
					<div class='more'>\
						"+look+"\
						"+interview+"\
					</div>\
				</li>"

	jqueryObj.append(html)
}


//我的申请记录New
function myApplicationRecordNew() {
	$.get('/offercvcopy/myApplicationRecord', {}, function(data) {
		data = JSON.parse(data)
		console.log(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			if(val.look == 1) {
				//未查看
				look = "<span class='text'>企业未查看</span>"
				applyAppliciotnRecordNew($('#ar-not-view').find('ul'), val);
			}else {
				applyAppliciotnRecordNew($('#ar-already-view').find('ul'), val);
				if(val.interview == 2 || val.interview == 3) {
					data['data'][index]['publishDate'] = val.interviewDate
					applyAppliciotnRecordNew($('#ar-invite-interview').find('ul'), val)
				}
			}
			applyAppliciotnRecordNew($('#ar-all').find('ul'), val)
		});
		$('.ar-inside .len').text(data.data.length)
	});
}

function applyAppliciotnRecordNew(jqueryObj, object) {
	var look = ""
	,	interview = ""
	,	href = ""
	if(object.look == 1) {
		look = "<span class='text'>企业未查看</span>"
	}else {
		if(object.interview == 2) {
			var name = encodeURI(encodeURI(object.name))
//			look = "<span class='text'>邀面试</span>"
			look = "<span class='text' interview = '2'>已邀请未查看</span>"
			interview = "<a href='interview-invitation.html?cvId="+object.cvCopyId+"&name="+name+"' data-role='none' data-ajax='false' class='vi-button'>点击查看</a>"
			href ='interview-invitation.html?cvId='+object.cvCopyId+'&name='+name
		}else if(object.interview == 3) {
			var name = encodeURI(encodeURI(object.name))
//			look = "<span class='text'>接受面试</span>"
			look = "<span class='text'>已邀请已查看</span>"
			interview = "<a href='interview-invitation.html?cvId="+object.cvCopyId+"&name="+name+"' data-role='none' data-ajax='false' class='vi-button'>点击查看</a>"
			href ='interview-invitation.html?cvId='+object.cvCopyId+'&name='+name
		}else if(object.interview == 4) {
			look = "<span class='text'>不合适</span>"
		}else {
			look = "<span class='text'>企业已查看</span>"
		}
	}

	var whatDate = object.publishDate.substring(0,1)

	if(object.positionName!=null && whatDate!="-"){
		console.log(object.publishDate)
		var html = "<li cvCopyId="+object.cvCopyId+">\
						<a data-ajax='false' data-role='none' href='"+href+"'>\
							<div class='portrait bg-center' style='background-image: url(../images/picture-loading02.jpg);'></div>\
							<div class='info'>\
								<div class='first-column'>\
									<span class='title'>"+object.positionName+"</span>\
									<span class='monthly-pay'>"+object.pay+"</span>\
								</div>\
								<div class='second-column'>\
									<span class='name'>"+object.businessName+"</span>\
								</div>\
								<div class='third-column'>\
									<span class='jobs'>"+object.position+"</span>\
									<span class='welfare'>"+object.offerWelfareName+"</span>\
								</div>\
								<span class='date'>"+object.publishDate+"</span>\
							</div>\
						</a>\
						<div class='more'>\
							"+look+"\
							"+interview+"\
						</div>\
					</li>"	
	}

	jqueryObj.append(html)
}

function myInterview() {
	var cvCopyId = GetQueryString('cvId')
	,	name = decodeURI(GetQueryString('name'))

	$('strong').text(name)
	$.get('/offerinterview/myInterview', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var offerInfo = data.data.offerInfo
		,	interviewInfo = data.data.interviewInfo;
		$.each(offerInfo, function(index, val) {
			$('#'+index).text(val)
		});
		$.each(interviewInfo, function(index, val) {
			$('#'+index).text(val)
		});
	});
}

function allowInterview() {
	var cvCopyId = GetQueryString('cvId')
	$.get('/offercvcopy/allowInterview', {cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = "application-record.html"
	});
}

function rejectInterview(reason) {
	var cvCopyId = GetQueryString('cvId')
	$.post('/offercvcopy/rejectInterview', {reason: reason, cvCopyId: cvCopyId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = "application-record.html"
	});
}