function getInformationList() {
	$.get('/information/getInformationList', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			var html = "<a href='information-details.html?informationId="+val.informationId+"' data-ajax='false'>\
						<div class='portrait'><div class='bg-center' style='background-image: url(../images/picture-loading.jpg);'></div></div>\
						<div class='info'>\
							<p class='title'>"+val.title+"</p>\
							<span class='time'>"+val.createTime+"</span>\
						</div>\
					</a>"
			$('.il-list').append(html)
		});
	});
}

function getDetail() {
	var informationId = GetQueryString('informationId');
	$.get('/information/getDetail', {informationId: informationId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			if(index == 'content') {
				$('#content').html(val)
			}else if(index == 'comment') {
				if(val) {
					var html = ""
					$.each(val, function(i, v) {
						if(v.answer) {
							var answer = "<div class='system-reply'>\
											<p text='系统回复'>"+v.answer+"</p>\
										</div>"
						}else {
							var answer = ""
						}
						html += "<li>\
									<div class='portrait'><div class='bg-center' style='background-image: url("+v.headImgUrl+");'></div></div>\
									<div class='info'>\
										<p class='name'>"+v.nickName+"</p>\
										<p class='time'>"+v.createTime+"</p>\
										<p class='text'>"+v.content+"</p>\
									</div>\
									"+answer+"\
								</li>"
					});
					$('.id-comment-list').append(html)
				}
			}else {
				$("#"+index).text(val)
			}
		});
	});
}

function publishContent() {
	var content = $('#publishContent').val()
	,	informationId = GetQueryString('informationId')

	if(!content) {
		alert('内容不能为空')
		return false;
	}

	$.post('/information/publishComment', {informationId: informationId, content: content}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('评论成功')
		window.location.reload();
	});
}