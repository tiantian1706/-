function footer() {
	var nav = "<div class='footer-navbar'>\
					<ul>\
						<li><a href='job-list.html' data-ajax='false'><span class='ico icon-index'></span>首页</a></li>\
						<li><a href='resume-management.html' data-ajax='false'><span class='ico icon-resume'></span>简历管理</a></li>\
						<li><a href='hr-center.html' data-ajax='false'><span class='ico icon-mine'></span>HR中心</a></li>\
					</ul>\
				</div>"
	$('.warper').append(nav);
};