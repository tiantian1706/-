function getQuestionList() {
	$.get('/question/getQuestionList', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var surveyList = ""
		for (var i=0; i<data.data.length; i++) {
			surveyList += "<a href='invitation.html?questionId="+data.data[i].questionId+"' data-ajax='false'>\
							<p class='title'>"+data.data[i].title+"</p>\
							<p class='describe'>"+data.data[i].description+" </p>\
							<p class='other'><span class='time' text='时间：'>"+data.data[i].createTime+"</span>  <span class='num' text='参加人数：'>"+data.data[i].count+"</span></p>\
						</a>"
		}
		$('.survey-list').append(surveyList)
	});
}

function checkCodeUseful() {
	var questionId = GetQueryString('questionId')
	,	code = $('#code').val()
	,	href = "questionnaire.html?questionId="+questionId+"&code="+code;

	$.get('/questioncode/checkCodeUseful', {questionId: questionId, code: code}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = href;
	});
}

function getQuestionDetail() {
	var questionId = GetQueryString('questionId')
	$.get('/questiondetail/getQuestionDetail', {questionId: questionId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		for (var i=0; i<data.data.length; i++) {
			var	list = ""
			$.each(data.data[i].answer, function(i, v) {
				list += "<a><span class='letter'><span>"+select[i]+"</span></span> <span class='text'>"+v+"</span></a>"
			});

			html += "<div class='item'>\
						<div class='subject'>\
							<div class='num'><span class='current-number'>"+(i+1)+"</span> / <span class='total-number'>"+data.data.length+"</span></div>\
							<div class='topic'>"+data.data[i].question+"</div>\
						</div>\
						<div class='choice-question'>\
							"+list+"\
						</div>\
					</div>"
		}
		$('.questionnaire-middle').append(html)

		$('.questionnaire-middle .item:eq(0)').addClass('current')

		length = data.data.length
	});
}

function subList(result) {
	var questionId = GetQueryString('questionId')
	,	code = GetQueryString('code')

	$.post('/questionlist/subList', {code: code, questionId: questionId, result: result}, function(data, textStatus, xhr) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = "survey-list.html"
	});
}