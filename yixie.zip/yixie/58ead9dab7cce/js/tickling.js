var cvObj = {}
,	allExperience = []
,	mod = -1
,	cvId = GetQueryString('cvId')
,	modCvId = 0
,	cvInfo = {}

function getTickling(next) {
//	$.get('/offercvcopy/mySend', {}, function(data) {
	$.get('/offercv/getMyCv', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		cvInfo = data.data
		console.log(cvInfo)
		var html = ""
		if(cvInfo.length>0){
			$.each(cvInfo, function(index, val) {
				if(val.open == 1){
					if(val.workAge==18){
						var text = "应届毕业生"
					}else{
						var text = val.workAge+"年以上"
					}
					var time = val.modifyTime.substring(0,10)
					html += "<div class='list' cvId='"+val.cvId+"'>\
				    			<div class='title'>\
				    				<span class='job'>"+val.position+"</span>\
									<span class='monthly-pay orange'>"+val.will+"</span>\
				    			</div>\
				    			<div class='prompt'>\
				    				<span class='browse-times' text='浏览次数：'>"+val.browse+"</span>\
				    			</div>\
								<div class='above'>\
									<span>"+val.position+"</span>\
									<span>"+text+"</span>\
									<span class='text'>"+time+"</span>\
								</div>\
								<a id='btn' data-role='none'  option='preview' data-ajax='false'>详情</a>\
				    		</div>"
				}
			});
		}else{
			html="<p style='text-align: center;line-height: 3rem;font-size: .6rem;color: #333;'>您还没有投递过简历</p>"
		}
		$('.rl-box').append(html)
	});
}

$('body').on('click', '.list #btn', function() {
	var cvId = $(this).parents('.list').attr('cvId')
	,	index = $(this).parents('.list').index() - 1
	,	sessionCv = cvInfo[index]

	var index = $(this).parents('.list').index()
	,	obj = allExperience[index]

	var href = "tickling_preview.html?cvId="+cvId
	window.location.href = href;
});

function getTicklingId(userType) {	

	
}



function getMyLookRecord(next){
	var cvId = GetQueryString('cvId')
	console.log(cvId)
	$.get('/offercvcopy/myLookRecord', {cvCopyId: cvId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		lookData = data.data
		console.log(lookData)
		var html = ""
		$.each(lookData, function(index, val) {		
			
//			var time = val.createTime.substring(0,10)
			
			html += '<div class="item">\
		    			<div class="img" style="background-image: url(../images/picture-loading02.jpg);"></div>\
		    			<div class="text">\
		    				<h2>'+val.businessName+'</h2>\
		    				<span text="联系人：">'+val.name+'</span>\
		    				<p text="手机号：">'+val.phone+'</p>\
							<p class="time">'+val.createTime+'</p>\
		    			</div>\
	    			</div>'
		});
		$('.examine').append(html)
	});
};

function alter(){
	$("body").on('click', '.pass span', function() {
		var password = $(".pass input").val()
		console.log(password)
		if(password.length==0){
			alert("请输入更改密码")
		}else{
			if(confirm("您确认要更改密码吗？")){
				$.post('/fontuser/modPassword', {password: password}, function(data) {
					data = JSON.parse(data)
					if(data.code != 0) {
						alert("更改不成功,请重置密码!")
						return false;
					}
					if(data.code == 0) {
						alert("密码更改成功!")
					}		
				});		
			};
		}		
	})
	
		
	$("body").on('click', '.btn', function() {
		$.post('/fontuser/logout',function(data) {
			var href = "../login.html"
			window.location.href = href;
		})	
	})
}

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return '';
}

function getArticleByType(next){
	var type = GetQueryString('type')
	if(type == 1){
		$("title").text("活动报名")
		$(".article_img img").attr("src","images/article01.png");
		$(".article_btn").text("发起活动");
	}
	if(type == 2){
		$("title").text("人才观点")
		$(".article_img img").attr("src","images/article02.png");
		$(".article_btn").text("我要投稿");
	}
	if(type == 3){
		$("title").text("培训报名")
		$(".article_img img").attr("src","images/article03.png");
		$(".article_btn").text("发起培训");
	}
	if(type == 4){
		$("title").text("投票调研")
		$(".article_img img").attr("src","images/article04.png");
		$(".article_btn").text("发起投票");
	}
	$.get('/article/getArticleByType', {type: type}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		articleData = data.data.data
		console.log(articleData)
		
		var html = ""
		
		$.each(articleData, function(index, val) {	
			
			console.log(index+1)
			
			var time = val.createTime.substring(0,10)
			
			html += '<a class="item" href='+val.link+'>\
						<h3>'+(index+1)+'.'+val.title+'</h3>\
						<p>'+val.summary+'</p>\
						<div class="bottom">\
							<span>'+val.remark+'</span>\
							<span>'+time+'</span>\
						</div>\
					</a>'
		});
		
		$('.article_list').append(html)
	});
	$("body").on("click",".article_btn",function(){
		var href = "article-join.html?type="+type;
		window.location.href = href;
	})
};

function articleJoin(){
	var type = GetQueryString('type')
	if(type == 1){
		$("title").text("活动报名")
		$(".article_img img").attr("src","images/article01.png");
		$(".article_btn").text("发起活动");
		var theme = "活动报名"
	}
	if(type == 2){
		$("title").text("人才观点")
		$(".article_img img").attr("src","images/article02.png");
		$(".article_btn").text("我要投稿");
		var theme = "人才观点"
	}
	if(type == 3){
		$("title").text("培训报名")
		$(".article_img img").attr("src","images/article03.png");
		$(".article_btn").text("发起培训");
		var theme = "培训报名"
	}
	if(type == 4){
		$("title").text("投票调研")
		$(".article_img img").attr("src","images/article04.png");
		$(".article_btn").text("发起投票");
		var theme = "投票调研"
	}

	var join = '<p>欢迎投稿！请将相关资料以“酷才医械人资服务 —— '+theme+'”为主题发送至邮箱：<br />\
					<span>2092015578@qq.com</span><br />\
					并致电 <span> 020-85537701</span>\
				</p>'
	$(".article_join").append(join)
}

function getAllBusiness(){
	$.get('/fontuser/getAllBusiness', function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allBusiness = data.data
		console.log(allBusiness)
		
		var html = ""  
		
		$.each(allBusiness, function(index, val) {
			
			var x = val.star;
		    var y = String(x).indexOf(".") + 1;//获取小数点的位置
		    var count = String(x).length - y;//获取小数点后的个数
		    if(count > 1) {
		        var star = parseFloat(x).toFixed(1)
		    } else {
				var star = val.star
		    }
		    var integer = Math.floor(star/5*100)
			var width = integer+"%"
			
			html += '<a class="item" href="ranking-details.html?fontUserId='+val.fontUserId+'" data-ajax="false">\
						<i style="background-image: url(../images/picture-loading02.jpg);"></i>\
						<div class="comemnt">\
							<p>'+val.businessName+'</p>\
							<div class="c-stars-youzhi">\
								<div class="c-stars-up-youzhi" style="width:'+width+'"></div>\
							</div>\
							<div class="college-bottom">\
								<div class="pingfen"><span id="star">'+star+'分</span></div>\
								<p>评价（'+ val.comemntNum +'）</p>\
							</div>\
						</div>\
					</a>'
		});
		
		$('.ranking').append(html)		
		console.log(allBusiness)
		$.each(allBusiness, function(index, val) {
			var sum = parseInt(val.star)
		    console.log(sum)
		    for (var i=0;i<sum;i++) {
		    	var image = '<image src="../images/star04.png">'
		    	$('.stars').eq(index).append(image)
		    }
		})
	});
}


function getDetailInfo(){	
	$.get('/fontuser/getDetailInfoByFont',{fontUserId:GetQueryString('fontUserId')}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allBusiness = data.data
		commentList = data.data.commentList
		length = commentList.length

		$('#businessName').text(allBusiness.businessName)
		$('#businessNameTwo').text(allBusiness.businessName)
		$('#remark').text(allBusiness.remark)
		$('#len').text(length)

		$('#tradeTitle').text(data.data.tradeTitle)
		$('#sizeTitle').text(data.data.sizeTitle)
		$('#natureTitle').text(data.data.natureTitle)
		
		var html = ""
		
		$.each(commentList, function(index, val) {
			var sex = val.sex
			if(sex==1){
				var url = "../images/portrait.png"
			}else if(sex==2){
				var url = "../images/portrait02.png"
			}
			var time = val.createTime.substring(0,10)
			
			var degree = val.degree
			console.log(degree)
			var star = ""
			for (var i = 0;i < degree;i++) {
				star += '<i class="star_open"></i>'
			}
			
			html += '<li>\
						<img src="'+url+'" />\
						<div class="details_text">\
							<h3 id="name"><span>'+val.name+'</span><i>*****</i></h3>\
							<p id="details">'+val.content+'</p>\
							<div class="bottom">\
								<div class="star">\
									'+star+'\
								</div>\
								<span id="time">'+time+'</span>\
							</div>\
						</div>\
					</li>'
		});
		
		$('.ranking_details ul').append(html)			
	});
}


function getAllBusinessOne(){
	$.get('/fontuser/getAllBusiness', function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allBusiness = data.data
		console.log(allBusiness)
		
		var html = ""
		$.each(allBusiness, function(index, val) {
			
			var x = val.star;
		    var y = String(x).indexOf(".") + 1;//获取小数点的位置
		    var count = String(x).length - y;//获取小数点后的个数
		    if(count > 1) {
		        var star = parseFloat(x).toFixed(1)
		    } else {
				var star = val.star
		    }
		    var integer = Math.floor(star/5*100)
			var width = integer+"%"
			
			console.log("star",star,"count",count,"y",y,"width",width)
			
			html += '<a class="item" href="ranking-details.html?fontUserId='+val.fontUserId+'" data-ajax="false">\
				<i style="background-image: url(images/picture-loading02.jpg);"></i>\
				<div class="comemnt">\
					<p>'+val.businessName+'</p>\
					<div class="c-stars-youzhi">\
						<div class="c-stars-up-youzhi" style="width:'+width+'"></div>\
					</div>\
					<div class="college-bottom">\
						<div class="pingfen"><span id="star">'+star+'分</span></div>\
						<p>评价（'+ val.comemntNum +'）</p>\
					</div>\
				</div>\
			</a>'
		});		

		$('.ranking').append(html);
		
		console.log(allBusiness)
		$.each(allBusiness, function(index, val) {
			var sum = parseInt(val.star)
		    console.log(sum)
		    for (var i=0;i<sum;i++) {
		    	var image = '<image src="images/star04.png">'
		    	$('.stars').eq(index).append(image)
		    }
		})
	});
}

function getDetailInfoOne(){	
	$.get('/fontuser/getDetailInfoByFont',{fontUserId:GetQueryString('fontUserId')}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allBusiness = data.data
		commentList = data.data.commentList
		length = commentList.length

		$('#businessName').text(allBusiness.businessName)
		$('#remark').text(allBusiness.remark)
		$('#len').text(length)

		$('#tradeTitle').text(data.data.tradeTitle)
		$('#sizeTitle').text(data.data.sizeTitle)
		$('#natureTitle').text(data.data.natureTitle)
		
		var html = ""
		
		$.each(commentList, function(index, val) {
			var sex = val.sex
			if(sex==1){
				var url = "images/portrait.png"
			}else if(sex==2){
				var url = "images/portrait02.png"
			}
			var time = val.createTime.substring(0,10)
			
			var degree = val.degree
			console.log(degree)
			var star = ""
			for (var i = 0;i < degree;i++) {
				star += '<i class="star_open"></i>'
			}
			
			html += '<li>\
						<img src="'+url+'" />\
						<div class="details_text">\
							<h3 id="name"><span>'+val.name+'</span><i>*****</i></h3>\
							<p id="details">'+val.content+'</p>\
							<div class="bottom">\
								<div class="star">\
									'+star+'\
								</div>\
								<span id="time">'+time+'</span>\
							</div>\
						</div>\
					</li>'
		});
		
		$('.ranking_details ul').append(html)			
	});
}