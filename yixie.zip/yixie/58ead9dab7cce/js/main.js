var headerHeight = $('#header').outerHeight()
,	control = null
;
//$(document).ready(function(){
//	control = {disable:false,render:render}
//	var SC = $('.swiper-container').outerHeight()
//	var hidescroll = SC - headerHeight
//	function render(event){
//		var o
//		if(control.disable){
//			o = 1
//		}else{
//			var scrollTop = $(document).scrollTop()
//			o = (scrollTop <= hidescroll) ? scrollTop / hidescroll : 1
//		}
//		$("#header").css('background-color', 'rgba(51, 161, 183,'+o+')');
//	}
//	document.addEventListener('touchmove',render, false);
//	document.addEventListener('scroll',render, false);
//})

function render(event){
	var o = .3
//	if(control.disable){
//		o = .3
//	}else{
//		var scrollTop = $(document).scrollTop()
//		o = (scrollTop <= hidescroll) ? scrollTop / hidescroll : 8
//	}
	$("#header").css('background-color', 'rgba(51, 161, 183,'+o+')');
}

//index header
function indexHeader() {
	$(document).ready(function(){
		control = {}
		control = {disable:false,render:render}
		var SC = $('.swiper-container').outerHeight()
		var hidescroll = SC - headerHeight
		function render(event){
			var o = .3
//			if(control.disable){
//				o = .3
//			}else{
//				var scrollTop = $(document).scrollTop()
//				o = (scrollTop <= hidescroll) ? scrollTop / hidescroll : 8
//			}
			$("#header").css('background-color', 'rgba(51, 161, 183,'+o+')');
		}
		document.addEventListener('touchmove',render, false);
		document.addEventListener('scroll',render, false);
	})
}
//header
function header(){
	var headerDiv = $("<div class='header-placeholder'></div>").prependTo('.warper')
	headerDiv.height(headerHeight)
	$('#header').addClass('header-fixed')
}
//list filter
function filterPop() {
	var filterPop = $('.filter-pop')
	,	pageH = $(window).outerHeight()
	,	fixedPop = pageH - headerHeight;
	
	$('body').on('click','.filter a', function(e){
		e.preventDefault();
		console.log("222")
		if ($(this).hasClass('current')) {
			$('body').removeClass('disable-scrolling')
			$('html').removeClass('disable-scrolling')
			$(this).removeClass('current')
			filterPop.css({
				'top': headerHeight,
				'height': 0 + 'px'
			});
		}else {
			$('body').addClass('disable-scrolling')
			$('html').addClass('disable-scrolling')
			$(this).addClass('current')
			$(this).siblings('a').removeClass('current')
			filterPop.css({
				'top': headerHeight,
				'height': fixedPop + 'px'
			});
		}
		if($(this).hasClass('post')) {
			$('#post').show()
			$('#description,#more,#rank').hide()
		} else if ($(this).hasClass('description')) {
			$('#description').show()
			$('#post,#more,#rank').hide()
		} else if ($(this).hasClass('rank')){
			$('#rank').show()
			$('#post,#description,#more').hide()
		} else if ($(this).hasClass('more')){
			$('#more').show()
			$('#post,#description,#rank').hide()
		}
	})
}

function hideSlect() {
	$('.filter-pop').css({
		'top': headerHeight,
		'height': 0 + 'px'
	});
	$('.filter a').removeClass('current')
}

function searchShow() {
	$('#search-popup').addClass('pop-show')
	$('.filter').hide()
	control = {}
	control.disable = true
	// control.render()
	render()
}
function searchHide() {
	$('#search-popup').removeClass('pop-show')
	$('.filter').show()
	control = {}
	control.disable = false
	setTimeout(control.render,100)
}

$(function() {

    FastClick.attach(document.body);

	//history record
	var hrLen = $('.history-record li').length
	$('body').on('click', '.history-record .clear', function() {
		$('.history-record li').remove()
	});


	//listRadio
	$('body').on('click', '.listRadio a', function(event){
		var $this = $(this)
		if ($this.hasClass('current')) {
			$this.removeClass('current')
		}else {
			$this.addClass('current').siblings('a').removeClass('current')
		}
	})

});

function getOfferCvCopy(data) {
	$.get('/offercvcopy/myApplicationRecordNothandle', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data)
		if(data.data>0){
			$("body").find(".red_dot").show()
		}
	})
}