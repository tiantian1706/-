function getTrainList() {
	$.get('/train/getQuestionList', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data.data)
		$.each(data.data, function(index, val) {
			var html = "<a href='train-details.html?trainListId="+val.trainListId+"' class='item' data-ajax='false'>\
							<p class='title'>"+val.title+"</p>\
							<p class='describe'>"+val.description+"</p>\
							<div class='pic bg-center' style='background-image: url();'></div>\
							<img src='"+val.image+"' alt=''>\
							<div class='more'>\
								<span class='time'>"+val.createTime+"</span>\
								<span class='sign-up' text='已报名：'>"+val.count+"人</span>\
							</div>\
						</a>"
			if(val.signup == 1) {
				$('.train-sign-up ul').append(html)
			}else {
				$('.train-info ul').append(html)
			}
		});
	});
}

function getTrain() {
	var trainListId = GetQueryString('trainListId');
	$.get('/train/get', {trainListId: trainListId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			if(index == 'content') {
				$('#content').html(val)
			}else if(index == 'image') {
				$('#image').attr("src", val);
			}else {
				$("#"+index).text(val)
			}
		});
	});
}

function signUp() {
	var trainListId = GetQueryString('trainListId')
	,	name = $('#name').val()
	,	phone = $('#phone').val()

	$.post('/trainsignup/signup', {trainListId: trainListId, name: name, phone: phone}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('报名成功')
		window.location.href = "train-list.html"
	});
}