var back = $('.pic').css('backgroundImage')
,	mod = -1
,	headImgUrl = '';
function checkMustLogin(next) {
	$.get('/fontuser/checkMustLogin', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(data.data.type != 1) {
			// alert('用户类型非法')
			window.location.href = "../login.html"
			return false;
		}
		window.sessionStorage.setItem('fontUser', JSON.stringify(data.data.info))
		window.sessionStorage.setItem('detail', JSON.stringify(data.data.detail))
		next();
	});
}

function checkAndGetData() {
	var name = $("input[name=name]").val()
	,	sex  = $("select[name=sex]").val()
	,	birthday = $("input[name=birthday]").val()
	,	address = $("#address").val()
	,	contact = $("input[name=contact]").val()
	,	email = $("input[name=email]").val()
	,	school = $("input[name=school]").val()
	,	skill = $("input[name=skill]").val()
	,	startTime = $("input[name=startTime]").val()
	,	endTime = $("input[name=endTime]").val()
	,	educational = $("select[name=educational]").val()
	,	English = $("select[name=English]").val()
	,	computerAbility = $("select[name=computerAbility]").val()
	,	atSchoolPrize = $('input[name=atSchoolPrize]').val()
	,	atSchoolPosition = $('input[name=atSchoolPosition]').val()
	,	remark = $('#remark').val();

	return {
		name: name,
		sex: sex,
		birthday: birthday,
		address: address,
		contact: contact,
		email: email,
		school: school,
		skill: skill,
		startTime: startTime,
		endTime: endTime,
		educational: educational,
		English: English,
		computerAbility: computerAbility,
		atSchoolPrize: atSchoolPrize,
		atSchoolPosition: atSchoolPosition,
		remark: remark,
		headImgUrl: headImgUrl,
		mod: mod,
	};
}

function readUrl(){
    var file = document.getElementById('file').files

    $.each(file, function(index, val) {
    	f = val;
    	if(!/image\/\w+/.test(f.type)){  
            alert("看清楚，这个需要图片！");  
            return false;  
        } 
        var reader = new FileReader();
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(f);

        reader.onloadstart = function(e){
        }

        reader.onload = function(e){
        	headImgUrl = this.result
        	mod = 1
	        $('.pic').css({backgroundImage:'url('+this.result+')'});
        }
    });
}

$('#file').change(function() {
	readUrl();
});
	
$("body").on("click",".yx-button",function(){
	var data = checkAndGetData();
		
	if(data.birthday==""){
		alert("请填写出生日期");
		return false;
	}
	
	$.post('/fontuser/modFontUserInfo', {data: data}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}

		var r=confirm("已完善个人资料，去创建新的简历吧~");
		
		if (r==true){
			window.location.href = "resume-list.html";
		}else{
		    window.location.href = "personal-center.html";
		}
	});
});