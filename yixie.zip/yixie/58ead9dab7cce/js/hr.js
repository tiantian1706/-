var back = $('.pic').css('backgroundImage')
,	mod = -1
,	headImgUrl = ''
,	cvCopyId = GetQueryString('cvCopyId')
,	cvObj = {}
,	allExperience = []
,	allCopyCv = {}

if(back) {
	var right = back.indexOf(")")
	,	headImgUrl = back.substr(4, right-4)
}

function getData() {
	var businessName = $('#businessName').val()
	,	name = $('#name').val()
	,	contact = $('#contact').val();

	if(!businessName) {
		alert('请填入企业名称')
		return 0;
	}
	if(!name) {
		alert('请填入联系人姓名')
		return 0;
	}
	if(!contact) {
		alert('请填入联系方式')
		return 0;
	}

	return {
		businessName: businessName,
		name: name,
		contact: contact,
		headImgUrl: headImgUrl,
		mod: mod,
	};
}

function readUrl(){
    var file = document.getElementById('file').files

    $.each(file, function(index, val) {
    	f = val;
    	if(!/image\/\w+/.test(f.type)){  
            alert("看清楚，这个需要图片！");  
            return false;  
        } 
        var reader = new FileReader();
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(f);

        reader.onloadstart = function(e){
        }

        reader.onload = function(e){
        	headImgUrl = this.result
        	mod = 1
	        $('.pic').css({backgroundImage:'url('+this.result+')'});
        }
    });
}

$('#file').change(function() {
	readUrl();
});


// 简历部分

$('.add-button').click(function() {

	var editDiv = $('a[name=edit]')
	$.each(editDiv, function(index, val) {
		var className = $(this).attr('div')
		$('.'+className).hide()
	});

	$('.editor-box-popup').addClass('pop-show')
	$('body').addClass('disable-scrolling')
	$('html').addClass('disable-scrolling')
	$('.work-experience-editor').show()
	// $('.job-intention-editor,.self-description-editor').hide()

	$('.work-experience-editor').find('input').val(null)
	$('.work-experience-editor').find('textarea').val(null)
	initDate()
});

function initDate() {
	//初始化配置参数      
    $('#startTime, #endTime, #jobStartTime, #jobEndTime').mobiscroll().date({
        theme: "mobiscroll",  
        lang: "zh",  
        cancelText: null,  
        dateFormat: 'yy-mm', //返回结果格式化为年月格式 
    });
}

function hideEditor() {
	$('.editor-box-popup').removeClass('pop-show')
	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
}

function firstApply(object) {
	$("p[name=position]").text(object.position)
	$("span[name=address]").text(object.address)
	$("span[name=will]").text(object.will)
	$("span[name=workAge]").text(object.workAge)
//	$("span[name=offerClassifyName]").text($("span[offerClassifyId='"+object.offerClassifyId+"']").text())
//	$("span[name=offerClassifyName]").attr('offerClassifyId', object.offerClassifyId)
	$("span[name=offerClassifyName]").text(object.offerClassifyTitle)
	
	console.log(object)
	if(cvCopyId) {
		$('#position').val(object.position)
		$('#city').val(object.address)
		$('#will').val(object.will)
		$('#workAge').val(object.workAge)
		$('#address').val(object.address)
		$('#offerClassifyId').attr('offerClassifyId', object.offerClassifyId)
//		$('#offerClassifyId').val($("span[offerClassifyId='"+object.offerClassifyId+"']").text())
		$("#offerClassifyId").val(object.offerClassifyTitle)
	}
}

function secondApply(object) {
	console.log(object)
	var startTime = object.startTime
	var endTime = object.endTime
	if(startTime){
		var start = startTime
		var end = endTime
	}else if(!startTime){
		var start = object.jobStartTime
		var end = object.jobEndTime
	}
	var html =  "<li>\
					<div class='left'>\
						<div class='line'></div>\
						<div class='circular'></div>\
					</div>\
					<div class='info'>\
						<p class='min-text'><span>"+start+"</span> - <span>"+end+"</span></p>\
						<p class='name'>"+object.exWorkName+"</p>\
						<p><span class='job'>"+object.exPosition+"</span> <span class='job-description'>"+object.exDescription+"</span></p>\
					</div>\
					<a class='editor-button main-tone wee-button' name='edit'><span class='ico icon-modify'></span>编辑</a>\
				</li>"

	if(mod == -1) {
		$('ul').append(html)
	}else {
		$('ul').find('li').eq(mod).replaceWith(html)
	}
	
}

function thirdApply(object) {
	$("p[name=description]").text(object.description)

	if(cvCopyId) {
		$('#description').val(object.description)
	}
}

function fourApply(object) {
	var sex = object.sex
	if(sex=="男"||sex==1){
		var s = "男"	
	}else if(sex=="女"||sex==2){
		var s = "女"	
	}
	$("p[name=name]").text(object.name)
	$("p[name=sex]").text(s)	
	$("p[name=birthday]").text(object.birthday)
	$("p[name=city]").text(object.city)
	$("p[name=place]").text(object.place)

	if(cvCopyId) {
		$('#name').val(object.name)
		$('#sex').val(s)
		$('#birthday').val(object.birthday)
		$('#city').val(object.city)
		$('#place').val(object.place)
	}
}

function fiveApply(object) {
	$("p[name=school]").text(object.school)
	$("i[name=startTime]").text(object.startTime)
	$("i[name=endTime]").text(object.endTime)
	$("p[name=educational]").text(object.educational)
	$("p[name=skill]").text(object.skill)
	$("p[name=English]").text(object.English)
	$("p[name=computerAbility]").text(object.computerAbility)

	if(cvCopyId) {
		$('#school').val(object.school)
		$('#startTime').val(object.startTime)
		$('#endTime').val(object.endTime)
		$('#educational').val(object.educational)
		$('#skill').val(object.skill)
		$('#English').val(object.English)
		$('#computerAbility').val(object.computerAbility)
	}
}

function sixApply(object) {
	$("p[name=contact]").text(object.contact)
	$("p[name=email]").text(object.email)

	if(cvCopyId) {
		$('#contact').val(object.contact)
		$('#email').val(object.email)
	}
}

//第一部分编辑框
$('a[name=firstSave]').click(function() {
	var position = $('#position').val()
//	,	address = $('#city').val()
	,	address = $('#address').val()
	,	will = $('#will').val()
	,	offerClassifyId = $('#offerClassifyId').attr('offerClassifyId')
//	,	$('#offerClassifyId').val($("span[offerClassifyId='"+object.offerClassifyId+"']").text())
	,	workAge = $('#workAge').val()

	console.log(cvObj)
	cvObj.position = position
	cvObj.address = address
	cvObj.will = will
	cvObj.offerClassifyId = offerClassifyId
	cvObj.workAge = workAge
	console.log("::::"+workAge)

	if($('#offerClassifyId').val().length == 0 || position.length == 0 || address.length == 0 || will.length == 0 || workAge == null){
		alert("请完善简历！");
		return false;
	}else{
		hideEditor()
	}

	firstApply(cvObj)
	
	var work = $("#work").html()
	if(work == "18/" || work == "18"){
		$("#work").html("应届毕业生")
	}

});

//第二部分编辑
$('a[name=secondSave]').click(function() {
	var exWorkName = $('#exWorkName').val()
	,	jobStartTime = $('#jobStartTime').val()
	,	jobEndTime = $('#jobEndTime').val()
	,	exPosition = $('#exPosition').val()
	,	exDescription = $('#exDescription').val()
	,	experience = {}

	experience.exWorkName = exWorkName
	experience.jobStartTime = jobStartTime
	experience.jobEndTime = jobEndTime
	experience.exPosition = exPosition
	experience.exDescription = exDescription

	console.log(mod)
	if(mod == -1) {
		allExperience.push(experience)
	}else {
		allExperience[mod] = experience
	}
	console.log(allExperience)

	if(exWorkName.length == 0 || jobStartTime.length == 0 || jobEndTime.length == 0 || exPosition.length == 0 || exDescription.length == 0){
		alert("请完善工作经验！")
		return false;
	}else{
		secondApply(experience)
		hideEditor()
	}

});

//第二部分删除键
$('a[name=deleteSave]').click(function() {
	hideEditor()
	$('ul').find('li').eq(mod).remove()
});


//第三部分编辑框
$('a[name=thirdSave]').click(function() {
	var description = $('#description').val()

	cvObj.description = description

	if(description.length == 0){
		alert("请完善自我描述！")
		return false;
	}else{
		hideEditor()
		thirdApply(cvObj)
	}

});

//第四部分编辑框 －－ 个人基本信息
$('a[name=fourSave]').click(function() {
	var name = $('#name').val()
	,	sex = $('#sex').val()
	,	birthday = $('#birthday').val()
//	,	city = $('#city').val()
//	,	place = $('#place').val()

	cvObj.name = name
	cvObj.sex = sex
	cvObj.birthday = birthday
//	cvObj.city = city
//	cvObj.place = place

	if(name.length == 0 || sex.length == 0 || birthday.length == 0){
		alert("请完善个人信息！")
		return false;
	}else{
		hideEditor()
		fourApply(cvObj)
	}
});

//第五部分编辑框－－教育信息
$('a[name=fiveSave]').click(function() {
	var school = $('#school').val()
	,	startTime = $('#startTime').val()
	,	endTime = $('#endTime').val()
	,	skill = $('#skill').val()
	,	English = $('#English').val()
	,	educational = $('#educational').val()
	,	computerAbility = $('#computerAbility').val()

	cvObj.school = school
	cvObj.startTime = startTime
	cvObj.endTime = endTime
	cvObj.skill = skill
	cvObj.English = English
	cvObj.educational = educational
	cvObj.computerAbility = computerAbility


	if(school.length == 0 || startTime.length == 0 || endTime.length == 0 || skill.length == 0 || English.length == 0 || educational.length == 0 || computerAbility.length == 0){
		alert("请完善教育信息！")
		return false;
	}else{
		hideEditor()

		fiveApply(cvObj)
	}
});

//第六部分编辑－－个人信息
$('a[name=sixSave]').click(function() {
	var contact = $('#contact').val()
	,	email = $('#email').val()

	cvObj.contact = contact
	cvObj.email = email

	if(contact.length == 0 || email.length == 0){
		alert("请完善联系方式！")
		return false;
	}else{
		hideEditor()

		sixApply(cvObj)
	}

});

function getAllExperience() {
	var list = $('.work-experience').find('ul').find('li')
	,	experienceObj = []
	$.each(list, function(index, val) {
		var e = {}

		var jobStartTime = $(this).find('.info').find('p').eq(0).find('span').eq(0).text()
		,	jobEndTime = $(this).find('.info').find('p').eq(0).find('span').eq(1).text()
		,	exWorkName = $(this).find('.info').find('p').eq(1).text()
		,	exPosition = $(this).find('.info').find('p').eq(2).find('span').eq(0).text()
		,	exDescription = $(this).find('.info').find('p').eq(2).find('span').eq(1).text()

		e.jobStartTime = jobStartTime;
		e.jobEndTime = jobEndTime;
		e.exWorkName = exWorkName;
		e.exPosition = exPosition;
		e.exDescription = exDescription;
		experienceObj.push(e)
	});

	return experienceObj
}

$('#subOnce').click(function() {
	allExperience = getAllExperience()
	cvObj.experience = allExperience
	if(mod == 1) {
		cvObj.headImgUrl = headImgUrl
	}
	
	if(!allExperience.length) cvObj.experience = ''

	var length = $(".work-experience ul").find("li").length
	
	console.log(cvObj)

//	if('name' && 'school' && 'skill' && 'description' && 'contact' in cvObj && length >= 1){
		if(cvCopyId) {
			$.post('/offercvcopy/modCopyCvByHr', {cvCopyId: cvCopyId, cvObj: cvObj}, function(data) {
				data = JSON.parse(data)
				if(data.code != 0) {
					alert(data.msg)
					return false;
				}
				window.location.href = "resume-management.html"
			});
		}else {
			$.post('/offercvcopy/addCopyCvByHr', {cvObj: cvObj}, function(data) {
				data = JSON.parse(data)
				if(data.code != 0) {
					// alert(data.msg)
					// return false;
					window.location.href = "../login.html"
				}
				window.location.href = "resume-management.html"
			});
		}
//	} else {
//		alert("请完善简历！")
//		return false;
//	}

});

function commonHrCv(jqueryObject, obj, index) {

	//用于判断是否需要加入够选框
	var href = window.location.href
	if(href.indexOf('details') > 0) {
		var optionHtml = "<div class='push-resume-selection'><span></span></div>"
	}else {
		var optionHtml = ""
	}

	var state = ""
	if(obj.type == 2) {
		if(obj.look == 1) {
			state = "<div class='state'><span class='notView'>未查看</span></div>"
		}else {
			state = "<div class='state'><span class='alreadyView'>已查看</span></div>"
		}
	}
	console.log(obj)
	
	if(obj.sex==1 || obj.sex == "男"){
		var url = "../images/portrait.png"
	}else if(obj.sex==2 || obj.sex == "女"){
		var url = "../images/portrait02.png"
	}
	
	var workAge = obj.workAge
	if(workAge == 18){
		var workage = '<span>应届</span>'
		
	}else{
		var workage = '<span>'+workAge+'年</span>'
	}

	
	var html = "<li index='"+index+"' cvCopyId='"+obj.cvCopyId+"'>\
					<a class='con' data-ajax='false'>\
						"+optionHtml+"\
						<div class='portrait bg-center' style='background-image: url("+url+");'></div>\
						<div class='info'>\
							<p class='name'>"+obj.name+"</p>\
							<p class='btn'><span>"+obj.age+"岁</span>"+workage+"<span>"+obj.city+"</span></p>\
							<p class='expect'>在找<span class='job'>"+obj.offerClassifyTitle+"</span class='expect_span'><br/>期望薪资   <span class='salary orange'>"+obj.will+"</span></p>\
						</div>\
					</a>\
				</li>"

	jqueryObject.append(html)
}

//简历的编辑
$('body').on('click', '.behind .blue-bg', function() {
	var index = $(this).parents('li').attr('index')
	,	sessionCopyCv = allCopyCv[index]

	window.sessionStorage.setItem('copyCvInfo', JSON.stringify(sessionCopyCv))

	window.location.href = "resume-editor-all.html?cvCopyId="+allCopyCv[index]['cvCopyId']
});

function myCvByHr(next) {
	$.get('/offercvcopy/myCvByHr', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			// alert(data.msg)
			// return false;
			window.location.href = "../login.html"
		}
		allCopyCv = data.data
		$.each(allCopyCv, function(index, val) {
			if(val.type == 3) {
				commonHrCv($('#already-created').find('ul'), val, index)
			}else if(val.type == 4) {
				commonHrCv($('#already-collection').find('ul'), val, index)
			}else if(val.type == 2) {
				commonHrCv($('#already-recommend').find('ul'), val, index)
			}
		});
		next();
	});
}

function sendCvByHr() {
	var offerId = GetQueryString('offerId')
	,	cvId = []

	$.each($('.icon-on'), function(index, val) {
		cvId.push($(this).parents('li').attr('cvCopyId'))
	});

	if(cvId.length > 0) {
		$.post('/offercvcopy/sendCvByHr', {offerId: offerId, cvCopyIdInfo: cvId}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			alert('投递成功');
		});
	}
}

function getHrInfo(fontUserId) {
	$.get('/fontuser/getHrInfo', {fontUserId: fontUserId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#'+index).text(val)
		});
		$('.portrait').css({backgroundImage:'url('+data.data.headImgUrl+')'});
	});
}

function getPersonalComment(fontUserId) {
	$.get('/offercomment/getPersonalComment', {fontUserId: fontUserId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var html = ""
		$.each(data.data, function(index, val) {
			if(val.headImgUrl.length==null){
				var url="../images/picture-loading02.jpg"
			}else{
				var url=val.headImgUrl
			}

			html += "<li>\
						<div><div class='portrait bg-center' style='background-image: url("+url+");'></div></div>\
						<div class='info'>\
							<p class='name'>"+val.businessName+"</p>\
							<p class='time'>"+val.createTime+"</p>\
							<p class='information'>"+val.content+"</p>\
						</div>\
					</li>"
		});
		$('ul').append(html)
		$('.inside-head .len').text(data.data.length)
	});
}

//企业绑定hr
function bindHr(phone) {
	$.get('/offerassociate/bindHr', {phone: phone}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload();
	});
}

//hr绑定企业
function bindBusiness(phone) {
	$.get('/offerassociate/bindBusiness', {phone: phone}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload();
	});
}

//解除关联
function unbindHr() {
	$.get('/offerassociate/unbindHr', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload();
	});
}

function unbindBusiness() {
	$.get('/offerassociate/unbindBusiness', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload();
	});
}

function myAssociateByBusiness() {
	$.get('/offerassociate/myAssociateByBusiness', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(data.data != 0) {
			if(data.data.state == 1) {
				if(data.data.author == 0) {
					$('.confirm').show();
					$('.already').show();
				}
				var state = "<a class='associate-button wait-association'>等待关联</a>"
			}else {
				$('.already').show();
				var state = "<a class='associate-button already-associated'>已经关联</a>"
			}
			if(data.data.headImgUrl.length==null){
				var url="../images/picture-loading02.jpg"
			}else{
				var url=data.data.headImgUrl
			}
			
			var html = "<div class='portrait'><div class='bg-center' style='background-image: url("+url+");'></div></div>\
						<div class='info'>\
							<p class='name'>"+data.data.name+"</p>\
							<p class='tel' text='联系方式：'>"+data.data.phone+"</p>\
							"+state+"\
						</div>"
			$('.associate-info').append(html)
		}
	});
}

function myAssociateByHr() {
	$.get('/offerassociate/myAssociateByHr', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(data.data != 0) {
			if(data.data.state == 1) {
				if(data.data.author == 0) {
					$('.confirm').show();
					$('.already').show();
				}
				var state = "<a class='associate-button wait-association'>等待关联</a>"
			}else {
				$('.already').show();
				var state = "<a class='associate-button already-associated'>已经关联</a>"
			}
			
			if(data.data.headImgUrl.length==null){
				var url="../images/picture-loading02.jpg"
			}else{
				var url=data.data.headImgUrl
			}


			var html = "<div class='portrait'><div class='bg-center' style='background-image: url("+url+");'></div></div>\
						<div class='info'>\
							<p class='name'>"+data.data.name+"</p>\
							<p class='tel' text='联系方式：'>"+data.data.phone+"</p>\
							"+state+"\
						</div>"
			$('.associate-info').append(html)
		}
	});
}

function withdraw() {
	var name = $('#name').val()
	,	phone = $('#phone').val()
	,	bank = $('#bank').val()
	,	bankAcount = $('#bankAcount').val()
	,	num = $('#num').val()
	,	obj = {}

	obj.name = name;
	obj.phone = phone;
	obj.bank = bank
	obj.bankAcount = bankAcount;
	obj.num = num;

	$.post('/withdraw/draw', {data: obj}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = "h-my-money.html"
	});
}