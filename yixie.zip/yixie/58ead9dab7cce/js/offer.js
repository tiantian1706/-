var headImgUrl = ''
,	mod = 0
,	cvInfo = {}
,	allCv = {}
,	offerInfo = {}
,	allOffer = {}
,	offerCondition = {}
,	offerClassifyTitle = ""
, 	payShare = ""
,	positionNameShare = ""
,	moneyShare = ""



function getOfferWelfare(next) {
	$.get('/offerwelfare/getByUserId', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var html = ""
		$.each(data.data, function(index, val) {
			console.log("lalala",val)
			html += "<a offerWelfareId='"+val.offerWelfareId+"'>"+val.title+"</a>"
		});
		
//		var id = $('#offerWelfareId').attr("offerwelfareid")
//		console.log(id)
		
		$('#offerWelfareId').append(html)
		next()
	});
}

$('#publish, #save').click(function() {
	var offerId = GetQueryString('offerId')
	,	offerClassifyId = $('#offerClassifyId').attr('offerClassifyId')
	,	positionName = $('#positionName').val()
	,	city = $('#city').val()
	,	address = $('#address').val()
	,	pay = $('#pay').val()
	,	left_pay = $('#left_pay').val()
	,	right_pay = $('#right_pay').val()
	,	face = $("#face").text()
	,	position = $('#position').val()
	,	positionRequire = $('#positionRequire').val()
	,	educational = $('#educational').val()
	,	workExperience = $('#workExperience').val()
	,	money = $('#money').val()
	,	num = $('#num').val();

	if ($("#face").hasClass('faceChange')) {
		pay = face
		if(pay.length==0){
			alert('请选择月薪')
			return false;
		}
	}else {
		if(!left_pay || !right_pay){
			alert('请选择月薪')
			return false;
		}
		pay = left_pay+'K-'+right_pay+'K';
	}
	
//	pay = left_pay+'K-'+right_pay+'K'
//	pay = left_pay+'-'+right_pay

	var offerWelfareId = []
	if($('#offerWelfareId').find('.current').length > 0) {
		$.each($('#offerWelfareId').find('.current'), function(index, val) {
			offerWelfareId.push($(this).attr('offerWelfareId'))
		});
	}else{
		alert('请选择福利待遇')
		return false;
	}

	if($(this).attr('id') == 'save') {
		var state = 1;
	}else {
		var state = 2;
	}
	
	
	if(!offerClassifyId) {
		alert('请选择招聘的内容')
		return false;
	}
	if(!positionName){
		alert('请输入职位')
		return false;
	}
	if(!city){
		alert('请选择地区')
		return false;
	}	
	if(!address){
		alert('请输入工作地址')
		return false;
	}
	if(!pay) {
		alert('请选择月薪')
		return false;
	}	
	if(!position) {
		alert('请填写职位描述')
		return false;
	}
	if(!num) {
		alert('请填写招聘人数')
		return false;		
	}
	if(!positionRequire) {
		alert('请输入任职要求')
		return false;
	}
	

	if(offerId && state == 2) {
		$.post('/offer/modOffer', {
			offerId: offerId,
			offerClassifyId: offerClassifyId,
			offerWelfareId: offerWelfareId,
			positionName: positionName,
			positionRequire: positionRequire,
			city: city,
			address: address,
			pay: pay,
			position: position,
			educational: educational,
			workExperience: workExperience,
			money: money,
			state: state,
			num: num,
		}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			window.location.href = 'recruitment-management.html'
		});
	}else{
		$.post('/offer/publish', {
			offerClassifyId: offerClassifyId,
			offerWelfareId: offerWelfareId,
			positionName: positionName,
			positionRequire: positionRequire,
			address: address,
			city: city,
			pay: pay,
			position: position,
			educational: educational,
			workExperience: workExperience,
			money: money,
			state: state,
			num: num,
		}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			window.location.href = 'recruitment-management.html'
		});
	}
});

function myOffer(next) {
	$.get('/offer/myOffer', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}

		var nonReward = ''
		,	reward = ''
		,	unpublished = '';
		console.log(data.data)
		$.each(data.data, function(index, val) {
			var radio = "<div class='newRadio'><span class='newRadioIco icon-dagou'></span></div>"
			if(val.state == 1) {
				unpublished += "<li offerId='"+val.offerId+"'>\
									<p class='job'>"+val.positionName+"</p>\
									<p><span class='state gray-bg'>待发布</span></p>\
									<p class='m'><span class='time' text='生成时间：'>"+val.createTime+"</span></p>\
									<a class='again' name='edit'>\
										<span class='icon-modify'></span>\
										编辑\
									</a>\
									<p class='btn'><a name='delete'>删除</a> <a name='firm_preview'>预览</a> <a name='publish'>立即发布</a></p>\
								</li>"
			}else {
				if(val.state == 2) {
					var option = "<a name='down'>下架</a>"
					,	state = "<p><span class='state main-tone-bg'>展示中</span></p>"
				}else {
					var option = "<a name='up'>上架</a>"
					,	state = "<p><span class='state orange-bg'>已下架</span></p>"
				}
				if(val.money != 0) {
					reward += "<li offerId='"+val.offerId+"' state='"+val.state+"'>\
									<p class='job'>"+val.positionName+"</p>\
									"+state+"\
									<p class='m'><span class='time' text='发布时间：'>"+val.modifyTime+"</span> | <span class='browse-times' text='浏览次数：'>"+val.count+"</span></p>\
									<p class='btn'><a name='delete'>删除</a> <a  name='break'>刷新</a> <a name='edit'>编辑</a> <a name='firm_preview'>预览</a>"+option+"</p>\
									<span class='ico icon-offer-reward'></span>\
								</li>"
				}else {
					nonReward += "<li offerId='"+val.offerId+"' state='"+val.state+"'>\
									<p class='job'>"+val.positionName+"</p>\
									"+state+"\
									<p class='m'><span class='time' text='发布时间：'>"+val.modifyTime+"</span> | <span class='browse-times' text='浏览次数：'>"+val.count+"</span></p>\
									<p class='btn'><a name='delete'>删除</a> <a name='break'>刷新</a> <a name='edit'>编辑</a> <a name='firm_preview'>预览</a>"+option+"</p>\
								</li>"
				}
			}
		});
		$('#non-reward').find('ul').append(nonReward)
		$('#reward').find('ul').append(reward)
		$('#unpublished').find('ul').append(unpublished)

		next()
	});
}

//$('body').on('click', 'a[name=delete]', function() {
//	var offerId = $(this).parents('li').attr('offerId')
//
//	if(window.confirm('是否删除该简历？')){
//		$.get('/offer/delOffer', {offerId: offerId}, function(data) {
//			data = JSON.parse(data)
//			if(data.code != 0) {
//				alert(data.msg)
//				return false;
//			}
//			window.location.reload()
//		});
//	}
//});


$('body').on('click', 'a[name=break]', function() {
	var offerId = $(this).parents('li').attr('offerId')
	
	$.get('/offer/updateOffer', {offerId: offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log("123",data)
		alert("岗位刷新成功！");
		window.location.reload();
	});
})

$('body').on('click', 'a[name=publish]', function() {
	var offerId = $(this).parents('li').attr('offerId')
	
	$.get('/offer/changePublish', {offerId: offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload()
	});
});

$('body').on('click', 'a[name=up], a[name=down]', function() {
	var offerId = $(this).parents('li').attr('offerId')
	
	$.get('/offer/changeState', {offerId: offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.reload()
	});
});

$('body').on('click', 'a[name=edit]', function() {
	var offerId = $(this).parents('li').attr('offerId')
	window.location.href = 'release.html?offerId='+offerId
});

$('body').on('click', 'a[name=firm_preview]', function() {
	var offerId = $(this).parents('li').attr('offerId')
	window.location.href = 'recruit-details.html?offerId='+offerId
});

//行业、性质、规模
function tradeGetAll(next) {
	$.get('/offertrade/getAll', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#trade').append("<option value='"+val.offerTradeId+"'>"+val.title+"</option>")
		});
		next();
	});
}
function naturalGetAll(next) {
	$.get('/offernature/getAll', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#nature').append("<option value='"+val.offerNatureId+"'>"+val.title+"</option>")
		});
		next();
	});
}
function sizeGetAll(next) {
	$.get('/offersize/getAll', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		$.each(data.data, function(index, val) {
			$('#size').append("<option value='"+val.offerSizeId+"'>"+val.title+"</option>")
		});
		next();
	});
}

function readUrl(){
    var file = document.getElementById('file').files

    $.each(file, function(index, val) {
    	f = val;
    	if(!/image\/\w+/.test(f.type)){  
            alert("看清楚，这个需要图片！");  
            return false;  
        } 
        var reader = new FileReader();
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(f);

        reader.onloadstart = function(e){
        }

        reader.onload = function(e){
        	headImgUrl = this.result
        	mod = 1
	        $('.pic').css({backgroundImage:'url('+this.result+')'});
        }
    });
}

$('#file').change(function() {
	readUrl();
});

function getData() {
	var businessName = $('#businessName').val()
	,	name = $('#name').val()
	,	address = $('#address').val()
	,	contact = $('#contact').val()
	,	trade = $('#trade').val()
	,	nature = $('#nature').val()
	,	size = $('#size').val()
	,	remark = $('#remark').val();

	if(!businessName) {
		alert('请填入企业名称')
		return 0;
	}
	if(!name) {
		alert('请填入联系人姓名')
		return 0;
	}
	if(!address) {
		alert('请填入地址信息')
		return 0;
	}
	if(!trade) {
		alert('请选择所属行业')
		return 0;
	}
	if(!nature) {
		alert('请选择公司性质')
		return 0;
	}
	if(!size) {
		alert('请选择公司规模')
		return 0;
	}

	return {
		businessName: businessName,
		name: name,
		address: address,
		contact: contact,
		trade: trade,
		nature: nature,
		size: size,
		remark: remark,
		headImgUrl: headImgUrl,
		mod: mod,
	};
}

$('#saveInfo').click(function() {
	var data = getData();
	$.post('/fontuser/modFontUserInfo', {data: data}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		window.location.href = 'enterprise-center.html'
	});
});

function applyCv(cvInfo, empty) {
	if(empty) {
		$('.resume-list').find('ul').empty()
	}
	var html = ""
	$.each(cvInfo, function(index, val) {
		allCv[val.cvId] = val

//		if(val.headImgUrl.length==0){
//			var url = "../images/portrait.png"
//		}else{
//			var url = val.headImgUrl
//		}
		if(val.sex==1 || val.sex=="男"){
			var url = "../images/portrait.png"
		}else if(val.sex==2 || val.sex=="女"){
			var url = "../images/portrait02.png"
		}

		if(val.cvCopyId == undefined) {
			var cId = val.cvId
			,	c = 'cvId'
		}else {
			var cId = val.cvCopyId
			,	c = 'cvCopyId'
		}
		
		if(val.workAge==18){
			var text = "应届"
		}else{
			var text = val.workAge+"年"
		}
		
		html += "<li>\
					<a class='con' href='index-preview.html?cvId="+cId+"&c="+c+"' data-ajax='false' cvId='"+cId+"'>\
						<div class='portrait bg-center' id='portrait' style='background-image: url("+url+");'></div>\
						<div class='info'>\
							<p class='name'>"+val.name+"</p>\
							<p class='btn'><span>"+val.age+"岁</span> <span>"+text+"</span> <span>"+val.address+"</span></p>\
							<p class='expect'>在找  <span class='job'>" +val.position+"</span class='expect_span'><br/>期望薪资   <span class='salary orange'>"+val.will+"</span></p>\
						</div>\
					</a>\
				</li>"
							
//					<div class='behind'>\
//						<a class='blue-bg'>更多</a>\
//						<a class='red-bg'>删除</a>\
//					</div>\

	});
	$('.resume-list').find('ul').append(html);
}

$('body').on('click', '.con', function() {
	var cvId = $(this).attr('cvId')
	,	href = "e-resume-preview.html?cvId="+cvId

	window.sessionStorage.setItem('cvInfo', JSON.stringify(allCv[cvId]))

	var login = JSON.parse(window.sessionStorage.getItem('fontUser'))
	if(login['type'] == 3 || login['type'] == 2) {
		console.log(123)
		return false;
	}else {
		window.location.href = href;
	}
});

function getCvInfoByCondition(condition) {
	var selectCvInfo = []
	,	error = 0
	$.each(cvInfo, function(index, val) {
		$.each(condition, function(i, v) {
			if(val[i] != v) {
				error = 1
				return false;
			}
		});
		if(error == 0) {
			selectCvInfo.push(val)
		}else {
			error = 0;
		}
	});
	applyCv(selectCvInfo, 1)
}

function getAllCv(next) {
	$.get('/offercv/getAllCv', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		cvInfo = data.data
		applyCv(cvInfo)
		next();
	});
}

function getAllCvByState(state, city, empty, pageIndex, pageSize, next) {
	$.get('/offercv/getAllCvByState', {state: state, city: city, pageIndex: pageIndex, pageSize:pageSize}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			window.location.href = "../login.html"
		}
		if(pageIndex == 0) {
			cvInfo = data.data
		}else {
			if(data.data) {
				$.each(data.data, function(index, val) {
					cvInfo.push(val)
				});
			}else {
				last = 1;
			}
		}
		applyCv(data.data, empty)
		next();
	});	
}

function applyOffer(object, hr) {
	$('.recruit-list').find('ul').empty()
	var html = ""
	,	fontUser = JSON.parse(window.sessionStorage.getItem('fontUser'))

	if(fontUser == null) {
		hr = 0;
	}else {
		if(fontUser.type == 3) {
			hr = 1
		}else {
			hr = 0
		}
	}
	if(object) {
		$.each(object, function(index, val) {
			if(hr == 1) {
				var money = "<span class='reward-amount' text='元'>"+val.money+"</span>"
				,	href = "h-recruit-details.html"
				,	url = "";
			}else {
				var money = ""
				,	href = "recruit-details.html"
				,	url = "<div class='portrait bg-center' style='background-image: url(../images/picture-loading02.jpg);'></div>"
			}
			var publishDate = val.publishDate.substring(5,10)
			var publishTime = val.publishTime.substring(0,10)
			
			var length = val.comment.length;
			var num = 0;
			if(length>0){
				for (var i=0;i<length;i++) {
					num += parseInt(val.comment[i].degree)
				}
			}
			
			var x = num/length;
		    var y = String(x).indexOf(".") + 1;//获取小数点的位置
		    var count = String(x).length - y;//获取小数点后的个数
		    if(count > 1) {
		        var star = parseFloat(x).toFixed(1)
		    } else {
				var star = num/length
		    }
		    var integer = Math.floor(star/5*100)
			var width = integer+"%"
			
			html += "<li>\
						<a href='"+href+"?offerId="+val.offerId+"' data-ajax='false' data-role='none'>\
							"+url+"\
							"+money+"\
							<div class='info'>\
								<div class='first-column'>\
									<span class='title'>"+val.positionName+"</span>\
									<span class='monthly-pay'>"+val.pay+"</span>\
								</div>\
								<div class='second-column'>\
									<span class='name'>"+val.businessName+"</span>\
									<div class='c-stars_new' style='margin-top:0;'>\
										<div class='c-stars-up_new' style='width:"+width+"'></div>\
									</div>\
								</div>\
								<div class='third-column'>\
									<span class='jobs'>"+val.onfferClassifyTitle+"</span>\
									<span class='welfare'>"+val.offerWelfareName+"</span>\
								</div>\
								<div class='bottom'>\
									<span class='city'>"+val.offerWelfareName+"</span>\
									<span class='date'>"+publishTime+"</span>\
								</div>\
							</div>\
						</a>\
					</li>"
		});
	}
	$('.recruit-list').find('ul').append(html)
}

function applyHrOffer(object) {
	$('.recruit-list').find('ul').empty()
	var html = ""
	
	if(object) {
		$.each(object, function(index, val) {
			var publishDate = val.publishDate.substring(5,10)
			var modifyTime = val.modifyTime.substring(0,10)

			html += "<li>\
						<a href='h-recruit-details.html?offerId="+val.offerId+"' data-ajax='false' data-role='none'>\
							<span class='reward-amount' text='元'>"+val.money+"</span>\
							<div class='info'>\
								<div class='first-column'>\
									<span class='title'>"+val.positionName+"</span>\
									<span class='monthly-pay'>"+val.pay+"</span>\
								</div>\
								<div class='second-column'>\
									<span class='name'>"+val.businessName+"</span>\
								</div>\
								<div class='third-column'>\
									<span class='jobs'>"+val.onfferClassifyTitle+"</span>\
									<span class='welfare'>"+val.offerWelfareName+"</span>\
								</div>\
								<div class='bottom'>\
									<span class='city'>"+val.offerWelfareName+"</span>\
									<span class='date'>"+val.publishDate+"</span>\
								</div>\
							</div>\
						</a>\
					</li>"
		});
	}
	$('.recruit-list').find('ul').append(html)
}

function getAllOffer(offerCondition, next) {
	$.get('/AllOffer', {offerCondition: offerCondition}, function(data) {
		data = JSON.parse(data)
		console.log(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allOffer = data.data
		applyOffer(allOffer)
		if(next) next();
	});
}

function getOfferByIndex($offerCondition, pageIndex, pageSize, next) {
	var text = $('#city').val()
	console.log(text)
	if(text == "不限"){
		delete offerCondition.city;
//		pageIndex = 0;
	}
	console.log("弹出来","offerCondition",offerCondition,"pageIndex",pageIndex,"pageSize",pageSize)
	$.get('/offer/getAllOffer', {offerCondition: offerCondition, pageIndex: pageIndex, pageSize: pageSize}, function(data) {
		data = JSON.parse(data)
		console.log(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allOffer = data.data
		console.log("allOffer",allOffer)
		applyOfferByPage(allOffer, 0)
		if(next) next();
	});
}

function applyOfferByPage(object, hr) {
	var html = ""
	,	fontUser = JSON.parse(window.sessionStorage.getItem('fontUser'))

	// if(fontUser == null) {
	// 	hr = 0;
	// }else {
	// 	if(fontUser.type == 3) {
	// 		hr = 1
	// 	}else {
	// 		hr = 0
	// 	}
	// }
	// hr = 0
	$.each(object, function(index, val) {
		if(hr == 1) {
			var money = "<span class='reward-amount' text='元'>"+val.money+"</span>"
			,	href = "h-recruit-details.html"
			,	url = "";
		}else {
			var money = ""
			,	href = "recruit-details.html"
			,	url = "<div class='portrait bg-center' style='background-image: url(../images/picture-loading02.jpg);'></div>"
		}
		console.log(hr)
		var publishDate = val.publishDate.substring(5,10)
		var publishDate = val.publishDate.substring(0,10)
		
		var length = val.comment.length;
		var num = 0;
		if(length>0){
			for (var i=0;i<length;i++) {
				num += parseInt(val.comment[i].degree)
			}
		}
		
		var x = num/length;
	    var y = String(x).indexOf(".") + 1;//获取小数点的位置
	    var count = String(x).length - y;//获取小数点后的个数
	    if(count > 1) {
	        var star = parseFloat(x).toFixed(1)
	    } else {
			var star = num/length
	    }
	    var integer = Math.floor(star/5*100)
		var width = integer+"%"
		
		html += "<li>\
					<a href='"+href+"?offerId="+val.offerId+"' data-ajax='false' data-role='none'>\
						"+url+"\
						"+money+"\
						<div class='info'>\
							<div class='first-column'>\
								<span class='title'>"+val.positionName+"</span>\
								<span class='monthly-pay'>"+val.pay+"</span>\
							</div>\
							<div class='second-column'>\
								<span class='name'>"+val.businessName+"</span>\
								<div class='c-stars_new' style='margin-top:0;'>\
									<div class='c-stars-up_new' style='width:"+width+"'></div>\
								</div>\
							</div>\
							<div class='third-column'>\
								<span class='jobs'>"+val.onfferClassifyTitle+"</span>\
								<span class='welfare'>"+val.offerWelfareName+"</span>\
							</div>\
							<div class='bottom'>\
								<span class='city'>"+val.offerWelfareName+"</span>\
								<span class='date'>"+publishDate+"</span>\
							</div>\
						</div>\
					</a>\
				</li>"
	});
	$('.recruit-list').find('ul').append(html)
}

// function getOfferByCondition(condition) {
// 	var selectOffer = []
// 	,	error = 0
// 	$.each(allOffer, function(index, val) {
// 		$.each(condition, function(i, v) {
// 			if(val[i] != v) {
// 				error = 1
// 				return false;
// 			}
// 		});
// 		if(error == 0) {
// 			selectOffer.push(val)
// 		}else {
// 			error = 0;
// 		}
// 	});
// 	applyCv(selectOffer)
// }

function getOffer(offerId) {
	$.get('/offer/get', {offerId: offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}

		var price = data.data.pay
		,	pos = price.split('-')
		,	left_pay = pos[0]
		,	right_pay = pos[1]
		console.log(right_pay)
		if(price=="面议"){
			$("#face").addClass('faceChange')
		}else{
			left_pay = left_pay.split('K')[0]
			right_pay = right_pay.split('K')[0]
			
			data.data.left_pay = left_pay
			data.data.right_pay = right_pay
		}

		$.each(data.data, function(index, val) {
			$('#'+index).val(val)
		});
		if(data.data.money > 0) {
			$('.slide-switch').trigger('click')
		}
		var classifyTitle = data.data.classifyTitle
		console.log(classifyTitle)
		$('#offerClassifyId').val(classifyTitle)
		
		var classifyId = data.data.offerClassifyId
	    var offerClassifyId = $('#offerClassifyId').attr('offerClassifyId',classifyId)
		console.log(classifyId)
		
		var welfareId = data.data.offerWelfareId
//	    var offerWelfareId = $('#offerWelfareId').attr('offerWelfareId',classifyId)
		console.log(welfareId)
		if(welfareId) {
			for(var i = 0; i<welfareId.length;i++) {
				$("a[offerwelfareid='"+welfareId[i]+"']").addClass('current')
			}
		}
	});
}

//招聘职位搜索
$('body').on('click', '#search-input', function(e) {
//	searchShow()
	$('#header').css({
		'background': '#33a1b7',
		'z-index': '15'
	});
	$(this).attr("readonly",false);	
});

//$('body').on('blur', '#search-input', function() {
//	searchHide()
////	$('#header').css({
////		'background': '#33a1b7',
////		'z-index': '15'
////	});
////	$(this).attr("readonly",false);
//});

$('body').on('click', '.guanbi', function() {
	searchHide()
});

//添加查询记录
function addSearchRecord(title) {
	if(!title) {
		alert('请填写查询描述')
		return false;
	}
	$.get('/offersearchrecord/addSearch', {title: title}, function(data) {
//		$('#search-input').val(data)
		data = JSON.parse(data)
//		alert(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		// var login = window.sessionStorage.getItem('fontUser')
		// if(login) {

		// }else {
		// 	window.location.href = 'job-list.html?title='+encodeURI(encodeURI(title));
		// }
		window.location.href = 'job-list.html?title='+encodeURI(encodeURI(title));
	});
}

// search val
$('body').on('click', '#search-popup .list a, .history-record li', function() {
	
	if($(this).find('span').hasClass('ico')) {
		//li
		var text = $(this).find('a').text()
	}else {
		//a
		var text = $(this).children('span').text()
	}
	$('#search-input').val(text)
	
	searchHide()
	$('#header').css({
		'background': 'rgba(255,255,255,0)',
		'z-index': '15'
	});
	
	console.log("文字啊文字",text)
	
	addSearchRecord(text);
});

$('.icon-search1').click(function() {
	var title = $('#search-input').val()
//	alert(title)
	addSearchRecord(title);
});

function getOfferByTitle(next) {
	var title = GetQueryString('title')
	$.get('/offer/getOfferByTitle', {title: title}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allOffer = data.data
		applyOffer(allOffer)
		next();
	});
}

function getMoneyOfferByTitle(next) {
	var title = GetQueryString('title')
	$.get('/offer/getMoneyOfferByTitle', {title: title, city: $('#city').val()}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		allOffer = data.data
		applyHrOffer(allOffer)
		next();
	});
}

function compare(property){
    return function(a,b){
        var value1 = a[property];
        var value2 = b[property];
        return value2 - value1;
    }
}

function getOfferWelfareByList(next) {
	$.get('/offerwelfare/getByUserId', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var html = ""
		$.each(data.data, function(index, val) {
			html += "<a href='' data-ajax='false' data-role=''><span>"+val.title+"</span></a>"
		});
		$('#more').find('.list').append(html)
		next()
	});
}

function createOfferCondition(name) {
	var div = $("div[name='"+name+"']").find('.current')
	if(div.length > 0) {
		offerCondition[name] = div.find('span').text()
	}else {
		delete offerCondition[name]
	}
	localStorage.setItem("hrOfferCondition", JSON.stringify(offerCondition));
}

//筛选条件
$('.confirm').click(function() {
	createOfferCondition('educational')
	createOfferCondition('workExperience')
	createOfferCondition('offerWelfareName')
	createOfferCondition('pay')
	createOfferCondition('money')
	
	hideSlect()
	getConditionOffer();
});

$("a[name='hrConfirm']").click(function() {
	createOfferCondition('educational')
	createOfferCondition('workExperience')
	createOfferCondition('offerWelfareName')
	createOfferCondition('pay')
	createOfferCondition('money')
	
	hideSlect()
	getConditionOfferByHr();
});

function localGetConditionOffer(offerCondition) {
	var selectOffer = []
	,	error = 0
	,	money = 0

	$.each(allOffer, function(index, val) {
		$.each(offerCondition, function(i, v) {
			if(val[i]) {
				if(i == 'offerWelfareName') {
					if(v != '不限') {
						if(val[i].indexOf(v) < 0) {
							error = 1
							return false;
						}
					}
				}else if(i == 'money') {
					money = 1
				}else {
					if(v != '不限') {
						if(val[i] != v) {
							error = 1
							return false;
						}
					}
				}
			}else {
				error = 1;
			}
			
		});
		if(error == 0) {
			selectOffer.push(val)
		}else {
			error = 0;
		}
	});

	if(money == 1) {
		selectOffer.sort(compare('money'))
	}

	applyOffer(selectOffer)

	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
}

function getConditionOffer() {
	var selectOffer = []
	,	error = 0
	,	money = 0

	$.each(allOffer, function(index, val) {
		$.each(offerCondition, function(i, v) {
			if(val[i]) {
				if(i == 'offerWelfareName') {
					if(v != '不限') {
						if(val[i].indexOf(v) < 0) {
							error = 1
							return false;
						}
					}
				}else if(i == 'money') {
					if(v == '悬赏排序') {
						money = 1
					}
				}else {
					if(v != '不限') {
						if(val[i] != v) {
							error = 1
							return false;
						}
					}
				}
			}else {
				error = 1;
			}
			
		});
		if(error == 0) {
			selectOffer.push(val)
		}else {
			error = 0;
		}
	});

	if(money == 1) {
		selectOffer.sort(compare('money'))
	}

	applyOffer(selectOffer)

	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
}

function getConditionOfferByHr() {
	var selectOffer = []
	,	error = 0
	,	money = 0

	$.each(allOffer, function(index, val) {
		$.each(offerCondition, function(i, v) {
			if(val[i]) {
				if(i == 'offerWelfareName') {
					if(v != '不限') {
						if(val[i].indexOf(v) < 0) {
							error = 1
							// return false;
						}
					}
				}else if(i == 'money') {
					if(v == '悬赏排序') {
						money = 1
					}
				}else {
					if(v != '不限') {
						if(val[i] != v) {
							error = 1
							// return false;
						}
					}
				}
			}else {
				error = 1;
			}
			
		});
		if(error == 0) {
			selectOffer.push(val)
		}else {
			error = 0;
		}
	});

	if(money == 1) {
		selectOffer.sort(compare('money'))
	}
	applyHrOffer(selectOffer)

	$('body').removeClass('disable-scrolling')
	$('html').removeClass('disable-scrolling')
}

function getOfferByOfferId(next) {
	var offerId = GetQueryString('offerId')
	$.get('/offer/getAllDetail', {offerId: offerId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log("哈哈哈",data.data);
		payShare = data.data.pay;
		positionNameShare =  data.data.positionName;
		moneyShare = data.data.money-data.data.plaformReceive;
		$("#businessNameTwo").text(data.data.businessName);
		$.each(data.data, function(index, val) {
			if(index == 'position') {
				$('#position').html(val)
			}else if(index == 'contact') {
				$('#callPhone').attr('href', "tel:"+val);
			}else {
				$("#"+index).text(val)
			}
		});
		
				
		console.log(data.data)
		var length = data.data.comment.length;
		var num = 0;
		if(length>0){
			for (var i=0;i<length;i++) {
				num += parseInt(data.data.comment[i].degree)
			}
		}
		
		var x = num/length;
	    var y = String(x).indexOf(".") + 1;//获取小数点的位置
	    var count = String(x).length - y;//获取小数点后的个数
	    if(count > 1) {
	        var star = parseFloat(x).toFixed(1)
	    } else {
			var star = num/length
	    }
	    var integer = Math.floor(star/5*100)
		var width = integer+"%"

		var starHtml = '<div class="c-stars-up-detail" style="width:'+width+'"></div>'
		$(".c-stars-detail").append(starHtml);

		var fontUserId = data.data.fontUserId
		var offerId = data.data.offerId
		var member = data.data.member
		
		$("#ranking_btn").attr("fontUserId",fontUserId)
		
		if(member=="1"){
			$("#member").hide();
		}else if(member=="2"){
				$("#member").show();
		}
		$(".more_resumes").attr("fontUserId",fontUserId)
		$(".more_resumes").attr("offerId",offerId)
		next();
	});
}

//投递简历
function sendCopyCv(offerId, cvId) {
	$.get('/offercvcopy/sendCopyCv', {offerId: offerId, cvId: cvId}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('投递成功')
		window.location.reload();
	});
}

//企业查看自己的简历
//function myCopyCv(next) {
//	$.get('/offercvcopy/myCopyCv', {}, function(data) {
//		data = JSON.parse(data)
//		if(data.code != 0) {
//			alert(data.msg)
//			return false;
//		}
//		console.log(data)
//		$.each(data.data, function(index, val) {
//			var name = encodeURI(encodeURI(val.name))
//			if(val.type == 1) {
//				if(val.look == 1) {
//					var option = "<div class='behind'>\
//									<a class='gray-bg' data-ajax='false' href='e-resume-preview.html?cvCopyId="+val.cvCopyId+"'>查看简历</a>\
//									<a class='red-bg' name='delete'>删除</a>\
//								</div>"
//					applyCopyCv($('#jsd-not').find('ul'), val, option)
//				}else {
//					var option = "<div class='behind'>\
//									<a class='gray-bg' data-ajax='false' href='e-resume-preview.html?cvCopyId="+val.cvCopyId+"'>查看简历</a>\
//									<a class='blue-bg' data-ajax='false' href='business-invitation.html?cvId="+val.cvCopyId+"&name="+name+"'>邀请</a>\
//									<a class='red-bg' name='delete'>删除</a>\
//								</div>"
//					applyCopyCv($('#jsd-already').find('ul'), val, option)
//				}
//			}else if(val.type == 2) {
//				if(val.pay == 2) {
//					var option = "<div class='behind'>\
//									<a class='gray-bg' data-ajax='false' href='e-resume-preview.html?cvCopyId="+val.cvCopyId+"'>查看简历</a>\
//									<a class='green-bg' data-ajax='false' href='javascript:;' name='comment'>评价</a>\
//									<a class='red-bg' name='delete'>删除</a>\
//								</div>"
//					applyCopyCv($('#hp-payment').find('ul'), val, option)
//				}
//				if(val.look == 1) {
//					var option = "<div class='behind'>\
//									<a class='gray-bg' data-ajax='false' href='e-resume-preview.html?cvCopyId="+val.cvCopyId+"'>查看简历</a>\
//									<a class='red-bg' name='delete'>删除</a>\
//								</div>"
//					applyCopyCv($('#hp-not').find('ul'), val, option)
//				}else {
//					var option = "<div class='behind'>\
//									<a class='gray-bg' data-ajax='false' href='e-resume-preview.html?cvCopyId="+val.cvCopyId+"'>查看简历</a>\
//									<a class='red-bg' name='delete'>删除</a>\
//								</div>"
//					applyCopyCv($('#hp-already').find('ul'), val, option)
//				}
//			}
//		});
//
//		next();
//	});

//						<span class='icon-prev'></span>\

//}
function myCopyCv(next) {
	$.get('/offercvcopy/myCopyCv', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data)
		$.each(data.data, function(index, val) {
			var name = encodeURI(encodeURI(val.name));
			console.log()
			if(val.type == 1) {
				if(val.look == 1) {
					var option = "<div class='behind'>\
									<a class='blue-bg' inside='1' style='opacity:0'>邀请</a>\
									<a class='red-bg' name='delete'>删除</a>\
								</div>"
					applyCopyCv($('#jsd-not').find('ul'), val, option)
				}else {
					
					if(val.interview == 2 || val.interview == 3){
						var text = "<a class='blue-bg' data-ajax='false' inside='2'>已邀请</a>"
					}else{
						var text = "<a class='blue-bg' data-ajax='false' href='business-invitation.html?cvId="+val.cvCopyId+"&name="+name+"' inside='1'>邀请</a>"
					}
					
					var option = "<div class='behind'>\
									"+text+"\
									<a class='red-bg' name='delete'>删除</a>\
								</div>"
					
					applyCopyCv($('#jsd-already').find('ul'), val, option)
				}
			}else if(val.type == 2) {
				if(val.pay == 2) {
					var option = "<div class='behind'>\
									<a class='green-bg' data-ajax='false' href='javascript:;' name='comment'>评价</a>\
									<a class='red-bg' name='delete'>删除</a>\
								</div>"
					applyCopyCv($('#hp-payment').find('ul'), val, option)
				}
				if(val.look == 1) {
					var option = "<div class='behind'>\
									<a class='red-bg' name='delete'>删除</a>\
								</div>"
					applyCopyCv($('#hp-not').find('ul'), val, option)
				}else {
					var option = "<div class='behind'>\
									<a class='red-bg' name='delete'>删除</a>\
								</div>"
					applyCopyCv($('#hp-already').find('ul'), val, option)
				}
			}
		});

		next();
	});
}

function applyCopyCv(jqueryObj, cvInfo, option) {
	// jqueryObj.empty()
	allCv[cvInfo.cvCopyId] = cvInfo
	
	if(cvInfo.sex==1 || cvInfo.sex == "男"){
		var url = "../images/portrait.png"
	}else if(cvInfo.sex==2 || cvInfo.sex == "女"){
		var url = "../images/portrait02.png"
	}
	
	var workAge = cvInfo.workAge
	if(workAge == 18){
		var workage ='<span>应届</span>'
		
	}else{
		var workage = '<span>'+workAge+'年</span>'
	}
	
	var createTime = cvInfo.createTime.substring(0,10)
	if(cvInfo.offerInfo.length>0){
		var positionNamePost = "<p class='expect'>投递岗位   <span class='job'>"+cvInfo.offerInfo[0].positionName+"</span class='expect_span'>"
	}else{
		var positionNamePost = "<p class='expect'>在找   <span class='job'>"+cvInfo.offerClassifyTitle+"</span class='expect_span'>"
	}
	var html = "<li cvId='"+cvInfo.cvCopyId+"' author='"+cvInfo.author+"' name='gogogo'>\
					<a class='con' href='javascript:;' data-ajax='false' cvId='"+cvInfo.cvCopyId+"'>\
						<div class='portrait bg-center' style='background-image: url("+url+");'></div>\
						<div class='info'>\
							<p class='name'>"+cvInfo.name+"</p>\
							<p class='btn'><span>"+cvInfo.age+"岁</span> "+workage+" <span>"+cvInfo.address+"</span></p>\
							"+positionNamePost+"<br/>期望薪资   <span class='salary orange'>"+cvInfo.will+"</span></p>\
							<p class='delivery'>投递时间："+createTime+"</p>\
						</div>\
					</a>\
					"+option+"\
				</li>"
	jqueryObj.append(html);
}

function lookCv(cvId) {
	$.get('/offercvcopy/lookCv', {cvId: cvId}, function(data) {
	});
}

function fontGetConfig(next) {
	$.get('/offermemberconfig/fontGetConfig', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(data.data != 0) {
			$('span[name=money]').text(data.data.moneyShow)
			next();
		}
	});
}

//开通会员
$('#buyMember').click(function() {
	if(confirm('确定开通会员吗？')) {
		$.get('/fontuser/buyMember', {}, function(data) {
			data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			window.location.reload();
		});
	}
});

function myCollectByBusiness(){
	$.get('/offercvcopy/myCollectByBusiness', function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data)
		var collect = data.data
		var html = "";
		$.each(collect, function(index, cvInfo) {
			
			allCv[cvInfo.cvCopyId] = cvInfo
			
			console.log(cvInfo.sex)
			
			if(cvInfo.sex==1 || cvInfo.sex == "男"){
				var url = "../images/portrait.png"
			}else if(cvInfo.sex==2 || cvInfo.sex == "女"){
				var url = "../images/portrait02.png"
			}
			
			var workAge = cvInfo.workAge
			if(workAge == 18){
				var workage = '<span>应届</span>'
				
			}else{
				var workage = '<span>'+workAge+'年</span>'
			}
			
			html += "<li cvId='"+cvInfo.cvCopyId+"' author='"+cvInfo.author+"' name='gogogo'>\
							<a class='collect-a' href='javascript:;' data-ajax='false' cvId='"+cvInfo.cvCopyId+"'>\
								<div class='portrait bg-center' style='background-image: url("+url+");'></div>\
								<div class='info'>\
									<p class='name'>"+cvInfo.name+"</p>\
									<p class='btn'><span>"+cvInfo.age+"岁</span>"+workage+"<span>"+cvInfo.address+"</span></p>\
									<p class='expect'>在找<span class='job'>"+cvInfo.position+"</span class='expect_span'><br/>期望薪资   <span class='salary orange'>"+cvInfo.will+"</span></p>\
								</div>\
							</a>\
						</li>"

		});
		$('#collect-ul').append(html)
	});
}

$('body').on('click', '.collect-a', function() {
	var cvId = $(this).attr('cvId')
	,	href = "merchant-collect.html?cvCopyId="+cvId
	console.log(cvId)
	
	window.sessionStorage.setItem('cvInfo', JSON.stringify(allCv[cvId]))

	window.location.href = href;
//	var login = JSON.parse(window.sessionStorage.getItem('fontUser'))
//	console.log(login['type'])
//	
//	if(login['type'] == 3 || login['type'] == 2) {
//		console.log(123)
//		return false;
//	}else {
//		window.location.href = href;
//	}
});

function getBrowse(){
	$.get('/fontuser/browse', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
	})
}


function readyGo(){
	var desc = "岗位："+positionNameShare+"\n"+"薪资："+payShare;
	console.log(desc)
	wx.onMenuShareAppMessage({
		title: '岗位详情', // 分享标题
		desc: desc, // 分享描述
		link: '', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
		imgUrl: 'http://10081.medhr.co/10081/images/share.png', // 分享图标
		type: '', // 分享类型,music、video或link，不填默认为link
		dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
		success: function () {
		// 用户确认分享后执行的回调函数
		},
		cancel: function () {
		// 用户取消分享后执行的回调函数
		}
	});
}


function readyGoHrDetail(){
	var desc = "岗位："+positionNameShare+"\n"+"赏金："+moneyShare+"元";
	wx.onMenuShareAppMessage({
		title: '岗位详情', // 分享标题
		desc: desc, // 分享描述
		link: '', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
		imgUrl: 'http://10081.medhr.co/10081/images/share.png', // 分享图标
		type: '', // 分享类型,music、video或link，不填默认为link
		dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
		success: function () {
		// 用户确认分享后执行的回调函数
		},
		cancel: function () {
		// 用户取消分享后执行的回调函数
		}
	});
}
