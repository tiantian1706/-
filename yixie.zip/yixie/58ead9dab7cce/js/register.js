//用于压缩图片的canvas
var canvas = document.createElement("canvas");
var ctx = canvas.getContext('2d');
//瓦片canvas
var tCanvas = document.createElement("canvas");
var tctx = tCanvas.getContext("2d");
var maxsize = 100 * 1024;

//使用canvas对大图片进行压缩
function compress(img) {
    var initSize = img.src.length;
    var width = img.width;
    var height = img.height;
    //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
    var ratio;
    if ((ratio = width * height / 4000000) > 1) {
      	ratio = Math.sqrt(ratio);
      	width /= ratio;
      	height /= ratio;
    } else {
      	ratio = 1;
    }
    canvas.width = width;
    canvas.height = height;
    //铺底色
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    //如果图片像素大于100万则使用瓦片绘制
    var count;
    if ((count = width * height / 1000000) > 1) {
      	count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
    		//计算每块瓦片的宽和高
      	var nw = ~~(width / count);
      	var nh = ~~(height / count);
      	tCanvas.width = nw;
      	tCanvas.height = nh;
      	for (var i = 0; i < count; i++) {
	        for (var j = 0; j < count; j++) {
	          	tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);
	          	ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
	        }
  		}
    } else {
      	ctx.drawImage(img, 0, 0, width, height);
    }
    //进行最小压缩
    var ndata = canvas.toDataURL('image/jpeg', 0.1);
    console.log('压缩前：' + initSize);
    console.log('压缩后：' + ndata.length);
    console.log('压缩率：' + ~~(100 * (initSize - ndata.length) / initSize) + "%");
    tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
    return ndata;
}


function checkAndGetData(fontUserType) {
	var div = $('div[fontUserType='+fontUserType+']')
	,	phone = div.find('input[name=phone]').val()
	,	password = div.find('input[name=password]').val()
	,	repassword = div.find('input[name=repassword]').val()
	,	businessName = div.find('input[name=businessName]').val()
	,	governor = div.find('input[name=governor]').val()
	,	code = div.find('input[name=code]').val()
	,	img1 = $('#file1').siblings('img').attr('src')
	,	img2 = $('#file2').siblings('img').attr('src')
	,	img3 = $('#file3').siblings('img').attr('src')
	,	img4 = $('#file4').siblings('img').attr('src')
	,	img5 = $('#file5').siblings('img').attr('src')
	,	myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1}))+\d{8})$/
	,	error = 0;

	if(!password) {
		alert('密码不能为空')
		error = 1
		return error;
	}
	if(password.length < 6) {
		alert('请输入至少6位数的密码')
		error = 1
		return error;
	}
	if(password != repassword) {
		alert('密码与确认密码不一致')
		error = 1
		return error;
	}

	if(!code) {
		alert('请输入验证码');
		error = 1
		return error;
	}

	if(fontUserType == 2 || fontUserType == 3) {
		if(fontUserType == 2) {
			if(!businessName) {
				alert('请输入企业名称')
				error = 1
				return error;
			}
			if(!img1) {
				alert('请上传营业执照')
				error = 1
				return error;
			}
		}
		if(!governor) {
			alert('请输入管理人姓名')
			error = 1
			return error;
		}

		if(fontUserType == 3) {
			if(!img2) {
				alert('请上传身份证正面')
				error = 1
				return error;
			}
			if(!img3) {
				alert('请上传身份证反面')
				error = 1
				return error;
			}
			if(!img4) {
				alert('请上传工作证正面')
				error = 1
				return error;
			}
			if(!img5) {
				alert('请上传工作证反面')
				error = 1
				return error;
			}
		}
	}

	if(error == 0) {
		return {
			phone: phone,
			password: password,
			repassword: repassword,
			code: code,
			businessName: businessName,
			governor: governor,
			bl: img1,
			idCard1: img2,
			idCard2: img3,
			workCard1: img4,
			workCard2: img5,
		}
	}else {
		return error;
	}
}

function readUrl(fontUserType, index, id){
    var file = document.getElementById(id).files
    ,	div = $('div[fontUserType='+fontUserType+']')
    ,	fileDiv = div.find('.file').eq(index)

    $.each(file, function(index, val) {
    	f = val;
    	if(!/image\/\w+/.test(f.type)){  
            alert("看清楚，这个需要图片！");  
            return false;  
        } 
        var reader = new FileReader();
        //将文件以Data URL形式读入页面
        reader.readAsDataURL(f);

        reader.onloadstart = function(e){
        	var html = "<img src='' />";
	        fileDiv.prepend(html);
        }

        reader.onload = function(e){
	        // fileDiv.find('img').attr('src', this.result);
	        var image = new Image();  
            image.src = this.result; 

            image.onload = function() {
	        	var newData = compress(image)
	        	fileDiv.find('img').attr('src', newData);
            }
        }
    });
}

$('input[type=file]').change(function() {
    var fontUserType = $(this).parents(".login-form").attr('fontUserType')
    ,	index = $(this).parent('.file').attr('index')
    ,	id = $(this).attr('id')

    readUrl(fontUserType, index, id)
    // handleFileSelect()
});

//register
$('.submit').click(function() {	
	var fontUserType = $(this).parents('.login-form').attr('fontUserType')
	,	result = checkAndGetData(fontUserType)
	if(result == 1) {
		return false;
	}

	$.post('/fontuser/register', {fontUserType: fontUserType, data: result}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		if(fontUserType != 1){
			alert('提交成功 等待审核')
		}else {
			alert('注册成功')
		}
//		window.location.reload();
		window.location.href = "login.html"
	});
});

function sendCode(phone, register) {
	$.get('/fontuser/sendCode', {phone: phone, register: register}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('验证码已经发送，请注意查收')
	});
}

function sendEmailCode(email) {
	$.get('/fontuser/sendEmailCode', {email: email}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		alert('验证码已经发送，请注意查收')
	});
}