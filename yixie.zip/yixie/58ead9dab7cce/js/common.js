var href = location.href
if(href != 'http://10081.medhr.co/10081/hr/job-list.html' && href.indexOf('/hr/h-recruit-details.html') < 0) {
    localStorage.removeItem("hrOfferCondition")
}
function checkMustLogin(type, next) {
	$.get('/fontuser/checkMustLogin', {}, function(data) {
		data = JSON.parse(data)
		console.log(data)
		if(data.code != 0) {
//			alert(data.msg)
            window.location.href = "../login.html"
			return false;
		}
		if(data.data.type != type) {
//			alert('用户类型非法')
            window.location.href = "../login.html"
			return false;
		}
		window.sessionStorage.setItem('fontUser', JSON.stringify(data.data.info))
		window.sessionStorage.setItem('detail', JSON.stringify(data.data.detail))
		next();
	});
}

function checkMustHandLogin(next) {
    $.get('/clientlogin/islogin', {}, function (data) {
        data = JSON.parse(data);
        if (data.code != 0) {
            location.href = buildQueryUrl('/clientlogin/wxHandLogin', {
                callback: location.href
            });

            return;
        }
        clientId = data.data;
        myData.clientId = clientId;
        next();
    });
}

function buildQueryUrl(url, urlArgv) {
    for (var i in urlArgv) {
        if (url.indexOf('?') == -1)
            url += '?';
        else
            url += '&';
        url += i + '=' + encodeURIComponent(urlArgv[i]);
    }
    return encodeURI(url);
}

function getOfferClassify(jqueryObj, next) {
	$.get('/offerclassify/getOfferClassify', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			window.location.href = '../login.html'
			return false;
		}
		data = data.data;
		var html = ""
		$.each(data, function(index, val) {
			var list = "";
			if(val._child) {
				$.each(val._child, function(i, v) {
					list += "<a data-ajax='false' data-role='none'><span offerClassifyId='"+v.offerClassifyId+"'>"+v.title+"</span></a>"
				});
			}
			html += "<div class='list-box'>\
						<div class='title' style='background-color: rgb(237, 242, 246);cursor: pointer;'>\
							<span class='ico icon-collection1'></span>\
							<i class='text'>"+val.title+"</i>\
						</div>\
						<div class='list list-margin' style='display:none'>\
							"+list+"\
						</div>\
					</div>"
		});
		jqueryObj.append(html)
		next();
	});
}

function GetQueryString(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if(r!=null)return  unescape(r[2]); return '';
}

//注入微信权限
function getJsConfig(next) {
    $.get('/redpack/getJsConfig', {
        url: location.href
    }, function (data) {
        data = JSON.parse(data);
        if (data.code != 0) {
            alert(data.msg);
            return;
        }
        data = data.data;

        wx.config({
            debug: false, // 开启调试模式
            appId: data.appId, // 必填，公众号的唯一标识
            timestamp: data.timestamp, // 必填，生成签名的时间戳
            nonceStr: data.nonceStr, // 必填，生成签名的随机串
            signature: data.signature, // 必填，签名，见附录1
            jsApiList: ['chooseWXPay', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'openLocation', 'getLocation'] // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
        });
        wx.error(function (res) {
            // console.log(123123213)
            // alert(res);
        })
        next();
    });
}

function getSearchRecord() {
    $.get('/offersearchrecord/getSearchRecord', {}, function(data) {
        data = JSON.parse(data);
        if (data.code != 0) {
            alert(data.msg);
            return;
        }

        var like = data.data.like
        ,   record = data.data.record;

        if(like) {
            $.each(like, function(index, val) {
                $('#like').append("<a><span>"+val.title+"</span></a>")
            });
        }

        if(record) {
            $.each(record, function(index, val) {
                $('#record').append("<li><span class='ico icon-time'></span><a href='javascript:;'>"+val.title+"</a></li>")
            });
        }

        $('body').on('click', '#removeAllSearch', function() {
            $.get('/offersearchrecord/removeAllSearch', {}, function(data) {
            });
        });
    });
}
