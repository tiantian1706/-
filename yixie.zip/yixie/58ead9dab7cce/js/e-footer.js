function footer(next) {
	var nav = "<div class='footer-navbar'>\
					<ul>\
						<li><a href='index.html' data-ajax='false'><span class='ico icon-index'></span>首页</a></li>\
						<li><a data-ajax='false' class='judge'><div class='release'><span class='ico icon-add'></span></div><span class='ico icon-add opacity'></span>发布</a></li>\
						<li><a href='enterprise-center.html' data-ajax='false'><span class='ico icon-mine'></span>我的</a><i class='red_dot red_footer'></i></li>\
					</ul>\
				</div>"
	$('.warper').append(nav);
	next();
};

function judge(){
	$.get('/fontuser/checkMustLogin', {}, function(data) {
		var data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		var detail = data.data.detail;
		$("body").on("click",".judge",function(){
			if(detail==null){
				alert('请完善企业信息后再发布岗位');
				window.location.href='enterprise-information.html';
			}else{
				window.location.href='release.html';
			}
		})
	})
}
