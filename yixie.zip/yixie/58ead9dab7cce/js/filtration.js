function footer() {
	var nav = "<div class='footer-navbar'>\
				<div class='item pitch'><span class='ico icon-index'></span>校园招聘</div>\
				<div class='item'><span class='ico icon-search'></span>高校排名</div>\
				<div class='item'><span class='ico icon-mine'></span>高校登陆</div>\
			</div>"
	$('.warper').append(nav);
};