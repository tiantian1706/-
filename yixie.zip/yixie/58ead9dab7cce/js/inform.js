var list = {}
,	msgIdArr = JSON.parse(window.sessionStorage.getItem('msgIdArr'))
;
function getMsgList(red){
		$.get('/systemmsg/msgList',function(data) {
			var data = JSON.parse(data)
			if(data.code != 0) {
				alert(data.msg)
				return false;
			}
			var allmsgList=data.data
			list = allmsgList
			window.sessionStorage.setItem('allmsgList', JSON.stringify(allmsgList))
			var html = ""
			$.each(allmsgList, function(index, val) {
						var time = val.modifyTime.substring(0,10)
				    	html += '<a class="item" href="inform-detail.html?msgId='+val.msgId+'">\
					    			<div>\
					    				<h3>'+val.title+'</h3>\
					    				<p>'+time+'</p>\
					    			</div>\
					    			<span class="ico2 icon-down"></span>\
					    		</a>'
						if(red) {
							if(msgIdArr) {
								var result = isInArray(msgIdArr, val.msgId)
								if(!result) {
									msgIdArr.push(val.msgId)
									window.sessionStorage.setItem('msgIdArr', JSON.stringify(msgIdArr))
								}
							}else {
								var arr = []
								arr.push(val.msgId)
								window.sessionStorage.setItem('msgIdArr', JSON.stringify(arr))
								msgIdArr = JSON.parse(window.sessionStorage.getItem('msgIdArr'))
							}
						}
			})
			$(".terrace-inform").append(html)
			
			getMsgListRed();
		})
}
function getMsgListDetail(){
	var allmsgList = JSON.parse(window.sessionStorage.getItem('allmsgList'))
	
	if(allmsgList != null){

		var msgId = GetQueryString("msgId")
		
//		if(msgIdArr) {
//			var result = isInArray(msgIdArr, msgId)
//			if(!result) {
//				msgIdArr.push(msgId)
//				window.sessionStorage.setItem('msgIdArr', JSON.stringify(msgIdArr))
//			}
//		}else {
//			var arr = []
//			arr.push(msgId)
//			window.sessionStorage.setItem('msgIdArr', JSON.stringify(arr))
//		}
		
		console.log("什么鬼",allmsgList,msgId)
		var html = ""
		$.each(allmsgList, function(index, val) {
			if(val.msgId == msgId){
				var time = val.modifyTime.substring(0,10)
		    	html += '<h3>'+val.title+'</h3>\
    					<p>'+time+'</p>\
    					<pre>'+val.content+'</pre>'
			}
		})
		$(".inform-detail-content").append(html)
	}
	
}

function isInArray(arr,value){
    for(var i = 0; i < arr.length; i++){
        if(value === arr[i]){
            return true;
        }
    }
    return false;
}

function getMsgListRed(){
	var red = 0;
	if(!msgIdArr) {
		if(list.length > 0) {
			//红点提示
			console.log('需要红点')
			$("#informRed").show();
		}
	}else {
		if(list.length > 0) {
			$.each(list, function(index, val) {
				var result = isInArray(msgIdArr, val.msgId)
				if(!result) {
					red = 1;
					return;
				}
			});
		}
	}
	
	if(red) {
		//红点
		console.log('需要红点')
		$("#informRed").show();
	}
}
