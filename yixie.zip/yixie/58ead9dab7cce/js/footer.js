function getOfferCvCopy(data) {
	$.get('/offercvcopy/myApplicationRecordNothandle', {}, function(data) {
		data = JSON.parse(data)
		if(data.code != 0) {
			alert(data.msg)
			return false;
		}
		console.log(data)
		if(data.data>0){
			$("body").find(".red_dot").show()
		}
	})
}

function footer() {
	var nav = "<div class='footer-navbar'>\
					<ul>\
						<li><a href='index.html' data-ajax='false'><span class='ico icon-index'></span>首页</a></li>\
						<li><a href='job-search.html' data-ajax='false'><span class='ico icon-search'></span>职位</a></li>\
						<li><a href='personal-center.html' data-ajax='false'><span class='ico icon-mine'></span>我的<i class='red_dot red_footer'></i></a></li>\
					</ul>\
				</div>"
	$('.warper').append(nav);
	
	getOfferCvCopy()
};