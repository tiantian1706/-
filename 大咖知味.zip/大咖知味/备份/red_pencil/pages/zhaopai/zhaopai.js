// pages/zhaopai/zhaopai.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var userinfo = wx.getStorageSync("userinfo_key");
var area = require('../../data/area');
var p = 0, c = 0, d = 0;
var zhan;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  
  data: {
    zhaopaizu: [],
    host: host,
    imgUrl: app.globalData.imgUrl,
    testhost: testhost,
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    miyao: "CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
    userlongitude: 0,
    userlatitude: 0,
    beiuserlongitude: 0,
    beiuserlatitude: 0,
    showDistpicker: false,
    provinceName: [],
    provinceCode: [],
    provinceSelIndex: '',
    cityName: [],
    cityCode: [],
    citySelIndex: '',
    xiantan: true,
    districtName: [],
    districtCode: [],
    districtSelIndex: '',
    iamhere: '顺德区',
    zhijie:[],
    wozhijie:'',
    fencouponsId:0,
    isnew:0,
    loading:true,
    dakalist:[],
    active:false,
    //备用的
    // x1: [0, 0, 0],
    // x2: [0, 0, 0],
    // x3: [0, 0, 0],
    // x4: [0, 0, 0],
    //备用的
    p2rotate:90,
    shuozhan:false,
    wid51:51,
    heig56:56,
    gangrotate:0,
    gangmarig1:2,
    animationData:{},
    gourmetfoodAllData: [],
    // 当季美食js版
    imgx: [{ xx: "../../imgs/s1.jpg" }, { xx: "../../imgs/s2.jpg" }, { xx: "../../imgs/s3.jpg" }, { xx: "../../imgs/s4.jpg" }, { xx: "../../imgs/s5.jpg" }, { xx: "../../imgs/s6.jpg" }, { xx: "../../imgs/s7.jpg" }, { xx: "../../imgs/s8.jpg" }, { xx: "../../imgs/s9.jpg" }],
    newimgx:[],
    // 当季美食js版
    showLoading: true,    
  },
  baUrl: function () {
    var that = this;
    wx.navigateTo({
      url: '../games2/games2?shopId=0',
    })
  },
  games: function () {
    var that = this;
    wx.navigateTo({
      url: '../games2/games2?shopId=0',
    })
  },
  getDefault: function (shopId) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId,
      },
      success: function (res) {

        var getDefault = res.data.data;
        if (getDefault) {
          luckyDrawId = getDefault.luckyDrawId;
          that.luckydraw();
        }

      }
    })
  },
  luckydraw: function () {
    var that = this;

    wx.request({
      url: host + 'luckydraw/get',
      data: {
        luckyDrawId: luckyDrawId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }

        if (res.data.data.state == 2) {
          // that.games();
          that.setData({
            baUrl: true
          })
        }
      }
    })
  },
  leaderboard: function() {
    var that = this;
    wx.navigateTo({
      url: '../leaderboard/leaderboard',
    })
  },
  dengduo: function(){
    wx.navigateTo({
      url: '../index3/index3?isType=1',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  toshop: function (e) {
    var that = this;
    wx.request({
      url: host + 'gourmetrouteshop/read',
      data: {
        userId: app.globalData.userId,
        shopId: that.data.gourmetfoodAllData[e.currentTarget.dataset.inx].shopId,
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function (res) {
      },
      fail: function (res) { },
      complete: function (res) { },
    })

    if (that.data.gourmetfoodAllData.length != 0) {
        wx.navigateTo({
          url: '../shop2/shop2?shopId=' + that.data.gourmetfoodAllData[e.currentTarget.dataset.inx].shopId + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
        });
    }
  },
  getAll: function() {
    var that = this;

    wx.request({
      url: host + 'gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        console.log("resresres", res.data.data)
          var gourmetfoodAllDatas = [];
          var gourmetrouteline = res.data.data;
          for (var i = 0, len = gourmetrouteline.length; i < len; i++) {
            for (var j = 0, lens = gourmetrouteline[i].shopInfo.length; j < lens; j++) {
              if (gourmetrouteline[i].shopInfo[j].recommend == 1) {
                gourmetfoodAllDatas.push(gourmetrouteline[i].shopInfo[j])
              }
            }
          }

        console.log("gourmetfoodAllDatas",gourmetfoodAllDatas);
          that.setData({
            gourmetfoodAllData: gourmetfoodAllDatas
          })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 当季美食
  menujs:function(e){
    var that=this;
    var num=1;
    let xxx=[];
    for (let i = 0; i < that.data.imgx.length;i++){
      if(i==that.data.imgx.length-1){
        if (num < 5) {
          xxx.push(that.data.imgx[i]);
          that.data.newimgx.push(xxx);
        } else {
          that.data.newimgx.push(xxx);
          xxx = [];
          xxx.push(that.data.imgx[i]);
          that.data.newimgx.push(xxx);
        }
      }else{
        if (num < 5) {
          xxx.push(that.data.imgx[i]);
          num++;
        } else {
          that.data.newimgx.push(xxx);
          xxx = [];
          num = 1;
          i--
        }
      }
    }
    that.setData({
      newimgx: that.data.newimgx
    })
    console.log("zzzz", that.data.newimgx,)
  },
  // 当季美食
  // 扇形
  zhankai:function(e){
    var that=this;

    // that.setData({
    //   wid51: 150,
    //   heig56: 150,
    // })
    // clearInterval(zhan)
    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
      // zhan = setInterval(function () {
      //   that.setData({
      //     wid51: 51,
      //     heig56: 56,
      //   })
      //   clearInterval(zhan)
      // }, 1000)
    }
    // setTimeout(function(){
    //   if (that.data.p2rotate == 90) {
    //     that.setData({
    //       gangrotate: 45,
    //       gangmarig1: -5,
    //       p2rotate: 0,
    //     })
    //   } else {
    //     that.setData({
    //       p2rotate: 90,
    //       gangrotate: 0,
    //       gangmarig1: 2,
    //     })
    //     zhan = setInterval(function () {
    //       that.setData({
    //         wid51: 51,
    //         heig56: 56,
    //       })
    //       clearInterval(zhan)
    //     }, 1000)
    //   }
    // },10)
  },
  clickm:function(e){
    var that=this;
    // console.log(e);
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    // wx.redirectTo({
    //   url: e.currentTarget.dataset.url,
    // });

    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  },
  // 扇形
  //备用的
  // xxx:function(e){
  //   var that=this;
  //   console.log("that.data.active", that.data.active)
  //   if (that.data.active){
      
  //     that.setData({
  //       active: !that.data.active,
  //       x1: [0, 0, 0],
  //       x2: [0, 0, 0],
  //       x3: [0, 0, 0],
  //       x4: [0, 0, 0],
  //     })
  //   }else{
  //     that.setData({
  //       active: !that.data.active,
  //       x1: [0, (80 * Math.cos(90 / 3 * 0 * (Math.PI / 180))), (-80 * Math.sin(90 / 3 * 0 * (Math.PI / 180)))],
  //       x2: [50, (80 * Math.cos(90 / 3 * 1 * (Math.PI / 180))), (-80 * Math.sin(90 / 3 * 1 * (Math.PI / 180)))],
  //       x3: [100, (80 * Math.cos(90 / 3 * 2 * (Math.PI / 180))), (-80 * Math.sin(90 / 3 * 2 * (Math.PI / 180)))],
  //       x4: [150, (80 * Math.cos(90 / 3 * 3 * (Math.PI / 180))), (-80 * Math.sin(90 / 3 * 3 * (Math.PI / 180)))],
  //     })
  //   }
  // },
  //备用的
  tocou:function(e){
    if (this.data.isnew == 0 || this.data.isnew == 1){
      wx.navigateTo({
        url: '../couponmy/couponmy',
      })
    }else{
      wx.navigateTo({
        url: '../couponactivity/couponactivity',
      })
    }
  },
  xinjiuren: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    that.zongliebiao(function () {
      that.myjuan(function () {
        // console.log("打印.zhijie,.wozhijie", that.data.zhijie, "-----", that.data.wozhijie)
        let geshu=0;
        for (let i = 0; i < that.data.zhijie.length;i++){
          if (that.data.wozhijie.indexOf(that.data.zhijie[i])!=-1){
            // console.log("有", that.data.zhijie[i])
            geshu++
          }
          
          if (i == that.data.zhijie.length-1){
            if (geshu == 0) {
              // console.log("我还是新人0", geshu)
              that.setData({
                isnew: 0,
              })
            } else if (geshu < that.data.zhijie.length){
              // console.log("我还是新人1", geshu)
              that.setData({
                isnew: 1,
              })
            } else {
              // console.log("我已经不是新人了");
              that.setData({
                isnew: 2,
              })
            }
            that.setData({
              loading: false,
            })
          }
        }
      })
    })
  },
  zongliebiao: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          coulists: res.data.data,
        })
        that.data.zhijie=[];
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.data.zhijie.push(res.data.data[i].couponsId)
            that.setData({
              zhijie: that.data.zhijie,
            })
          } else if (res.data.data[i].method==2){
            that.setData({
              fencouponsId: res.data.data[i].couponsId,
            })
          }
        }
        if (res.data.data.length == 0) {
          that.setData({
            loading: false,
            xiantan: false,
          })
        }
        console.log('总优惠劵！！！', that.data.coulists);
        return afun();
      },
      fail: function (res) { }
    })
  },
  myjuan: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        that.data.wozhijie=''
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.setData({
              wozhijie: that.data.wozhijie + res.data.data[i].oldCouponsId + ",",
            })
          }
        }
        console.log('我的优惠劵！！！', that.data.mycoulist);
        return afun();
      },
      fail: function (res) { }
    })
  },
  closetan: function (e) {
    this.setData({
      xiantan: false,
    })
  },
  tozhaodaka: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.index)
    wx.navigateTo({
      url: '../zhaodaka/zhaodaka?arr=' + JSON.stringify(that.data.dakalist[e.currentTarget.dataset.index]),
    })
  },
  tozhaodetail:function(e){
    var that = this;
    console.log(e.currentTarget.dataset.foodid, that.data.zhaopaizu)
    for (var i=0;i<that.data.zhaopaizu.length;i++){
      if (e.currentTarget.dataset.foodid == that.data.zhaopaizu[i].foodarr.foodId) {
        var preview = parseInt(that.data.zhaopaizu[i].foodarr.preview) + 1
        console.log("preview", preview)
        that.data.zhaopaizu[i].foodarr.preview = preview
      }
    }
    that.setData({
      zhaopaizu: that.data.zhaopaizu
    })
    wx.navigateTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.foodid,
    })
  },
  seemore:function(r){
    var that=this;
    console.log("超高难度", r.currentTarget.dataset.inx)
    that.data.zhaopaizu[r.currentTarget.dataset.inx].miaosu = that.data.zhaopaizu[r.currentTarget.dataset.inx].foodarr.other[0].content;
    that.data.zhaopaizu[r.currentTarget.dataset.inx].moreclick=false;
    that.setData({
      zhaopaizu: that.data.zhaopaizu,
    })
  },
  shoucang:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log(e.currentTarget.dataset.inx)
    wx.request({
      url: testhost + '/gourmetfood/option',
      data: {
        foodId: e.currentTarget.dataset.foodid,
        event: (e.currentTarget.dataset.iscang == 0 ? 2 : 4),
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        // console.log("点钟", res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
        } else {
          // console.log("进来啦！！", res)
          wx.request({
            url: testhost + '/gourmetfood/getOptionMySelf',
            data: {
              foodId: e.currentTarget.dataset.foodid,
              userId: app.globalData.userId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              openId: userinfo.openid,
            },
            dataType: 'json',
            method: 'get',
            success: function (resd) {
              if (resd.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: resd.data.msg,
                })
              } else {
                console.log("收藏", resd);
                if (resd.data.data.collect > 0) {
                  that.data.zhaopaizu[e.currentTarget.dataset.inx].iscang = 1;
                  wx.showToast({
                    title: '收藏成功',
                  })
                } else if (resd.data.data.collect == 0) {
                  that.data.zhaopaizu[e.currentTarget.dataset.inx].iscang = 0;
                } else {
                  console.log("点赞收藏的出错！", resd)
                }

                console.log(that.data.zhaopaizu)
                that.setData({
                  zhaopaizu:that.data.zhaopaizu,
                })
              }
            },
          })
        }
      },
    })
  },
  search: function (e) {
    wx.navigateTo({
      url: '../sreach/sreach',
    })
  },
  toaddshop: function (e) {
    wx.navigateTo({
      url: '../addmyshop/addmyshop',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    that.getDefault(0);

    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    //定位地区的
    that.setAreaData();
    that.menujs();

    wx.request({
      url: host + 'banner/xcxBannerList',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        that.setData({
          imgUrls: res.data.data
        })
        console.log("轮播", that.data.imgUrls)
      },
      fail: function (res) { },
      complete: function (res) { }
    })
    wx.request({
      url: testhost + '/gourmetdaka/getAll',
      // url: testhost + '/gourmetdaka/gourmetDaka',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        let geshu;
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].menu = res.data.data[i].menu.split(",");
        }
        that.setData({
          dakalist: res.data.data,
        })
        console.log("大咖列表dakalist", that.data.dakalist)
      },
    })
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlongitude: res.longitude,
          userlatitude: res.latitude,
          beiuserlongitude: res.longitude,
          beiuserlatitude: res.latitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=' + that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resb) {
            console.log("自己位置的地区", resb, )
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district == '') {
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            } else {
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }
          },
        })
      }
    })
    //定位地区的
    wx.request({
      url: testhost +'/gourmetfood/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res){
        if (res.data.code != 0) {
          wx.showToast({
            title: res.data.msg,
          })
        } else {
          var zhaopaizu=[];
          for (let x in res.data.data){
            wx.request({
              url: testhost + '/gourmetfood/getOptionMySelf',
              data: {
                foodId: res.data.data[x].foodId,
                userId: app.globalData.userId,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                openId: userinfo.openid,
              },
              dataType: 'json',
              method: 'get',
              success: function (resd) {
                var content = res.data.data[x].other[0].content.replace(/\n/g, '').slice(0, 65);
                var line = parseInt(content.length / 11)
                var miaosuData = [];
                for (var t = 0; t <= line; t++) {
                  var miaosuTxte = {
                    text : content.slice(t * 11, t * 11 + 11)
                  };

                  miaosuData.push(miaosuTxte)
                }
                console.log("miaosuData", miaosuData)
                let newfood = {
                  iscang: resd.data.data.collect, 
                  foodarr: res.data.data[x],
                  miaosu: res.data.data[x].other[0].content,
                  miaosuData: miaosuData,
                  // miaosu: res.data.data[x].other[0].content.replace(/\n/g,'').slice(0, 37), 
                  moreclick: (res.data.data[x].other[0].content.replace(/\n/g, '').length > 65?true:false),
                }

                console.log('newfood',newfood);
                zhaopaizu.push(newfood);
                that.setData({
                  zhaopaizu: zhaopaizu,
                }, function () {
                  that.setData({
                    showLoading: false
                  }, function () {
                    wx.hideLoading();
                  })
                })                       
              },
            })
          }
        }
      },
    })
    //判断新旧人的
    that.xinjiuren();
    // that.getAll();
    // 判断新旧人的
  },
  //定位地区的
  setAreaData: function (p, c, d) {
    var p = p || 0 // provinceSelIndex
    var c = c || 0 // citySelIndex
    var d = d || 0 // districtSelIndex
    // 设置省的数据
    var province = area['100000']
    var provinceName = [];
    var provinceCode = [];
    for (var item in province) {
      provinceName.push(province[item])
      provinceCode.push(item)
    }
    this.setData({
      provinceName: provinceName,
      provinceCode: provinceCode
    })
    // 设置市的数据
    var city = area[provinceCode[p]]
    var cityName = [];
    var cityCode = [];
    for (var item in city) {
      cityName.push(city[item])
      cityCode.push(item)
    }
    this.setData({
      cityName: cityName,
      cityCode: cityCode
    })
    // 设置区的数据
    var district = area[cityCode[c]]
    var districtName = [];
    var districtCode = [];
    for (var item in district) {
      districtName.push(district[item])
      districtCode.push(item)
    }
    this.setData({
      districtName: districtName,
      districtCode: districtCode
    })
  },
  changeArea: function (e) {
    p = e.detail.value[0]
    c = e.detail.value[1]
    d = e.detail.value[2]
    this.setAreaData(p, c, d)
  },
  showDistpicker: function () {
    this.setData({
      showDistpicker: true
    })
  },
  distpickerCancel: function () {
    var that = this;
    that.setData({
      showDistpicker: false,
      iamhere: that.data.districtName[that.data.districtSelIndex],
    })

    console.log("查询中心！！！", that.data.districtName[that.data.districtSelIndex], that.data.provinceName[that.data.provinceSelIndex], that.data.cityName[that.data.citySelIndex])
    wx.request({
      url: 'https://apis.map.qq.com/ws/district/v1/search?&keyword=' + that.data.districtName[that.data.districtSelIndex] + '&key=' + that.data.miyao,
      data: {},
      header: {
        'Content-Type': 'application/json'
      },
      dataType: 'json',
      method: 'get',
      success: function (resb) {
        console.log("查询中心！！！", resb.data.result[0][0].location, resb)
        that.setData({
          userlongitude: resb.data.result[0][0].location.lng,
          userlatitude: resb.data.result[0][0].location.lat,
          mapscale: 11,
        })
      },
    })
  },
  distpickerSure: function () {
    this.setData({
      provinceSelIndex: p,
      citySelIndex: c,
      districtSelIndex: d,
    })
    this.distpickerCancel()
    console.log(this.data.districtName[this.data.districtSelIndex])
  },
  //定位地区的
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.getAll();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})