// pages/miji/miji.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var zhan;

var compare = function (prop) {
  return function (obj1, obj2) {
    var val1 = obj1[prop];
    var val2 = obj2[prop]; if (val1 < val2) {
      return -1;
    } else if (val1 > val2) {
      return 1;
    } else {
      return 0;
    }
  }
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    mijizu:[],
    host:host,
    testhost: testhost,
    userlongitude:0,
    userlatitude:0,
    dataallmenu:[],
    haveclose: true,
    // 扇形
    p2rotate: 90,
    shuozhan: false,
    wid51: 51,
    heig56: 56,
    gangrotate: 0,
    gangmarig1: 2,
    animationData: {},
    searchForInputValues: ''
    // 扇形
  },
  // 扇形
  zhankai: function (e) {
    var that = this;

    // that.setData({
    //   wid51: 150,
    //   heig56: 150,
    // })
    // clearInterval(zhan)
    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
      // zhan = setInterval(function () {
      //   that.setData({
      //     wid51: 51,
      //     heig56: 56,
      //   })
      //   clearInterval(zhan)
      // }, 1000)
    }
    // setTimeout(function(){
    //   if (that.data.p2rotate == 90) {
    //     that.setData({
    //       gangrotate: 45,
    //       gangmarig1: -5,
    //       p2rotate: 0,
    //     })
    //   } else {
    //     that.setData({
    //       p2rotate: 90,
    //       gangrotate: 0,
    //       gangmarig1: 2,
    //     })
    //     zhan = setInterval(function () {
    //       that.setData({
    //         wid51: 51,
    //         heig56: 56,
    //       })
    //       clearInterval(zhan)
    //     }, 1000)
    //   }
    // },10)
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },

  // 扇形
  tomijidetail:function(e){
    console.log(e.currentTarget.dataset.menuid)
    wx.navigateTo({
      url: '../mijidetail/mijidetail?menuid=' + e.currentTarget.dataset.menuid + '&shopId=' + e.currentTarget.dataset.shopid
    })
  },
  closeguang:function(){
    this.setData({
      haveclose: false,
    })
  },
  getAll: function(ids) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )
        wx.request({
          url: testhost + '/gourmetmenu/getAll',
          data: {
            userId: app.globalData.userId,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showToast({
                title: res.data.msg,
              })
            } else {
              var thisallmenu = res.data.data;
              var dataallmenu = [];
              console.log("allshoparr", thisallmenu);

              var newmenus;
              for (let i = 0; i < thisallmenu.length; i++) {
                
                if (ids == 0) {
                  newmenus = {
                    juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, thisallmenu[i].shopInfo.lat, thisallmenu[i].shopInfo.lng),
                    thisarr: thisallmenu[i],
                  }
                  dataallmenu.push(newmenus);
                } else {
                  if (thisallmenu[i].title.indexOf(that.data.searchForInputValues) != -1) {
                    newmenus = {
                      juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, thisallmenu[i].shopInfo.lat, thisallmenu[i].shopInfo.lng),
                      thisarr: thisallmenu[i],
                    }
                    dataallmenu.push(newmenus);
                  }
                }
              }

              dataallmenu = dataallmenu.sort(compare('juli'));

              that.setData({
                dataallmenu: dataallmenu,
              })
              wx.hideLoading();
            }
          },
        })
      }
    });
  },
  searchForInput: function(e) {
    var that = this;
    var inputValue = e.detail.value;

    that.setData({
      searchForInputValues: inputValue
    })
  },
  // 搜索
  searchFor: function() {
    var that = this;
    that.getAll(that.data.searchForInputValues);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.showLoading({
      title: '加载中',
    })
    console.log("options", options)
    that.getAll(0);
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})