 //pages/mijidetail/mijidetail.js
// var WxParse = require('../../wxParse/wxParse.js');
const txvContext = requirePlugin("tencentvideo");
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    menuid: 0,
    // article: '<div><h3 style="color:#f05812;font-weight:normal;text-align:center;">菜式品鉴</h3><p style="margin-top:8px;margin-bottom:8px;">顺德新世界酒店的菜式“吉列春花饼”糅合中西做法，首先以凤城名菜“香炸春花卷”为基础，以沙噶、花生、芝麻、猪肉、葱花等普通选料切成粒状，加入秘制的调料，均匀搅拌，用面包糠网油包裹着材料，然后以“吉列”方式炸至外层金黄色，内层呈现蛋黄与葱绿色<br>交替。入口第一感觉是甜而不腻，爽脆可口。细细品尝，花生仁的香、沙噶的脆、葱花的酥，口感独特，形神俱备，让人回味无穷。</p><img src="http://www.xiexingcun.com/Poetry/6/images/53.jpg"></div>',
    iszan:false,
    iscang:false,
    zanmn:0,
    dishdetail:[],
    cangtext:"收藏",
    maimgsrc: '../../imgs/mama.jpg',
    phonemun:13231231321,
    hiddenLoading: true,
    gourmetcook: []
  },
  bindchanges: function(e) {
    var that = this;
    console.log(e);
    
    that.queryMultipleNodes(e.detail.current);

    that.setData({
      currentId: e.detail.current
    })
  },
  queryMultipleNodes: function(index) {
    let heights = null;
    let that = this;
    const query = wx.createSelectorQuery()
    query.select('#swiperItem_'+ index +' #the-id').boundingClientRect(function (res) {
      heights += res.height;
    }).select('#swiperItem_' + index +' #the-id2').boundingClientRect(function (res) {

      heights += res.height;
    }).select('#swiperItem_' + index +' #the-id3').boundingClientRect(function (res) {

      heights += res.height;
    }).select('#swiperItem_' + index +' #the-id4').boundingClientRect(function (res) {
      heights += res.height;
    }).select('#swiperItem_' + index +' #the-id5').boundingClientRect(function (res) {
      heights += res.height;
    }).select('#swiperItem_' + index +' #the-id6').boundingClientRect(function (res) {
      heights += res.height;
    }).select('#swiperItem_' + index + ' #the-id7').boundingClientRect(function (res) {
      heights += res.height;

      that.setData({
        heights: heights
      })
    }).exec();

    
  },
  gourmetcook: function (shopId, menuid) {
    var that = this;
    var currentId = null;
    wx.request({
      url: host + 'gourmetcook/get',
      data: {
        shopId: shopId
      },
      success: function(res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

          return;
        }
        var gourmetcookData = res.data.data;
        

        gourmetcookData['honor'] = gourmetcookData['honor'].split(';');
        console.log('gourmetcookData', gourmetcookData);

        for (var k = 0, lenk = gourmetcookData.cuisine.length; k < lenk; k++) {
          if (gourmetcookData.cuisine[k].menuId == menuid) {
            currentId = k;
          }
        }


        that.setData({
          gourmetcook: gourmetcookData,
          currentId: currentId
        });

        setTimeout(function () {
          that.queryMultipleNodes(currentId);
        }, 500)
        
      }
    })
  },
 
  indexsUrl: function() {
    wx.navigateTo({
      url: '../zhaopai/zhaopai',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  toorder: function (e) {
    var that = this;

    if (that.data.dishdetail.shopInfo.appointment== 1) {
      wx.navigateTo({
        url: '../order/order?shopId=' + that.data.dishdetail.shopInfo.shopId + '&name=' + that.data.dishdetail.shopInfo.name,
      });
    } else {
      wx.showModal({
        title: '温馨提示',
        content: '抱歉，该商家还没开通订座功能，请等待商家开通此功能再使用',
        success: function (res) { }
      })
    }
  },
  tophone: function (r) {
    wx.makePhoneCall({
      phoneNumber: this.data.phonemun,
    })
  },
  // tomap: function (r) {
  //   var that = this;
  //   wx.openLocation({
  //     latitude: parseInt(that.data.dishdetail.shopInfo.lat),
  //     longitude: parseInt(that.data.dishdetail.shopInfo.lng),
  //     scale: 28,
  //   })
  // },
  tomap: function (e) {
    var that = this;
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.dishdetail.shopInfo.address,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("获取的经纬度", res, that.data.dishdetail.shopInfo.address)
        wx.openLocation({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng,
          scale: 28,
        })
      },
    });
  },
  zanshou: function (r) {
    var that = this;
    var dowhat=0;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log(r.currentTarget.dataset.type);
    if (r.currentTarget.dataset.type=="zan"){
      if (that.data.iszan){
        dowhat = 3;
      }else{
        dowhat = 1;
      }
      that.setData({
        iszan: !that.data.iszan,
      })
    } else if (r.currentTarget.dataset.type=="cang"){
      if (that.data.iscang) {
        dowhat = 4;
      } else {
        dowhat = 2;
      }
      that.setData({
        iscang: !that.data.iscang,
      })
    }

    wx.request({
      url: testhost + '/gourmetmenu/option',
      data: {
        menuId: that.data.menuid,
        event: dowhat,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success:function(res){
        console.log("点赞和收藏的返回",res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
        } else {
          if (dowhat == 1) {
            wx.showToast({
              title: '点赞成功',
            })
            that.setData({
              zanmn: that.data.zanmn + 1,
            })
          } else if (dowhat == 3) {
            wx.showToast({
              title: '取消点赞',
            })
            that.setData({
              zanmn: that.data.zanmn - 1,
            })
          } else if (dowhat == 2 ) {
            wx.showToast({
              title: '收藏成功',
            })
            that.setData({
              cangtext: "已收藏",
              iscang: true,
            })
          } else if (dowhat == 4) {
            wx.showToast({
              title: '取消收藏',
            })
            that.setData({
              cangtext: "收藏",
              iscang: false,
            })
          } else {
            console.log("点赞收藏的出错！", res)
          }
          // wx.request({
          //   url: testhost + '/gourmetmenu/getOptionMySelf',
          //   data: {
          //     menuId: that.data.menuid,
          //     userId: app.globalData.userId,
          //     nickName: userinfo.nickName,
          //     headImgUrl: userinfo.avatarUrl,
          //     openId: userinfo.openid,
          //   },
          //   dataType: 'json',
          //   method: 'get',
          //   success: function (resd) {
          //     if (resd.data.code != 0) {
          //       wx.showModal({
          //         title: '提示',
          //         content: resd.data.msg,
          //       })
          //     } else {
          //       if (dowhat == 1 && resd.data.data.laud>0){
          //         wx.showToast({
          //           title: '点赞成功',
          //         })
          //         that.setData({
          //           zanmn: that.data.zanmn + 1,
          //         })
          //       } else if (dowhat == 3 && resd.data.data.laud == 0){
          //         wx.showToast({
          //           title: '取消点赞',
          //         })
          //         that.setData({
          //           zanmn: that.data.zanmn - 1,
          //         })
          //       } else if (dowhat == 2 && resd.data.data.collect > 0) {
          //         wx.showToast({
          //           title: '收藏成功',
          //         })
          //         that.setData({
          //           cangtext: "已收藏",
          //           iscang: true,
          //         })
          //       } else if (dowhat == 4 && resd.data.data.collect == 0) {
          //         wx.showToast({
          //           title: '取消收藏',
          //         })
          //         that.setData({
          //           cangtext: "收藏",
          //           iscang:false,
          //         })
          //       }else{
          //         console.log("点赞收藏的出错！",resd)
          //       }
          //     }
          //   },
          // })
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.setData({
      menuid: options.menuid,
    });

    that.gourmetcook(options.shopId, options.menuid);
    
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: testhost + '/gourmetmenu/getOptionMySelf',
      data: {
        menuId: that.data.menuid,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (resd) {
        if (resd.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: resd.data.msg,
          })
        } else {

          if (resd.data.data.collect > 0) {
            that.setData({
              cangtext: "已收藏",
              iscang: true,
            })
          } else if (resd.data.data.collect == 0) {
            that.setData({
              cangtext: "收藏",
              iscang: false,
            })
          } else {
            console.log("收藏的出错！", resd)
          }
        }
      },
    })
    // 预览的!
    wx.request({
      url: testhost + '/gourmetmenu/preview',
      data: {
        menuId: that.data.menuid,
      },
      dataType: 'json',
      method: 'get',
      success:function(resd){
        // 秘籍详情！
        if (resd.data.code!=0){return;}
        console.log("浏览的！".resd)
        wx.request({
          url: testhost + '/gourmetmenu/get',
          data: {
            menuId: that.data.menuid,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            
            console.log("秘籍详情！", res)
            if (res.data.code != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.msg,
              })
            } else {
              res.data.data.remark = res.data.data.remark.split('\n');
              that.setData({
                dishdetail: res.data.data,
                videoId: res.data.data.video,
                phonemun: res.data.data.shopInfo.contact,
                zanmn: res.data.data.laudNum,
                hiddenLoading:false,
              }, function(){
                if (that.data.videoId) {
                  that.txvContext = txvContext.getTxvContext('txv1');
                }
              });
              // that.data.aaa = WxParse.wxParse('article', 'html', that.data.article, that, 5);
              console.log("dishdetail.remark",that.data.dishdetail.remark,)
            }
          },
        })
    // 秘籍详情！
      },
    })
    // 预览的!
    // that.setData({
    //   article: temp
    // })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})