// pages/my/my.js
var app = getApp();
var zhan;
var host = "https://menu.honqb.com/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    nickName: '',
    avatarUrl: '',
    //扇形
    p2rotate: 90,
    shuozhan: false,
    wid51: 51,
    heig56: 56,
    gangrotate: 0,
    gangmarig1: 2,
    host: host
    //扇形
  },
  // 扇形
  zhankai: function (e) {
    var that = this;
    // that.setData({
    //   wid51: 150,
    //   heig56: 150,
    // })
    // clearInterval(zhan)
    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
      // zhan = setInterval(function () {
      //   that.setData({
      //     wid51: 51,
      //     heig56: 56,
      //   })
      //   clearInterval(zhan)
      // }, 1000)
    }
    // setTimeout(function(){
    //   if (that.data.p2rotate == 90) {
    //     that.setData({
    //       gangrotate: 45,
    //       gangmarig1: -5,
    //       p2rotate: 0,
    //     })
    //   } else {
    //     that.setData({
    //       p2rotate: 90,
    //       gangrotate: 0,
    //       gangmarig1: 2,
    //     })
    //     zhan = setInterval(function () {
    //       that.setData({
    //         wid51: 51,
    //         heig56: 56,
    //       })
    //       clearInterval(zhan)
    //     }, 1000)
    //   }
    // },10)
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },
  // 扇形
  myCoupons:function(e){
    wx.navigateTo({
      url: '../couponmy/couponmy?allcou=1',
    })
  },
  myCang: function (e) {
    wx.navigateTo({
      url: '../mycang/mycang',
    })
  },
  myOrder: function (e) {
    wx.navigateTo({
      url: '../myorder/myorder',
    })
  },
  mytreat:function(er){
    wx.navigateTo({
      url: '../mytreat/mytreat',
    })
    
  },
  myOrder2: function (e) {
    wx.navigateTo({
      url: '../myorder2/myorder2',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.getUserInfo({
      success: function (res) {
        var userInfo = res.userInfo
        var nickName = userInfo.nickName
        var avatarUrl = userInfo.avatarUrl
        // console.log(res.userInfo) 
        that.setData({
          nickName: nickName,
          avatarUrl: avatarUrl,
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})