// pages/mycang/mycang.js
var testhost = "https://menu.honqb.com";
var app = getApp();

var host = "https://menu.honqb.com/";
var p = 0, c = 0, d = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    host: host,
    foodmap:[],
    newcang:{},
    userlongitude: 0,
    userlatitude: 0,
    beiuserlongitude: 0,
    beiuserlatitude: 0,
    zhaopaizu:[],
  },
  toshop: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.shopid);
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + e.currentTarget.dataset.shopid,
    });
  }, 
  tocang: function(e) {
    var that = this;
    console.log(e.currentTarget.dataset.foodid)
    wx.navigateTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.foodid,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (resd) {
        that.setData({
          userlongitude: resd.longitude,
          userlatitude: resd.latitude,
          beiuserlongitude: resd.longitude,
          beiuserlatitude: resd.latitude,
        })
        console.log("用户位置", resd.longitude, resd.latitude, )
        that.getfoodmenu(function () {
          wx.request({
            url: host + 'gourmetrouteshop/myCollect',
            data: {
              userId: app.globalData.userId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              openId: userinfo.openid,
            },
            dataType: 'json',
            method: 'get',
            success: function (res) {
              console.log("收藏列表的！", res)
              var newcang = [];
              for (let i = 0; i < res.data.data.length; i++) {
                for (let j = 0; j < that.data.foodmap.length; j++) {
                  for (let x = 0; x < that.data.foodmap[j].shopInfo.length; x++) {
                    if (that.data.foodmap[j].shopInfo[x].shopId == res.data.data[i].shopId) {
                      let list = { shoparr: that.data.foodmap[j].shopInfo[x], juli: that.newdistance(that.data.foodmap[j].shopInfo[x].lat, that.data.foodmap[j].shopInfo[x].lng, resd.latitude, resd.longitude),};
                      console.log(that.newdistance(that.data.foodmap[j].shopInfo[x].lat, that.data.foodmap[j].shopInfo[x].lng, resd.latitude, resd.longitude), resd.latitude, that.data.foodmap[j].shopInfo[x].latitude,)
                      newcang.push(list);
                    }
                  }
                }
              }
              that.setData({
                newcang: newcang,
              })
              console.log("重新的收藏", that.data.newcang)
            },
          })
        })
      }
    })
    //菜式收藏接口
    wx.request({
      url: testhost + '/gourmetfood/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showToast({
            title: res.data.msg,
          })
        } else {
          var zhaopaizu = [];
          for (let x in res.data.data) {
            wx.request({
              url: testhost + '/gourmetfood/getOptionMySelf',
              data: {
                foodId: res.data.data[x].foodId,
                userId: app.globalData.userId,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                openId: userinfo.openid,
              },
              dataType: 'json',
              method: 'get',
              success: function (resd) {
                let newfood = { iscang: resd.data.data.collect, foodarr: res.data.data[x], miaosu: res.data.data[x].other[0].content.slice(0, 52), moreclick: (res.data.data[x].other[0].content.length > 52 ? true : false), }
                zhaopaizu.push(newfood);
                that.setData({
                  zhaopaizu: zhaopaizu,
                })

                console.log("zhaopaizu",zhaopaizu)
              },
            })
          }
          wx.hideLoading();
        }
      },
    })
    //菜式收藏接口
  },
  
  getfoodmenu:function(afun){
    var that=this;
    wx.request({
      url: testhost + '/gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (reback) {
        if (reback.data.code == 1) {
          wx.showModal({
            title: '温馨提示',
            content: reback.data.msg,
          })
        } else {
          that.setData({
            foodmap: reback.data.data,
          })
          // let ds = that.distance(that.data.foodmap[0].latitude, that.data.markers[i].longitude, that.data.userlatitude, that.data.userlongitude);
          console.log("美食地图的返回数据", that.data.foodmap);
          return afun();
        }
      }
    });
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//地球的半径啊
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数.
    return s;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})