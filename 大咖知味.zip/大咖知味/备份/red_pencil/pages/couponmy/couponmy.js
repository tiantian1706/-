// pages/couponmy/couponmy.js
var utils = require('../../utils/util.js');
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    url: url,
    coulists:[],
    mycoulist:[],
    showlist:[],
    zhijie: 0,
    wozhijie: 0,
    allcou:0,
  },
  todetail:function(er){
    var that = this;
    if (that.data.allcou==1){
      wx.navigateTo({
        url: '../coupondetail/coupondetail?juanarr=' + JSON.stringify(this.data.showlist[er.currentTarget.dataset.idx]),
      })
    }
  },
  lingqu: function(er){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'shopcoupons/receive',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
        couponsId: er.currentTarget.dataset.couponsid,
      },
      dataType: 'json',
      method: 'get',
      success:function(rr){
        if (rr.data.code!=0){
          wx.showModal({
            title: '温馨提示',
            content: rr.data.msg,
          })
        }else{
          console.log("领取的！",rr);
          that.myjuan(function(){
            that.data.coulists[0]["isling"] = "isling";
            for (let i = 0; i < that.data.coulists.length; i++) {
              for (let j = 0; j < that.data.mycoulist.length; j++) {
                if (that.data.coulists[i].couponsId == that.data.mycoulist[j].oldCouponsId) {
                  that.data.coulists[i]["isling"] = true;
                  break;
                } else {
                  that.data.coulists[i]["isling"] = false;
                }
              }
            }
            that.setData({
              showlist: that.data.coulists,
            })
            console.log("领取后的！", that.data.showlist);
          })
        }
      }
    })
  },
  zongliebiao: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          coulists: res.data.data,
        })
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.setData({
              zhijie: (++that.data.zhijie),
            })
            console.log("zhijie", that.data.zhijie);
          }
        }
        console.log('总优惠劵！！！', that.data.coulists);
        return afun();
      },
      fail: function (res) { }
    })
  },
  myjuan: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.setData({
              wozhijie: (++that.data.wozhijie),
            })
            console.log("wozhijie", that.data.wozhijie);
          }
        }
        console.log('我的优惠劵！！！', that.data.mycoulist);
        return afun();
      },
      fail: function (res) {}
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var allcou = options.allcou;

    that.setData({
      allcou: allcou
    })
    // 旧的
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        var dates = utils.formatTime(new Date);
        var CurrentDate = dates.slice(0, 10).replace(/\//g, '');
      
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].sillShow = parseInt(res.data.data[i].sillShow)
          res.data.data[i].moneyNumShow = parseInt(res.data.data[i].moneyNumShow)
        }
        that.setData({
          coulists: res.data.data,
        })
        console.log('优惠劵总列表！！！', that.data.coulists);
        // 我的优惠劵！！
        wx.request({
          url: host + 'shopcoupons/myCoupons',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
          },
          dataType: 'json',
          method: 'get',
          success: function (ress) {
           
            var pastDate = '';
            var vArray = [];
            for (var k = 0, lenk = ress.data.data.length; k < lenk; k++) {
              pastDate = ress.data.data[k].deadLine.replace(/-/g, '');
              // 判断过期
              if (pastDate > CurrentDate) {
                vArray.push(ress.data.data[k]);
              }
            }
            
            that.setData({
              mycoulist: vArray,
            });
            console.log('我的优惠劵！！！', that.data.mycoulist);
            if (allcou != undefined && allcou == 1) {
              for (let i = 0; i < that.data.mycoulist.length; i++) {
                for (let j = 0; j < that.data.coulists.length; j++) {
                  // if (that.data.coulists[j].couponsId == that.data.mycoulist[i].oldCouponsId) {
                  //   that.data.showlist.push(that.data.coulists[j]);
                  // }
                }
              }
              that.setData({
                showlist: that.data.mycoulist,
              })
            } else {
              for (let i = 0; i < that.data.coulists.length; i++) {
                that.data.coulists[i]["isling"] = "";
                for (let j = 0; j < that.data.mycoulist.length;j++){
                  if (that.data.coulists[i].couponsId == that.data.mycoulist[j].oldCouponsId){
                    that.data.coulists[i]["isling"] = true;
                    break;
                  }else{
                    that.data.coulists[i]["isling"] = false;
                  }
                }
              }
              that.setData({
                showlist: that.data.coulists,
              })
              console.log("这里是外面点进来的！", that.data.showlist);
            }
          },
          fail: function (res) { }
        })
        // 我的优惠劵！！
      },
      fail: function (res) { }
    })
    // 旧的
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})