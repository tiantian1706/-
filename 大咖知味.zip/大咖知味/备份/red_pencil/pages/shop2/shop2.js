// pages/shop2/shop2.js
const txvContext = requirePlugin("tencentvideo");
var WxParse = require('../../wxParse/wxParse.js');
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var userinfo = wx.getStorageSync("userinfo_key");
var thss,thss2;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    globalImgUrl: app.globalData.imgUrl,
    testhost: testhost,
    shopbanner: [],
    shoparr: [],
    address: '',
    shopname: '',
    showerwei: false,
    meishilist: [],
    imgarr: [],
    reasonarr: [],
    // menu:[],
    foodmap: [],
    hiddenLoading: true,
    hideyu: false,
    lineidx: 0,
    shopidx: 0,
    shopId: 0,
    windowWidth: 0,
    windowHeight: 0,
    isshowcanvas: false,
    ceshishuju:[
      { name: "xxx1" },
      { name: "xxx2" },
      { name: "xxx3" },
      { name: "xxx4" },
      { name: "xxx5" },
      { name: "xxx6" },
    ],
    marqueePace: 1,//滚动速度
    marqueeDistance: 0,//初始滚动距离
    marquee_margin: 30,
    size: 10,
    interval: 20 ,// 时间间隔
    scrollleft:0,
    scrollleft2: 0,
    marlet:0,
    marlet2:0,
    wenzigundongsudu:50,
    baUrl: false,
    isCollection: null, // 判断收藏
    gourmetcookData: [],
    cuisine: [],
    showLoading:true,
  },

  // 跳外链
  outside:function(e){
    var that = this;
    console.log("e", e.currentTarget.dataset.id)
    var shopId = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '../outside/outside?shopId=' + shopId,
    })
  },
  tomijidetail: function (e) {
    console.log(e.currentTarget.dataset.menuid)
    wx.navigateTo({
      url: '../mijidetail/mijidetail?menuid=' + e.currentTarget.dataset.menuid + '&shopId=' + e.currentTarget.dataset.shopid
    })
  },
  stallNumber: function(e) {
    var that = this;
    console.log(e.currentTarget.dataset.map);
    wx.previewImage({
      urls: [e.currentTarget.dataset.map],
    })
  },
  gourmetcook: function (shopId) {
    var that = this;
    var cuisineArray = [];
    wx.request({
      url:host + 'gourmetcook/get',
      data: {
        shopId: shopId
      },
      success: function(res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

          return;
        }
        
        if (res.data.data.length != 0) {
          for (var i = 0, len = res.data.data.cuisine.length; i < len; i++) {
            if (i < 2) {
              cuisineArray.push(res.data.data.cuisine[i]);
            }
          }
        }
        

        that.setData({
          gourmetcookData: res.data.data,
          cuisine: cuisineArray
        });
      }
    })
  },
  indexsUrl: function () {
    wx.reLaunch({
      url: '../zhaopai/zhaopai',
    })
  },
  baUrl: function () {
    var that = this;
    wx.navigateTo({
      url: '../games2/games2?shopId=' + that.data.shopId,
    })
  },
  games: function () {
    var that = this;
    wx.navigateTo({
      url: '../games2/games2?shopId=' + that.data.shopId,
    })
  },
  getDefault: function (shopId) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId,
      },
      success: function (res) {

        var getDefault = res.data.data;
        if (getDefault) {
          luckyDrawId = getDefault.luckyDrawId;
          that.luckydraw();
        }

      }
    })
  },
  luckydraw: function () {
    var that = this;

    wx.request({
      url: host + 'luckydraw/get',
      data: {
        luckyDrawId: luckyDrawId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }

        if (res.data.data.state == 2) {
          that.games();
          that.setData({
            baUrl: true
          })
        }
      }
    })
  },

  elerotate:function(e){
    var animation = wx.createAnimation({
      duration: 1000,
      timingFunction: 'ease',
    })
    animation.translate(0, 0).step();
    console.log("animation", animation)
    this.setData({
      animationData: animation.export()
    })
  },
  //文字滚动
  // ceshi:function(e){
  //   var that=this;
  //   // thss=setInterval(function(){
  //   //   // console.log("thss0", that.data.marlet, that.data.marlet2, that.data.scrollleft, that.data.scrollleft2)
  //   //   that.setData({
  //   //     scrollleft: that.data.scrollleft+2,
  //   //   })
  //   // }, that.data.wenzigundongsudu)
  // },
  totehui:function(e){
    wx.navigateTo({
      url: '../tehui/tehui',
    })
  },
  bindscrolltolower1:function(e){
    var that=this;
    // console.log("1号到尾部了", e, that.data.scrollleft)
    clearInterval(thss)
    that.setData({
      scrollleft2: 0,
      marlet2: that.data.windowWidth,
    })
    thss2 = setInterval(function () {
      // console.log("thss2", that.data.marlet, that.data.marlet2, that.data.scrollleft, that.data.scrollleft2)
      if (that.data.marlet > -that.data.windowWidth || that.data.marlet2>0){
        that.setData({
          marlet: that.data.marlet - 1,
          marlet2: that.data.marlet2 - 1,
        })
      }else{
        that.setData({
          scrollleft2: that.data.scrollleft2 + 2,
        })
      }
    }, that.data.wenzigundongsudu)
  },
  bindscrolltolower2: function (e) {
    var that = this;
    clearInterval(thss2)
    that.setData({
      scrollleft: 0,
      marlet: that.data.windowWidth,
    })
    // console.log("2号到尾部了", that.data.scrollleft2)
    thss = setInterval(function () {
      // console.log("thss", that.data.marlet, that.data.marlet2, that.data.scrollleft,that.data.scrollleft2)
      if (that.data.marlet2 > -that.data.windowWidth || that.data.marlet > 0){
        that.setData({
          marlet2: that.data.marlet2 - 1,
          marlet: that.data.marlet - 1,
        })
      }else{
        that.setData({
          scrollleft: that.data.scrollleft + 2,
        })
      }
    }, that.data.wenzigundongsudu)
  },
  //文字滚动
  toorder: function (e) {
    var that = this;
    console.log(that.data.shoparr, that.data.shoparr.username.length)
    if (that.data.shoparr.appointment == 1) {
      wx.navigateTo({
        url: '../order/order?shopId=' + that.data.shoparr.shopId + '&name=' + that.data.shoparr.name + '&address=' + that.data.shoparr.address,
      })
    } else {
      wx.showModal({
        title: '温馨提示',
        content: '抱歉，该商家还没开通订座功能，请等待商家开通此功能再使用',
        success: function (res) {}
      })
    }
    // if (that.data.hideyu){
    // wx.navigateTo({
    //   url: '../order/order?shopId=' + that.data.shoparr.shopId + '&name=' + that.data.shoparr.name + '&address=' + that.data.shoparr.address + "&lineidx=" + that.data.lineidx + "&shopidx=" + that.data.shopidx,
    // })
    // wx.navigateTo({
    //   url: '../order/order?shopId=' + that.data.shoparr.shopId + '&name=' + that.data.shoparr.name + '&address=' + that.data.shoparr.address,
    // })
    // }else{
    //   that.setData({
    //     hideyu: true,
    //   })
    // }
  },
  checkCollect: function (shopId, cb) {
    var that = this;

    wx.request({
      url: testhost + '/gourmetrouteshop/checkCollect',
      data: {
        shopId: shopId,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (resd) {
        console.log("检测收藏", resd);
        var option;
        if (resd.data.data == null) {
          option = 1;

          that.setData({
            isCollection: 2
          })

        } else {
          option = 2;
          that.setData({
            isCollection: 1
          })
        }

        cb(option);
      }
    })
  },

  isOption(option) {
    var that = this;
    wx.request({
      url: testhost + '/gourmetrouteshop/option',
      data: {
        shopId: that.data.shopId,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
        option: option,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
        } else {
          if (option == 1) {

            wx.showToast({
              title: '收藏成功',
            })
            that.setData({
              isCollection: 1
            })
          } else {
            wx.showToast({
              title: '取消收藏',
            })
            that.setData({
              isCollection: 2
            })
          }
        }
        console.log("是否收藏", res)
      },
    })
  },

  shoucang: function (e) {
    var that = this;
    
    that.checkCollect(that.data.shopId, function (option){
      that.isOption(option);
    });
  },

  downswitch: function (e) {
    this.setData({
      showerwei: false,
    })
  },
  tohome: function () {
    wx.redirectTo({
      url: '../index3/index3',
    })
  },
  opener: function () {
    this.setData({
      showerwei: true,
    })
  },
  bodadianhua: function (e) {
    wx.makePhoneCall({
      phoneNumber: this.data.shoparr.contact
    })
  },
  previewImage: function (e) {
    wx.previewImage({
      urls: [erwei.jpg],
      // 需要预览的图片http链接  使用split把字符串转数组。不然会报错  
    })
    console.log([testhost + this.data.shoparr.img2])
  },
  tozhaodetail: function (e) {
    wx.redirectTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.ids,
    })
  },
  imgYu: function (event) {//获取data-src
    var imgList = [];//获取data-list
    imgList.push(testhost + this.data.shoparr.img1)
    imgList.push(testhost + this.data.shoparr.img2)
    imgList.push(testhost + this.data.shoparr.img3)
    //图片预览
    wx.previewImage({
      urls: imgList // 需要预览的图片http链接列表
    })
  },
  // 拨打电话
  phone: function (e) {
    wx.makePhoneCall({
      phoneNumber: e.currentTarget.dataset.phone,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.elerotate();

    console.log("初始化", options)

    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    that.checkCollect(options.shopId,function (option) {

    });
    that.gourmetcook(options.shopId);
    that.getDefault(options.shopId);
    // that._data_lunbo_Ajax();
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("我来了！", options, options.scene)
    var scene = decodeURIComponent(options);
    console.log("我来了2！", decodeURIComponent(options))
    wx.getSystemInfo({
      success: function (res) {
        console.log("手机信息", res)
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight,
          marlet2: res.windowWidth,
        })
        // that.ceshi();
      },
    })

    // var sss = { "scene":"%2c11411"}
    var shopId=0;
    if (options.shopId!=undefined){
      console.log("options.shopId", options)
      shopId = options.shopId;
      that.setData({
        lineidx: options.lineidx,
        shopidx: options.shopidx,
        shopId: options.shopId,
      })
    } else if (options.scene!=undefined){
      shopId = parseInt(options.scene.replace("%2C", ""));
      console.log("options.scene", options.scene, options.scene.replace("%2C", ""), options.scene.replace(",", ""), shopId)
      that.setData({
        lineidx: options.lineidx,
        shopidx: options.shopidx,
        shopId: options.scene.replace("%2C",""),
      })
    }else{
      wx.showModal({
        title: '出错了',
        content: options,
      })
    }
    
    
    wx.request({
      url: testhost + '/gourmetrouteshop/get',
      data: {
        // shopId: that.data.shopId,
        shopId: shopId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("查询商品信息！！", res, shopId)


        var detail = res.data.data.instruction;

        var details = detail.replace(/src="/g, 'src="' + app.globalData.url);
        WxParse.wxParse('res', 'html', details, that, 0);

        that.setData({
          shoparr: res.data.data,
          videoId: res.data.data.video,
          address: res.data.data.address,
          shopname: res.data.data.name,
          phone: res.data.data.contact,
        }, function(){
          if (that.data.videoId) {
            that.txvContext = txvContext.getTxvContext('txv1');
          }
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        });
        if (that.data.shoparr.reason != "") {
          console.log("分割原因", that.data.shoparr.reason.split(","))
          that.setData({
            reasonarr: that.data.shoparr.reason.split(","),
          })
        };
        console.log(that.data.shoparr, that.data.shoparr.others.length, that.data.shoparr.shopImg)
        wx.request({
          url: testhost + '/gourmetfood/getAll',
          data: {
            userId: app.globalData.userId,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.msg,
              })
            } else {
              let meishilist = [];
              for (let i = 0; i < res.data.data.length; i++) {
                if (that.data.shoparr.shopId == res.data.data[i].shopId) {
                  meishilist.push(res.data.data[i])
                }
              }
              
              that.setData({
                meishilist: meishilist,
                hiddenLoading: false,
              })
              console.log("米兔", that.data.meishilist)
            }
          },
        })
      },
    })
    // wx.request({
    //   url: testhost + '/gourmetrouteline/getAll',
    //   data:{
    //     userId: app.globalData.userId,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (reback) {
    //     if (reback.data.code == 1) {
    //       wx.showModal({
    //         title: '温馨提示',
    //         content: reback.data.msg,
    //       })
    //     } else {
    //       that.setData({
    //         foodmap: reback.data.data,
    //       })
    //       console.log("美食地图的返回数据", that.data.foodmap);
    //       that.setData({
    //         shoparr: reback.data.data[options.lineidx].shopInfo[options.shopidx],
    //         address: reback.data.data[options.lineidx].shopInfo[options.shopidx].instruction,
    //         shopname: reback.data.data[options.lineidx].shopInfo[options.shopidx].name,
    //         phone: reback.data.data[options.lineidx].shopInfo[options.shopidx].shopId
    //       })
    //       if (that.data.shoparr.menu != "") {
    //         console.log("分割菜单", that.data.shoparr.menu.split(","))
    //         that.setData({
    //           menu: that.data.shoparr.menu.split(","),
    //         })
    //         console.log("腿夹菜", that.data.menu)
    //       };
    //       if (that.data.shoparr.reason != "") {
    //         console.log("分割原因", that.data.shoparr.reason.split(","))
    //         that.setData({
    //           reasonarr: that.data.shoparr.reason.split(","),
    //         })
    //       };
    //       if (that.data.shoparr.shopImg != "") {
    //         console.log("分割banner", that.data.shoparr.shopImg.split(","))
    //         that.setData({
    //           shopbanner: that.data.shoparr.shopImg.split(","),
    //         })
    //       }
    //       console.log(that.data.shoparr, that.data.shoparr.others.length, that.data.shoparr.shopImg)
    //       wx.request({
    //         url: testhost + '/gourmetfood/getAll',
    //         data: {
    //           userId: app.globalData.userId,
    //         },
    //         dataType: 'json',
    //         method: 'get',
    //         success: function (res) {
    //           if (res.data.code != 0) {
    //             wx.showModal({
    //               title: '提示',
    //               content: res.data.msg,
    //             })
    //           } else {
    //             let meishilist = [];
    //             for (let i = 0; i < res.data.data.length; i++) {
    //               if (that.data.shoparr.shopId == res.data.data[i].shopId) {
    //                 meishilist.push(res.data.data[i])
    //               }
    //             }
    //             that.setData({
    //               meishilist: meishilist,
    //               hiddenLoading: false,
    //             })
    //             console.log("米兔", that.data.meishilist)
    //           }
    //         },
    //       })
    //     }
    //   }
    // });
  },

  tomap: function (e) {
    var that = this;
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.shoparr.address,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("获取的经纬度", res)
        wx.openLocation({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng,
          scale: 28,
        })
      },
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // var that=this;
    // var userinfo = wx.getStorageSync("userinfo_key");

    // var windowHeight = that.data.windowHeight;
    // var windowWidth = that.data.windowWidth;

    // let title ="超级海鲜酒家的东家啊";

    // const ctx = wx.createCanvasContext('firstCanvas')

    // ctx.stroke()
    // ctx.font ="YouYuan";
    // ctx.setFontSize(17)
    // ctx.setTextAlign('center');
    // ctx.fillStyle = 'red';
    // ctx.fillText(title, windowWidth / 2, 35)
    // ctx.setTextAlign('center')

    // ctx.fillStyle = '#000';
    // ctx.strokeStyle = 'green';
    // ctx.setFontSize(55)
    // ctx.fillText("歡迎您光臨", windowWidth / 2, 100)

    // ctx.setFontSize(20)
    // ctx.fillText("提前订座免排队", windowWidth / 2, 145)
    // ctx.setFontSize(18)
    // ctx.fillText("长按识别小程序码立即订座", windowWidth / 2, windowHeight * 0.5 + 185)
    // // ctx.drawImage("../../imgs/cece.png", windowWidth *0.05, 155, windowWidth * 0.9, windowHeight*0.5)
    // // ctx.drawImage("https://menu.honqb.com/data/upload/xcxqrcode/20180417/1523947379104177.png", windowWidth * 0.05, 155, windowWidth * 0.9, windowHeight * 0.5)
    // var url = testhost + "/data/upload/xcxqrcode/20180417/1523950488104174.png";
    // console.log("urlurlurlurlurlurlurlurlurl",url);
    // wx.downloadFile({
    //   url: url, //仅为示例，并非真实的资源
    //   success: function (resd) {
    //     // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
    //     // res.tempFilePath
    //     console.log("这是吃", resd.tempFilePath)
    //     wx.saveFile({
    //       tempFilePath:resd.tempFilePath,
    //       success: function (res) {
    //         var savedFilePath = res.savedFilePath
    //         console.log("保存的地址", savedFilePath)
    //         ctx.drawImage(savedFilePath, windowWidth * 0.05, 155, windowWidth * 0.9, windowHeight * 0.5);
    //         ctx.draw();
    //       }
    //     })
    //   }
    // })
    // wx.request({
    //   url: host + 'xcx/getXcxQrCode',
    //   data: {
    //     userId: app.globalData.userId,
    //     enjoyClientId: userinfo.clientId
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (res) {
    //     console.log('二维码', res.data.data);

    //   },
    //   fail: function (res) {}
    // })
    // ctx.setFontSize(18)
    // ctx.fillText("长按识别小程序码立即订座", windowWidth / 2, windowHeight * 0.5 + 185)

    //ctx.setTextAlign('center');
    //ctx.fillText("歡迎您光臨", 150, 60);
    //console.log(ctx.);

    // setTimeout(function(){
    //   wx.canvasToTempFilePath({
    //     x: 0,
    //     y: 0,
    //     width: windowWidth,
    //     height: windowHeight,
    //     destWidth: windowWidth,
    //     destHeight: windowHeight,
    //     fileType:"jpg",
    //     canvasId: 'firstCanvas',
    //     success: function (res) {
    //       console.log(res.tempFilePath);
    //       wx.previewImage({
    //         urls: [res.tempFilePath],
    //         success: function (res) {
    //           console.log('成功')
    //         }
    //       })
    //     }
    //   })
    // },2000)

  },

  makecode: function (e) {
    var that = this;
    var windowHeight = that.data.windowHeight;
    var windowWidth = that.data.windowWidth;
    that.drawcode(function () {
      setTimeout(function () {
        wx.canvasToTempFilePath({
          x: 0,
          y: 0,
          quality: 1,
          width: windowWidth,
          height: windowHeight,
          destWidth: windowWidth,
          destHeight: windowHeight,
          fileType: "png",
          canvasId: 'firstCanvas',
          success: function (res) {
            console.log("这里是画的那个路径", res.tempFilePath);
            wx.previewImage({
              urls: [res.tempFilePath],
              success: function (resd) {
                console.log('这里是打开图片的函数', resd)
                that.setData({
                  isshowcanvas: false,
                })
              }
            })
          }
        })
      }, 250)
    })
  },
  drawcode: function (afun) {
    var that = this;
    that.setData({
      isshowcanvas: true,
    })
    var userinfo = wx.getStorageSync("userinfo_key");

    var windowHeight = that.data.windowHeight;
    var windowWidth = that.data.windowWidth;

    let title = that.data.shoparr.name;

    const ctx = wx.createCanvasContext('firstCanvas')

    ctx.stroke()
    ctx.font = "YouYuan";
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, windowWidth, windowHeight);
    ctx.rect(0, 0, 200, 200)

    ctx.setTextAlign('center');
    ctx.fillStyle = '#000';
    ctx.setFontSize(17)
    ctx.fillText("欢迎您光临", windowWidth / 2, 75)
    // ctx.fillText("ssssssssssssssss", windowWidth / 2, 75)

    ctx.setTextAlign('center');
    ctx.fillStyle = 'red';
    ctx.setFontSize(30)
    ctx.fillText(title, windowWidth / 2, 140)

    ctx.setTextAlign('center')
    ctx.fillStyle = '#000';
    ctx.setFontSize(20)
    // ctx.fillText("提前订座免排队", windowWidth / 2, 185)
    ctx.fillText("2018顺德美食节展位", windowWidth / 2, 185)

    ctx.fillStyle = '#000';
    ctx.setFontSize(18);
    // ctx.fillText("长按识别小程序码立即订座", windowWidth / 2, windowHeight * 0.5 + 250)
    ctx.fillText("长按识别小程序码，一键展位导航", windowWidth / 2, windowHeight * 0.5 + 250)
    
    // ctx.drawImage("../../imgs/cece.png", windowWidth *0.05, 155, windowWidth * 0.9, windowHeight*0.5)
    // ctx.draw();

    // var url = testhost + "/data/upload/xcxqrcode/20180417/1523950488104174.png";
    // console.log("urlurlurlurlurlurlurlurlurl", that.data.shoparr.shopId, userinfo.clientId, app.globalData.userId);
    wx.request({
      url: host + 'xcx/getXcxQrCode',
      data: {
        userId: app.globalData.userId,
        enjoyClientId: that.data.shoparr.shopId,
        shopId: that.data.shoparr.shopId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('二维码', testhost + res.data.data);
        wx.downloadFile({
          url: testhost + res.data.data, //仅为示例，并非真实的资源
          // url: url,
          success: function (resd) {
            // 只要服务器有响应数据，就会把响应内容写入文件并进入 success 回调，业务需要自行判断是否下载到了想要的内容
            // res.tempFilePath
            console.log("这是是下载图片的路径", resd.tempFilePath)
            wx.saveFile({
              tempFilePath: resd.tempFilePath,
              success: function (res) {
                var savedFilePath = res.savedFilePath
                console.log("保存的到手机的路径", savedFilePath)
                if (windowWidth>640){
                  ctx.drawImage(savedFilePath, windowWidth * 0.1, 215, 500, windowWidth * 0.8);
                }else{
                  ctx.drawImage(savedFilePath, windowWidth * 0.1, 215, windowWidth * 0.8, windowWidth * 0.8);
                }
                ctx.draw();
                return afun();
              }
            })
          }
        })
      },
      fail: function (res) { }
    })
  },
  // 生成二维码二合一

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // var that = this;
    // //var length = that.data.text.length * that.data.size;//文字长度
    // var length=0; //= that.data.ceshishuju.length * that.data.size;
    // var windowWidth = wx.getSystemInfoSync().windowWidth;// 屏幕宽度
    // for (let i = 0; i < that.data.ceshishuju.length;i++){
      
    //   length+=that.data.ceshishuju[i].name.length;
    //   console.log("zz?", length)
    //   if (i == that.data.ceshishuju.length-1){
    //     // length=length * that.data.size;
    //     console.log(length)
    //     that.setData({
    //       length: length,
    //       windowWidth: windowWidth
    //     });
    //     console.log(that.data.length)
    //     that.scrolltxt();// 第一个字消失后立即从右边出现
    //   }
    // }

    
    //console.log(length,windowWidth);
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})