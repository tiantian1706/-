//app.js
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    var that = this;

    this.getUserInfo(function (userinfo, code) {
      userinfo.code = code
      console.log("getUserInfo",userinfo, code)
      wx.request({
        url: that.globalData.host + 'xcx/xcxLogin',
        data: {
          userId: that.globalData.userId,
          code: userinfo.code,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          console.log('sd',res)
          userinfo.openid = res.data.data.openId
          userinfo.clientId = res.data.data.clientId
          console.log(res.data.data.openId)
          wx.setStorageSync("userinfo_key", userinfo)
        },
        fail: function(res){
          console.log('ds',res)
        }
      })
    })

    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');

    if (parseInt(resSDKVersion) < that.globalData.resSDKVersionNumber) {

    }
  },
  getUserInfo: function (cb) {
    var that = this
    if (this.globalData.userInfo) {
      typeof cb == "function" && cb(this.globalData.userInfo)
    } else {
      //调用登录接口
      wx.login({
        success: function (res) {
          var code = res.code;
          // https://xcx.honqb.com/xcx/login
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo, code)
            },
            fail: function (res) {
              // console.log(res)
              wx.showModal({
                title: '温馨提示',
                content: '您拒绝授权后，会影响到您使用小程序的部分功能。请点击确定重新授权； 如点击取消，请在小程序列表中删除后，再进入重新授权',
                success: function (res) {
                  if (res.confirm) {
                    wx.openSetting({
                      success: (res) => {
                        if (res.authSetting["scope.userInfo"]) {
                          wx.getUserInfo({
                            success: function (res) {
                              console.log('重新授权', res);
                              that.globalData.userInfo = res.userInfo
                              var userinfo = res.userInfo
                              wx.login({
                                success: function (res) {
                                  console.log('重新登录', res, userinfo, that.globalData.userId)
                                  var code = res.code;
                                  wx.request({
                                    url: that.globalData.host + 'xcx/xcxLogin',
                                    data: {
                                      userId: that.globalData.userId,
                                      code: code,
                                      nickName: userinfo.nickName,
                                      headImgUrl: userinfo.avatarUrl
                                    },
                                    header: {
                                      'content-type': 'application/json'
                                    },
                                    method: 'get',
                                    success: function (res) {
                                      console.log("重新openid", res, that.globalData.userId);
                                      if (res.data.code != 0) {
                                        wx.showModal({
                                          title: '提示',
                                          content: res.data.msg,
                                        })
                                        return;
                                      }
                                      userinfo.openid = res.data.data.openId;
                                      userinfo.clientId = res.data.data.clientId;
                                      wx.setStorageSync("userinfo_key", userinfo);
                                      that.globalData.tiao = true;
                                    }
                                  })
                                }
                              })
                            }
                          })
                        }
                      }
                    })
                  }
                }
              })
            }
          })
        }
      })
    }
  },
  globalData: {
    userInfo: null,
    userId: 10414,
    // url: "https://basehqb.honqb.com",
    // host: "https://basehqb.honqb.com/",
    url: "https://menu.honqb.com",
    imgUrl: "https://xcx.honqb.com",  // 全局图片变量
    host: "https://menu.honqb.com/",
    resSDKVersionNumber: 154
  }
})