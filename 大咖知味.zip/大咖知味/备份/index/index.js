//index.js
//获取应用实例
var testhost = "https://basehqb.honqb.com";
// var app = getApp();
// const app = getApp()
var app = getApp()
var host = "https://basehqb.honqb.com/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    host: host,
    bleft: 0,
    btop: 0,
    showlinemun: 0,
    ischoosemenu: false,
    foodmap: [],
    shopmane: '子曰，礼茶居',
    address: '振华路239号海纳方旁',
    stylec: '暂无',
    goodcook: '暂无',
    consume: '暂无',
    menushwo: true,
    scrollleft: 0,
    scrolltop: 0,
    windowWidth: 0,
    windowHeight: 0,
    kmmun: 0,
    longitude: 0,
    latitude: 0,
    isscale: false,
    xpan: 47.5,
    toshort: false,
    showmessage:false,
  },

  /**
   * 生命周期函数--监听页面加载
   */

  onLoad: function (options) {
    console.log(getApp().globalData)
    var that = this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          windowWidth: res.windowWidth,
          windowHeight: res.windowHeight,
        })
      }
    })
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        var speed = res.speed
        var accuracy = res.accuracy
        that.setData({
          longitude: res.longitude,
          latitude: res.latitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )
      }
    })
    console.log("userId", app.globalData.userId);
    wx.request({
      url: testhost + '/gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (reback) {
        that.setData({
          foodmap: reback.data.data,
        })
        console.log("美食地图的返回数据", that.data.foodmap);
        // for (let i = 0; i < that.data.foodmap.length; i++) {
        //   for (let j = 0; j < that.data.foodmap[i].length; j++) {
        //     for (let z = 0; z < that.data.foodmap[i][j].length; z++) {
        //       // if (that.data.foodmap[i][j][z].indexOf("顺德") != -1) {
        //       console.log("检索数据", that.data.foodmap[i][j][z]);
        //       // }
        //     }
        //   }
        // }
      }
    })
  },
  top2:function(r){
    wx.redirectTo({
      url: '../aaa/aaa',
    })
  },
  menuclick: function (re) {
    var that = this;
    that.setData({
      showmessage:false,
    })
    if (re.target.dataset.index != null) {
      console.log(re.target.dataset.index);
      that.setData({
        ischoosemenu: true,
        isscale: true,
        showlinemun: re.target.dataset.index,
      })
    }
    switch (re.target.dataset.index) {
      case 0:
        that.setData({
          // scrolltop: 171,
          scrollleft: 504,
        })
        wx.pageScrollTo({
          scrollTop: 171,
        })
        break;
      case 1:
        that.setData({
          // scrolltop: 171,
          scrollleft: 447,
        })
        wx.pageScrollTo({
          scrollTop: 171,
        })
        break;
      case 2:
        that.setData({
          // scrolltop: 171,
          scrollleft: 410,
        })
        wx.pageScrollTo({
          scrollTop: 171,
        })
        break;
      case 3:
        that.setData({
          // scrolltop: 171,
          scrollleft: 410,
        })
        wx.pageScrollTo({
          scrollTop: 171,
        })
        break;
      case 4:
        that.setData({
          // scrolltop: 222,
          scrollleft: 407,
        })
        wx.pageScrollTo({
          scrollTop: 222,
        })
        break;
    }
  },
  showmenu: function (r) {
    var that = this;
    if (!that.data.menushwo){
      that.setData({
        scrollleft: 1200 / 2 - that.data.windowWidth / 2,
      })
      wx.pageScrollTo({
        scrollTop: 790 / 2 - that.data.windowHeight / 2,
      })
    }
    that.setData({
      menushwo: !this.data.menushwo,
      ischoosemenu: false,
      isscale: false,
    })
  },
  mapscroll: function (e) {
    this.setData({
      scrollleft: e.detail.scrollLeft,
      scrolltop: e.detail.scrollTop,
    })
    // console.log(this.data.scrollleft, "+", this.data.scrolltop);
  },
  botclick: function (ev) {
    var that = this;
    let lineindex = ev.currentTarget.dataset.index;
    let shopindex = ev.target.dataset.index;
    let moleft = that.data.scrollleft;
    let motop = that.data.scrolltop;
    
    that.setData({
      showmessage: true,
      scrollleft: ev.target.offsetLeft - that.data.windowWidth / 2,
    })
    wx.pageScrollTo({
      scrollTop: ev.target.offsetTop - that.data.windowHeight / 2,
    })
    let addlengthpx2 = 144;
    console.log("超出的！", 1200 - ev.target.offsetLeft)
    console.log("zz", (-((addlengthpx2 - 1200 + ev.target.offsetLeft) / addlengthpx2) * 100).toFixed(2)); 
    if (1200 - ev.target.offsetLeft < addlengthpx2/2){
      console.log("超", 1200 - ev.target.offsetLeft, addlengthpx2 / 2)
      that.setData({
        xpan: (-((addlengthpx2 - 1200 + ev.target.offsetLeft) / addlengthpx2) * 100).toFixed(2),
      })
    } else {
      that.setData({
        xpan: -47.5,
      })
    }
    // console.log("targetop,viewtop", ev.target.offsetTop - that.data.windowHeight / 2, motop)
    // console.log("targeleft,viewleft", ev.target.offsetLeft - that.data.windowWidth / 2, moleft)
    // console.log("targeleft,viewleft", ev.target.offsetLeft)
    // console.log("搞的1|", ev.target.offsetTop)
    if (ev.target.offsetTop < 160) {
      that.setData({
        toshort: true,
      })
      // console.log("小于的！", that.data.toshort)
    } else {
      that.setData({
        toshort: false,
      })
      // console.log("大于的！", that.data.toshort)
    }

    if (that.data.foodmap[lineindex] == null || that.data.foodmap[lineindex].shopInfo[shopindex] == null) {
      // wx.showModal({
      //   title: '温馨提示',
      //   content: '暂无店铺，敬请期待',
      // })
      that.setData({
        bleft: ev.target.offsetLeft,
        btop: ev.target.offsetTop,
        shopmane: '暂无数据',
        address: '暂无数据',
      })
    } else {
      that.setData({
        bleft: ev.target.offsetLeft,
        btop: ev.target.offsetTop,
        shopmane: that.data.foodmap[lineindex].shopInfo[shopindex].name,
        address: that.data.foodmap[lineindex].shopInfo[shopindex].instruction,
      })
      let numlength = that.data.foodmap[lineindex].shopInfo[shopindex].instruction.replace(/[^0-9]/ig, "").length;
      let zimulength = that.data.foodmap[lineindex].shopInfo[shopindex].instruction.replace(/[^a-z]/g, "").length;
      let addlengthpx = (that.data.foodmap[lineindex].shopInfo[shopindex].instruction.length - numlength - zimulength) * 12 + numlength * 6 + zimulength * 7 + 33;
      // let addheight=;

      console.log("地址长度", (that.data.foodmap[lineindex].shopInfo[shopindex].instruction.length - numlength - zimulength) * 12 + numlength * 6 + zimulength * 7 + 33)
      if (ev.target.offsetLeft < addlengthpx / 2.1) {
        console.log("小咯！", that.data.windowWidth / 2 - ev.target.offsetLeft, parseInt(addlengthpx / 2.1), ((that.data.windowWidth / 2 - ev.target.offsetLeft) / parseInt(addlengthpx / 2.1)).toFixed(2) * 50 + (ev.target.offsetLeft / addlengthpx).toFixed(2) * 100)
        // that.data.xpan = 47.5 - ev.target.offsetLeft, parseInt(addlengthpx / 2.1), (ev.target.offsetLeft / parseInt(addlengthpx / 2.1)).toFixed(2);
        that.setData({
          xpan: -(47.5 - ((that.data.windowWidth / 2 - ev.target.offsetLeft) / parseInt(addlengthpx / 2.1)).toFixed(2) * 50 + (ev.target.offsetLeft / addlengthpx).toFixed(2) * 100 - 3),
        })
      } else {
        that.setData({
          xpan: -47.5,
        })
      }
      wx.request({
        url: host + 'notify/navigation',
        data: {
          address: that.data.foodmap[lineindex].shopInfo[shopindex].instruction,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          let ds = that.distance(res.data.data.lat, res.data.data.lng, that.data.latitude, that.data.longitude);
          console.log(ds);
          that.setData({
            kmmun: ds,
          })
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    }

    // wx.request({
    //   url: host + 'notify/navigation',
    //   data: {
    //     address: that.data.shopAddress
    //   },
    //   header: {
    //     'content-type': 'application/json'
    //   },
    //   method: 'get',
    //   dataType: '',
    //   success: function (res) {

    //     that.setData({
    //       latitude: res.data.data.lat,
    //       longitude: res.data.data.lng
    //     })
    //     console.log(res)
    //     console.log("latitude000", that.data.latitude)
    //     that.getTude();
    //   },
    //   fail: function (res) { },
    //   complete: function (res) { }
    // });

  },
  distance: function (lat1, lng1, lat2, lng2) {
    let a = (lat1 * Math.PI / 180.0) - (lat2 * Math.PI / 180.0);
    let b = (lng1 * Math.PI / 180.0) - (lng2 * Math.PI / 180.0);
    let s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos((lat1 * Math.PI / 180.0)) * Math.cos((lat2 * Math.PI / 180.0)) * Math.pow(Math.sin(b / 2), 2)));
    s = s * 6378.137;
    s = Math.round(s * 10000) / 10000;
    // console.log(s);
    return s;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})