// pages/shop/shop.js
var testhost = "https://basehqb.honqb.com";

var app = getApp()
var host = "https://basehqb.honqb.com/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    foodmap:[],
    shopname:"",
    shoptype: "",
    shopaddress: "",
    phone:'110-110110110',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    console.log("接受的商品id", options.shopId)
    wx.request({
      url: testhost + '/gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success:function(reback){
        that.setData({
          foodmap: reback.data.data
        })
        for (let i = 0; i < that.data.foodmap.length;i++){
          for (let j = 0; j < that.data.foodmap[i].shopInfo.length;j++){
            if (options.shopId == that.data.foodmap[i].shopInfo[j].shopId){
              that.setData({
                shopname: that.data.foodmap[i].shopInfo[j].name,
                shoptype: that.data.foodmap[i].shopInfo[j].name,
                shopaddress: that.data.foodmap[i].shopInfo[j].instruction,
              })
            }
          }
        }
      }
    })
  },
  back:function(e){
    wx.redirectTo({
      url: '../index3/index3',
    })
  },
  showmap:function(e){
    var that=this;
    let latitude;
    let longitude;
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.shopaddress,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log(res);
        latitude = res.data.data.lat;
        longitude = res.data.data.lng;
      },
    });
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        //var latitude = res.latitude
        //var longitude = res.longitude
        wx.openLocation({
          latitude: parseInt(latitude),
          longitude: parseInt(longitude),
          scale: 28
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})