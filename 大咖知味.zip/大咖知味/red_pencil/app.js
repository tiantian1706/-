//app.js
App({
  onLaunch: function () {
    //调用API从本地缓存中获取数据
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) < that.globalData.resSDKVersionNumber) {
      console.log(123123)
    }
    // 登录
    wx.login({
      success: res => {
        // ------ 获取凭证 ------
        var code = res.code;
        if (code) {
          // console.log('获取用户登录凭证：' + code);
          // ------ 发送凭证 ------
          wx.request({
            url: that.globalData.host + 'clientlogin/newLogin',
            data: { code: code, userId: that.globalData.userId },
            method: 'get',
            header: {
              'content-type': 'application/json'
            },
            success: function (res) {
              var data = wx.getStorageSync("userinfo_key")
              console.log("wx.getStorageSync", data)
              if (!data.nickName || data.nickName == "") {
                var userinfo = {
                  "openid": res.data.data.openId,
                  "clientId": res.data.data.clientId,
                  "nickName": '',
                  "avatarUrl": ''
                }
                console.log("res", res.data.data, userinfo, userinfo.openid)
                wx.setStorageSync("userinfo_key", userinfo)
              }
            },
          })
        } else {
          console.log('获取用户登录失败：' + res.errMsg);
        }
      }
    })
  },
  globalData: {
    userInfo: null,
    userId: 10414,
    basehqbUrl: "https://basehqb.honqb.com",
    url: "https://menu.honqb.com",
    imgUrl: "https://xcx.honqb.com",  // 全局图片变量
    host: "https://menu.honqb.com/",
    mapUrl:"https://apis.map.qq.com",
    resSDKVersionNumber: 154,
    key: "CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
  }
})