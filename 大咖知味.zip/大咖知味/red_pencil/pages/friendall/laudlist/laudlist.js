// pages/friendall/laudlist/laudlist.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
const userId = app.globalData.userId;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    cfid:0,
    host: host,
    url: url,
    detail:[],
  },
  thatone: function (e) {
    let clientid = e.currentTarget.dataset.clientid;
    wx.navigateTo({
      url: '../mylist/mylist?ismy=1&clientid=' + clientid,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var cfid = options.cfid;
    that.setData({
      cfid: cfid,
    })
    console.log(options);
    wx.request({
      url: url + '/cf/getDetail',
      data: {
        cfId: cfid,
      },
      success: function (res) {
        console.log("ces", res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          that.setData({
            detail: res.data.data,
          })
          console.log("detail", that.data.detail)
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})