// pages/friendall/mylist/mylist.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
const userId = app.globalData.userId;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mylist:[],
    nickName:'',
    headImgUrl:'',
    host: host,
    url: url,
    loading: true,
    notnew: false,
    zkmenu: false,
  },
  dels: function(e) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    var cfid = e.currentTarget.dataset.cfid;

    wx.showModal({
      title: '提示',
      content: '确定删除吗？',
      success: function(res) {
        if (res.confirm) {
          wx.request({
            url: host + 'cf/delCf',
            data: {
              cfId: cfid,
              userId: userId,
              openId: userInfo.openid,
              nickName: userInfo.nickName,
              headImgUrl: userInfo.avatarUrl,
            },
            success: function (res) {
              if (res.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: res.data.msg,
                });

                return;
              }

              if (res.data.code == 0) {
                
                that.myList(that.data.options);

                wx.showModal({
                  title: '提示',
                  content: '删除成功',
                });
              }
            }
          })
        }
      }
    })
  },
  homesUrl: function () {
    var that = this;

    wx.navigateTo({
      url: '../homes/homes',
    })
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },
  getDetail: function (e) {
    var that = this;
    let cfid = e.currentTarget.dataset.cfid;
    wx.navigateTo({
      url: '../danye/danye?cfid=' + cfid,
    })
  },
  zkmenu: function (e) {
    this.setData({
      zkmenu: !this.data.zkmenu,
    })
  },
  tomy: function (e) {
    wx.redirectTo({
      url: "../mylist/mylist",
    })
  },
  tohome: function (e) {
    wx.redirectTo({
      url: "../homes/homes",
    })
  },
  dianzan:function(e){
    var that=this;
    console.log(e)
    var cfid = e.currentTarget.dataset.cfid;
    console.log(cfid)
    var userInfo = wx.getStorageSync("userinfo_key");
    wx.request({
      // url:host + 'cflaud/laud',//点赞的
      url: host + 'cflaud/delLaud',//取消点赞的
      data:{
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        cfId: cfid,
      },
      success:function(res){
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */

  myList: function (options) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    if (options.ismy == undefined) {
      that.setData({
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
      });
      wx.request({
        url: host + 'cf/myList',
        data: {
          userId: userId,
          openId: userInfo.openid,
          nickName: userInfo.nickName,
          headImgUrl: userInfo.avatarUrl,
        },
        success: function (res) {
          console.log("自己的！", res)
          if (res.data.data.length == 0) {
            that.setData({
              notnew: true,
            })
          }
          that.setData({
            mylist: res.data.data,
            loading: false,
          })
        }
      })
    } else if (options.clientid != undefined) {
      wx.request({
        url: host + 'cf/getListByClientId',
        data: {
          clientId: options.clientid,
        },
        success: function (res) {
          if (res.data.data.length == 0) {
            that.setData({
              notnew: true,
            })
          }
          console.log("某人的！", res)
          that.setData({
            nickName: res.data.data[0].nickName,
            headImgUrl: res.data.data[0].headImgUrl,
            mylist: res.data.data,
            loading: false,
          })
        }
      })
    }
  },
  onLoad: function (options) {
    var that = this;
    console.log("options,", options);

    that.setData({
      options: options
    })

    that.myList(options);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})