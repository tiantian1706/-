// pages/friendall/isay/isay.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
const userId = app.globalData.userId;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imglists: [],
    uploadingImgArrays: [],
    imglists2:[],
    roomname:"所在位置",
    content:"",
    imageUrl:[],
    host: host,
    provincedistrict:"广东省-顺德区",
    miyao: "CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
  },
  textara:function(e){
    var that=this;
    that.setData({
      content: e.detail.value
    })
    // console.log(that.data.content);
  },
  chosemap:function(e){
    var that=this;

    wx.chooseLocation({
      success: function (res) {
        // success
        console.log(res, "location")
        console.log(res.name)
        console.log(res.latitude)
        console.log(res.longitude)
        that.setData({
          roomname: res.name,
        })
        wx.request({
          // url: 'https://apis.map.qq.com/ws/district/v1/?location=' + res.latitude + ',' + res.longitude+'&key=CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA&get_poi=0',
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?',
          data: {
            location: res.latitude + "," + res.longitude,
            key: that.data.miyao,
            get_poi: 0,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resd) {
            console.log("查询中心！！！", resd)
            that.setData({
              provincedistrict: resd.data.result.address
            });
          },
        })
      },
      fail: function () {
        // fail
      },
      complete: function () {
        // complete
      }
    })
  },
  clickimg:function(e){
    var that=this;
    var indx = e.target.dataset.index;
    console.log(indx);
    that.data.uploadingImgArrays.splice(indx, 1);
    that.setData({
      uploadingImgArrays: that.data.uploadingImgArrays,
    })
    console.log(indx, that.data.uploadingImgArrays)
  },
  addimg:function(e){
    var that=this;
    console.log(that.data)
    wx.chooseImage({
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        console.log("res", res, that.data)
        let nlist = { src: res.tempFilePaths };
        that.data.imglists.push(nlist);
        that.data.imglists2.push(res.tempFilePaths[0]);
        that.setData({
          imglists: that.data.imglists,
          imglists2: that.data.imglists2,
        })
        console.log("imglists2", that.data.imglists2)
        // wx.uploadFile({
        //   url: 'https://example.weixin.qq.com/upload', //仅为示例，非真实的接口地址
        //   filePath: tempFilePaths[0],
        //   name: 'file',
        //   formData: {
        //     'user': 'test'
        //   },
        //   success: function (res) {
        //     var data = res.data
        //     console.log("res", res, resz)
        //     //do something
        //   }
        // })
      }
    })
  },
  uploadingImg: function () {
    console.log(123);
    var that = this;
    wx.chooseImage({
      success: function (res) {
        var tempFilePaths = res.tempFilePaths
        console.log("xxxx", tempFilePaths,)
        for (let i = 0; i < tempFilePaths.length;i++){
          that.data.uploadingImgArrays.push(tempFilePaths[i])
        }
        
        that.setData({
          uploadingImgArrays: that.data.uploadingImgArrays,
        })
        // for (let i = 0; i < tempFilePaths.length;i++){
        //   const uploadTask = wx.uploadFile({
        //     url: host + 'uploadimage/uploadImg',
        //     // url: host + 'cf/publish',
        //     filePath: tempFilePaths[i],
        //     name: 'file',
        //     formData: {
        //       'user': 'test'
        //     },
        //     success: function (res) {
        //       console.log(res);
        //       var data = JSON.parse(res.data)
        //       that.data.uploadingImgArrays.push(data.data)
        //       console.log("uploadingImgArrays",that.data.uploadingImgArrays)
        //       that.setData({
        //         imageUrl: data.data,
        //         uploadingImgArray_data: that.data.uploadingImgArrays
        //       })
        //     }
        //   })
        //   uploadTask.onProgressUpdate((res) => {
        //     console.log('上传进度'+i, res.progress)
        //     console.log('已经上传的数据长度' + i, res.totalBytesSent)
        //     console.log('预期需要上传的数据总长度' + i, res.totalBytesExpectedToSend)
        //   })
        // }
      }
    })
  },
  upimgtosever:function(e){
    var that=this;
    var userInfo = wx.getStorageSync("userinfo_key");
    wx.showLoading({
      title: '上传中，请稍等',
    })
    if (that.data.uploadingImgArrays.length!=0){
      for (let i = 0; i < that.data.uploadingImgArrays.length; i++) {
        if (i < that.data.uploadingImgArrays.length - 1) {
          const uploadTask = wx.uploadFile({
            url: host + 'uploadimage/uploadImg',
            // url: host + 'cf/publish',
            filePath: that.data.uploadingImgArrays[i],
            name: 'file',
            formData: {
              'user': 'test'
            },
            success: function (res) {
              console.log(res);
              var data = JSON.parse(res.data)
              // that.data.uploadingImgArrays.push(data.data)
              that.data.imageUrl.push(data.data)
              console.log("uploadingImgArrays", that.data.imageUrl)
              that.setData({
                imageUrl: that.data.imageUrl,
                uploadingImgArray_data: that.data.uploadingImgArrays
              })
            }
          })
          uploadTask.onProgressUpdate((res) => {
            console.log('上传进度' + i, res.progress)
            console.log('已经上传的数据长度' + i, res.totalBytesSent)
            console.log('预期需要上传的数据总长度' + i, res.totalBytesExpectedToSend)
          })
        } else {
          const uploadTask = wx.uploadFile({
            url: host + 'uploadimage/uploadImg',
            // url: host + 'cf/publish',
            filePath: that.data.uploadingImgArrays[i],
            name: 'file',
            formData: {
              'user': 'test'
            },
            success: function (res) {
              console.log(res);
              var data = JSON.parse(res.data)
              // that.data.uploadingImgArrays.push(data.data)
              that.data.imageUrl.push(data.data)
              console.log("uploadingImgArrays", that.data.imageUrl)
              that.setData({
                imageUrl: that.data.imageUrl,
                uploadingImgArray_data: that.data.uploadingImgArrays
              })
              setTimeout(function () {
                wx.request({
                  url: host + 'cf/publish',
                  data: {
                    userId: userId,
                    openId: userInfo.openid,
                    nickName: userInfo.nickName,
                    headImgUrl: userInfo.avatarUrl,
                    data: {
                      detailAddress: that.data.roomname,
                      address: that.data.provincedistrict,
                      content: that.data.content,
                      image: that.data.imageUrl,
                    }
                  },
                  success: function (resz) {
                    if (resz.statusCode == 200) {
                      if (resz.data.code != 0) {
                        wx.showModal({
                          title: '提示',
                          content: resz.data.msg,
                        });
                        return;
                      } else {
                        wx.hideLoading()
                        wx.showModal({
                          title: '温馨提示',
                          showCancel: false,
                          content: '上传成功',
                          success: function (res) {
                            
                            wx.redirectTo({
                              url: '../homes/homes',
                            })
                            if (res.confirm) {
                              console.log('用户点击确定')
                            } else if (res.cancel) {
                              console.log('用户点击取消')
                            }
                          }
                        })
                        console.log("上传公告")
                      }
                      // cb(res)
                    }
                  }
                })
              }, 1000)
              // uploadTask.onProgressUpdate((res) => {
              //   console.log('上传进度' + i, res.progress)
              //   console.log('已经上传的数据长度' + i, res.totalBytesSent)
              //   console.log('预期需要上传的数据总长度' + i, res.totalBytesExpectedToSend)

              // })
            }
          })
          // uploadTask.onProgressUpdate((res) => {
          //   console.log('上传进度' + i, res.progress)
          //   console.log('已经上传的数据长度' + i, res.totalBytesSent)
          //   console.log('预期需要上传的数据总长度' + i, res.totalBytesExpectedToSend)
          //   if (res.progress==100){
          //     wx.request({
          //       url: host + 'cf/publish',
          //       data: {
          //         userId: userId,
          //         openId: userInfo.openid,
          //         nickName: userInfo.nickName,
          //         headImgUrl: userInfo.avatarUrl,
          //         data: {
          //           content: that.data.content,
          //           image: that.data.imageUrl,
          //         }
          //       },
          //       success: function (resz) {
          //         if (resz.statusCode == 200) {
          //           if (resz.data.code != 0) {
          //             wx.showModal({
          //               title: '提示',
          //               content: resz.data.msg,
          //             });
          //             return;
          //           }
          //           // cb(res)
          //         }
          //       }
          //     })
          //   }
          // })
        }
      }
    }else{
      wx.request({
        url: host + 'cf/publish',
        data: {
          userId: userId,
          openId: userInfo.openid,
          nickName: userInfo.nickName,
          headImgUrl: userInfo.avatarUrl,
          data: {
            detailAddress: that.data.roomname,
            address: that.data.provincedistrict,
            content: that.data.content,
            image: that.data.imageUrl,
          }
        },
        success: function (resz) {
          if (resz.statusCode == 200) {
            if (resz.data.code != 0) {
              wx.showModal({
                title: '提示',
                content: resz.data.msg,
              });
              return;
            } else {
              wx.hideLoading()
              wx.showModal({
                title: '温馨提示',
                showCancel:false,
                content: '上传成功',
                success: function (res) {
                  wx.redirectTo({
                    url: '../homes/homes',
                  })
                  if (res.confirm) {
                    console.log('用户点击确定')
                  } else if (res.cancel) {
                    console.log('用户点击取消')
                  }
                }
              })
              console.log("上传公告")
            }
          }
        }
      })
    }
  },
  publishAJax: function (content, image, num, cb) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    console.log("userInfo", userInfo)
    wx.request({
      url: host + 'cf/publish',
      data: {
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        data:{
          address: that.data.provincedistrict,
          detailAddress: that.data.roomname,
          content: that.data.content,
          image: that.data.uploadingImgArrays,
        }
      },
      success: function (res) {
        if (res.statusCode == 200) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '提示',
              content: res.data.msg,
            });
            return;
          }
          cb(res)
        }
      }
    })
  },
  commit: function () {
    var that = this;
    // console.log(that.data.textareaData_data, that.data.uploadingImgArrays, !that.data.textareaData_data)

    // if (that.data.phoneData_data.length == 0) {
    //   wx.showModal({
    //     title: '提示',
    //     content: '联系方式必须填',
    //   })

    //   return;
    // }
    // if (that.data.phoneData_data.length != 11) {
    //   wx.showModal({
    //     title: '提示',
    //     content: '联系方式必须是11位',
    //   })

    //   return;
    // }
    // if (that.data.textareaData_data == '') {
    //   wx.showModal({
    //     title: '提示',
    //     content: '请输入内容',
    //   })

    //   return;
    // }

    // if (that.data.uploadingImgArrays.length == 0) {
    //   wx.showModal({
    //     title: '提示',
    //     content: '请添加图片',
    //   })

    //   return;
    // }

    var uploadingImgObject = that.data.uploadingImgArrays.join(',');
    console.log(uploadingImgObject)
    that.publishAJax(that.data.textareaData_data, uploadingImgObject, 1, function (res) {
      if (res.data.code == 0) {
        wx.showModal({
          title: '提示',
          content: '已成功提交',
          success: function (res) {
            if (res.confirm) {
              wx.navigateBack({
                delta: 1
              })
            } else if (res.cancel) {
              wx.navigateBack({
                delta: 1
              })
            }
          }
        })
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userInfo = wx.getStorageSync("userinfo_key");
    // wx.request({
    //   url: host + 'cf/myList',
    //   data: {
    //     userId: userId,
    //     openId: userInfo.openid,
    //     nickName: userInfo.nickName,
    //     headImgUrl: userInfo.avatarUrl,
    //   },
    //   success: function (res) {
    //     console.log("自己的！",res)
    //   }
    // })
    //取消点赞
    // wx.request({
    //   url: host + 'cflaud/delLaud',
    //   data: {
    //     cfId: 6,
    //     userId: userId,
    //     openId: userInfo.openid,
    //     nickName: userInfo.nickName,
    //     headImgUrl: userInfo.avatarUrl,
    //   },
    //   success: function (res) {
    //     console.log("自己的2！", res)
    //   }
    // })
    //取消点赞
    // //点赞
    // wx.request({
    //   url: host + 'cflaud/laud',
    //   data: {
    //     cfId:6,
    //     userId: userId,
    //     openId: userInfo.openid,
    //     nickName: userInfo.nickName,
    //     headImgUrl: userInfo.avatarUrl,
    //   },
    //   success: function (res) {
    //     console.log("自己的！", res)
    //   }
    // })
    // //点赞
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})