// pages/friendall/homes/homes.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
const userId = app.globalData.userId;
var rwq = 1;
Page({
  /**
   * 页面的初始数据
   */
  data: {
    alllist:[],
    alllistbei:[],
    host: host,
    url: url,
    tabnum: 0,
    loading:true,
    guanlist:[], 
    xiaoxi:"暂无信息",
    notnew:false,
    zkmenu: false,
  },
  dels: function (e) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    var cfid = e.currentTarget.dataset.cfid;

    wx.showModal({
      title: '提示',
      content: '确定删除吗？',
      success: function (res) {
        if (res.confirm) {
          wx.request({
            url: host + 'cf/delCf',
            data: {
              cfId: cfid,
              userId: userId,
              openId: userInfo.openid,
              nickName: userInfo.nickName,
              headImgUrl: userInfo.avatarUrl,
            },
            success: function (res) {
              if (res.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: res.data.msg,
                });

                return;
              }

              if (res.data.code == 0) {

                that.getalllist();

                wx.showModal({
                  title: '提示',
                  content: '删除成功',
                });
              }
            }
          })
        }
      }
    })
  },
  homesUrl: function() {
    var that = this;

    wx.navigateTo({
      url: '../homes/homes',
    })
  },
  detomap:function(e){
    var that = this;
    console.log(e.currentTarget.dataset.deadd)
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: e.currentTarget.dataset.deadd,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("获取的经纬度", res);

        if (res.data.data == 0) {
          wx.showModal({
            title: '提示',
            content: '您好，无法定位',
          })

          return;
        }
        wx.openLocation({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng,
          scale: 28,
        })
      },
    });
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },
  zkmenu:function(e){
    console.log("fasf")
    this.setData({
      zkmenu: !this.data.zkmenu,
    })
  },
  laudlist:function(e){
    let cfid = e.currentTarget.dataset.cfid;
    wx.navigateTo({
      url: '../laudlist/laudlist?cfid=' + cfid,
    })
  },
  thatone:function(e){
    let clientid = e.currentTarget.dataset.clientid;
    wx.navigateTo({
      url: '../mylist/mylist?ismy=1&clientid=' + clientid,
    })
  },
  caresomeone:function(e){
    var that=this;
    var userInfo = wx.getStorageSync("userinfo_key");
    let clientid = e.currentTarget.dataset.clientid;
    let isguan = e.currentTarget.dataset.isguan;
    console.log(e.currentTarget.dataset);
    wx.request({
      url: host+'cffollow/option',
      data:{
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        followClientId: clientid,
        option: (isguan ? 2:1),
      },
      success:function(res){
        // console.log(res)
        that.setData({
          loading: true,
        })
        wx.request({
          url: url + '/cffollow/myList',
          data: {
            userId: userId,
            openId: userInfo.openid,
            nickName: userInfo.nickName,
            headImgUrl: userInfo.avatarUrl,
          },
          success: function (resd) {
            let alllist = that.data.alllistbei;
            let guanlist = resd.data.data;

            // 如果有关注的数据
            if (guanlist.length > 0) {
              for (let a = 0; a < alllist.length; a++) {

                for (let b = 0; b < guanlist.length; b++) {

                  if (alllist[a].clientId == guanlist[b].followClientId) {

                    alllist[a].isguan = true;
                    break;

                  } else {

                    alllist[a].isguan = false;
                    
                  }
                }
              }
            } else {

              // 如果等于已关注 == 0
              for (let a = 0; a < alllist.length; a++) {
                alllist[a].isguan = false;
              }
            }

            that.setData({
              alllist: alllist,
              alllistbei: alllist,
              guanlist: guanlist,
              loading: false,
            })
          }
        })
      }
    })
  },
  imgYu: function (event) {//获取data-src
    var that=this;
    let imgList, imgList2 = [];//获取data-list
    let index = event.currentTarget.dataset.index;
    let midx = event.currentTarget.dataset.midx;
    
    imgList = that.data.alllist[index].image;
    for (let i = 0; i < imgList.length;i++){
      imgList2.push(that.data.host+ imgList[i])
    }

    //图片预览
    wx.previewImage({
      current: that.data.host + that.data.alllist[index].image[midx],
      urls: imgList2 // 需要预览的图片http链接列表
    })
  },
  getDetail:function(e){
    var that=this;
    let cfid = e.currentTarget.dataset.cfid;

    wx.navigateTo({
      url: '../danye/danye?cfid=' + cfid,
    })
    // wx.request({
    //   url: url+ '/cf/getDetail',
    //   data:{
    //     cfId:cfid,
    //   },
    //   success:function(res){
    //     console.log(res)
    //   }
    // })
  },
  compare: function (prop) {
    return function (obj1, obj2) {
      var val1 = obj1[prop];
      var val2 = obj2[prop]; 
      if (val1 < val2) {
        return -1;
      } else if (val1 > val2) {
        return 1;
      } else {
        return 0;
      }
    }
  },
  sortNumber: function (property) {
    return function (a, b) {
      let value1 = a[property];
      let value2 = b[property];
      return value2 - value1;
    }
  },
  clicktab:function(e){
    var that=this;
    let lix = e.target.dataset.lix;
    let alllist = that.data.alllistbei;

    that.data.alllist = [];

    that.setData({
      alllist: [],
      loading: true,
      notnew: false,
      // xiaoxi: "暂无信息",
    });



    if (lix==0){
      console.log('最新', alllist);

      var alllists = alllist.sort(that.sortNumber("cfId"));

      console.log('排序结果', alllists);
      that.setData({
        alllist: alllists,
      })

       
    } else if (lix==1){

      alllist.sort(that.sortNumber("laudNum"))
      console.log('热门', alllist);
      that.setData({
        alllist: alllist,
      });
      
    } else {

      let alllistfilter=alllist.filter(function(x){
        return x.isguan==true;
      })
      console.log('关注', alllistfilter);
      if (alllistfilter.length==0){
        that.setData({
          xiaoxi:"暂无关注",
          notnew:true,
        })
      }

      that.setData({
        alllist: alllistfilter,
      })
    }

    that.setData({
      tabnum: lix,
      loading: false,
    });
  },
  dianzan: function (e) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    let cfid = e.currentTarget.dataset.cfid;
    wx.request({
      url: host + 'cflaud/laud',
      data: {
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        cfId: cfid,
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          wx.showToast({
            title: '点赞成功',
            icon: "success",
          })
          that.getalllist();
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  toisay:function(e){
    var that=this;
    wx.navigateTo({
      url: "../isay/isay",
    })
  },
  tomy:function(e){
    wx.redirectTo({
      url: "../mylist/mylist",
    })
  },
  tohome:function(e){
    wx.redirectTo({
      url: "../homes/homes",
    })
  },
  getalllist:function(e){
    var that=this;
    var userInfo = wx.getStorageSync("userinfo_key");

    console.log(userInfo);
    wx.request({
      url: url + '/cf/getAll',
      data: {
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          let alllist = res.data.data;
          
          wx.request({
            url: url + '/cffollow/myList',
            data: {
              userId: userId,
              openId: userInfo.openid,
              nickName: userInfo.nickName,
              headImgUrl: userInfo.avatarUrl,
            },
            success: function (resd) {
              let guanlist = resd.data.data;
      
              for (let a = 0; a < alllist.length;a++){
                for (let b = 0; b < guanlist.length; b++) {
                  if (alllist[a].clientId == guanlist[b].followClientId){
                    alllist[a].isguan = true;
                    break;
                    console.log("tes");
                  }else{
                    alllist[a].isguan = false;
                    console.log("no");
                  }
                  // if (a == alllist.length - 1 && b == guanlist.length - 1){
                  //   that.setData({
                  //     alllist: alllist,
                  //     alllistbei: alllist,
                  //     loading: false,
                  //   })
                  //   console.log("alllist", that.data.alllist, guanlist)
                  // }
                }
              }
              that.setData({
                alllist: alllist,
                alllistbei: alllist,
                guanlist: guanlist,
                loading: false,
              }, function(){

                if (that.data.alllist.length == 0) {
                  that.setData({
                    loading: false,
                    notnew: true,
                  })
                }
                
              })
              console.log("alllist", that.data.alllist, guanlist)
            }
          })
        }
      }
    })
  },
  onLoad: function (options) {
    var that=this;
    var userInfo = wx.getStorageSync("userinfo_key");
    that.getalllist();
    
    that.setData({
      clientIds: userInfo.clientId
    })

    console.log(userInfo.clientId);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;

    that.getalllist();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})