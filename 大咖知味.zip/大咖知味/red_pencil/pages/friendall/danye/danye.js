// pages/friendall/danye/danye.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
const userId = app.globalData.userId;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    xxx: true,
    context:"",
    host: host,
    commentid:0,
    name:"",
    url: url,
    host: host,
    cfid:0,
    detail:[],
    qianName: '评论'
  },
  dianzan: function (e) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    let cfid = that.data.detail.cfId;
    wx.request({
      url: host + 'cflaud/laud',
      data: {
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        cfId: cfid,
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          wx.showToast({
            title: '点赞成功',
            icon: "success",
          })
          that.getdetail(cfid)
        }
      }
    })
  },
  imgYu: function (event) {//获取data-src
    var that = this;
    let imgList, imgList2 = [];//获取data-list
    let midx = event.currentTarget.dataset.midx;
    imgList = that.data.detail.image;
    for (let i = 0; i < imgList.length; i++) {
      imgList2.push(that.data.host + imgList[i])
    }
    //图片预览
    wx.previewImage({
      current: that.data.host + that.data.detail.image[midx],
      urls: imgList2 // 需要预览的图片http链接列表
    })
  },
  laudlist: function (e) {
    let cfid = e.currentTarget.dataset.cfid;
    wx.navigateTo({
      url: '../laudlist/laudlist?cfid=' + cfid,
    })
  },
  pintag:function(e){
    var that=this;
    let commentid = e.currentTarget.dataset.commentid;
    let name = e.currentTarget.dataset.name;
    that.setData({
      commentid: commentid,
      name: name,
      context:"",
      qianName: '回复'
    })
  },
  xxx: function (e) {
    this.setData({
      xxx: !(this.data.xxx),
    })
  },
  gettext:function(e){
    this.setData({
      context: e.detail.value,
    })
  },
  sendping: function (e) {
    var that = this;
    var userInfo = wx.getStorageSync("userinfo_key");
    if (that.data.context==""){
      wx.showModal({
        title: '温馨提示',
        content: '内容不能为空',
      })
      return;
    }
    wx.request({
      url: host + 'cfcomment/publish',
      data: {
        userId: userId,
        openId: userInfo.openid,
        nickName: userInfo.nickName,
        headImgUrl: userInfo.avatarUrl,
        content: that.data.context,
        cfId: that.data.detail.cfId,
        targetId: that.data.commentid,
      },
      success: function (res) {
        console.log("发送信息的", res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          that.setData({
            commentid: 0,
          })
          wx.showToast({
            title: '评论成功',
            icon: "success",
          })
          wx.navigateBack({
            data: 1
          });
          
          that.getdetail(that.data.detail.cfId)
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var cfid = options.cfid;
    that.setData({
      cfid: cfid,
    })
    console.log(options);
    that.getdetail(cfid);
    // wx.request({
    //   url: url + '/cf/getDetail',
    //   data: {
    //     cfId: cfid,
    //   },
    //   success: function (res) {
    //     console.log("ces", res)
    //     if (res.data.code != 0) {
    //       wx.showModal({
    //         title: '温馨提示',
    //         content: res.data.msg,
    //       })
    //     } else {
    //       that.setData({
    //         detail: res.data.data,
    //       })
    //       console.log("detail", that.data.detail)
    //     }
    //   }
    // })
  },
  getdetail: function (cfid){
    var that=this;
    wx.request({
      url: url + '/cf/getDetail',
      data: {
        cfId: cfid,
      },
      success: function (res) {
        console.log("ces", res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          that.setData({
            detail: res.data.data,
          })
          console.log("detail", that.data.detail)
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})