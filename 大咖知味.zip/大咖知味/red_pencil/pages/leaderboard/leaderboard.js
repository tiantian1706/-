// pages/leaderboard/leaderboard.js
var testhost = "https://menu.honqb.com";
var host = "https://menu.honqb.com/";
var app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tabIds: 1,
    imgUrl: host,
    getRankByShop: [],
    getAllResultByClientId: []
  },

  /**
   * 生命周期函数--监听页面加载
   */
  toshop: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + e.currentTarget.dataset.inx + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
    });
  },
  getAllResultByClientId: function() {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/getAllResultByClientId',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      success: function (res) {
      var sArray = [];
      for (var i = 0, len = res.data.data.length; i < len; i++) {

        console.log(res.data.data[i].commodity);

        if (res.data.data[i].title != '谢谢参与') {
          sArray.push(res.data.data[i]);
        }
      }

       that.setData({
         getAllResultByClientId: sArray
       })
      }
    })
  },
  getRankByShop: function() {
    var that = this;
    wx.request({
      url: host + 'luckydraw/getRankByShop',
      data: {
        userId: app.globalData.userId
      },
      success: function(res) {
        that.setData({
          getRankByShop: res.data.data
        })
      }
    })
  },
  
  onLoad: function (options) {
    var that = this;
    that.getRankByShop();
    that.getAllResultByClientId();
  },
  tabtop: function(e) {
    var that = this;
    var ids = e.currentTarget.dataset.index;
    
    that.setData({
      tabIds: ids
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})