// pages/newtreatdetail/newtreatdetail.js
var app = getApp()
var testhost = app.globalData.url;
var host = app.globalData.url;
var menuhost = "https://menu.honqb.com";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    menuhost: menuhost,
    testhost: testhost,
    shopAddress:'',
    createTimes:true,
    intervitemane:'',
    interviteId:0,
    interdetail:[],
    shengs:0,
    headImgUrl:'',
    isaccept:false,
    shopName:'',
    howmany:0,
    shopname2:'',
    address:'',
    shoparr:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var userid = options.userid.replace("z", "");
    that.setData({
      interviteId: options.interviteId,
      shopCommodityId: options.shopCommodityId,
      shopname2: options.shopname,
      address: options.address,
    })
    console.log("怎么都打印下interviteId!!!!!", options);
    // console.log("是否本人！", JSON.parse(options.clientId))
    if (userinfo.clientId == userid && userid!=null){
      console.log()
      wx.redirectTo({
        url: '../treatDetail/treatDetail?interviteId=' + that.data.interviteId + '&shopCommodityId=' + that.data.shopCommodityId +'&isfirst=1',
      })
    }else{
      wx.request({
        url: menuhost + '/intervite/get',
        data: {
          interviteId: options.interviteId,
          // interviteId: that.data.interviteId,
        },
        dataType: 'json',
        method: 'get',
        success: function (res) {
          console.log('显示邀请的详情!', res, userinfo.clientId,);
          wx.request({
            url: menuhost + '/gourmetrouteshop/get',
            data: {
              shopId: parseInt(res.data.data.shopId),
            },
            dataType: 'json',
            method: 'get',
            success:function(res){
              that.setData({
                shoparr: res.data.data,
              })
              console.log("商品信息！",res)
            },
          })
          // wx.request({
          //   url: '',
          //   data:{
          //     res.data.data.shopCommodityId
          //   }
          // })
          if (res.data.data == ' ' || res.data.data == null || res.data.data==undefined){
            wx.showModal({
              title: '提示',
              content: res.data.msg,
              success: function (res) {
                wx.redirectTo({
                  url: '../mytreat/mytreat',
                })
              }
            })
          } else if (userinfo.clientId == res.data.data.clientId){
            // wx.redirectTo({
            //   url: '../treatDetail/treatDetail?interviteId=' + that.data.interviteId + '&shopCommodityId=' + that.data.shopCommodityId +'&isfirst=1',
            // })
          }else{
            that.setData({
              headImgUrl: res.data.data.headImgUrl,
              // shopAddress: res.data.data.address,
              createTimes: res.data.data.dinnerTime,
              intervitemane: res.data.data.nickName,
              interdetail: res.data.data,
              // shopName: res.data.data.shopName,
            })

            var frisendid = res.data.data.friends.split(",");
            console.log("这个是friends的长度！！", frisendid.length, userinfo.clientId);

            if (frisendid[0] == "") {
              that.setData({
                howmany: 7 - frisendid.length,
              })
            } else {
              that.setData({
                howmany: 6 - frisendid.length,
              })
            }
            if (res.data.data.friends.indexOf(userinfo.clientId) != -1) {
              that.setData({
                isaccept: true,
              })
            }
          // for (let i = 0; i < frisendid.length; i++) {
          //   if (userinfo.clientId == frisendid[i]) {
          //     that.setData({
          //       isaccept: true,
          //     })
          //   }
          // }
          }
        },
        fail: function (res) { }
      })
    }
  },
  invite_accept: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    if(!that.data.isaccept){
      that.setData({
        isaccept: true,
      })
      wx.request({
        url: menuhost + '/intervite/acceptIntervite',
        data: {
          userId: app.globalData.userId,
          interviteId: that.data.interviteId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
        },
        method: 'get',
        header: {
          'content-type': 'application/json'
        },
        success: function (redata) {
          console.log("朋友接受邀请后的返回", redata);
          wx.request({
            url: menuhost + '/intervite/get',
            data: {
              interviteId: that.data.interviteId,
            },
            dataType: 'json',
            method: 'get',
            success: function (res) {
              console.log('显示邀请的详情!', res, userinfo.clientId, parseInt(res.data.data.clientId));
              that.setData({
                interdetail: res.data.data,
                howmany: 6 - res.data.data.friends.split(",").length,
              })
              // if (that.data.interdetail.list.length < 7) {
              //   var shengs = 7 - that.data.interdetail.list.length;
              //   that.setData({
              //     sheng: shengs,
              //   })
              // }
            },
            fail: function (res) { }
          })
        }
      })
    }else{
      wx.reLaunch({
        url: '../index3/index3'
      })
    }
  },
  tude: function () {
    var that = this
    wx.request({
      url: host + '/notify/navigation',
      data: {
        address: that.data.shopAddress
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })
        console.log(res)
        console.log("latitude000", that.data.latitude)
        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  headline: function () {
    var that = this;
    wx.request({
      url: host + '/user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('地址', res);
        that.setData({
          shopName: res.data.data.shopName,
          shopAddress: res.data.data.shopAddress
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        // var latitude = res.latitude
        // var longitude = res.longitude
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          address: that.data.shopAddress
        })
      }
    })
  },
  didian: function () {
    var that = this
    that.tude();
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})