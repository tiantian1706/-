// pages/location/location.js
import qqmap from '../../utils/map.js';//地图
import area from '../../data/area.js';//地区
import areaData from '../../data/areaData.js';//地区
import { Initials } from '../../utils/initials.js';
var InitialsModel = new Initials();
var app = getApp();

Page({
  data: {
    //下面是字母排序
    letter: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"],
    cityListId: '',
    citylists: [],
    //下面是城市列表信息，这里只是模拟数据
    citylist: [],
    //下面是热门城市数据，模拟数据
    newcity: ['北京', '上海', '广州', '深圳', '成都', '杭州'],
    // citySel: '全国',
    locateCity: '',
    showLoading: true,
  },

  //点击城市
  cityTap(e) {
    console.log(e)
    const val = e.currentTarget.dataset.val || '',
      types = e.currentTarget.dataset.types || '',
      Index = e.currentTarget.dataset.index || '',
      that = this;
    let city = this.data.citySel;
    switch (types) {
      case 'locate':
        //定位内容
        city = this.data.locateCity;
        break;
      case 'national':
        //全国
        city = '全国';
        break;
      case 'new':
        //热门城市
        city = val;
        break;
      case 'list':
        //城市列表
        city = val.cityName;
        break;
    }
    if (city) {
      wx.setStorage({
        key: 'city',
        data: city
      })
      //点击后给父组件可以通过bindcitytap事件，获取到cityname的值，这是子组件给父组件传值和触发事件的方法
      console.log("city", city)
      // this.triggerEvent('citytap', { cityname: city });

      let pages = getCurrentPages();//当前页面
      let prevPage = pages[pages.length - 2];//上一页面
      prevPage.setData({
        iamhere: city,
      })
      wx.navigateBack({
        delta: 1,
      })
      
    } else {
      console.log('还没有');
      this.getLocate();
    }

  },
  //点击城市字母
  letterTap(e) {
    const Item = e.currentTarget.dataset.item;
    this.setData({
      cityListId: Item
    });
    console.log("..............." + this.data.cityListId);
  },
  //调用定位
  getLocate() {
    let that = this;
    new qqmap().getLocateInfo().then(function (val) {//这个方法在另一个文件里，下面有贴出代码
      console.log(val);
      if (val.indexOf('市') !== -1) {//这里是去掉“市”这个字
        console.log(val.indexOf('市') - 1);
        val = val.slice(0, val.indexOf('市'));
        console.log(val);
      }
      that.setData({
        locateCity: val
      });
      //把获取的定位和获取的时间放到本地存储
      wx.setStorageSync('locatecity', { city: val, time: new Date().getTime() });
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("JSON.parse(areaData)", JSON.parse(areaData)[0])
      that.setData({
      citylist: JSON.parse(areaData),
      // citylist: moth,
    }, function () {
      that.setData({
        showLoading: false
      }, function () {
        wx.hideLoading();
      })
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function (){
    
    console.log(getApp());
    let that = this,
      cityOrTime = wx.getStorageSync('locatecity') || {},
      time = new Date().getTime(),
      city = '';


    if (!cityOrTime.time || (time - cityOrTime.time > 1800000)) {//每隔30分钟请求一次定位
      this.getLocate();
    } else {//如果未满30分钟，那么直接从本地缓存里取值
      that.setData({
        locateCity: cityOrTime.city
      })
    }

  },
  cityData: function (c) {
    var c = c || 0
      , that = this
      , district = area
      , zim
      , zm
      , keys
      , values = {}
      , arrays = []
      , arrsd = [];

    delete district['100000'];


    console.log("district", district)
    // test = new a(1, 2);
    for (var key in district) {
      keys = district[key];
      for (var k in keys) {
        //console.log(keys[k])

        zim = InitialsModel.getData(keys[k]);
        zm = zim[0].slice(0, 1);
        //console.log(zm);

        if (zm == 'A') {

          values = {
            "type": "A",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'B') {
          values = {
            "type": "B",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'C') {
          values = {
            "type": "C",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'D') {
          values = {
            "type": "D",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'E') {
          values = {
            "type": "E",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'F') {
          values = {
            "type": "F",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'G') {
          values = {
            "type": "G",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'H') {
          values = {
            "type": "H",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'I') {
          values = {
            "type": "I",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'J') {
          values = {
            "type": "J",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'K') {
          values = {
            "type": "K",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'L') {
          values = {
            "type": "L",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'M') {
          values = {
            "type": "M",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'N') {
          values = {
            "type": "N",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'O') {
          values = {
            "type": "O",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'P') {
          values = {
            "type": "P",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'Q') {
          values = {
            "type": "Q",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'R') {
          values = {
            "type": "R",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'S') {
          values = {
            "type": "S",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'T') {
          values = {
            "type": "T",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'U') {
          values = {
            "type": "U",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'V') {
          values = {
            "type": "V",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'W') {
          values = {
            "type": "W",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'X') {
          values = {
            "type": "X",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'Y') {
          values = {
            "type": "Y",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
        } else if (zm == 'Z') {
          values = {
            "type": "Z",
            "id": k,
            "cityName": keys[k]
          }

          arrsd.push(values);
          console.log("arrsd", arrsd)
        }

      }
    }

    var moth = [],
      flag = 0,
      list = arrsd;
    var wdy = {
      letter: '',
      data: ''
    }
    for (var i = 0; i < list.length; i++) {
      var az = '';
      for (var j = 0; j < moth.length; j++) {
        if (moth[j].letter == list[i]['type']) {
          flag = 1;
          az = j;
          break;
        }
      }
      if (flag == 1) {
        var ab = moth[az];
        ab.data.push(list[i]);
        flag = 0;

      } else if (flag == 0) {
        wdy = {};
        wdy.letter = list[i]['type'];
        wdy.data = new Array();
        wdy.data.push(list[i]);
        moth.push(wdy);
      }
    }

    moth = moth.sort(function (a, b) {
      return a.letter > b.letter ? 1 : -1
    });
  }
})