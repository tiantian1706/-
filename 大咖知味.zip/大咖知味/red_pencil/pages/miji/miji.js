// pages/miji/miji.js

var app = getApp();
var testhost = app.globalData.url;
var host = app.globalData.host;
var key = app.globalData.key;
var zhan;

var compare = function (prop) {
  return function (obj1, obj2) {
    var val1 = obj1[prop];
    var val2 = obj2[prop]; if (val1 < val2) {
      return -1;
    } else if (val1 > val2) {
      return 1;
    } else {
      return 0;
    }
  }
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    mijizu:[],
    host:host,
    testhost: testhost,
    userlongitude:0,
    userlatitude:0,
    dataallmenu:[],
    haveclose: true,
    // 扇形
    p2rotate: 90,
    shuozhan: false,
    wid51: 51,
    heig56: 56,
    gangrotate: 0,
    gangmarig1: 2,
    animationData: {},
    searchForInputValues: '',
    tabMenuIndex: 0,
    iamhere:"",
    miyao: key,
    showLoading:true,
  },
  // 地址
  locationGo: function () {
    wx.navigateTo({
      url: '../location/location?url=coupon',
    })
  },
  search: function (e) {
    wx.navigateTo({
      url: '../sreach/sreach',
    })
  },
  tabMenu: function(e) {
    var that = this;
    var index = e.currentTarget.dataset.index;

    if (index == 0) {
      // 最新
      that.getAll(0, 0)
    } else if (index == 1) {
      // 人气
      that.getAll(0, 1)
    } else if (index == 2) {
      // 距离
      that.getAll(0, 2)
    } 

    that.setData({
      tabMenuIndex: index
    })
  },
  // 扇形
  zhankai: function (e) {
    var that = this;

    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
    }
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },

  // 扇形
  tomijidetail:function(e){
    console.log(e.currentTarget.dataset.menuid)
    wx.navigateTo({
      url: '../mijidetail/mijidetail?menuid=' + e.currentTarget.dataset.menuid + '&shopId=' + e.currentTarget.dataset.shopid
    })
  },
  closeguang:function(){
    this.setData({
      haveclose: false,
    })
  },
  getAll: function(ids, types) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )

        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=' + that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resb) {
            console.log("自己位置的地区", resb, )
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district == '') {
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            } else {
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }
          },
        })

        wx.request({
          url: testhost + '/gourmetmenu/getAll',
          data: {
            userId: app.globalData.userId,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showToast({
                title: res.data.msg,
              })
            } else {
              var thisallmenu = res.data.data;
              var dataallmenu = [];
              console.log("allshoparr", thisallmenu);

              var newmenus;
              for (let i = 0; i < thisallmenu.length; i++) {
                
                if (ids == 0) {
                  newmenus = {
                    juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, thisallmenu[i].shopInfo.lat, thisallmenu[i].shopInfo.lng),
                    preview: thisallmenu[i].preview,
                    thisarr: thisallmenu[i],
                  }
                  dataallmenu.push(newmenus);
                } else {
                  if (thisallmenu[i].title.indexOf(that.data.searchForInputValues) != -1) {
                    newmenus = {
                      juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, thisallmenu[i].shopInfo.lat, thisallmenu[i].shopInfo.lng),
                      preview: thisallmenu[i].preview,
                      thisarr: thisallmenu[i],
                    }
                    dataallmenu.push(newmenus);
                  }
                }
              }

              if (types == 0) {
                console.log(0);
                dataallmenu = dataallmenu
              } else if (types == 1){
         
                dataallmenu = dataallmenu.sort(function(a, b){
                  return  b.preview - a.preview;
                });
                
                console.log(dataallmenu);

              } else if (types == 2) {
         
                dataallmenu = dataallmenu.sort(function (a, b) {
                  return a.juli - b.juli;
                });
              }

              that.setData({
                dataallmenu: dataallmenu,
              }, function () {
                that.setData({
                  showLoading: false
                }, function () {
                  wx.hideLoading();
                })
              })
            }
          },
        })
      }
    });
  },
  searchForInput: function(e) {
    var that = this;
    var inputValue = e.detail.value;

    that.setData({
      searchForInputValues: inputValue
    })
  },
  // 搜索
  searchFor: function() {
    var that = this;
    that.getAll(that.data.searchForInputValues);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    console.log("tabMenuIndex", that.data.tabMenuIndex)
    that.getAll(0,that.data.tabMenuIndex);
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})