// pages/zhaodaka/zhaodaka.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var userinfo = wx.getStorageSync("userinfo_key");
Page({
  /**
   * 页面的初始数据
   */
  data: {
    zhaopaizu: [],
    host: host,
    testhost: testhost,
    daka: {},
  },

  tozhaodetail: function (e) {
    console.log(e.currentTarget.dataset.foodid)
    wx.navigateTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.foodid,
    })
  },
  seemore: function (r) {
    var that = this;
    console.log("超高难度", r.currentTarget.dataset.inx)
    that.data.zhaopaizu[r.currentTarget.dataset.inx].miaosu = that.data.zhaopaizu[r.currentTarget.dataset.inx].foodarr.other[0].content;
    that.data.zhaopaizu[r.currentTarget.dataset.inx].moreclick = false;
    that.setData({
      zhaopaizu: that.data.zhaopaizu,
    })
  },
  shoucang: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.inx)
    wx.request({
      url: testhost + '/gourmetfood/option',
      data: {
        foodId: e.currentTarget.dataset.foodid,
        event: (e.currentTarget.dataset.iscang == 0 ? 2 : 4),
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        // console.log("点钟", res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
        } else {
          // console.log("进来啦！！", res)
          wx.request({
            url: testhost + '/gourmetfood/getOptionMySelf',
            data: {
              foodId: e.currentTarget.dataset.foodid,
              userId: app.globalData.userId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              openId: userinfo.openid,
            },
            dataType: 'json',
            method: 'get',
            success: function (resd) {
              if (resd.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: resd.data.msg,
                })
              } else {
                console.log("收藏", resd);
                if (resd.data.data.collect > 0) {
                  that.data.zhaopaizu[e.currentTarget.dataset.inx].iscang = 1;
                  wx.showToast({
                    title: '收藏成功',
                  })
                } else if (resd.data.data.collect == 0) {
                  that.data.zhaopaizu[e.currentTarget.dataset.inx].iscang = 0;
                } else {
                  console.log("点赞收藏的出错！", resd)
                }
                that.setData({
                  zhaopaizu: that.data.zhaopaizu,
                })
              }
            },
          })
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.showLoading({
      title: '加载中',
    })
    that.setData({
      daka: JSON.parse(options.arr),
    })
    console.log("options", JSON.parse(options.arr))
    wx.request({
      url: testhost + '/gourmetfood/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showToast({
            title: res.data.msg,
          })
        } else {
          var zhaopaizu = [];
          for (let x in res.data.data) {
            wx.request({
              url: testhost + '/gourmetfood/getOptionMySelf',
              data: {
                foodId: res.data.data[x].foodId,
                userId: app.globalData.userId,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                openId: userinfo.openid,
              },
              dataType: 'json',
              method: 'get',
              success: function (resd) {
                let newfood = { iscang: resd.data.data.collect, foodarr: res.data.data[x], miaosu: res.data.data[x].other[0].content.slice(0, 45), moreclick: (res.data.data[x].other[0].content.length > 45 ? true : false), }
                for (let z = 0; z < that.data.daka.menu.length; z++) {
                  if (res.data.data[x].foodId == that.data.daka.menu[z]) {
                    zhaopaizu.push(newfood);
                  }
                  if (z == that.data.daka.menu.length - 1) {
                    that.setData({
                      zhaopaizu: zhaopaizu,
                    })
                    wx.hideLoading();
                  }
                }
              },
            })
          }
        }
      },
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})