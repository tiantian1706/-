// pages/coupondetail/coupondetail.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    url: url,
    juanarr:[],
    lijima:'立即领取',
    isling:false,
    couponid:0,
  },
  bieling:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host+'shopcoupons/teamReceive',
      data: {
        couponsId: that.data.couponid,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success:function(res){
        console.log(res)
      },
    })
  },
  linqude:function(e){
    // wx.navigateTo({
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var couponid = that.data.juanarr.couponsId;
    if (!that.data.isling){
      wx.request({
        url: host + 'shopcoupons/receive',
        data: {
          couponsId: that.data.couponid,
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          console.log(res)
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log(res)
            // wx.redirectTo({
            //   url: '../coupondeyi/coupondeyi?juanarr=' + JSON.stringify(that.data.juanarr),
            // })
          }
        },
      })
    }else{
      wx.switchTab({
        url: '../find/find',
      })
    }
  },
  toshop:function(e){
    var that=this;
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + that.data.juanarr.shopId
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("couponid看过来", JSON.parse(options.juanarr), options.couponid)
    var juanarr = JSON.parse(options.juanarr);
    if (options.couponid!=undefined){
      console.log("1");
      that.setData({
        // juanarr: JSON.parse(options.juanarr),
        couponid: options.couponid,
      })
    }else{
      juanarr.rule = juanarr.rule.split('\n');
      console.log("2");
      that.setData({
        juanarr: juanarr,
        couponid: juanarr.couponsId,
      })
      // console.log("juanarr.rule", that.data.juanarr.rule)
    }
    // 我的优惠劵！！！
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function(res){
        for (let i = 0; i < res.data.data.length;i++){
          if (res.data.data[i].oldCouponsId == that.data.couponid){
            that.setData({
              isling:true,
              lijima: '立即使用',
              wode: res.data.data[i],
            })
            console.log("我的！", res.data.data[i])
            break;
          }
        }
      },
      fail: function(res){}
    })
    // 我的优惠劵！！！
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    console.log("商品数量", this.data.sales)
    var that = this;
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res, )
      }
    })
    return {
      title: that.data.remark,
      path: 'pages/coupondetail/coupondetail?couponid=' + that.data.couponid,
      imageUrl: 'https://basehqb.honqb.com/data/upload/image/xcx/han.jpg',
      success: function (res) {
        // // 转发成功
        console.log("信测转发的！", 'pages/newtreatdetail/newtreatdetail?interviteId=' + that.data.interviteId + '&clientId=' + userinfo.clientId + '&shopCommodityId=' + that.data.shopCommodityId + '&userid=z' + that.data.qingid + '&isfirst=1')
        wx.showModal({
          title: '提示',
          content: '成功发出邀请',
          success: function (res) {
            console.log("转发的interviteId!!!!!!", that.data.interviteId)
            if (that.data.isfirst == 0) {
              wx.redirectTo({
                url: '../mytreat/mytreat',
              })
            }
          }
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
})