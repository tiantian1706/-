// pages/subscribe/subscribe.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dinnertime:'',
    testhost: testhost,
    host: host,
    num:0,
    phone:0,
    pople:0,
    remark:'',
    shopname:'',
    shopaddress: '',
    lineidx: 0,
    shopidx: 0,
    shopId:0,
    appointmentid:0,
    subscribearr:[],
    shoparr:[],
    hiddenLoading: true,
  },
  toshop:function(e){
    var that=this;
    // console.log(that.data.shopId)
    wx.redirectTo({
      url: '../shop2/shop2?shopId=' + that.data.shopId + "&lineidx=" + that.data.lineidx + "&shopidx=" + that.data.shopidx,
    })
  },
  consoding:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.showModal({
      title: '温馨提示',
      content: '确定取消订单吗？',
      success:function(back){
        if (back.confirm) {
          wx.request({
            url: testhost + '/appointment/cancel',
            data: {
              appointmentId: that.data.appointmentid,
              userId: app.globalData.userId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              openId: userinfo.openid,
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            dataType: '',
            success: function (res) {
              console.log("我取消了？", res)
              wx.navigateBack({
                delta: 1
              });
              // if (res.data.code!=0){
              //   wx.showModal({
              //     title: res.data.msg,
              //     content: '',
              //   })
              // }else{
              //   wx.navigateBack({
              //     delta: 1
              //   });
              // }
            },
          })
        } else if (back.cancel) {
          // wx.showToast({
          //   title: '放弃取消',
          //   icon: 'success',
          // })
          return;
        }
      },
    })
  },
  tomap: function (e) {
    var that = this;
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.shoparr.address,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("获取的经纬度", res)
        wx.openLocation({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng,
          scale: 28,
        })
      },
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // /appointment / get
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log(options, parseInt(options.appointmentid))
    if (options.num == undefined) {
      that.setData({
        shopId: options.shopId,
        appointmentid: options.appointmentid,
      });
      wx.request({
        url: testhost + '/appointment/get',
        data: {
          appointmentId: parseInt(options.appointmentid),
        },
        dataType: 'json',
        method: 'get',
        success: function (res) {
          console.log("接受的", res)
          that.setData({
            subscribearr: res.data.data,
            hiddenLoading: false,
          })
        },
      })
    } else {
      that.setData({
        noaid: true,
        shopId: options.shopid,
        dinnertime: options.dinnertime,
        num: options.num,
        phone: options.phone,
        pople: options.pople,
        remark: options.remark,
        shopaddress: options.shopaddress,
        shopname: options.shopname,
        appointmentid: options.appointmentid,
        hiddenLoading: false,
      });
    }
    // that.setData({
    //   shopId: options.shopid,
    //   // dinnertime: options.dinnertime,
    //   // num: options.num,
    //   // phone: options.phone,
    //   // pople: options.pople,
    //   // remark: options.remark,
    //   // shopaddress: options.shopaddress,
    //   // shopname: options.shopname,
    //   // lineidx: options.lineidx,
    //   // shopidx: options.shopidx,
    //   // shopId: options.shopId,
    //   appointmentid: options.appointmentid,
    // });

    // wx.request({
    //   url: testhost + '/appointment/get',
    //   data: {
    //     appointmentId: parseInt(options.appointmentid),
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success:function(res){
    //     console.log("接受的",res)
    //     that.setData({
    //       subscribearr:res.data.data,
    //     })
    //   },
    // })
    wx.request({
      url: testhost + '/gourmetrouteshop/get',
      data: {
        shopId: options.shopId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("查询商品信息！！", res)
        that.setData({
          shoparr: res.data.data,
        })
      },
    })
    // wx.request({
    //   url: testhost + '/gourmetrouteline/getAll',
    //   data: {
    //     userId: app.globalData.userId,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success:function(res){
    //     console.log("美食地图总列表",res.data.data)

    //   },
    // })
    // wx.request({
    //   url:testhost+ '/appointment/myApply',
    //   data:{
    //     userId: app.globalData.userId,
    //     nickName: userinfo.nickName,
    //     headImgUrl: userinfo.avatarUrl,
    //     openId: userinfo.openid,
    //     shopId: options.shopId,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success:function(res){
    //     if (res.data.code == 1) {
    //       wx.showModal({
    //         title: '温馨提示',
    //         content: res.data.msg,
    //       })
    //     }else{
    //       console.log("预定信息",res)
    //     }
    //   },
    // })
    //请客菜详情？

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})