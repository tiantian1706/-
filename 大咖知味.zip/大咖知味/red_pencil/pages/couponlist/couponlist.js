// pages/couponlist/couponlist.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
var testhost = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host:host,
    testhost:testhost,
    coulists:[],
    mycoulist:[],
    zhijie:0,
    wozhijie:0,
    isold:false,
    todecou:[],
  },
  zongliebiao:function(afun){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          coulists: res.data.data,
        })
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method==1){
            that.setData({
              zhijie: (++that.data.zhijie),
            })
            console.log("zhijie", that.data.zhijie);
          }
        }
        console.log('总优惠劵！！！', that.data.coulists);
        return afun();
      },
      fail: function (res) {}
    })
  },
  myjuan:function(afun){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.setData({
              wozhijie: (++that.data.wozhijie),
            })
            console.log("wozhijie", that.data.wozhijie);
          }
        }
        console.log('我的优惠劵！！！', that.data.mycoulist);
        return afun();
      },
      fail: function (res) {}
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key")
    that.zongliebiao(function(){
      that.myjuan(function(){
        console.log("打印.zhijie,.wozhijie",that.data.zhijie,that.data.wozhijie)
        if (that.data.zhijie >= that.data.wozhijie){
          console.log("我还是新人")
        }else{
          console.log("我已经不是新人了")
        }
      })
    })
  },
  todetail: function (er) {
    var that = this;
    console.log(er.currentTarget.dataset.method)
    if (er.currentTarget.dataset.method==2){
      wx.navigateTo({
        url: '../couponactivity/couponactivity',
      })
    }else{
      console.log("erxx", er)
      for (let z = 0; z < that.data.mycoulist.lengthl;z++){
        
      }
      that.lingqu(er.currentTarget.dataset.couponsid,1,function(){
        that.myjuan(function(){
          for (let i = 0; i < that.data.mycoulist.length; i++) {
            if (that.data.mycoulist[i].dedaodeid == that.data.dedaodeid) {
              wx.navigateTo({
                url: '../coupondetail/coupondetail?juanarr=' + JSON.stringify(that.data.mycoulist[i]),
              })
              return;
            }
          }
        })
      })
    }
  },
  lingqu: function (er, isc,afun) {
    var that = this;
    // console.log(that.data.coulist[er.currentTarget.dataset.idx],er);
    var userinfo = wx.getStorageSync("userinfo_key")
    var lingcouponsid;
    console.log("zzzzzzzzz", isc);
    // if (er.currentTarget.dataset.couponsid!=undefined)
    if (isc==undefined){
      lingcouponsid = er.currentTarget.dataset.couponsid
    }else{
      lingcouponsid = er;
    }
    wx.request({
      url: host + 'shopcoupons/receive',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
        couponsId: lingcouponsid,
      },
      dataType: 'json',
      method: 'get',
      success: function (rr) {
        if (rr.data.code != 0){
          wx.showModal({
            title: '温馨提示',
            content: rr.data.msg,
          })
          return;
        } else {
          that.setData({
            dedaodeid:rr.data.data,
          })
          console.log("领取后的",rr);
          return afun();
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})