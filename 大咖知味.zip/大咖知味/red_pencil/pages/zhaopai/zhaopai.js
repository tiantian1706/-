// pages/zhaopai/zhaopai.js
var app = getApp();
var host = app.globalData.host;
var testhost = app.globalData.url;
var userinfo = wx.getStorageSync("userinfo_key");
var area = require('../../data/area');
var p = 0, c = 0, d = 0;
var zhan;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  
  data: {
    zhaopaizu: [],
    host: host,
    imgUrl: app.globalData.imgUrl,
    testhost: testhost,
    imgUrls: [],
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    miyao: "CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
    userlongitude: 0,
    userlatitude: 0,
    beiuserlongitude: 0,
    beiuserlatitude: 0,
    showDistpicker: false,
    provinceName: [],
    provinceCode: [],
    provinceSelIndex: '',
    cityName: [],
    cityCode: [],
    citySelIndex: '',
    xiantan: true,
    districtName: [],
    districtCode: [],
    districtSelIndex: '',
    iamhere: '顺德区',
    zhijie:[],
    wozhijie:'',
    fencouponsId:0,
    isnew:0,
    loading:true,
    dakalist:[],
    active:false,
    p2rotate:90,
    shuozhan:false,
    wid51:51,
    heig56:56,
    gangrotate:0,
    gangmarig1:2,
    animationData:{},
    gourmetfoodAllData: [],
    showLoading: true,
    userlongitude: "",
    userlatitude: "",
  },

  // 小程序跳转
  otherIndexGo:function(){
    wx.navigateToMiniProgram({
      appId: 'wxcc4a5eb5b832869b',
      path: 'pages/indexs/indexs?id=123',
      extraData: {
        
      },
      envVersion: 'develop',
      success:function(res) {
        // 打开成功
        console.log("success", res)     
      },
      fail: function(res){
        console.log("fail",res)
      },
      complete: function(res){
        console.log("complete", res)
      },
    })
  },
  couponUrl: function() {
    wx.navigateTo({
      url: '../coupon/coupon'
    })
  },
  baUrl: function () {
    var that = this;

    // method == 1 是大转盘 2 是8.88
    if (that.data.luckydrawData.method == 1) {
      wx.navigateTo({
        url: '../bigTurntable/bigTurntable?shopId=0',
      })
    } else {
      wx.navigateTo({
        url: '../games2/games2?shopId=0',
      })
    }
  },
  games: function () {
    var that = this;

    // method == 1 是大转盘 2 是8.88
    if (that.data.luckydrawData.method == 1) {
      wx.navigateTo({
        url: '../bigTurntable/bigTurntable?shopId=0',
      })
    } else {
      wx.navigateTo({
        url: '../games2/games2?shopId=0',
      })
    }

  },
  getDefault: function (shopId) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId,
      },
      success: function (res) {

        var getDefault = res.data.data;
        if (getDefault) {
          luckyDrawId = getDefault.luckyDrawId;
          that.luckydraw();
        }

      }
    })
  },
  luckydraw: function () {
    var that = this;

    wx.request({
      url: host + 'luckydraw/get',
      data: {
        luckyDrawId: luckyDrawId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }
        that.setData({
          luckydrawData: res.data.data
        });
        if (res.data.data.state == 2) {
          that.setData({
            baUrl: true
          })
        }
      }
    })
  },
  leaderboard: function() {
    var that = this;
    wx.navigateTo({
      url: '../leaderboard/leaderboard',
    })
  },
  dengduo: function(){
    wx.navigateTo({
      url: '../index3/index3?isType=1',
      success: function(res) {},
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  toshop: function (e) {
    var that = this;

    if (that.data.gourmetfoodAllData.length != 0) {
        wx.navigateTo({
          url: '../shop2/shop2?shopId=' + that.data.gourmetfoodAllData[e.currentTarget.dataset.inx].shopId + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
        });
    }
  },
  getAll: function() {
    var that = this;
    wx.request({
      url:host + 'gourmetrouteshop/getAll',
      data: {
        userId: app.globalData.userId,
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        console.log("全部酒楼", res.data.data)
          var gourmetfoodAllDatas = [];
          var gourmetrouteline = res.data.data;
          that.setData({
            gourmetfoodAllData: gourmetrouteline
          })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  },
  // 扇形
  zhankai:function(e){
    var that=this;
    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
    }
  },
  clickm:function(e){
    var that=this;
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    wx.navigateTo({
      url: e.currentTarget.dataset.url,
    })
  },
  tocou:function(e){
    if (this.data.isnew == 0 || this.data.isnew == 1){
      wx.navigateTo({
        url: '../couponmy/couponmy',
      })
    }else{
      wx.navigateTo({
        url: '../couponactivity/couponactivity',
      })
    }
  },
  xinjiuren: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    that.zongliebiao(function () {
      that.myjuan(function () {
        let geshu=0;
        for (let i = 0; i < that.data.zhijie.length;i++){
          if (that.data.wozhijie.indexOf(that.data.zhijie[i])!=-1){
            geshu++
          }
          
          if (i == that.data.zhijie.length-1){
            if (geshu == 0) {
              that.setData({
                isnew: 0,
              })
            } else if (geshu < that.data.zhijie.length){
              that.setData({
                isnew: 1,
              })
            } else {
              that.setData({
                isnew: 2,
              })
            }
            that.setData({
              loading: false,
            })
          }
        }
      })
    })
  },
  zongliebiao: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          coulists: res.data.data,
        })
        that.data.zhijie=[];
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.data.zhijie.push(res.data.data[i].couponsId)
            that.setData({
              zhijie: that.data.zhijie,
            })
          } else if (res.data.data[i].method==2){
            that.setData({
              fencouponsId: res.data.data[i].couponsId,
            })
          }
        }
        if (res.data.data.length == 0) {
          that.setData({
            loading: false,
            xiantan: false,
          })
        }
        console.log('总优惠劵！！！', that.data.coulists);
        return afun();
      },
      fail: function (res) { }
    })
  },
  myjuan: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        that.data.wozhijie=''
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 1) {
            that.setData({
              wozhijie: that.data.wozhijie + res.data.data[i].oldCouponsId + ",",
            })
          }
        }
        console.log('我的优惠劵！！！', that.data.mycoulist);
        return afun();
      },
      fail: function (res) { }
    })
  },
  closetan: function (e) {
    this.setData({
      xiantan: false,
    })
  },
  tozhaodaka: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.index)
    wx.navigateTo({
      url: '../zhaodaka/zhaodaka?arr=' + JSON.stringify(that.data.dakalist[e.currentTarget.dataset.index]),
    })
  },
  tozhaodetail:function(e){
    var that = this;
    wx.navigateTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.foodid,
    })
  },
  search: function (e) {
    wx.navigateTo({
      url: '../sreach/sreach',
    })
  },
  toaddshop: function (e) {
    wx.navigateTo({
      url: '../addmyshop/addmyshop',
    })
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");

    that.getDefault(0);

    //定位地区的
    that.setAreaData();
    wx.request({
      url: host + 'banner/xcxBannerList',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        that.setData({
          imgUrls: res.data.data
        })
        console.log("轮播", that.data.imgUrls)
      },
      fail: function (res) { },
      complete: function (res) { }
    })
    wx.request({
      url: testhost + '/gourmetdaka/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        let geshu;
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].menu = res.data.data[i].menu.split(",");
        }
        that.setData({
          dakalist: res.data.data,
        })
        console.log("大咖列表dakalist", that.data.dakalist)
      },
    })

    //判断新旧人的
    that.xinjiuren();
    // that.getAll();
    // 判断新旧人的

    // 美食推荐
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlongitude: res.longitude,
          userlatitude: res.latitude,
          beiuserlongitude: res.longitude,
          beiuserlatitude: res.latitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=' + that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resb) {
            console.log("自己位置的地区", resb, )
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district == '') {
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            } else {
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }

            wx.request({
              url: host + 'gourmetfood/getAll',
              data: {
                userId: app.globalData.userId,
                recommend: 1
              },
              header: {
                'Content-Type': 'application/json'
              },
              dataType: 'json',
              method: 'get',
              success: function (res) {
                var zhaopaizu = [];
                var newfood = {};
                for (var x = 0; x < res.data.data.length; x++) {
                  var content = res.data.data[x].other[0].content.replace(/\n/g, '').slice(0, 65);
                  var line = parseInt(content.length / 11)
                  var miaosuData = [];
                  for (var t = 0; t <= line; t++) {
                    var miaosuTxte = {
                      text: content.slice(t * 11, t * 11 + 11)
                    };

                    miaosuData.push(miaosuTxte)
                  }

                  newfood = {
                    foodarr: res.data.data[x],
                    miaosu: res.data.data[x].other[0].content,
                    miaosuData: miaosuData,
                    moreclick: (res.data.data[x].other[0].content.replace(/\n/g, '').length > 65 ? true : false),
                    juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, res.data.data[x].shopInfo.lat, res.data.data[x].shopInfo.lng),
                  }

                  zhaopaizu.push(newfood);
                }

                zhaopaizu = zhaopaizu.sort(function (a, b) {
                  return a.juli - b.juli;
                });

                that.setData({
                  zhaopaizu: zhaopaizu,
                }, function () {
                  that.setData({
                    showLoading: false
                  }, function () {
                    wx.hideLoading();
                  })
                })
              }
            })
          },
        })

      }
    })
  },
  //定位地区的
  setAreaData: function (p, c, d) {
    var p = p || 0 // provinceSelIndex
    var c = c || 0 // citySelIndex
    var d = d || 0 // districtSelIndex
    // 设置省的数据
    var province = area['100000']
    var provinceName = [];
    var provinceCode = [];
    for (var item in province) {
      provinceName.push(province[item])
      provinceCode.push(item)
    }
    this.setData({
      provinceName: provinceName,
      provinceCode: provinceCode
    })
    // 设置市的数据
    var city = area[provinceCode[p]]
    var cityName = [];
    var cityCode = [];
    for (var item in city) {
      cityName.push(city[item])
      cityCode.push(item)
    }
    this.setData({
      cityName: cityName,
      cityCode: cityCode
    })
    // 设置区的数据
    var district = area[cityCode[c]]
    var districtName = [];
    var districtCode = [];
    for (var item in district) {
      districtName.push(district[item])
      districtCode.push(item)
    }
    this.setData({
      districtName: districtName,
      districtCode: districtCode
    })
  },
  changeArea: function (e) {
    p = e.detail.value[0]
    c = e.detail.value[1]
    d = e.detail.value[2]
    this.setAreaData(p, c, d)
  },
  showDistpicker: function () {
    // 地址
    wx.navigateTo({
      url: '../location/location',
    })
  },
  distpickerCancel: function () {
    var that = this;
    that.setData({
      showDistpicker: false,
      iamhere: that.data.districtName[that.data.districtSelIndex],
    })

    console.log("查询中心！！！", that.data.districtName[that.data.districtSelIndex], that.data.provinceName[that.data.provinceSelIndex], that.data.cityName[that.data.citySelIndex])
    wx.request({
      url: 'https://apis.map.qq.com/ws/district/v1/search?&keyword=' + that.data.districtName[that.data.districtSelIndex] + '&key=' + that.data.miyao,
      data: {},
      header: {
        'Content-Type': 'application/json'
      },
      dataType: 'json',
      method: 'get',
      success: function (resb) {
        console.log("查询中心！！！", resb.data.result[0][0].location, resb)
        that.setData({
          userlongitude: resb.data.result[0][0].location.lng,
          userlatitude: resb.data.result[0][0].location.lat,
          mapscale: 11,
        })
      },
    })
  },
  distpickerSure: function () {
    this.setData({
      provinceSelIndex: p,
      citySelIndex: c,
      districtSelIndex: d,
    })
    this.distpickerCancel()
    console.log(this.data.districtName[this.data.districtSelIndex])
  },
  //定位地区的
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    // 所有店铺
    that.getAll();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})