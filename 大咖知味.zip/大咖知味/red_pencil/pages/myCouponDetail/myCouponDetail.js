// pages/myCouponDetail/myCouponDetail.js
var app = getApp();
var testhost = app.globalData.url;
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    detailData: [],
    phoneXs:"",
    userlatitude:'',
    userlongitude:"",
    codeShow:false,
    showLoading: true,
    latitude: "",
    longitude: "",
    name: "",
    address: ""
  },
  codeIf: function () {
    var that = this;
    that.setData({
      codeShow: false
    })
  },
  codeIfTop: function () {
    var that = this;
    that.setData({
      codeShow: true
    })
  },

  shopGo: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + e.currentTarget.dataset.id,
    });
  },
  // 定位
  tude: function () {
    var that = this
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.address
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })
        console.log(res)
        console.log("latitude000", that.data.latitude)
        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          name: that.data.name,
          address: that.data.address
        })
      }
    })
  },
  // 定位

  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("options", options)
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })
        console.log("定位", res.latitude)
        wx.request({
          url: host + 'gourmetcouponsorder/getOne',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
            couponsId: options.couponsId,
          },
          success: function (res) {
            // 定位
            res.data.data.juli = that.newdistance(that.data.userlatitude, that.data.userlongitude, res.data.data.shopInfo.lat, res.data.data.shopInfo.lng)

            that.setData({
              detailData: res.data.data,
              phoneXs: res.data.data.shopInfo.contact,
              latitude: res.data.data.shopInfo.lat,
              longitude: res.data.data.shopInfo.lng,
              name: res.data.data.shopInfo.name,
              address: res.data.data.shopInfo.address
            }, function () {
              that.setData({
                showLoading: false
              }, function () {
                wx.hideLoading();
              })
            })
            console.log("详情", res.data.data)
          }
        })
      }
    })
  },

  phone:function(){
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phoneXs,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})