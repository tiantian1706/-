// pages/chuang/chuang.js
var app = getApp();
var testhost = app.globalData.url;
var host = app.globalData.host;
var area = require('../../data/area');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    zhaopaizu: [],
    host: host,
    testhost: testhost,
    tabMenuIndex: 0,
    miyao: "CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
    // 当季美食js版
    imgx: [{ xx: "../../imgs/s1.jpg" }, { xx: "../../imgs/s2.jpg" }, { xx: "../../imgs/s3.jpg" }, { xx: "../../imgs/s4.jpg" }, { xx: "../../imgs/s5.jpg" }, { xx: "../../imgs/s6.jpg" }, { xx: "../../imgs/s7.jpg" }, { xx: "../../imgs/s8.jpg" }, { xx: "../../imgs/s9.jpg" }],
    newimgx: [],
    iamhere:"",
    showLoading: true,
  },
  // 地址
  locationGo: function () {
    wx.navigateTo({
      url: '../location/location?url=coupon',
    })
  },
  search: function (e) {
    wx.navigateTo({
      url: '../sreach/sreach',
    })
  },
  tozhaodetail: function (e) {
    var that = this;
    wx.navigateTo({
      url: '../zhaodetail/zhaodetail?foodid=' + e.currentTarget.dataset.foodid,
    })
  },
  
  tabMenu: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    if (index == 0) {
      // 最新
      that.getAll(0)
    } else if (index == 1) {
      // 人气
      that.getAll(1)
    } else if (index == 2) {
      // 距离
      that.getAll(2)
    }

    that.setData({
      tabMenuIndex: index
    })
  },
  // 当季美食
  menujs: function (e) {
    var that = this;
    var num = 1;
    let xxx = [];
    for (let i = 0; i < that.data.imgx.length; i++) {
      if (i == that.data.imgx.length - 1) {
        if (num < 5) {
          xxx.push(that.data.imgx[i]);
          that.data.newimgx.push(xxx);
        } else {
          that.data.newimgx.push(xxx);
          xxx = [];
          xxx.push(that.data.imgx[i]);
          that.data.newimgx.push(xxx);
        }
      } else {
        if (num < 5) {
          xxx.push(that.data.imgx[i]);
          num++;
        } else {
          that.data.newimgx.push(xxx);
          xxx = [];
          num = 1;
          i--
        }
      }
    }
    that.setData({
      newimgx: that.data.newimgx
    })
    console.log("zzzz", that.data.newimgx, )
  },
  //定位地区的
  setAreaData: function (p, c, d) {
    var p = p || 0 // provinceSelIndex
    var c = c || 0 // citySelIndex
    var d = d || 0 // districtSelIndex
    // 设置省的数据
    var province = area['100000']
    var provinceName = [];
    var provinceCode = [];
    for (var item in province) {
      provinceName.push(province[item])
      provinceCode.push(item)
    }
    this.setData({
      provinceName: provinceName,
      provinceCode: provinceCode
    })
    // 设置市的数据
    var city = area[provinceCode[p]]
    var cityName = [];
    var cityCode = [];
    for (var item in city) {
      cityName.push(city[item])
      cityCode.push(item)
    }
    this.setData({
      cityName: cityName,
      cityCode: cityCode
    })
    // 设置区的数据
    var district = area[cityCode[c]]
    var districtName = [];
    var districtCode = [];
    for (var item in district) {
      districtName.push(district[item])
      districtCode.push(item)
    }
    this.setData({
      districtName: districtName,
      districtCode: districtCode
    })
  },
  changeArea: function (e) {
    p = e.detail.value[0]
    c = e.detail.value[1]
    d = e.detail.value[2]
    this.setAreaData(p, c, d)
  },
  showDistpicker: function () {
    this.setData({
      showDistpicker: true
    })
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },
  getAll: function (types) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })

        console.log("用户位置", res.longitude, res.latitude, )
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=' + that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resb) {
            console.log("自己位置的地区", resb, )
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district == '') {
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            } else {
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }
          },
        })

        wx.request({
          url: testhost + '/gourmetfood/getAll',
          data: {
            userId: app.globalData.userId,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showToast({
                title: res.data.msg,
              })
            } else {
              var zhaopaizu = [];
              for (let x in res.data.data) {
                var content = res.data.data[x].other[0].content.replace(/\n/g, '').slice(0, 65);
                var line = parseInt(content.length / 11)
                var miaosuData = [];
                for (var t = 0; t <= line; t++) {
                  var miaosuTxte = {
                    text: content.slice(t * 11, t * 11 + 11)
                  };

                  miaosuData.push(miaosuTxte)
                }
                console.log("miaosuData", miaosuData)
                let newfood = {
                  juli: that.newdistance(that.data.userlatitude, that.data.userlongitude, res.data.data[x].shopInfo.lat, res.data.data[x].shopInfo.lng),
                  preview: res.data.data[x].preview,
                  foodarr: res.data.data[x],
                  miaosu: res.data.data[x].other[0].content,
                  miaosuData: miaosuData,
                  moreclick: (res.data.data[x].other[0].content.replace(/\n/g, '').length > 65 ? true : false),
                }

                zhaopaizu.push(newfood);
              }
              console.log("zhaopaizuzhaopaizu", zhaopaizu)

              if (types == 0) {
                console.log(0);
                zhaopaizu = zhaopaizu
              } else if (types == 1) {

                zhaopaizu = zhaopaizu.sort(function (a, b) {
                  return b.preview - a.preview;
                });


              } else if (types == 2) {

                zhaopaizu = zhaopaizu.sort(function (a, b) {
                  return a.juli - b.juli;
                });
              }

              that.setData({
                zhaopaizu: zhaopaizu,
              }, function () {
                that.setData({
                  showLoading: false
                }, function () {
                  wx.hideLoading();
                })
              })

            }
          },
        })
      }
    });

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    //定位地区的
    that.setAreaData();
    that.menujs();
    //定位地区的

    // that.getAll(0);

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("tabMenuIndex", that.data.tabMenuIndex)
    that.getAll(that.data.tabMenuIndex);    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})