// pages/couponDeials2/couponDeials2.js
var app = getApp();
var testhost = app.globalData.url;
var host = app.globalData.host;
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    detailData: [],
    menuInfoData: [],
    moreShow: false,
    moreText:"查看更多",
    moreIf:true,
    showLoading: true,
    userlatitude: "",
    userlongitude: "",
    phoneXs:"",
    latitude: "",
    longitude: "",
    name: "",
    address: ""
  },
  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("初始化", options.couponsId)
    that.setData({
      couponsId: options.couponsId,
    })

    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })
        console.log("定位", res.latitude)
        wx.request({
          url: host + 'gourmetcoupons/get',
          data: {
            userId: app.globalData.userId,
            couponsId: that.data.couponsId,
          },
          success: function (res) {
            console.log("优惠券详情", res.data.data)
            var moreShow;
            var menuInfoData = [];
            // 定位
            res.data.data.juli = that.newdistance(that.data.userlatitude, that.data.userlongitude, res.data.data.shopInfo.lat, res.data.data.shopInfo.lng)
            if (res.data.data.menuInfo.length > 2) {
              for (var i = 0; i < 2; i++) {
                menuInfoData.push(res.data.data.menuInfo[i])
                res.data.data.menuInfoData = menuInfoData
              }
              moreShow = true
            } else {
              menuInfoData = res.data.data.menuInfo
              res.data.data.menuInfoData = res.data.data.menuInfo
              moreShow = false
            }
            that.setData({
              detailData: res.data.data,
              phoneXs: res.data.data.shopInfo.contact,              
              menuInfoData: menuInfoData,
              moreShow: moreShow,
              latitude: res.data.data.shopInfo.lat,
              longitude: res.data.data.shopInfo.lng,
              name: res.data.data.shopInfo.name,
              address: res.data.data.shopInfo.address
            }, function () {
              that.setData({
                showLoading: false
              }, function () {
                wx.hideLoading();
              })
            })
            console.log("detailData", that.data.detailData)
          }
        })
      }
    })

  },

  shopGo:function(e){
    var that = this;
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + e.currentTarget.dataset.id,
    });
  },

  // 定位
  tude: function () {
    var that = this
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.address
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })
        console.log(res)
        console.log("latitude000", that.data.latitude)
        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          name: that.data.name,
          address: that.data.address
        })
      }
    })
  },
  // 定位
  moreSee:function(){
    var that = this;
    if (that.data.moreIf){
      that.setData({
        moreIf:false,
        moreText: "收起",
        menuInfoData: that.data.detailData.menuInfo,        
      })
    }else{
      that.setData({
        moreIf: true,
        moreText: "查看更多",
        menuInfoData: that.data.detailData.menuInfoData,
      })
    }
  },

  // 支付
  gobuy:function(e){
    var that = this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      var userinfo = wx.getStorageSync("userinfo_key");
      wx.showModal({
        title: '提示',
        content: '确认购买？',
        success: function (res) {
          if (res.confirm) {
            wx.request({
              url: host + 'gourmetcouponsorder/createXcxOrder',
              data: {
                userId: app.globalData.userId,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                openId: userinfo.openid,
                couponsId: that.data.couponsId,
              },
              success: function (res) {
                console.log("生成订单", res)
                if (res.data.code != 0) {
                  wx.showModal({
                    title: '提示',
                    content: res.data.msg
                  })
                  return
                }
                wx.request({
                  url: host + 'gourmetcouponsorder/xcxPay',
                  dataType: 'json',
                  method: 'get',
                  data: {
                    userId: app.globalData.userId,
                    nickName: userinfo.nickName,
                    headImgUrl: userinfo.avatarUrl,
                    openId: userinfo.openid,                    
                    orderId: res.data.data,                    
                  },
                  success: function (res) {
                    console.log("支付", res)                    
                    if (res.data.code != 0) {
                      wx.showModal({
                        title: '提示',
                        content: res.data.msg
                      })
                      return
                    }
                    var result = res.data.data;
                    wx.requestPayment({
                      userId: app.globalData.userId,
                      timeStamp: result.timeStamp,
                      nonceStr: result.nonceStr,
                      package: result.package,
                      signType: result.signType,
                      paySign: result.paySign,
                      success: function (res) {
                        wx.showToast({
                          title: '支付成功',
                          icon: 'success',
                          duration: 1000
                        });
                      },
                      fail: function (res) {

                      },
                      compelete: function (res) {

                      }
                    })
                  }
                })
              }
            })
          }else{
            console.log("取消支付")
          }
        }
      })
    })

  },
  phone: function () {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phoneXs,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})