var app = getApp();
var host = app.globalData.host;
var testhost = app.globalData.url;
var menuhost = "https://menu.honqb.com";
Page({
  data: {
    testhost: testhost,
    menuhost:menuhost,
    host: app.globalData.url,
    product_detail: '商品详情',
    select: false,
    activeIndex: -1,
    isShow: true,
    productSelect: false,
    shopCommodityId: '',
    host: host,
    invite_list: {},
    orderData:{},
    tagInfo: {},
    numInfo: {},
    dispalyMode_bottom_btn: '',
    latitude: '',
    longitude: '',
    sadjcnxz: '',
    xiangqing: true,
    inventorys: {},
    showLoading: true,
    inviteFriend: true,
    continueinvite: false,
    startdata:'',
    starttime:'',
    needtimechange: true,
    needchoosetime:true,
    exchangeing: {},
    shopName:'',
    shopAddress:'',
    createTimes:'',
    isfirst:0,
    sheng:0,
    interviteId:0,
    remark:'我请客，谁结账我跟谁急',
    remarkb:'土豪已买单，敬请享用',
    acceptinvitation:false,
    isinvitefinish:false,
    turnfinish:false,
    deadline:'2017-12-30 16:00',
    num:0,
    isovertime:false,
    inviteminmun:0,
    notenough:true,
    oldprice: 0,
    newprice:0,
    discount:0,
    myself:true,
    makesure: true,
    isshowmakesure:false,
    isqinga:true,
    starttime:0,
    qingid:0,
    bcontuct:'继续邀请好友',
    shoparr:[],
    nickName: '',
    avatarUrl: '',
    treatlist:[],
    address:'',
  },

  //弹出二维码层
  invite_finish: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var idxs = 0;
    
    wx.request({
      url: testhost +'/intervite/complete',
      data:{
        userId: app.globalData.userId,
        interviteId: that.data.interviteId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      method:'get',
      dataType:'json',
      success:function(backdata){
        console.log("完成邀请！！！", backdata)
        that.setData({
          isinvitefinish:true,
        })
        if (that.data.isqinga){
          wx.navigateTo({
            url: '../treatdress/treatdress?userinfo=' + JSON.stringify(userinfo) + '&interviteId=' + that.data.interviteId,
          })
        }else{

        }
      }
    })
  },
  //弹出二维码层
  chosetime:function(e){
    this.bindDateChange();
  },
  make_sure:function(e){
    this.sendintervite();
    this.setData({
      makesure: true,
    })
  },


  //点击遮罩层关闭弹出层
  dispalyModelClass: function () {
    this.setData({
      dispalyModel: false,
      dispalyModelClasShow: false
    })
  },
  // 跳转首页
  JumpPage: function () {
    console.log('跳转首页')
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  tomap:function(e){
    console.log(this.data.shoparr.lat)
    wx.openLocation({
      latitude: parseInt(this.data.shoparr.lat),
      longitude: parseInt(this.data.shoparr.lng),
      scale: 28,
    })
  },
  //地图

  onLoad: function (opt) {
    // wx.showLoading({
    //   title: '加载中',
    // });
    wx.hideShareMenu();
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    console.log("过来的opt",opt)
    
    that.setData({
      nickName: userinfo.nickName,
      avatarUrl: userinfo.avatarUrl,
      shopname: opt.name,
      shopaddress: opt.address,
      interviteId: opt.interviteId,
      // interviteId:10101,
      address: opt.address,
      shopCommodityId: opt.shopCommodityId,
    })
    console.log("传过来的shopid!", opt.interviteId)
    wx.request({
      url: menuhost + '/intervite/get',
      data: {
        interviteId: opt.interviteId,
        // interviteId: that.data.interviteId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          treatlist: res.data.data,
        })
        console.log('显示邀请的详情zzzzzzz!', that.data.treatlist);
        wx.request({
          url: menuhost + '/gourmetrouteshop/get',
          data: {
            shopId: parseInt(res.data.data.shopId),
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            that.setData({
              shoparr: res.data.data,
            })
            console.log("商品信息！", res)
            that.setData({
              shopname: res.data.data.name,
              address: res.data.data.address,
            })
          },
        })
        // if (that.data.treatfrlist.length < 7) {
        //   var shengs = 7 - that.data.treatfrlist.length;
        //   that.setData({
        //     sheng: shengs,
        //   })
        // }
      },
      fail: function(res){}
    })
    // wx.request({
    //   url: testhost + '/gourmetrouteline/getAll',
    //   data: {
    //     userId: app.globalData.userId,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (res) {
    //     if (res.data.code == 1) {
    //       wx.showModal({
    //         title: '温馨提示',
    //         content: res.data.msg,
    //       })
    //     } else {
    //       outer:
    //       for(let i=0;i<res.data.data.length;i++){
    //         for (let j = 0; j < res.data.data[i].shopInfo.length;j++){
    //           if (res.data.data[i].shopInfo[j].shopId == opt.shopId){
    //             that.setData({
    //               shoparr: res.data.data[i].shopInfo[j],
    //             })
    //             console.log("商店信息！", that.data.shoparr)
    //             break outer;
    //           }
    //         }
    //       }
    //     }
    //   },
    // })   
    // console.log("穿过来的商品id！！", opt.shopCommodityId, opt.type);
    // if (opt.type != null && opt.type==2){
    //   that.setData({
    //     isqinga: false,
    //   })
    // }
    // var nowDate = new Date()
    // var yue;
    // var ri;
    // if (nowDate.getMonth()+1<10){
    //   yue = "0" + String(nowDate.getMonth() + 1);
    // }else{
    //   yue = (nowDate.getMonth() + 1);
    // }
    // if (nowDate.getDate()+1<10){
    //   ri = "0" + nowDate.getDate();
    // }else{
    //   ri =nowDate.getDate();
    // }
    // let chnowDate = nowDate.getFullYear() + "-" + yue + "-" +ri;
    // let chnowTime = nowDate.getHours() + ":" + nowDate.getMinutes();
    // that.setData({
    //   orderData: opt,
    //   startdata: chnowDate,
    //   starttime: chnowTime,
    //   showLoading: false,
    // })

    // wx.hideLoading();
    // // isqinga:,
    // //后来新改的商品详情
    wx.request({
      url: menuhost + '/intervitecommodity/get',
      data: {
        shopCommodityId: opt.shopCommodityId,
      },
      dataType: 'json',
      method: 'get',

      success: function (res) {
        let discount = parseFloat((res.data.data.priceShow / res.data.data.oldPriceShow) * 10).toFixed(1);//保留一位小数
        res.data.data.num = parseInt(res.data.data.num);
        that.setData({
          product_list: res.data.data,
          discount: discount,
        })
        console.log("请客菜商品信息!", that.data.product_list)
      },
      fail: function (res) {}
    })
    // //后来新改的商品详情
    // if (opt.interviteId!=null){
    //   wx.showLoading({
    //     title: '加载中',
    //   });
    //   var that=this;
    //   that.setData({
    //     isfirst:1,
    //     inviteFriend:false,
    //     myself: false,
    //     interviteId:opt.interviteId,
    //     shopCommodityId: opt.shopCommodityId,
    //     continueinvite: true,
    //     inviteFriend: false,
    //     needchoosetime: false,
    //   })

    //   wx.request({
    //     url: testhost + '/intervite/get',
    //     data:{
    //       interviteId: opt.interviteId,
    //     },
    //     dataType: 'json',
    //     method: 'get',
    //     success: function (res) {
    //       wx.showLoading({
    //         title: '加载中',
    //       });
    //       console.log('显示邀请的详情!', res, userinfo.clientId, parseInt(res.data.data.clientId));
    //       that.setData({
    //         nickName: res.data.data.nickName,
    //         avatarUrl: res.data.data.headImgUrl,
    //         remark: res.data.data.remark,
    //         remarkb: res.data.data.remark,
    //       })

    //         that.setData({
    //           shopName: res.data.data.shopName,
    //           shopAddress: res.data.data.address,
    //           createTimes: res.data.data.dinnerTime,
              
    //           treatfrlist:res.data.data.list,
    //           inviteminmun: res.data.data.num,
    //         }, function () {
    //           that.setData({
    //             showLoading: false
    //           }, function () {
    //             wx.hideLoading();
    //           })
    //         })

    //         if (that.data.treatfrlist.length > that.data.inviteminmun-1){
    //           console.log("够了",that.data.inviteminmun);
    //           that.setData({
    //             notenough: false,
    //             bcontuct:'人数已够',
    //           })
    //         }else{
    //           console.log("人数不够", that.data.inviteminmun);
    //         }

    //         if (res.data.data.code != ''){
    //           that.setData({
    //             isinvitefinish:true,
    //           })
    //         }

    //         console.log("朋友的头像列表！！！", that.data.treatfrlist)
            
    //         if (that.data.treatfrlist.length < res.data.data.num ) {
    //           var shengs = res.data.data.num - that.data.treatfrlist.length;
    //           that.setData({
    //             sheng: shengs,
    //           })
    //         }
    //     },
    //     fail: function (res) {}
    //   })
    // }else{
    //   var userinfo = wx.getStorageSync("userinfo_key");
    //   if (that.data.needchoosetime) {
    //     that.setData({
    //       nickName: userinfo.nickName,
    //       avatarUrl: userinfo.avatarUrl,
    //     })
    //   }
    // };


    // that.setData({
    //   shopCommodityId: opt.shopCommodityId,
    //   product_list_priceShow5: (that.data.product_list_priceShow * that.data.sales).toFixed(2)
    // })

    
  },




  invite_accept:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key")
    //朋友接受邀请
    wx.request({
      url:testhost+'/intervite/acceptIntervite',
      data:{
        userId: app.globalData.userId,
        interviteId: that.data.interviteId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      method:'get',
      header: {
        'content-type': 'application/json'
      },
      success:function(redata){
        that.setData({
          acceptinvitation:true,
        })
        console.log("朋友接受邀请后的返回",redata);
        //请客菜详情？
        wx.request({
          url: testhost + '/intervite/get',
          data: {
            interviteId: that.data.interviteId,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            console.log('显示邀请的详情!', res, userinfo.clientId, parseInt(res.data.data.clientId));
            that.setData({
              treatfrlist: res.data.data.list,
            })
            if (that.data.treatfrlist.length < 7) {
              var shengs = 7 - that.data.treatfrlist.length;
              that.setData({
                sheng: shengs,
              })
            }
          },
          fail: function (res) { }
        })
      }
    })
  },
  // sendintervite:function(e){
  //   var that=this;
  //   var userinfo = wx.getStorageSync("userinfo_key");
  //   console.log(that.data.shopCommodityId, userinfo.openid, userinfo.nickName, userinfo.avatarUrl, that.data.startdata + " " + that.data.starttime, userinfo.clientId);
  //   if (that.data.isqinga){
  //     wx.request({
  //       url: testhost + '/intervite/initIntervite',
  //       data: {
  //         userId: app.globalData.userId,
  //         shopCommodityId: that.data.shopCommodityId,
  //         dinnerTime: that.data.startdata + " " + that.data.starttime,
  //         remark: that.data.remark,
  //         openId: userinfo.openid,
  //         nickName: userinfo.nickName,
  //         headImgUrl: userinfo.avatarUrl,
  //       },
  //       method: 'get',
  //       success: function (res) {
  //         console.log("A版请求后的返回intervitedid", res.data.data);
  //         if (res.data.code == 1) {
  //           wx.showModal({
  //             title: '温馨提示',
  //             content: res.data.msg,
  //           })
  //           that.setData({
  //             makesure: false,
  //           })
  //           return;
  //         } else {
  //           that.setData({
  //             interviteId: res.data.data,
  //             isfirst: 0,
  //           })
  //         }
  //       }
  //     })
  //   }else{
  //     wx.request({
  //       url: testhost + '/intervite/initIntervite',
  //       data: {
  //         userId: app.globalData.userId,
  //         shopCommodityId: that.data.shopCommodityId,
  //         remark: that.data.remarkb,
  //         openId: userinfo.openid,
  //         nickName: userinfo.nickName,
  //         headImgUrl: userinfo.avatarUrl,
  //       },
  //       method: 'get',
  //       success: function (res) {
  //         console.log("b版请求后的返回intervitedid", res);
  //         if (res.data.code==1){
  //           wx.showModal({
  //             title: '温馨提示',
  //             content: res.data.msg,
  //           })
  //           that.setData({
  //             makesure: false,
  //           })
  //           return;
  //         }else{
  //           that.setData({
  //             interviteId: res.data.data,
  //             isfirst: 0,
  //           })
  //         }
  //       }
  //     })
  //   }
  // },
  
  /**
 * 用户点击右上角分享
 */
  onShareAppMessage: function (res) {
    console.log("商品数量", this.data.sales)
    var that = this;
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res, )
      }
    })

    if (res.from === 'button') {

    }
    if (that.data.isqinga){
      return {
        title: that.data.remark,
        path: 'pages/newtreatdetail/newtreatdetail?interviteId=' + that.data.interviteId + '&shopCommodityId=' + that.data.shopCommodityId + '&userid=z' + that.data.qingid + '&isfirst=1&address=' + that.data.address + '&shopname=' + that.data.shopname,
        imageUrl: 'https://basehqb.honqb.com/data/upload/image/xcx/han.jpg',
        success: function (res) {
          // // 转发成功
          console.log("信测转发的！", 'pages/newtreatdetail/newtreatdetail?interviteId=' + that.data.interviteId + '&clientId=' + userinfo.clientId + '&shopCommodityId=' + that.data.shopCommodityId + '&userid=z' + that.data.qingid + '&isfirst=1')
          wx.showModal({
            title: '提示',
            content: '成功发出邀请',
            success: function (res) {
              console.log("转发的interviteId!!!!!!", that.data.interviteId)
              if (that.data.isfirst == 0) {
                wx.redirectTo({
                  url: '../mytreat/mytreat',
                })
              }
            }
          })
        },
        fail: function (res) {
          // 转发失败
        }
      }
    } else{
      return {
        title: that.data.remarkb,
        path: 'pages/newtreatdetailb/newtreatdetailb?interviteId=' + that.data.interviteId + '&clientId=' + userinfo.clientId + '&shopCommodityId=' + that.data.shopCommodityId + '&userid=z' + that.data.qingid,
        imageUrl: 'https://basehqb.honqb.com/data/upload/image/xcx/hanb.jpg',
        success: function (res) {
          // // 转发成功
          wx.showModal({
            title: '提示',
            content: '成功发出邀请',
            success: function (res) {

              // that.sendintervite();
              console.log("转发的interviteId!!!!!!", that.data.interviteId)
              if (that.data.isfirst == 0) {
                wx.redirectTo({
                  url: '../mytreat/mytreat',
                })
              }
            }
          })
        },
        fail: function (res) {
          // 转发失败
        }
      }
    }
  },
  // onHide: function () {
  //   this.likeIf()
  //   this.laud()
  // },
  onReady: function () {

  }
})
