//couponactivity/couponactivity.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var timelost;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    coulist:{},
    onecou:{},
    sendcouponsid:0,
    couponsinfo:{},
    showtan:false,
    lingderen:'',
    avatarUrl: '',
    nickName: '',
    pengling: false,
    noclick: true,
    pengyiling: false,
    fenxiang: false,
    first:true,
    daojishi:'0天0时0分0秒',
    dierci: false,
    yuanshiid:0,
    clientId:0,
  },
  iling:function(e){
    
  },
  opentan:function(e){
    this.setData({
      showtan: true,
    })
  },
  colsetan:function(e){
    this.setData({
      showtan:false,
    })
  },
  yiling:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    if(that.data.noclick){
      that.lingqu(function(){});
      that.ranlie(that.data.sendcouponsid, function () {
        that.setData({
          pengyiling: true,
          pengling: false,
          noclick: false,
        })
      });
    }else{
      wx.reLaunch({
        url: '../zhaopai/zhaopai',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("优惠劵的!options", options)
    //如果options.couponsId为空，就是首次进来
    that.setData({
      avatarUrl: userinfo.avatarUrl,
      nickName: userinfo.nickName,
    })
    if (options.clientId!=undefined){
      that.setData({
        clientId: options.clientId,
      })
    }else{
      that.setData({
        clientId: userinfo.clientId,
      })
    }
    console.log("options.clientId", options.clientId, that.data.clientId, userinfo)
    if (options.couponsId != undefined && options.clientId != userinfo.clientId){
      console.log("不等于空啊!", options.couponsId)
      that.huoquzong(function(){
        that.setData({
          fenxiang: true,
          pengling: true,
          sendcouponsid: options.couponsId,
        })
        that.ranlie(that.data.sendcouponsid, function () {
          // that.lingqu();
          that.setData({
            fenxiang: true,
            pengling: true,
          })
          if (that.data.lingderen.indexOf(userinfo.clientId) == -1) {
            that.setData({
              noclick: true,
              pengyiling: false,
            })
          } else {
            that.setData({
              noclick: false,
              pengyiling: true,
            })
          }
        });
      })
    }else{
      // 首次进来查找分享的优惠劵
      // wx.request({
      //   url: host + 'shopcoupons/canCoupons',
      //   data: {
      //     userId: app.globalData.userId,
      //   },
      //   dataType: 'json',
      //   method: 'get',
      //   success: function (res) {
      //     console.log("总优惠劵",res.data.data)
      //     if (res.data.data == '') {
      //       console.log("优惠劵为空！！！！！！！！！！");
      //       return;
      //     }
      //     var onecou = {};
      //     for (let i = 0; i < res.data.data.length; i++) {
      //       if (res.data.data[i].method == 2) {
      //         res.data.data[i].peopleNum = parseInt(res.data.data[i].peopleNum);
      //         onecou = res.data.data[i];
      //         break;
      //       }
      //     }
      //     onecou.rule = onecou.rule.split('\n');
      //     that.setData({
      //       coulist: res.data.data,
      //       onecou: onecou,
      //     })
      //     console.log('优惠劵！！！', that.data.onecou);
      //     // 自动领取
          
      //     // 自动领取
      //     wx.request({
      //       url: host + 'shopcoupons/myCoupons',
      //       data: {
      //         userId: app.globalData.userId,
      //         nickName: userinfo.nickName,
      //         headImgUrl: userinfo.avatarUrl,
      //         openId: userinfo.openid,
      //       },
      //       dataType: 'json',
      //       method: 'get',
      //       success: function (resz) {
      //         // that.setData({
      //         //   mycoulist: res.data.data,
      //         // })
      //         console.log("sss",resz)
      //         let ashit=true;
      //         for (let i = 0; i < resz.data.data.length;i++){
      //           if (resz.data.data[i].oldCouponsId == that.data.onecou.couponsId&&resz.data.data[i].top==1){
      //             console.log("啊啊啊啊啊", resz.data.data[i].couponsId, that.data.onecou.couponsId, resz.data.data[i].oldCouponsId);
      //             ashit=false;
      //             console.log("第二次1")
      //             that.setData({
      //               fenxiang: true,
      //               dierci: true,
      //               sendcouponsid: resz.data.data[i].couponsId,
      //             })
      //             that.ranlie(resz.data.data[i].couponsId,function(){
      //               // that.lingqu(function(){});
      //               console.log("第二次染")
      //             })
      //           } else if (i == resz.data.data.length - 1 && ashit){
      //             console.log("第一次0", that.data.sendcouponsid)
      //             that.lingqu(function () {
      //               console.log("第一次1")
      //               that.setData({
      //                 fenxiang: true,
      //                 first:false,
      //               })
      //               that.lingqu(function(){
      //                 console.log("第一次2")
      //               });
      //             });
      //           }
      //         }
      //       },
      //     })
      //   },
      //   fail: function (res) { }
      // })
      that.huoquzong(function(){
        wx.request({
          url: host + 'shopcoupons/myCoupons',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
          },
          dataType: 'json',
          method: 'get',
          success: function (resz) {
            // that.setData({
            //   mycoulist: res.data.data,
            // })
            console.log("sss", resz)
            let ashit = true;
            for (let i = 0; i < resz.data.data.length; i++) {
              if (resz.data.data[i].oldCouponsId == that.data.onecou.couponsId && resz.data.data[i].top == 1 ) {
                console.log("啊啊啊啊啊", resz.data.data[i].couponsId, that.data.onecou.couponsId, resz.data.data[i].oldCouponsId);
                ashit = false;
                console.log("第二次1")
                that.setData({
                  fenxiang: true,
                  dierci: true,
                  sendcouponsid: resz.data.data[i].couponsId,
                })
                if (resz.data.data[i].enjoyOver == 2 || resz.data.data[i].enjoyOver == 3){
                  console.log("enjoyOver", resz.data.data[i].enjoyOver)
                  ashit = true;
                  that.setData({
                    fenxiang: false,
                    first: true,
                    dierci: false,
                  })
                  // continue;
                }else{
                  console.log("enjoyOver", resz.data.data[i].enjoyOver)
                  ashit = false;
                  that.setData({
                    fenxiang: true,
                    dierci: true,
                  })
                  that.ranlie(resz.data.data[i].couponsId, function () {
                    if (resz.data.data[i].enjoyOver == 1) {
                      // that.lingqu(function () {});
                      console.log("第二次染");
                    }
                  })
                  break;
                }
              } else if (i == resz.data.data.length - 1 && ashit) {
                console.log("第一次0", that.data.sendcouponsid)//等于第一次进来，没领过
                that.lingqu(function () {
                  console.log("第一次1")//建立表
                  that.setData({
                    fenxiang: true,
                    first: false,
                  })
                  that.lingqu(function () {
                    console.log("第一次2")//真正的成功
                  });
                });
              }
            }
          },
        })
      })
    }
    // 我的优惠劵
    // wx.request({
    //   url: host + 'shopcoupons/myCoupons',
    //   data: {
    //     userId: app.globalData.userId,
    //     nickName: userinfo.nickName,
    //     headImgUrl: userinfo.avatarUrl,
    //     openId: userinfo.openid,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (res) {
    //     that.setData({
    //       mycoulist: res.data.data,
    //     })
    //     console.log('我的优惠劵！！！', that.data.mycoulist);
    //   },
    //   fail: function (res) { }
    // })
    // 我的优惠劵
    // 获取劵详情
    // wx.request({
    //   url: host + 'shopcoupons/getTmenCouponsInfo',
    //   data: {
    //     couponsId: 10072,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (res) {
    //     console.log('getTmenCouponsInfo', res.data.data);
    //     that.setData({

    //     })
    //   },
    //   fail: function (res) {}
    // })
    // var day = parseInt(that.contrasttime("2018-04-27 00:00:00") / 86400);
    // console.log("总时间戳", that.contrasttime("2018-04-27 00:00:00"),)
    // console.log("天数", parseInt(that.contrasttime("2018-04-27 00:00:00") / 86400))
    // console.log("小时", Math.floor((that.contrasttime("2018-04-27 00:00:00") % 86400)/3600))
    // console.log("分钟", Math.floor(((that.contrasttime("2018-04-27 00:00:00") % 86400) % 3600)/60))
    // console.log("秒", ((that.contrasttime("2018-04-27 00:00:00") % 86400) % 3600) % 60)
    // that.setData({
    //   day: parseInt(that.contrasttime("2018-04-27 00:00:00") / 86400),
    //   hour: Math.floor((that.contrasttime("2018-04-27 00:00:00") % 86400) / 3600),
    //   minute: Math.floor(((that.contrasttime("2018-04-27 00:00:00") % 86400) % 3600) / 60),
    //   colck: ((that.contrasttime("2018-04-27 00:00:00") % 86400) % 3600) % 60,
    // })
    
  },
  huoquzong: function (afun){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("总优惠劵", res.data.data)
        if (res.data.data == '') {
          console.log("优惠劵为空！！！！！！！！！！");
          return;
        }
        var onecou = {};
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].method == 2) {
            res.data.data[i].peopleNum = parseInt(res.data.data[i].peopleNum);
            onecou = res.data.data[i];
            break;
          }
        }
        onecou.rule = onecou.rule.split('\n');
        that.setData({
          coulist: res.data.data,
          onecou: onecou,
          yuanshiid: onecou.couponsId,
        })
        console.log('优惠劵！！！', that.data.onecou);
        // 自动领取

        // 自动领取
        return afun();
      },
      fail: function (res) { }
    })
  },
  daojishi:function(deadtime){
    clearInterval(timelost)
    var that = this;
    var lasttime = 86400-Math.abs(that.contrasttime(deadtime));
    // console.log("lasttime", lasttime)
    var day = parseInt(lasttime / 86400);
    var hour = Math.floor((lasttime % 86400) / 3600);
    var minute = Math.floor(((lasttime % 86400) % 3600) / 60);
    var colck = ((lasttime % 86400) % 3600) % 60;
    if (lasttime <= 0) {
      wx.request({
        url: host + 'shopcoupons/checkAllTopCoupons',
        data: {
          userId: app.globalData.userId,
        },
        dataType: 'json',
        method: 'get',
        success:function(res){
          console.log("过期后执行的checkAllTopCoupons")
        },
      })
      wx.showModal({
        title: '温馨提示',
        content: '该红包领取已经过期，将跳转首页，领取新红包',
        success: function (res) {
          wx.reLaunch({
            url: '../zhaopai/zhaopai',
          })
          return;
        },
      })
    } else {
      timelost = setInterval(function () {
        //秒
        if (colck < 1) {
          colck = 59;
          //分钟
          if (minute < 1) {
            minute = 59;
            //小时
            if (hour < 1) {
              hour = 23;
              //天数
              if (day < 1) {
                day = 0
              } else { day-- }
              //天数
            } else { hour-- }
            //小时
          } else { minute-- }
          //分钟
        } else { colck-- }
        //秒
        if (colck == 0 && minute == 0 && hour == 0 && day == 0) {
          clearInterval(timelost)
          wx.showModal({
            title: '温馨提示',
            content: '时间到了',
          })
          that.setData({
            daojishi: "已结束",
          })
        }
        if (day != 0) {
          that.setData({
            daojishi: day + "天" + hour + "时" + minute + "分" + colck + "秒",
          })
        } else {
          that.setData({
            daojishi: hour + "时" + minute + "分" + colck + "秒",
          })
        }
        // console.log(day + "天" + hour + "小时" + minute + "分钟" + colck + "秒")
      }, 1000)
    }
  },
  ranlie: function (couponsid,afun){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/getTmenCouponsInfo',
      data: {
        couponsId: couponsid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('getTmenCouponsInfo', res.data.data);
        res.data.data.peopleNum = parseInt(res.data.data.peopleNum)
        res.data.data.rule = res.data.data.rule.split('\n');
        let lingderen='';
        that.setData({
          pengling: false,
          onecou: res.data.data,
        })
        // that.daojishi(res.data.data.deadLine+" 00:00:00");
        that.daojishi(res.data.data.createTime);
        if (res.data.data.peopleNum == res.data.data.receiveClientId.length) {
          console.log("够人了", )
          if (that.data.dierci) {
            that.setData({
              fenxiang: false,
              first: true,
            })
            that.lingqu(function () {
              console.log("下面的第一次1")
              that.setData({
                fenxiang: true,
                first: false,
              })
              that.lingqu(function () {
                console.log("下面的第一次2")
              });
            });
          } else {
            wx.showModal({
              title: '温馨提示',
              content: '您参与拆红包活动已成功，请在个人中心查看已领取的红包',
              showCancel:false,
              success: function (r) {
                wx.reLaunch({
                  url: '../zhaopai/zhaopai',
                })
              }
            })
          }
        } else {
          for (let i = 0; i < res.data.data.receiveClientId.length; i++) {
            lingderen += res.data.data.receiveClientId[i].clientId + ","
            if (i == res.data.data.receiveClientId.length - 1) {
              that.setData({
                lingderen: lingderen,
              })
            }
          }
        }
        return afun();
        // for (let i =0;i<res.data.data.receiveClientId.length;i++){
        //   lingderen += res.data.data.receiveClientId[i].clientId+","
        //   if (i == res.data.data.receiveClientId.length-1){
        //     that.setData({
        //       lingderen: lingderen,
        //     })
        //   }
        // }
        // return afun();
      },
      fail: function (res) {}
    })
  },
  lingqu: function (afun) {
    var that = this;
    // console.log(that.data.coulist[er.currentTarget.dataset.idx],er);
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("lingderen", that.data.lingderen, that.data.onecou, that.data.sendcouponsid, that.data.lingderen.indexOf(userinfo.clientId))
    if (that.data.lingderen.indexOf(userinfo.clientId)==-1){
      if (!that.data.fenxiang) {
        wx.request({
          url: host + 'shopcoupons/receive',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
            couponsId: (that.data.first ? that.data.yuanshiid : that.data.onecou.oldCouponsId),
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              console.log("这里是首次领的出错了，", res)
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("这里是首次领的", res);
              that.setData({
                sendcouponsid: res.data.data,
              })
              
              that.ranlie(that.data.sendcouponsid, function(){
                return afun();
              })
            }
          }
        })
      } else {
        wx.request({
          url: host + 'shopcoupons/teamReceive',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
            // couponsId: that.data.onecou.couponsId,
            couponsId: that.data.sendcouponsid,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
                showCancel: false,
                success: function (r) {
                  wx.reLaunch({
                    url: '../zhaopai/zhaopai',
                  })
                }
              })
              console.log("分享领的人出错了，", res)
              
            } else {
              console.log("这里是分享领的！", res);
              that.ranlie(that.data.sendcouponsid, function () {
                return afun();
              })
            }
          }
        })
      }
    }
  },
  contrasttime: function (picktime) {
    let nowDate = new Date();
    let yue;
    let ri;
    if (nowDate.getMonth() + 1 < 10) {
      yue = "0" + String(nowDate.getMonth() + 1);
    } else {
      yue = (nowDate.getMonth() + 1);
    }
    if (nowDate.getDate() + 1 < 10) {
      ri = "0" + nowDate.getDate();
    } else {
      ri = nowDate.getDate();
    }
    let nowdata = nowDate.getFullYear() + '-' + yue + '-' + ri + ' ' + this.addmun(nowDate.getHours()) + ":" + this.addmun(nowDate.getMinutes()) + ":" + this.addmun(nowDate.getSeconds());
    let choosedata = picktime;
    let nowdatas = nowdata.substring(0, 10).split('-');
    let choosedatas = choosedata.substring(0, 10).split('-');
    nowdata = nowdatas[1] + '-' + nowdatas[2] + '-' + nowdatas[0] + ' ' + nowdata.substring(10, 19);
    choosedata = choosedatas[1] + '-' + choosedatas[2] + '-' + choosedatas[0] + ' ' + choosedata.substring(10, 19);
    let a = (Date.parse(choosedata) - Date.parse(nowdata));
    return a / 1000;
  },
  addmun: function (time) {
    if (time.toString().length < 2) {
      return '0' + time;
    } else {
      return time;
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },
  tohome:function(e){
    wx.reLaunch({
      url: '../zhaopai/zhaopai',
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.log("监听页面隐藏")
    clearInterval(timelost);  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log("监听页面卸载")
    clearInterval(timelost);
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    console.log("商品数量", this.data.sales)
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res, )
      }
    })
    return {
      title: "您的好友" + userinfo.nickName+"邀您组团抢红包",
      path: 'pages/couponactivity/couponactivity?couponsId=' + that.data.sendcouponsid + '&clientId=' + that.data.clientId,
      // imageUrl: 'https://basehqb.honqb.com/data/upload/image/xcx/han.jpg',
      imageUrl: '../../imgs/fenxiangde.png',
      success: function (res) {
        // // 转发成功
        wx.showModal({
          title: '提示',
          content: '成功发出邀请',
          success: function (res) {
            console.log("转发的couponsId!!!!!!", that.data.sendcouponsId)
            // if (that.data.isfirst == 0) {
              wx.reLaunch({
                // url: '../zhaopai/zhaopai?allcou=1',
                url: '../zhaopai/zhaopai',
              })
            // }
          }
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
})