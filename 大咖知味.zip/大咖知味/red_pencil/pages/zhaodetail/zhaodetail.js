// pages/zhaodetail/zhaodetail.js
const txvContext = requirePlugin("tencentvideo");
var WxParse = require('../../wxParse/wxParse.js');
var app = getApp();
var host = app.globalData.host;
var testhost = app.globalData.url;

Page({
  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    host:host,
    address:'佛山市顺德区大良清晖路150号',
    phonemun:"0757-22218333",
    iscang:false,
    shopde:[],
    laud:0,
    arrayx: [{
      message: 'foo',
    }, {
      message: 'bar'
    }],
    hiddenLoading: true,
    videoId: ""
  },
  indexsUrl: function () {
    wx.reLaunch({
      url: '../zhaopai/zhaopai',
    })
  },
  tophone: function (r) {
    wx.makePhoneCall({
      phoneNumber: this.data.phonemun,
    })
  },
  toorder: function (e) {
    var that = this;
    
    if (that.data.shopde.shopInfo.appointment== 1) {
      wx.navigateTo({
        url: '../order/order?shopId=' + that.data.shopde.shopInfo.shopId + '&name=' + that.data.shopde.shopInfo.name,
      })
    } else {
      wx.showModal({
        title: '温馨提示',
        content: '抱歉，该商家还没开通订座功能，请等待商家开通此功能再使用',
        success:function(res){}
      })
    }
  },
  tomap: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.shopde.shopInfo.address,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("获取的经纬度", res, that.data.shopde.shopInfo.address)
        wx.openLocation({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng,
          scale: 28,
        })
      },
    });
  },
  imgYu: function (event) {
    var imgList = [];//获取data-list
    imgList.push(this.data.shopde.shopInfo.qrcode)
    //图片预览
    wx.previewImage({
      urls: imgList // 需要预览的图片http链接列表
    })
  },
  shoucang: function (e) {
    var that = this;
    let tpnow=0;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("sss", e.currentTarget.dataset.type)
    if (e.currentTarget.dataset.type=="zan"){
      tpnow = 1
      // if (that.data.laud>0){
      //   tpnow = 3
      // }else{
      //   tpnow = 1
      // }
    } else if (e.currentTarget.dataset.type == "cang"){
      if (that.data.iscang){
        tpnow = 4
      }else{
        tpnow = 2
      }
    }else{
      console.log("点击后出错了，",e)
    }
    wx.request({
      url: testhost + '/gourmetfood/option',
      data: {
        foodId: that.data.shopde.foodId,
        event: tpnow,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("点钟", res)
        if (res.data.code != 0) {
          
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

        } else {
          console.log("进来啦！！", res)
          if (tpnow==1){
            that.setData({
              laud: that.data.laud + 1,
            })
            wx.showToast({
              title: '点赞成功',
            })
          } else if (tpnow == 3){
            that.setData({
              laud: that.data.laud - 1,
            })
          } else if (tpnow == 2) {
            that.setData({
              iscang: true,
            })
            wx.showToast({
              title: '收藏成功',
            })
          } else if (tpnow == 4) {
            that.setData({
              iscang: false,
            })
          }
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: testhost+'/gourmetfood/preview',
      data: {
        foodId: options.foodid,
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success:function(resd){
        // 这里是详情
        console.log("预览的!",resd);
        wx.request({
          url: testhost + '/gourmetfood/get',
          data: {
            foodId: options.foodid,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            that.setData({
              shopde: res.data.data,
              videoId: res.data.data.video
            }, function(){
              if (that.data.videoId) {
                that.txvContext = txvContext.getTxvContext('txv1');
              }
            });
            console.log("凤城美食！", that.data.shopde)
            for (let o = 0; o < that.data.shopde.other.length;o++){
              that.data.shopde.other[o].content = that.data.shopde.other[o].content.split('\n')
            }
            console.log("ggggg",that.data.shopde)
            wx.request({
              url: testhost + '/gourmetfood/getOptionMySelf',
              data: {
                foodId: options.foodid,
                userId: app.globalData.userId,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                openId: userinfo.openid,
              },
              dataType: 'json',
              method: 'get',
              success: function (resz) {
                if (resz.data.code != 0) {
                  wx.showModal({
                    title: '提示',
                    content: resz.data.msg,
                  })
                }
                else {
                  that.setData({
                    hiddenLoading: false,
                  })
                  if (resz.data.data.laud > 0) {
                    that.setData({
                      laud: resz.data.data.laud,
                    })
                  }
                  if (resz.data.data.collect > 0) {
                    that.setData({
                      iscang: true,
                    })
                  } else if (resz.data.data.collect == 0) {
                    that.setData({
                      iscang: false,
                    })
                  } else {
                    console.log("收藏的出错！", resz)
                  }
                }
              },
            })
          },
        });
        // 这里是详情
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: this.data.shopde.title,
      path: '/page/index3/index3/',
      imageUrl: testhost + this.data.shopde.image,
      success: function (res) {
        // 转发成功
        console.log("转发成功")
        wx.showToast({
          title: '转发成功',
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})