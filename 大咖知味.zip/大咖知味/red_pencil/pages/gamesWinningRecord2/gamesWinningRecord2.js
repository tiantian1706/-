// pages/gamesWinningRecord/gamesWinningRecord.js
var app = getApp()
var host = app.globalData.host;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    getMyResultByLuckyDrawId: [],
    imgUrl: app.globalData.imgUrl,
    showLoading: true,
  },
  getDefault: function (shopId) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId
      },
      success: function (res) {
        luckyDrawId = res.data.data.luckyDrawId;
        that.getMyResultByLuckyDrawId();
      }
    })
  },
  // 跳转个人中心
  personalUrl: function () {
    wx.navigateTo({
      url: '../couponmy/couponmy?allcou=1',
    })
  },
  getMyResultByLuckyDrawId: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/getMyResultByLuckyDrawId',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

          return;
        }

        that.setData({
          getMyResultByLuckyDrawId: res.data.data
        }, function(){
          that.setData({
            showLoading: false
          })
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getDefault(options.shopId);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})