// pages/myCouponList/myCouponList.js
var app = getApp();
var testhost = app.globalData.url;
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    getListData: [], 
    testhost: testhost,
    liIndex:0,
    showLoading: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    var userinfo = wx.getStorageSync("userinfo_key");    
    wx.request({
      url: host + 'gourmetcouponsorder/myList',
      // url: host +'gourmetcoupons/getList',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      success: function (res) {

        var zhaopaizu = res.data.data;

        that.setData({
          getListData: zhaopaizu
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
      }
    })
  },
  changeGo:function(e){
    var that = this;
    console.log("e", e.currentTarget.dataset.index)
    that.setData({
      liIndex: e.currentTarget.dataset.index
    })
  },
  // 详情
  toDetail: function (e) {
    var couponsId = e.currentTarget.dataset.couponsid
    wx.navigateTo({
      url: '../myCouponDetail/myCouponDetail?couponsId=' + couponsId,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})