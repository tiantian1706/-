// pages/coupon/coupon.js
var app = getApp();
var testhost = app.globalData.url;
var mapUrl = app.globalData.mapUrl;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    isShow: false,
    testhost: testhost,
    miyao: app.globalData.key,
    iamhere:"",
    tabMenuIndex: "0",
    listMenuIndex: "0",
    allText:"全部",
    getListData:[],
    showLoading:true,
    noClick:true,
  },

  // 详情
  toDetail:function(e){
    var couponsId = e.currentTarget.dataset.couponsid
    wx.navigateTo({
      url: '../couponDeials2/couponDeials2?couponsId=' + couponsId,
    })
  },

  tabMenu: function (e) {
    var that = this;
    var index = e.currentTarget.dataset.index;

    wx.showLoading({
      title: '加载中...'
    });
    if (index == 0) {
      // 最新
      that.getAll(0)
    } else if (index == 1) {
      // 人气
      that.getAll(1)
    } else if (index == 2) {
      // 距离
      that.getAll(2)
    }

    that.setData({
      tabMenuIndex: index,
      isShow: false,
      noClick: false,      
    })
  },

  tabMenus: function () {
    var that = this;
    console.log("noClick", that.data.noClick, "isShow", that.data.isShow)
    that.setData({
      tabMenuIndex: 0,
    })

    if (that.data.noClick){
      that.setData({
        noClick: false,
        isShow:true,
      })
    } else if (!that.data.noClick && !that.data.isShow){
      that.setData({
        noClick: true,
      })
      wx.showLoading({
        title: '加载中...'
      });

      that.getAll(0)
    } else if (!that.data.noClick && that.data.isShow){
      that.setData({
        isShow: false,
      })
    }
  },

  listChange:function(e){
    var that = this;
    var index = e.currentTarget.dataset.index;
    var text = e.currentTarget.dataset.text;
    console.log("text", text,"index",index);
    wx.showLoading({
      title: '加载中...'
    });
    that.setData({
      allText: text,
      listMenuIndex: index,
      isShow:false,
    }, function () {
      that.setData({
        showLoading: false
      }, function () {
        wx.hideLoading();
      })
    })
    if (that.data.listMenuIndex==0){
      that.getAll(0)
    }
  },

  // 地址
  locationGo:function(){
    wx.navigateTo({
      url: '../location/location',
    })
  },

  getRad: function (d) {
    var PI = Math.PI;
    return d * PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2) {
    var that = this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//The Radius of eath in meter.
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;

    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数。   
    return s;
  },

  getAll: function (types) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlatitude: res.latitude,
          userlongitude: res.longitude,
        })
        console.log("用户位置", res.longitude, res.latitude, )

        wx.request({
          url: mapUrl+'/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude + '&key=' + that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success: function (resb) {
            console.log("自己位置的地区", resb, )
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district == '') {
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            } else {
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }

            wx.request({
              url: testhost + '/gourmetcoupons/getList',
              data: {
                userId: app.globalData.userId,
              },
              success: function (res) {
                for (var i = 0; i < res.data.data.length; i++) {
                  res.data.data[i].juli = that.newdistance(that.data.userlatitude, that.data.userlongitude, res.data.data[i].shopInfo.lat, res.data.data[i].shopInfo.lng)
                }
                console.log("优惠券",res.data.data)

                var zhaopaizu = res.data.data;

                if (types == 0) {
                  console.log(0);
                  zhaopaizu = zhaopaizu
                } else if (types == 1) {

                  zhaopaizu = zhaopaizu.sort(function (a, b) {
                    return b.sales - a.sales;
                  });


                } else if (types == 2) {

                  zhaopaizu = zhaopaizu.sort(function (a, b) {
                    return a.juli - b.juli;
                  });
                }

                that.setData({
                  getListData: zhaopaizu
                }, function () {
                  that.setData({
                    showLoading: false
                  }, function () {
                    wx.hideLoading();
                  })
                })
              }
            })

          },
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    that.getAll(0);
    console.log("options", options)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})