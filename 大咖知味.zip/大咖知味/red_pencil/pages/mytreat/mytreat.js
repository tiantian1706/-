//获取应用实例 
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com";
var userinfo = wx.getStorageSync("userinfo_key");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: 'https://basehqb.honqb.com/',
    testhost: testhost,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,
    showLoading: true,
    //待付款
    waitpay: [
      {
        imgsrc: "../../imgs/22.png",
        title: "有礼有节2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "816.00",
        num: "12",
        dates: "2017-08-06"
      },
      {
        imgsrc: "../../imgs/23.png",
        title: "2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "910.00",
        num: "1",
        dates: "2017-08-06"
      },
    ],
    LinkButton: {},
    // 待发货
    waitsend: [
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "1",
        dates: "2017-08-06"
      }
    ],
    // 我的订单列表
    myorder: [],
    mytreat: [],
    ssssss: [
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      {
        imgsrc: "../../imgs/23.png",
      },
      
    ],
    payAgainMain: '立即支付',
    isqinga:false,
  },
  panmun: function (friends){
    console.log(friends.split(',').length);
    
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    wx.hideShareMenu()
    var that = this;
    wx.showLoading({
      title: '加载中',
    });
    that.getmytreat();
    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
    wx.request({
      url: host + '/interviteconfig/getConfig',
      // url: host + 'commoditygroup/xcxGetGroup',
      // url: host + 'intervitecommodity/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (resdate) {
        // console.log("请客banner！！", resdate);
        if (resdate.data.data.type==1){
          that.setData({
            isqinga:true,
          })
        } else if (resdate.data.data.type == 2){
          that.setData({
            isqinga: false,
          })
        }
        console.log("判断是a还是b", resdate);
      }
    })
    // 用户信息
    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo, )

    var openid = userinfo.openid

    // wx.request({
    //   url: 'https://basehqb.honqb.com/order/myXcxOrderLists',
    //   data: {
    //     userId: app.globalData.userId,
    //     openId: userinfo.openid,
    //     nickName: userinfo.nickName,
    //     headImgUrl: userinfo.avatarUrl
    //   },
    //   header: {
    //     'content-type': 'application/json'
    //   },
    //   method: 'get',
    //   dataType: '',
    //   success: function (res) {
    //     // console.log(res.data.data)
    //     var myorder = []
    //     for (var i = 0; i < res.data.data.length; i++) {
    //       var item = res.data.data[i];
    //       console.log(item.helpOrderId)
    //       if (item.helpOrderId == "0") {
    //         myorder.push(item)
    //       }
    //     }


    //     that.setData({
    //       myorder: myorder
    //     }, function () {
    //       that.setData({
    //         showLoading: false
    //       }, function () {
    //         wx.hideLoading()
    //       })
    //     })
    //     console.log("我的订单", that.data.myorder)
    //   },
    //   fail: function (res) { },
    //   complete: function (res) { },
    // })
  },
  seatab:function(e){
    this.setData({
      currentTab: e.currentTarget.dataset.choose,
    })
  },
  getmytreat:function(e){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: testhost+'/intervite/myIntervite',
      data:{
        userId:app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl:userinfo.avatarUrl,
      },
      method:'get',
      dataType: 'json',
      header: {
        'content-type': 'application/json'
      },
      success:function(reback){
        // console.log("fasf", reback)
        if (reback.data.data[0].length == 0 && reback.data.data[1].length==0){
          // console.log("fasf")
          that.setData({
            mytreat: reback.data.data,
          }, function () {
            console.log('1111');
            that.setData({
              showLoading: false
            }, function () {
              wx.hideLoading();
            })
          })
        }
        for (let i = 0; i < reback.data.data[0].length;i++){
          reback.data.data[0][i].num = parseInt(reback.data.data[0][i].num);
          if (i == reback.data.data[0].length-1){
            that.setData({
              mytreat: reback.data.data,
            }, function () {
              console.log('1111');
              that.setData({
                showLoading: false
              }, function () {

                
                wx.hideLoading();
              })
            })
          }
        }

        that.setData({
          showLoading: false
        }, function () {
          wx.hideLoading();
        })
        console.log("个人请客！", that.data.mytreat)
      }
    })
  },

  cancellationOfOrder: function (e) {
    var that = this;
    console.log('取消订单')
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.showModal({
      title: '提示',
      content: '确定删除订单吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')

          wx.request({
            url: host + 'order/delOrderByXcx',
            dataType: 'json',
            method: 'get',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              orderId: orderId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl
            },
            success: function (res) {
              console.log('取消订单', res)

              if (res.data.code == 0) {
                wx.showModal({
                  title: '提示',
                  content: '删除成功'
                })

                wx.request({
                  url: 'https://basehqb.honqb.com/order/myXcxOrderLists',
                  data: {
                    userId: app.globalData.userId,
                    openId: userinfo.openid,
                    nickName: userinfo.nickName,
                    headImgUrl: userinfo.avatarUrl
                  },
                  header: {
                    'content-type': 'application/json'
                  },
                  method: 'get',
                  dataType: '',
                  success: function (res) {
                    // console.log(res.data.data)
                    var myorder = []
                    for (var i = 0; i < res.data.data.length; i++) {
                      var item = res.data.data[i];
                      console.log(item.helpOrderId)
                      if (item.helpOrderId == "0") {
                        myorder.push(item)
                      }
                    }


                    that.setData({
                      myorder: myorder
                    })

                  },
                  fail: function (res) { },
                  complete: function (res) { },
                })
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })

  },
  /** 滑动切换tab 
  */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },


  jumpToDF: function (e) {
    var that = this;
    console.log("代付订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = that.data.myorder[index];
    var shopCommodityId = order.shopCommodityId
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopCommodityId
    })
  },


  jumpToDFH: function (e) {
    console.log("代发货订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];
    console.log("代发货订单", order)
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    wx.navigateTo({
      url: '../exchangedetail/exchangedetail?orderId=' + order.orderId + "&nickName=" + nickName,
    })
  },
  todetail:function(e){
    var that=this;
    if(that.data.isqinga){
      console.log(e.currentTarget.dataset.shopid)
      wx.redirectTo({
        url: '../newtreatdetail/newtreatdetail?interviteId=' + e.currentTarget.dataset.index + '&shopCommodityId=' + e.currentTarget.dataset.shopid + '&userid=z' + e.currentTarget.dataset.clientid,
      })
    } else if (!that.data.isqinga){
      wx.redirectTo({
        url: '../newtreatdetailb/newtreatdetailb?interviteId=' + e.currentTarget.dataset.index + '&shopCommodityId=' + e.currentTarget.dataset.shopid + '&userid=z' + e.currentTarget.dataset.clientid,
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    console.log('监听页面初次渲染完成');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    console.log('从子页面获取的数据', that.data.sy_quantity)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    console.log("下拉")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

