//index.js
//获取应用实例
var app = getApp()
var host = app.globalData.host;
var util = require('../../utils/util.js');
var luckyDrawId = null;

Page({
  data: {
    imgUrl: host,
    basehqbUrl: app.globalData.basehqbUrl,
    circleList: [],//圆点数组
    awardList: [],//奖品数组
    colorCircleFirst: '#fff9e6',//圆点颜色1
    colorCircleSecond: '#ff7e21',//圆点颜色2
    colorAwardDefault: '#fff4d0',//奖品默认颜色
    colorAwardSelect: '#fff4d0',//奖品选中颜色
    indexSelect: 0,//被选中的奖品index
    isRunning: false,//是否正在抽奖
    imageAward: [],//奖品图片数组
    
    tabMenusIndex: 0,
    isShowModel: false,
    isWinning: null,
    prizeInformation: {},
    jpHeightWidth: '',
    frequency: 0,
    showLoading: true,
  },
  getDefault: function (shopId,cb) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId
      },
      success: function (res) {
        luckyDrawId = res.data.data.luckyDrawId;
        that.getMyCount();
        that.getResultByLuckyDrawId();
        cb();
      }
    })
  },
  getMyCount: function (cb) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'luckydraw/get',
      data: {
        luckyDrawId: luckyDrawId
      },
      success: function (res) {
        
        res.data.data['createTime'] = res.data.data['createTime'].slice(0,10);
        res.data.data['endTime'] = res.data.data['endTime'].slice(0, 10);
        res.data.data['imageAward'] = [];
        res.data.data['titleArray'] = [];
        for (var i = 0, len = res.data.data.commodity.length; i < len; i++) {

          

          if (res.data.data.commodity[i].title == "一等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/1.png')
            res.data.data['titleArray'][0] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "二等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/2.png')
            res.data.data['titleArray'][1] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "三等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/3.png')
            res.data.data['titleArray'][2] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "四等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/4.png')
            res.data.data['titleArray'][3] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "五等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/5.png')
            res.data.data['titleArray'][4] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "六等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/6.png')
            res.data.data['titleArray'][5] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "七等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/7.png')
            res.data.data['titleArray'][6] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "八等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/8.png')
            res.data.data['titleArray'][7] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "九等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/9.png')
            res.data.data['titleArray'][8] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "十等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/10.png')
            res.data.data['titleArray'][9] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "十一等奖") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/11.png')
            res.data.data['titleArray'][10] = res.data.data.commodity[i];
          } else if (res.data.data.commodity[i].title == "谢谢参与") {
            res.data.data['imageAward'].push('/data/upload/image/xcx/JiugonggeDrawIion/xiexie.png')
          }
        }

        that.setData({
          luckydrawData: res.data.data,
          luckydrawDatas: res.data.data.titleArray
        });


        that.Awards();

        wx.request({
          url: host + 'drawclient/getMyMembers',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            luckyDrawId: luckyDrawId
          },
          success: function (res) {

            that.setData({
              getMyMembers: res.data.data
            });

            wx.request({
              url: host + 'luckydraw/getMyCount',
              data: {
                userId: app.globalData.userId,
                openId: userinfo.openid,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                luckyDrawId: luckyDrawId
              },
              success: function (res) {

                that.setData({
                  getMyCount: res.data.data
                })

                that.setData({
                  frequency: (parseInt(that.data.luckydrawData.chance) + that.data.getMyMembers) - that.data.getMyCount
                }, function () {
                  if (that.data.frequency <= 0) {
                    that.setData({
                      frequency: 0
                    }, function () {
                      that.setData({
                        showLoading: false
                      });
                    });
                  } else {
                    that.setData({
                      frequency: (parseInt(that.data.luckydrawData.chance) + that.data.getMyMembers) - that.data.getMyCount
                    }, function () {
                      that.setData({
                        showLoading: false
                      });
                    });
                  }
                });



              }
            })
          }
        });
      }
    });
  },
  prizeDetails: function() {
    var that = this;

    that.setData({
      isShowModel: true,
      tabMenusIndex: 1,
      isWinning: false
    })
  },
  prizeDetailsUrl: function() {
    wx.switchTab({
      url: '/pages/my/my',
    })
  },
  winningWuHide: function() {
    var that = this;

    that.setData({
      isWinning: false
    })
  },
  showModelShow: function() {
    var that = this;

    that.setData({
      isShowModel: true
    });
  },
  showModelHide: function () {
    var that = this;

    that.setData({
      isShowModel: false
    });
  },
  fh_btn: function() {
    var that = this;

    that.setData({
      isWinning: false
    });
  },
  tabMenus: function(e) {
    var that = this;
    var index = e.currentTarget.dataset.index;
    that.setData({
      tabMenusIndex: index
    })
  },
  // 执行抽奖
  commonDraw: function (cb) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
 
    wx.request({
      url: host + 'luckydraw/commonDraw',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId
      },
      success: function(res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }
        cb(res);
      }
    });
  },

  // 获取中奖纪录
  getResultByLuckyDrawId: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'luckydraw/getResultByLuckyDrawId',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
      },
      success: function (res) {

        that.setData({
          getResultByLuckyDrawId: res.data.data
        });
      }
    })
  },
  // 奖品排列设置 
  Awards: function() {
    //奖品item设置
    var that = this,
        awardList = [],
        topAward,
        leftAward;

    // 九宫格
    if (that.data.luckydrawData.commodity.length == 8) {
      topAward = 35;
      leftAward = 35;
      for (var j = 0; j < 8; j++) {
        if (j == 0) {
          topAward = 25;
          leftAward = 45;
        } else if (j < 3) {
          topAward = topAward;

          leftAward = leftAward + 140 + 35;
        } else if (j < 5) {
          leftAward = leftAward;

          topAward = topAward + 140 + 25;
        } else if (j < 7) {
          leftAward = leftAward - 140 - 35;
          topAward = topAward;
        } else if (j < 8) {
          leftAward = leftAward;
          topAward = topAward - 140 - 25;
        }
        // var imageAward = this.data.imageAward[j];
        var imageAward = that.data.luckydrawData.imageAward[j];
        var titleAward = that.data.luckydrawData.commodity[j].title;
        awardList.push(
          {
            topAward: topAward,
            leftAward: leftAward,
            imageAward: imageAward,
            titleAward: titleAward
          });
      }

      that.setData({
        jpHeightWidth: 140
      })

    } else {
      // 12 宫格
      topAward = 25;
      leftAward = 25;
      for (var j = 0; j < 12; j++) {
        if (j == 0) {
          topAward = 15;
          leftAward = 35;
        } else if (j < 4) {
          topAward = topAward;
          //166.6666是宽.15是间距.下同
          leftAward = leftAward + 110 + 25;
        } else if (j < 7) {
          leftAward = leftAward;
          //150是高,15是间距,下同
          topAward = topAward + 110 + 18;
        } else if (j < 10) {
          leftAward = leftAward - 110 - 25;
          topAward = topAward;
        } else if (j < 12) {
          leftAward = leftAward;
          topAward = topAward - 110 - 18;
        }
        var imageAward = that.data.luckydrawData.imageAward[j];
        var titleAward = that.data.luckydrawData.commodity[j].title;
        awardList.push(
          { 
            topAward: topAward, 
            leftAward: leftAward, 
            imageAward: imageAward,
            titleAward: titleAward
          }
          );
      }

      that.setData({
        jpHeightWidth: 110
      })
    }

    that.setData({
      awardList: awardList
    });
  },
  // 圆点设置
  cous: function() {
    var that = this,
        leftCircle = 7.5,
        topCircle = 7.5,
        circleList = [];

    for (var i = 0; i < 24; i++) {
      if (i == 0) {
        topCircle = 15;
        leftCircle = 15;
      } else if (i < 6) {
        topCircle = 7.5;
        leftCircle = leftCircle + 102.5;
      } else if (i == 6) {
        topCircle = 15
        leftCircle = 620;
      } else if (i < 12) {
        topCircle = topCircle + 94;
        leftCircle = 620;
      } else if (i == 12) {
        topCircle = 565;
        leftCircle = 620;
      } else if (i < 18) {
        topCircle = 570;
        leftCircle = leftCircle - 102.5;
      } else if (i == 18) {
        topCircle = 565;
        leftCircle = 15;
      } else if (i < 24) {
        topCircle = topCircle - 94;
        leftCircle = 7.5;
      } else {
        return
      }
      circleList.push({ topCircle: topCircle, leftCircle: leftCircle });
    }
    this.setData({
      circleList: circleList
    })
    
    //圆点闪烁
    var times = setInterval(function () {
      if (that.data.colorCircleFirst == '#fff9e6') {
        that.setData({
          colorCircleFirst: '#ff7e21',
          colorCircleSecond: '#fff9e6',
        })
      } else {
        that.setData({
          colorCircleFirst: '#fff9e6',
          colorCircleSecond: '#ff7e21',
        })
      }

    }, 800)//设置圆点闪烁的效果
  },
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    that.setData({
      userinfo: userinfo
    })
    that.cous();

    that.setData({
      shopId: options.shopId
    })

    that.getDefault(options.shopId, function () {

      var userinfo = wx.getStorageSync("userinfo_key");

      if (options.enjoyClientId) {
        if (userinfo.openid) {
          // console.log('自己的数据', userinfo)
          // console.log('别人点进来的数据', options)

          // console.log('luckyDrawId--->', luckyDrawId);
          wx.request({
            url: host + 'drawclient/develop',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              luckyDrawId: luckyDrawId,
              enjoyClientId: options.enjoyClientId
            },
            dataType: 'json',
            method: 'get',
            success: function (res) {
              // console.log('分销数据', res, res.data.code, res.data.masg);
            },
            fail: function (res) {
              wx.showModal({
                title: '接口调用失败',
                content: res,
              })
            }
          });
        } else {
          util.getOpenId(host, app.globalData.userId, function () {
            var userinfo = wx.getStorageSync("userinfo_key");
            wx.request({
              url: host + 'drawclient/develop',
              data: {
                userId: app.globalData.userId,
                openId: userinfo.openid,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                luckyDrawId: luckyDrawId,
                enjoyClientId: options.enjoyClientId
              },
              dataType: 'json',
              method: 'get',
              success: function (res) {
                // console.log('分销数据', res, res.data.code, res.data.masg);
              },
              fail: function (res) {
                wx.showModal({
                  title: '接口调用失败',
                  content: res,
                })
              }
            });
          })

        }

      }
    });
  },
  rnd: function(n, m){
    var random = Math.floor(Math.random() * (m - n + 1) + n);
    return random;
  },
  //开始抽奖
  startGame: function (e) {
    var that = this,
        indexSelect = 0,
        i = 0,
        istype,
        prizeInformation,
        timer = null,
        nums = '';

    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      // 检测登陆
      // 9宫
      if (that.data.luckydrawData.commodity.length == 8 ) {
        nums = 8
      } else {
        // 12 宫
        nums = 12
      }
      
      if (that.data.isRunning) return
      that.setData({
        isRunning: true
      })

      that.commonDraw(function (res) {
        prizeInformation = res.data.data;
      });
      timer = setInterval(function () {
        indexSelect++;
        //转盘速度
        i += 50;
        var rnds = that.rnd(1000, 2000);

        if (i > rnds) {
          
          if ((that.data.indexSelect + 1) == that.data.luckydrawData.commodity.length) {
            that.data.indexSelect = 0;
          } else {
            that.data.indexSelect = that.data.indexSelect + 1;
          }

          if (prizeInformation.currentKey == that.data.indexSelect) {
            clearInterval(timer);

            if (prizeInformation.currentCommodity.title == "谢谢参与") {
              istype = 2
            } else {
              istype = 1
            }

            that.setData({
              prizeInformation: prizeInformation.currentCommodity,
              isWinning: istype,
              isRunning: false,
            });

            that.getResultByLuckyDrawId();
            that.getMyCount();
          }
        }
        indexSelect = indexSelect % nums;
        that.setData({
          indexSelect: indexSelect,
          colorAwardSelect: '#ffe400',//奖品选中颜色
        })

      }, (100 + i));
    })
    
  },
  onShareAppMessage: function (e) {
    // 来自页面内转发按钮
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    return {
      title: that.data.enjoyIndexTitle,
      path: 'pages/bigTurntable/bigTurntable?enjoyClientId=' + userinfo.clientId,
      success: function (res) {
        // 转发成功
        console.log('转发成功', res)
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})
