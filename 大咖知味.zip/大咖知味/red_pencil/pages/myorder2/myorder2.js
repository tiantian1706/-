// pages/myorder2/myorder2.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var userinfo = wx.getStorageSync("userinfo_key");
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    yaoyuearr:[],
    isqinga:true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getmytreat();
  },
  getmytreat: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: testhost + '/intervite/myIntervite',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      method: 'get',
      dataType: 'json',
      header: {
        'content-type': 'application/json'
      },
      success: function (res) {
        console.log("个人请客！", res);
        that.setData({
          yaoyuearr: res.data.data[1]
        })
        console.log(that.data.yaoyuearr)
      }
    })
  },
  todetail: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.shopcommodityid,e)
    if (that.data.isqinga) {
      console.log(e.currentTarget.dataset.shopid)
      wx.redirectTo({
        url: '../newtreatdetail/newtreatdetail?interviteId=' + e.currentTarget.dataset.interviteid + '&shopCommodityId=' + e.currentTarget.dataset.shopcommodityid + '&userid=z' + e.currentTarget.dataset.clientid,
      })
    } else if (!that.data.isqinga) {
      wx.redirectTo({
        url: '../newtreatdetailb/newtreatdetailb?interviteId=' + e.currentTarget.dataset.interviteid + '&shopCommodityId=' + e.currentTarget.dataset.shopcommodityid + '&userid=z' + e.currentTarget.dataset.clientid,
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})