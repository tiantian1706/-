// pages/gamesRanking/gamesRanking.js
var app = getApp()
var host = app.globalData.host;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: app.globalData.imgUrl,
    rankArray_top: [],
    rankArray_mod: [],
    showLoading: true,
  },
  getDefault: function (shopId) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId
      },
      success: function (res) {
        luckyDrawId = res.data.data.luckyDrawId;
        that.rankluckyDrawId();
      }
    })
  },
  rankluckyDrawId: function() {
    var that = this;
    var rank_s = [];
    var rank_d = [];
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/rank',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

          return;
        }


        for (var i = 0; i < res.data.data.length; i++) {
          console.log(res.data.data[i]);
          
          if (i < 3) {
            rank_s.push(res.data.data[i]);
          } else {
            rank_d.push(res.data.data[i]);
          }
        }

        that.setData({
          rankArray_top: rank_s,
          rankArray_mod: rank_d
        }, function(){
          that.setData({
            showLoading: false
          })
        })

        console.log(that.data.rankArray_top);
        console.log(that.data.rankArray_mod);
      }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    that.getDefault(options.shopId);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})