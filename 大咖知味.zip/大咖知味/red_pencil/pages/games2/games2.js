// pages/games/games.js
var app = getApp()
var host = app.globalData.host;
var luckyDrawId = null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrl: app.globalData.imgUrl,
    imgUrl2: app.globalData.url,
    modelIsShow: false,
    btnsHtml: '开始',
    luckydrawData: [],
    gamesTile: '',
    typeName: '',
    prizeList: [],
    frequency: 0,
    getMyMembers: [],
    getMyCount: [],
    scrollTop: 0,
    getMyResultByLuckyDrawId: [],
    getResultByLuckyDrawId: [],
    isQuantity: 0,
    kjTextImg: true,
    noClicks: true,
    showLoading: true,
    isGameType: null,
  },
  getDefault: function (shopId, cb) {
    var that = this;

    wx.request({
      url: host + 'luckydraw/getDefault',
      data: {
        userId: app.globalData.userId,
        shopId: shopId
      },
      success: function (res) {
        luckyDrawId = res.data.data.luckyDrawId;
        that.getMyCount();
        that.getResultByLuckyDrawId();
        that.getMyResultByLuckyDrawId();

        cb();
      }
    })
  },
  myEventListener: function (e) {
    console.log(e.detail);

    let detailData = e.detail;

    if (detailData.secStr_g == 10) {
      that.setData({
        myCountdown: 0,
        btnsHtml: "开始"
      })
    }

    let that = this;
    if (that.data.btnsHtml == '开始') {
      // that.setData({
      //   frequency: (parseInt(that.data.luckydrawData.chance) + that.data.getMyMembers * 2) - that.data.getMyCount
      // });
      that.setData({
        kjTextImg: true,
        myCountdown: 1,
        btnsHtml: '停止'
      });
    } else if (that.data.btnsHtml == '停止') {

      console.log('isGameType', that.data.isGameType);
      that.getMyCount();
      that.getResultByLuckyDrawId();
      that.getMyResultByLuckyDrawId();
      var Datas = '';

      if (that.data.isGameType == 1) {
        if (detailData.secStr_s != 0) {
          Datas = detailData.secStr_s.toString() + detailData.secStr_g.toString() + '.' + detailData.msStr_s.toString() + detailData.msStr_g.toString() + detailData.msStr_gg.toString();
        } else {
          Datas = detailData.secStr_g.toString() + '.' + detailData.msStr_s.toString() + detailData.msStr_g.toString() + detailData.msStr_gg.toString();
        }
      } else if (that.data.isGameType == 2) {
        if (detailData.secStr_s != 0) {
          Datas = detailData.secStr_s.toString() + detailData.secStr_g.toString() + '.' + detailData.msStr_s.toString() + detailData.msStr_g.toString();
        } else {
          Datas = detailData.secStr_g.toString() + '.' + detailData.msStr_s.toString() + detailData.msStr_g.toString();
        }
      }

      console.log(Datas);

      for (var i = 0; i < that.data.luckydrawData.commodity.length; i++) {
        var Arraybenchmark = that.data.luckydrawData.commodity[i].benchmark.split('-');

        console.log(Arraybenchmark[0], Arraybenchmark[1]);
        if (Arraybenchmark[0] == Arraybenchmark[1]) {
          // 如果 开奖码 相等
          console.log('相等');
          if (Datas == Arraybenchmark[0]) {
            that.setData({
              noClicks: false,
              kjTextImg: false,
              kjTextImgIocn: i,
              gamesTile: that.data.luckydrawData.commodity[i].title,
              typeName: that.data.luckydrawData.commodity[i].typeName
            });

            setTimeout(function () {
              that.setData({
                modelIsShow: true,
                noClicks: true
              });
            }, 2000);
            console.log('这个是一等奖', i)
            that.drawResult(i, Datas);
            that.setData({
              // modelIsShow: true,
              myCountdown: 0,
              btnsHtml: '开始'
            });

            return;
          }
        } else if (!Arraybenchmark[0]) {
          // 如果 开奖码 为空
          that.setData({
            kjTextImg: false,
            kjTextImgIocn: i,
            // modelIsShow: true,
            gamesTile: that.data.luckydrawData.commodity[i].title,
            typeName: that.data.luckydrawData.commodity[i].typeName
          });
          that.drawResult(i, Datas);
          that.setData({
            myCountdown: 0,
            btnsHtml: '开始'
          });
          return;
        } else {
          if (Datas >= Arraybenchmark[0] && Datas <= Arraybenchmark[1]) {

            that.setData({
              kjTextImg: false,
              kjTextImgIocn: i,
              gamesTile: that.data.luckydrawData.commodity[i].title,
              typeName: that.data.luckydrawData.commodity[i].typeName
            });

            setTimeout(function () {
              that.setData({
                modelIsShow: true,
                noClicks: true
              })
            }, 2000)

            that.setData({
              myCountdown: 0,
              btnsHtml: '开始'
            });
            that.drawResult(i, Datas);
            return;

          } else {

          }
        }
      }
    }
  },
  getMyCount: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'luckydraw/get',
      data: {
        luckyDrawId: luckyDrawId
      },
      success: function (res) {
        that.setData({
          luckydrawData: res.data.data,
        });

        // 判断8.88 8.888
        var isBenchmark = res.data.data.commodity[0].benchmark.split('-')[0];


        if (isBenchmark.length == 5) {
          that.setData({
            myCountdown: 3,
            isGameType: 1,
          })
        } else if (isBenchmark.length == 4) {
          that.setData({
            myCountdown: 2,
            isGameType: 2
          })
        }

        for (var i = 0; i < res.data.data.commodity.length; i++) {
          if (res.data.data.commodity[i].quantity == 0) {
            that.setData({
              isQuantity: 1
            });
          }
        }

        wx.request({
          url: host + 'drawclient/getMyMembers',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            luckyDrawId: luckyDrawId
          },
          success: function (res) {

            that.setData({
              getMyMembers: res.data.data
            });

            wx.request({
              url: host + 'luckydraw/getMyCount',
              data: {
                userId: app.globalData.userId,
                openId: userinfo.openid,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                luckyDrawId: luckyDrawId
              },
              success: function (res) {

                that.setData({
                  getMyCount: res.data.data
                })

                console.log('这次看这里', that.data.luckydrawData, that.data.getMyMembers, that.data.getMyCount);
                that.setData({
                  frequency: (parseInt(that.data.luckydrawData.chance) + that.data.getMyMembers) - that.data.getMyCount
                }, function () {
                  if (that.data.frequency <= 0) {
                    that.setData({
                      frequency: 0
                    }, function () {
                      that.setData({
                        showLoading: false
                      });
                    });
                  } else {
                    that.setData({
                      frequency: (parseInt(that.data.luckydrawData.chance) + that.data.getMyMembers) - that.data.getMyCount
                    }, function () {
                      that.setData({
                        showLoading: false
                      });
                    });
                  }
                });



              }
            })
          }
        });
      }
    });
  },
  drawResult: function (index, result) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/drawResult',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
        index: index,
        result: result
      },
      success: function (res) {

        console.log('中奖也',res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });

          return;
        }
      }
    })
  },
  getMyResultByLuckyDrawId: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/getMyResultByLuckyDrawId',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
      },
      success: function (res) {
        that.setData({
          getMyResultByLuckyDrawId: res.data.data
        })
      }
    })
  },
  getResultByLuckyDrawId: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'luckydraw/getResultByLuckyDrawId',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        luckyDrawId: luckyDrawId,
      },
      success: function (res) {

        that.setData({
          getResultByLuckyDrawId: res.data.data
        })
      }
    })
  },
  // 点击关闭模态框
  modelHide: function () {
    var that = this;
    that.setData({
      modelIsShow: false
    })
  },
  // 跳转排行榜
  gamesRankingUrl: function () {
    var that = this;
    wx.navigateTo({
      url: '../gamesRanking2/gamesRanking2?shopId=' + that.data.shopId,
    })
  },
  gamesWinningRecordUrl: function () {
    var that = this;
    wx.navigateTo({
      url: '../gamesWinningRecord2/gamesWinningRecord2?shopId=' + that.data.shopId,
    })
  },
  // 跳转个人中心
  personalUrl: function () {
    wx.navigateTo({
      url: '../couponmy/couponmy?allcou=1',
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;

    console.log(options.shopId);

    that.setData({
      shopId: options.shopId
    })
  
    that.getDefault(options.shopId, function () {

      var userinfo = wx.getStorageSync("userinfo_key");

      if (options.enjoyClientId) {
        console.log('自己的数据', userinfo)
        console.log('别人点进来的数据', options)

        console.log('luckyDrawId--->', luckyDrawId);
        wx.request({
          url: host + 'drawclient/develop',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            luckyDrawId: luckyDrawId,
            enjoyClientId: options.enjoyClientId
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            console.log('分销数据', res, res.data.code, res.data.masg);
          },
          fail: function (res) {
            wx.showModal({
              title: '接口调用失败',
              content: res,
            })
          }
        });
      }
    });



    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({
            scope: 'scope.userInfo',
            success(res) {
              var userinfo = wx.getStorageSync("userinfo_key")
                , nickName = '测试昵称'
                , headImgUrl = 'xxx.com'
                ;
              console.log('允许')
              wx.login({
                success: function (res) {
                  if (res.code) {
                    var code = res.code

                    wx.request({
                      url: host + 'xcx/xcxLogin',
                      data: {
                        userId: app.globalData.userId,
                        code: code,
                        nickName: nickName,
                        headImgUrl: headImgUrl
                      },
                      success: function (res) {
                        var result = res.data.data
                        console.log('123123123123', result, app)

                        var openId = result.openId
                        nickName = app.globalData.userInfo.nickName
                        headImgUrl = app.globalData.userInfo.avatarUrl
                        // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
                        // wx.showModal({
                        //   title: '别人点进来的数据',
                        //   content: '123123123',
                        // })
                        // console.log('try:+++++', app.globalData.userInfo)

                        that.getDefault(function () {
                          if (options.enjoyClientId) {
                            wx.request({
                              url: host + 'drawclient/develop',
                              data: {
                                userId: app.globalData.userId,
                                openId: openId,
                                nickName: nickName,
                                headImgUrl: headImgUrl,
                                luckyDrawId: luckyDrawId,
                                enjoyClientId: options.enjoyClientId
                              },
                              dataType: 'json',
                              method: 'get',
                              success: function (res) {
                                console.log('分销数据xxxxxxxxxxxxxxxxxxxx', res, res.data.code, res.data.masg);
                              },
                              fail: function (res) {
                                wx.showModal({
                                  title: '接口调用失败',
                                  content: res,
                                })
                              }
                            });
                          }

                          that.getMyCount();
                          that.getResultByLuckyDrawId();
                          that.getMyResultByLuckyDrawId();
                        })

                      },
                      fail: function () {

                      }
                    })

                  } else {
                    console.log('登陆失败');
                  }
                }
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // clearTimeout(time);
    // total_micro_second = 1;
    // count_down(this);
    // return;


  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;

    // that.getMyCount();
    // that.getResultByLuckyDrawId();
    // that.getMyResultByLuckyDrawId();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    // 来自页面内转发按钮
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    console.log(userinfo.clientId)
    console.log('转发事件回调', e)
    return {
      title: that.data.luckydrawData.title,
      path: 'pages/games2/games2?enjoyClientId=' + userinfo.clientId,
      success: function (res) {
        // 转发成功
        console.log('转发成功', res)
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})