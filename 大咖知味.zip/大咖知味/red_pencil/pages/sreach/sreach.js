// pages/sreach/sreach.js
var app = getApp();
var testhost = "https://menu.honqb.com";
var host = "https://menu.honqb.com/";
Page({
  data: {
    search: {
      searchValue: '',
      showClearBtn: false
    },
    testhost: testhost,
    host: host,
    searchResult: [],
    foodmap:[],
    seachline:[],
    seachshop: [],
    showinfo:false,
    showshop:false,
    showline:false,
    ssss:"<text>s</text>",
    nodes: [{
      name: 'div',
      attrs: {
        class: 'div_class',
        style: 'line-height: 60px; color: red;'
      },
      children: [{
        type: 'text',
        text: 'Hello&nbsp;Worlds!'
      }]
    }]
  },
  searchSubmit: function () {
    let val = this.data.search.searchValue;
    let that = this;
    let seachline=[];
    let seachshop = [];
    var seachshops=[];
    wx.showLoading({
      title: '加载中',
    })
    that.setData({
      showinfo:true,
    })
    for (var i = 0; i < that.data.foodmap.length;i++){
      console.log(that.data.foodmap[i].name);
      if (that.data.foodmap[i].name.indexOf(val) != -1){
        let linefood = that.data.foodmap[i];
        linefood.inx=i;
        seachline.push(linefood);
        for (let j = 0; j < that.data.foodmap[i].shopInfo.length; j++) {
          for (let z = 0; z < Object.keys(that.data.foodmap[i].shopInfo[j]).length;z++){
            let shopInfoname = Object.keys(that.data.foodmap[i].shopInfo[j])[z];
            if (that.data.foodmap[i].shopInfo[j][shopInfoname].indexOf(val)!=-1){
              let bidc = '';
              if (that.data.foodmap[i].shopInfo[j].newMenu) {

                for (let k = 0, lenk = that.data.foodmap[i].shopInfo[j].newMenu.length; k < lenk; k++) {
                  bidc += that.data.foodmap[i].shopInfo[j].newMenu[k].name + ',';
                }
                that.data.foodmap[i].shopInfo[j].newMenu = bidc;
              }
              // that.data.foodmap[i].shopInfo[j][shopInfoname].replace(val, "<text class='tred'>" + val+"</text>");
              seachshops = {
                shoparr: that.data.foodmap[i].shopInfo[j], 
                lineidx: i, 
                shopidx: j, 
              }
              seachshop.push(seachshops);
              break;
            }
          }
        }
      }else{
        for (let y = 0; y < that.data.foodmap[i].shopInfo.length; y++){
          
          for (let x = 0; x < Object.keys(that.data.foodmap[i].shopInfo[y]).length; x++) {
            let shopInfoname2 = Object.keys(that.data.foodmap[i].shopInfo[y])[x];

            console.log('shopInfoname2', that.data.foodmap[i].shopInfo[y][shopInfoname2]);
            if (that.data.foodmap[i].shopInfo[y][shopInfoname2].indexOf(val) != -1) {
              let tred = that.data.foodmap[i].shopInfo[y][shopInfoname2];
              that.data.foodmap[i].shopInfo[y][shopInfoname2] = tred;
              let bidc = '';
              if (that.data.foodmap[i].shopInfo[y].newMenu) {
                
                for (let k = 0, lenk = that.data.foodmap[i].shopInfo[y].newMenu.length; k < lenk; k++) {
                  bidc += that.data.foodmap[i].shopInfo[y].newMenu[k].name + ',';
                }
                that.data.foodmap[i].shopInfo[y].newMenu = bidc;
              }

              seachshops = {
                shoparr: that.data.foodmap[i].shopInfo[y],
                lineidx:i,
                shopidx:y,
              }
              seachshop.push(seachshops);
              break;
            }
          }
        }
      }
    }
    that.setData({
      seachline: seachline,
      seachshop: seachshop,
    })
    console.log(that.data.seachshop)
    if (that.data.seachshop.length<1){
      that.setData({
        showshop: false,
      })
    }else{
      that.setData({
        showshop: true,
      })
    }
    if (that.data.seachline.length < 1) {
      that.setData({
        showline:false,
      })
    } else {
      that.setData({
        showline: true,
      })
    }
    wx.hideLoading();
    // console.log(that.data.seachshop, that.data.seachline);
  },
  toline:function(e){
    let cubtabline = e.currentTarget.dataset.index;
    wx.redirectTo({
      url: '../index3/index3?cubtabline=' + cubtabline,
    })
  },
  toshop: function (e) {
    let shopid=e.currentTarget.dataset.shopid;
    let index = e.currentTarget.dataset.index;
    console.log("我是搜索的", shopid)
    // console.log(e.currentTarget.dataset.lineidx, e.currentTarget.dataset.shopidx)
    wx.navigateTo({
      url: '../shop2/shop2?shopId=' + shopid + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
    });
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    var that=this;
    wx.request({
      url: testhost + '/gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (reback) {
        that.setData({
          foodmap: reback.data.data,
        })
        console.log("美食地图的返回数据", that.data.foodmap);
      }
    });
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  //输入内容时
  searchActiveChangeinput: function (e) {
    const val = e.detail.value;
    this.setData({
      'search.showClearBtn': val != '' ? true : false,
      'search.searchValue': val,
      showinfo:false,
    })
  },
  //点击清除搜索内容
  searchActiveChangeclear: function (e) {
    this.setData({
      'search.showClearBtn': false,
      'search.searchValue': '',
      showline: false,
      showshop: false,
    })
  },
  //点击聚集时
  focusSearch: function () {
    if (this.data.search.searchValue) {
      this.setData({
        'search.showClearBtn': true
      })
    }
  },
  //搜索提交
  // searchSubmit: function () {
  //   const val = this.data.search.searchValue;
  //   if (val) {
  //     const that = this,
  //       app = getApp();
  //     wx.showToast({
  //       title: '搜索中',
  //       icon: 'loading'
  //     });
  //     wx.request({
  //       url: app.globalData.API_URL + 'searchTeam',
  //       data: {
  //         keywords: val,
  //         user_id: app.globalData.userId
  //       },
  //       method: 'GET', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
  //       // header: {}, // 设置请求的 header
  //       success: function (res) {
  //         // success
  //         let searchResult = res.data.data;
  //         const len = searchResult.length;
  //         for (let i = 0; i < len; i++) {
  //           searchResult[i]['team_avator'] = app.globalData.STATIC_SOURCE + searchResult[i]['team_avator'];
  //         }
  //         that.setData({
  //           searchResult: searchResult,
  //           'search.showClearBtn': false,
  //         })
  //       },
  //       fail: function () {
  //         // fail
  //       },
  //       complete: function () {
  //         // complete
  //         wx.hideToast();
  //       }
  //     })
  //   }
  // }
})