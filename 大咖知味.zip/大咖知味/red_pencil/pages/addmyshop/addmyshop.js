// pages/addmyshop/addmyshop.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    shopname:'',
    shopadress:'',
    shopphone:'',
    shopweixin:'',
    shoppai:'',
    shopprice:'',
    latandlng:'',
    addlat:0,
    addlng:0,
  },
  chooseloction:function(e){
    var that=this;
    wx.chooseLocation({
      success: function(res) {
        console.log(res)
        that.setData({
          shopadress: res.address,
          latandlng: res.latitude + ',' + res.longitude,
          addlat: res.latitude,
          addlng: res.longitude,
          shopname:res.name,
        })
      },
    })
  },
  weixinkefu: function (e) {
    this.setData({
      shopweixin: e.detail.value,
    })
  },
  name: function (e) {
    this.setData({
      shopname: e.detail.value,
    })
  },
  address: function (e) {
    this.setData({
      shopadress: e.detail.value,
    })
  },
  phone: function (e) {
    this.setData({
      shopphone: e.detail.value,
    })
  },
  menu: function (e) {
    this.setData({
      shoppai: e.detail.value,
    })
  },
  price: function (e) {
    this.setData({
      shopprice: e.detail.value,
    })
  },
  formSubmit:function(e){
    console.log(e)
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("xxxxx", that.data.shopname == '' && that.data.shopadress)
    if (that.data.shopname != '' && that.data.shopadress != '' && that.data.shopphone != '' && that.data.shopweixin != '' && that.data.addlat != ''){
      if (that.data.shopphone.length==11){
        wx.request({
          url: testhost + '/gourmetshopapply/apply',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
            name: that.data.shopname,
            address: that.data.shopadress,
            phone: that.data.shopphone,
            weixin: that.data.shopweixin,
            menu: that.data.shoppai,
            price: that.data.shopprice,
            lat: that.data.addlat,
            lng: that.data.addlng,
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            console.log(res)
            if (res.data.code != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.msg,
              })
            } else {
              wx.showModal({
                title: '温馨提示',
                content: '您的入驻请求发送成功，我们会在3个工作日内给予答复，请耐心等待',
                success: function () {
                  wx.reLaunch({
                    url: '../zhaopai/zhaopai',
                  })
                }
              })
            }
          },
        })
      }else{
        wx.showModal({
          title: '温馨提示',
          content: '请输入11位手机号码',
        })
      }
    }else{
      if (that.data.shopname == ''){
        wx.showModal({
          title: '温馨提示',
          content: '请填写店铺名',
        })
      } else if (that.data.shopadress == '') {
        wx.showModal({
          title: '温馨提示',
          content: '请填写地址',
        })
      } else if (that.data.shopphone == '') {
        wx.showModal({
          title: '温馨提示',
          content: '请填写联系电话',
        })
      } else if (that.data.shopweixin == '') {
        wx.showModal({
          title: '温馨提示',
          content: '请填写客服微信',
        })
      } else if (that.data.addlat == '') {
        wx.showModal({
          title: '温馨提示',
          content: '请选择地图定位到您的商店（或者附近）',
        })
      }
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})