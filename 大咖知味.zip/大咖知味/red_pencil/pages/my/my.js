// pages/my/my.js
var app = getApp();
var zhan;
var host = app.globalData.host;
var imgUrl = app.globalData.url;
var util = require('../../utils/util.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userinfo:{},
    nickName: '',
    avatarUrl: '',
    //扇形
    p2rotate: 90,
    shuozhan: false,
    wid51: 51,
    heig56: 56,
    gangrotate: 0,
    gangmarig1: 2,
    host: host,
    loginNo:false,
    imgUrl: imgUrl,
    hostUrl: app.globalData.basehqbUrl,
    showLoading: true,
    mycoulength: 0,
    redDot: false,
    serviceModel_s:false,
    serviceModel:false,
    phoneXs: "",
    shopLogo: "",
    shopName: "",
    //扇形
  },

  // 在线客服
  serviceShow: function () {
    var that = this;

    that.setData({
      serviceModel: true,
      serviceModel_s: true
    })
  },
  phone: function () {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phoneXs,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },
  serviceModel_s_sj: function () {
    var that = this;

    that.setData({
      serviceModel: false,
      serviceModel_s: false
    })
  },
  // 在线客服

  // 扇形
  zhankai: function (e) {
    var that = this;
    if (that.data.p2rotate == 90) {
      that.setData({
        gangrotate: 45,
        gangmarig1: -5,
        p2rotate: 0,
      })
    } else {
      that.setData({
        p2rotate: 90,
        gangrotate: 0,
        gangmarig1: 2,
      })
    }
  },
  clickm: function (e) {
    var that = this;
    // console.log(e);
    this.setData({
      p2rotate: 90,
      gangrotate: 0,
      gangmarig1: 2,
    })
    wx.redirectTo({
      url: e.currentTarget.dataset.url,
    })
  },
  // 扇形
  myCoupons:function(e){
    var that = this;
    
    wx.setStorageSync("mycouLength", that.data.mycoulength)
    that.setData({
      redDot: false
    })

    wx.navigateTo({
      url: '../couponmy/couponmy?allcou=1',
    })
  },
  goCoupons:function(){
    wx.navigateTo({
      url: '../myCouponList/myCouponList',
    })
  },
  myCang: function (e) {
    wx.navigateTo({
      url: '../mycang/mycang',
    })
  },
  myOrder: function (e) {
    wx.navigateTo({
      url: '../myorder/myorder',
    })
  },
  mytreat:function(er){
    wx.navigateTo({
      url: '../mytreat/mytreat',
    })
    
  },
  myOrder2: function (e) {
    wx.navigateTo({
      url: '../myorder2/myorder2',
    })
  },

  //授权登陆
  getUserInfo: function (e) {
    console.log("e", e)
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      wx.reLaunch({
        url: '../my/my',
      })
    })
  },
  couponmyData: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].sillShow = parseInt(res.data.data[i].sillShow)
          res.data.data[i].moneyNumShow = res.data.data[i].moneyNumShow
        }
        that.setData({
          coulists: res.data.data,
        })
        console.log('优惠劵总列表！！！', that.data.coulists);
        // 我的优惠劵！！
        wx.request({
          url: host + 'shopcoupons/myCoupons',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
          },
          dataType: 'json',
          method: 'get',
          success: function (ress) {
            for (let i = 0; i < ress.data.data.length; i++) {
              ress.data.data[i].sillShow = parseInt(ress.data.data[i].sillShow)
              ress.data.data[i].moneyNumShow = ress.data.data[i].moneyNumShow
            }
            that.setData({
              mycoulist: ress.data.data,
            })

            var mycouLength = wx.getStorageSync("mycouLength")
            if (mycouLength) {

              if (that.data.mycoulist.length != mycouLength) {
                that.setData({
                  redDot: true,
                  mycoulength: that.data.mycoulist.length,
                })
              }
            } else {
              wx.setStorageSync("mycouLength", that.data.mycoulist.length)
            }


          },
          fail: function (res) { }
        })
        // 我的优惠劵！！
      },
      fail: function (res) { }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    wx.hideShareMenu();
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    that.phoneAjax();    
  },

  // 获取电话
  phoneAjax: function () {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      success: function (res) {
        console.log(res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }
        that.setData({
          phoneXs: res.data.data.contact,
          shopLogo: res.data.data.shopLogo,
          shopName: res.data.data.shopName,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    that.couponmyData();
    that.setData({
      avatarUrl: userinfo.avatarUrl,
      nickName: userinfo.nickName,
    });

    if (!userinfo.avatarUrl || userinfo.avatarUrl == "") {
      console.log("未登录")
      that.setData({
        loginNo: true,
      })
      return;
    } else {
      that.setData({
        loginNo: false,
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})