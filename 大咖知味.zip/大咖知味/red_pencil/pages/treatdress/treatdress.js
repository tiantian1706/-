// pages/treatdress/treatdress.js
var app = getApp()

var orderId = ""
var openId = ""
var quantity = 0
var receive = 1
var sendUserInfo = {

}

var reciveUserInfo = {

}
var host = "https://basehqb.honqb.com"
var testhost = "https://basehqb.honqb.com";

Page({

  /**
   * 页面的初始数据
   */
  data: {
    testhost: testhost,
    host: "https://basehqb.honqb.com",
    userInfo: {},
    duihuanma: "",
    shopAddress: '',
    latitude: '',
    longitude: '',
    address: {
      name: "收件人",
      tele: "手机号码",
      province: "省份/自治区",
      city: "市",
      area: "县/区",
      all: "详情地址",
    },
    touxiangImage: {},
    addressInfo: {
      userName: "",
      telNumber: "",
      provinceName: "",
      cityName: "",
      countyName: "",
      detailInfo: ""
    },
    drawDownImage: {},
    Stamped: "", // 图片盖章
    qrcode: {}, // 二维码
    shopCommodityIds: {},
    shopCommodityId:'',
    createTimes: {},
    quantity: '',
    quantity2: '',
    receive: '',
    guige: true,
    isClientId: "1",
    ziji_isClientId: "1",
    showLoading: true,
    benefactor: {},
    benefactor2: {},
    nikeName:'',
    interviteId:0,
    isxiao:false,
  },

  // 跳转到商品详情页
  JumpForDetails: function () {
    wx.navigateTo({
      url: '../treatDetail/treatDetail?shopCommodityId=' + this.data.shopCommodityIds
    })
  },
  JumpIndex: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    
    var that = this;
    // that.headline();
    // orderId = opt.orderId;
    // quantity = opt.quantity;
    // receive = opt.receive
    sendUserInfo = JSON.parse(opt.userinfo)
    
    console.log("状态状态状态状态状态状态状态状态状态状态状态", opt)
    that.setData({
      benefactor2: JSON.parse(opt.userinfo),
      // duihuanma: opt.duihuanma,
      // qrcode: host + opt.qrcode,
      interviteId: opt.interviteId,
      // quantity: quantity,
      // receive: receive,
      // fafa: opt.fafa,
      // isClientId2: sendUserInfo.clientId,
      // lala: opt.lala
    })

    // var pages = getCurrentPages();
    // var currPage = pages[pages.length - 1];  //当前页面
    // var prevPage = pages[pages.length - 2]; //上一页
    // prevPage.setData({
    //   isinvitefinish: true,
    // })

    // 获取兑换码
    wx.request({
      url: testhost+'/intervite/get',
      data: {
        interviteId: opt.interviteId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        
        that.setData({
          qrcode: res.data.data.qrcode,
          duihuanma: res.data.data.code,

        })
        if (res.data.data.state==3){
          that.setData({
            isxiao:true,
          })
        }
        console.log("获取兑换码!!", res, that.data.qrcode)
      }
    })
    // 获取兑换码

    wx.request({
      url: 'https://basehqb.honqb.com/orderreceive/checkReceiveCode',
      data: {
        userId: app.globalData.userId,
        receiveCode: that.data.duihuanma
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        console.log("测试盖章", res)
        console.log("测试盖章", that.data.Stamped)
        var userinfo = wx.getStorageSync("userinfo_key")

        that.setData({
          Stamped: res.data.data.use,
          receive: res.data.data.receive,
          quantity2: res.data.data.quantity,
          benefactor: res.data.data
        })
        if (that.data.receive == 1) {
          that.setData({
            isClientId: res.data.data.clientId,
            ziji_isClientId: userinfo.clientId
          })
        }
        if (that.data.isClientId == that.data.ziji_isClientId) {
          console.log('测试两人id是否匹配 ==> 匹配', that.data.isClientId, that.data.ziji_isClientId)
        } else {
          console.log('测试两人id是否匹配 ==> 不匹配', that.data.isClientId, that.data.ziji_isClientId)
        }
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })
    

    wx.request({
      url: testhost + '/intervite/get',
      data: {
        // userId: app.globalData.userId,
        interviteId: this.data.interviteId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        console.log("filladdress订单详情", res)
        that.setData({
          exchangeing: res.data.data,
          userInfo: sendUserInfo,
          createTimes: res.data.data.createTime,
          shopAddress: res.data.data.address,
          shopName: res.data.data.shopName,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        // console.log("规格有多少", that.data.exchangeing.description.length)
        // var length = that.data.exchangeing.description.length
        // if (length == 0) {
        //   that.setData({
        //     guige: false
        //   })
        // }
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })

    this.getDFUserInfo(function (userinfo, code) {

      console.log("收货人的信息", userinfo)

      reciveUserInfo = userinfo

      // console.log(reciveUserInfo.nickName)
      // console.log(reciveUserInfo.avatarUrl)

      wx.request({
        url: 'https://basehqb.honqb.com/xcx/login',
        data: {
          userId: app.globalData.userId,
          code: code,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          console.log("openid", res)
          openId = res.data.data.openId
          reciveUserInfo.openId = openId
        }
      })
      console.log(reciveUserInfo.nickName)
      console.log(reciveUserInfo.avatarUrl)
    })
    
  },
  tude: function () {
    var that = this
    wx.request({
      url: host + '/notify/navigation',
      data: {
        address: that.data.shopAddress
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })
        console.log(res)
        console.log("latitude000", that.data.latitude)
        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  headline: function () {
    var that = this;
    wx.request({
      url: host + '/user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('地址', res);
        that.setData({
          shopName: res.data.data.shopName,
          shopAddress: res.data.data.shopAddress
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        // var latitude = res.latitude
        // var longitude = res.longitude
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          address: that.data.shopAddress
        })
      }
    })
  },
  didian: function () {
    var that = this
    that.tude();
  },
  getDFUserInfo: function (cb) {
    wx.login({
      success: function (res) {

        var code = res.code
        wx.getUserInfo({
          success: function (res) {

            typeof cb == "function" && cb(res.userInfo, code)

          }
        })
      }
    })
  },

  choose_address: function () {
    var that = this;
    wx.chooseAddress({

      success: function (res) {


        console.log(res.userName)
        console.log(res.postalCode)
        console.log(res.provinceName)
        console.log(res.cityName)
        console.log(res.countyName)
        console.log(res.detailInfo)
        console.log(res.nationalCode)
        console.log(res.telNumber)

        that.setData({
          addressInfo: res
        })
      }
    })
  },

  confirm_recive: function () {
    var that = this;
    if (this.data.duihuanma && that.data.addressInfo.detailInfo.length > 0) {
      wx.request({
        url: 'https://basehqb.honqb.com/orderreceive/exchange',
        data: {
          userId: app.globalData.userId,
          openId: reciveUserInfo.openId,
          nickName: reciveUserInfo.nickName,
          headImgUrl: reciveUserInfo.avatarUrl,
          receiveCode: that.data.duihuanma,
          name: that.data.addressInfo.userName,
          phone: that.data.addressInfo.telNumber,
          address: that.data.addressInfo.provinceName + that.data.addressInfo.cityName + that.data.addressInfo.countyName + that.data.addressInfo.detailInfo,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          that.setData({
            drawDownImage: res.data.msg
          })
          console.log("recive_user使用资格码后，返回信息", res)
          if (res.data.msg == "该码已经失效") {
            wx.showModal({
              title: '提示',
              content: "该兑换码已使用，不可继续添加地址。",
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({

                  })
                } else if (res.cancel) {
                  wx.navigateBack({

                  })
                }
              }
            })
          }

          if (!res.data.data && res.data.msg.length == 0) {
            wx.showModal({
              title: '提示',
              content: "恭喜您，地址添加成功，商品将尽快发出！",
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({

                  })
                } else if (res.cancel) {
                  wx.navigateBack({

                  })
                }
              }
            })
          }

        }
      })
    } else {
      console.log("缺少兑换码或者缺少地址")
    }


  },
  btnGet: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    console.log(userinfo)
    wx.request({
      url: host + '/orderreceive/receiveCode',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        headImgUrl: userinfo.avatarUrl,
        nickName: userinfo.nickName,
        code: that.data.duihuanma
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        wx.showModal({
          title: '提示',
          content: '领取成功',
          success: function (res) {
            that.setData({
              pitch: true
            })
          }
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.log(this.data.drawDownImage)
    if (this.data.drawDownImage == '该码已经失效') {
      console.log('a')
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})
