// pages/index3/index3.js
var testhost = "https://menu.honqb.com";
var host = "https://menu.honqb.com/";
var app = getApp();
var area = require('../../data/area');
var p = 0, c = 0, d = 0;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    markers: [],
    polyline: [],
    controls: [],
    foodmap:[],
    zfoodmap: [],
    menutab:-1,
    userlongitude:0,
    userlatitude:0,
    beiuserlongitude:0,
    beiuserlatitude:0,
    shopname:"加载中...",
    zhaopai:"加载中...",
    juli:0,
    shopimg:"",
    shopId:0,
    shoparr:{},
    showlist:false,
    beiyongmarkers:[],
    showDistpicker: false,
    provinceName: [],
    provinceCode: [],
    provinceSelIndex: '',
    cityName: [],
    cityCode: [],
    citySelIndex: '',
    districtName: [],
    districtCode: [],
    districtSelIndex: '',
    iamhere:'顺德区',
    havetanshopid:'',
    havetan:false,
    mapscale:14,
    shoparrlineidx:0,
    shoparrshopidx:0,
    showtwo: false,
    miyao:"CANBZ-33ARP-E7XDY-VUQZJ-SVZG7-GWBZA",
    xiantan:true,
    isfrist: true,
    haveding:false,
    coulist: [],
    mycoulist: [],
    zhijie:'',
    wozhijie:'',
  },

  // 地址
  locationGo: function () {
    wx.navigateTo({
      url: '../location/location?url=coupon',
    })
  },
  
  tocoulist: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.tcouponsid, that.data.mycoulist)
    wx.navigateTo({
      url: '../coupondetail/coupondetail?juanarr=' + JSON.stringify(that.data.coulist[e.currentTarget.dataset.idx]),
    })
  },
  tomorecoupon: function (e) {
    wx.navigateTo({
      url: '../couponmy/couponmy',
    })
  },
  closetan:function(e){
    this.setData({
      xiantan: false,
    })
  },
  regionchange(e) {
    // console.log(e.type)
  },
  search:function(e){
    wx.navigateTo({
      url: '../sreach/sreach',
    })
  },
  toaddshop: function (e) {
    wx.navigateTo({
      url: '../addmyshop/addmyshop',
    });
  },
  regionchange:function(e){
    var that = this;
    var movemarkers = that.data.beiyongmarkers;
    var newmarkers=[];
    var zuijin=null;
    var xuni=0;
    if (e.type=="end"){
      that.mapCtx.getCenterLocation({
        success: function (res) {
          let nass = {
            id: 0,
            iconPath: '../../imgs/loc2.png',
            width: 35,
            height: 42,
            latitude: res.latitude,
            longitude: res.longitude,
          }
          newmarkers.push(nass);
          for(let i=0;i<movemarkers.length;i++){
            if (movemarkers[i].id != 0) {
              if (that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude) < 3) {
                // console.log("距离!们", "旧的" + that.distance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude), zuijin, "+++++++++新的" + that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude));
                // console.log("距离!们",zuijin,"+++++++++新的" + that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude));
                if (zuijin == null) {
                  zuijin = that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude);
                  // xuni=1;
                  movemarkers[i].width = 45;
                  movemarkers[i].height = 54;
                  // console.log("来了吗")
                } else {
                  if (that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude) < zuijin) {
                    zuijin = that.newdistance(res.latitude, res.longitude, movemarkers[i].latitude, movemarkers[i].longitude);
                    // console.log("最近的！", zuijin);
                    for (let x = 1; x < newmarkers.length; x++) {
                      // console.log("我在这", newmarkers, newmarkers[x])
                      newmarkers[x].width = 30;
                      newmarkers[x].height = 36;
                    }
                    movemarkers[i].width = 45;
                    movemarkers[i].height = 54;
                    // xuni = newmarkers.length;
                  } else {
                    movemarkers[i].width = 30;
                    movemarkers[i].height = 36;
                  }
                }
                newmarkers.push(movemarkers[i]);
              }
            }
          }
          that.setData({
            markers: newmarkers,
          })
        }
      })
    }
  },
  markertap(e) {
    var that=this;
    console.log(e.markerId);
    that.markclick(e.markerId);
  },

  controltap(e) {
    var that=this;
    // console.log(e)
    switch (e.controlId){
      case 0:
        that.setData({
          showlist:true,
        });
        break;
      case 1:
        wx.navigateTo({
          url: '../friendall/homes/homes',
        })
        
        break;
      case 2:
        that.forthemarkers(that.data.menutab);
        break;
      case 3:
        that.setData({
          userlongitude: that.data.beiuserlongitude, 
          userlatitude: that.data.beiuserlatitude,
          mapscale:14,
        })
        break;
      case 4:
        wx.navigateTo({
          url: '../zhaopai/zhaopai',
        })
        break;
      case 5:
        wx.navigateTo({
          url: '../miji/miji?userlongitude=' + that.data.userlongitude + '&userlatitude=' + that.data.userlatitude,
        })
        break;
      case 6:
        // wx.navigateTo({
        //   url: '../addmyshop/addmyshop',
        // })
        // wx.navigateTo({
        //   url: '../couponmy/couponmy',
        // })
        that.xinjiuren();
        break;
      case 7:
        // wx.navigateTo({
        //   url: '../addmyshop/addmyshop',
        // })
        wx.navigateTo({
          url: '../my/my',
        })
        break;
      case 8:
        console.log("广告关闭1", that.data.controls);
        that.data.controls.splice(8, 1);
        that.data.controls.splice(7, 1);
        that.setData({
          controls: that.data.controls,
        })
        console.log("广告关闭2", that.data.controls);
        break;
    }
    // wx.redirectTo({
    //   url: '../index/index',
    // })
  }, 
  tomy:function() {
    wx.navigateTo({
      url: '../my/my',
    })
  },
  tomiji: function () {
    wx.navigateTo({
      url: '../zhaopai/zhaopai',
    })
  },
  tozhaopai: function () {
    wx.navigateTo({
      url: '../miji/miji?userlongitude=' + this.data.userlongitude + '&userlatitude=' + this.data.userlatitude,
    })
  },
  backmap:function(){
    this.setData({
      showlist: false,
    })
  },
  
  markclick:function(id){
    var that = this;
    for (let i = 0; i < that.data.markers.length; i++) {
      if (that.data.markers[i].id!=0){
        that.data.markers[i].iconPath = '/imgs/loc.png';
        that.data.markers[i].width = 30;
        that.data.markers[i].height = 36;
        if (that.data.markers[i].id == id) {
          that.data.markers[i].iconPath = '/imgs/loc4.png';
          that.data.markers[i].width = 45;
          that.data.markers[i].height = 54;
          let ds = that.newdistance(that.data.markers[i].latitude, that.data.markers[i].longitude, that.data.userlatitude, that.data.userlongitude);
          let bidian ;
          let MustOrders = '';
          let newMenu;
          
          if (that.data.markers[i].newMenu) {
            for (let r = 0, lenr = that.data.markers[i].newMenu.length; r < lenr; r++) {
              MustOrders += that.data.markers[i].newMenu[r].name + ','
            }
          }


          if (MustOrders.length>35){
            bidian = MustOrders.substring(0, 35) + "...";
          }else{
            bidian = MustOrders;
          }
          that.setData({
            shopname: that.data.markers[i].shoparr.name,
            zhaopai: bidian,
            juli: ds,
            shopimg: that.data.markers[i].image,
            shopId: that.data.markers[i].id,
            shoparr: that.data.markers[i].shoparr,
            havetan: (that.data.havetanshopid.indexOf(that.data.markers[i].id)!=-1 ? true : false),
            haveding: (that.data.markers[i].appointment == 0 ? false : true),
            shoparrlineidx: that.data.markers[i].lineidx,
            shoparrshopidx: that.data.markers[i].shopidx,
          })
          // break;
          // console.log(that.data.haveding, that.data.markers[i])
        }
      }
    }
    that.setData({
      markers: that.data.markers,
    })
  },
  // distance: function (lat1, lng1, lat2, lng2) {
  //   let a = (lat1 * Math.PI / 180.0) - (lat2 * Math.PI / 180.0);
  //   let b = (lng1 * Math.PI / 180.0) - (lng2 * Math.PI / 180.0);
  //   let s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos((lat1 * Math.PI / 180.0)) * Math.cos((lat2 * Math.PI / 180.0)) * Math.pow(Math.sin(b / 2), 2)));
  //   s = s * 6378.137;
  //   s = (Math.round(s * 10000) / 10000).toFixed(2);
  //   // console.log(s);
  //   if(s<0.5){
  //     return s;
  //   }else{
  //     return (s - 0.5).toFixed(2);
  //   }
  // },
  getRad:function(d){
    var PI = Math.PI;
    return d* PI / 180.0;
  },
  newdistance: function (lat1, lng1, lat2, lng2){
    var that=this;
    var f = that.getRad((parseFloat(lat1) + parseFloat(lat2)) / 2);
    var g = that.getRad((lat1 - lat2) / 2);
    var l = that.getRad((lng1 - lng2) / 2);
    var sg = Math.sin(g);
    var sl = Math.sin(l);
    var sf = Math.sin(f);
    var s, c, w, r, d, h1, h2;
    var a = 6378137.0;//地球的半径啊
    var fl = 1 / 298.257;
    sg = sg * sg;
    sl = sl * sl;
    sf = sf * sf;
    s = sg * (1 - sl) + (1 - sf) * sl;
    c = (1 - sg) * (1 - sl) + sf * sl;
    w = Math.atan(Math.sqrt(s / c));
    r = Math.sqrt(s * c) / w;
    d = 2 * w * a;
    h1 = (3 * r - 1) / 2 / c;
    h2 = (3 * r + 1) / 2 / s;
    
    s = d * (1 + fl * (h1 * sf * (1 - sg) - h2 * (1 - sf) * sg));
    s = s / 1000;
    s = s.toFixed(2);//指定小数点后的位数.
    return s;
  },
  toshop:function(e){
    var that=this;
    // console.log("sfga", that.data.markers)
    if (that.data.markers.length!=0){
      if (e.currentTarget.dataset.inx == undefined) {
        // wx.navigateTo({
        //   url: '../shop2/shop2?shoparr=' + JSON.stringify(that.data.shoparr),
        // });
        wx.navigateTo({
          url: '../shop2/shop2?shopId=' + that.data.shoparr.shopId + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
        });
      } else {
        // console.log(that.data.markers[e.currentTarget.dataset.inx], JSON.stringify(that.data.markers[e.currentTarget.dataset.inx].shoparr))
        // wx.navigateTo({
        //   url: '../shop2/shop2?shoparr=' + JSON.stringify(that.data.markers[e.currentTarget.dataset.inx].shoparr),
        // });
        wx.navigateTo({
          url: '../shop2/shop2?shopId=' + that.data.beiyongmarkers[e.currentTarget.dataset.inx].id + "&lineidx=" + e.currentTarget.dataset.lineidx + "&shopidx=" + e.currentTarget.dataset.shopidx,
        });
      }
    }
  },
  loadthatfoodall: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: testhost + '/gourmetmenu/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("菜单的菜", res.data.data)
        let havetanshopid = '';
        for (let i = 0; i < res.data.data.length; i++) {
          havetanshopid += res.data.data[i].shopInfo.shopId + ",";
          if (i == res.data.data.length - 1) {
            wx.request({
              url: testhost + '/gourmetfood/getAll',
              data: {
                userId: app.globalData.userId,
              },
              dataType: 'json',
              method: 'get',
              success: function (resd) {
                console.log("秘籍里的菜", resd.data.data)
                let havetanshopid2 = '';
                for (let j = 0; j < resd.data.data.length; j++) {
                  havetanshopid2 += resd.data.data[j].shopInfo.shopId + ",";
                  if (j == resd.data.data.length - 1) {
                    that.setData({
                      havetanshopid: that.data.havetanshopid + havetanshopid2,
                    })
                    return afun();
                  }
                }
              },
            })
          }
        }
      },
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
   
 
    if (options.isType) {
      console.log(options.isType);
      that.setData({
        showlist: true,
        optionsIsType: options.isType
      })
    }


    that.setAreaData();
    wx.getSetting({
      success(res) {
        console.log("授权问题", res, res.authSetting.userInfo)
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({
            scope: 'scope.userInfo',
            success() {
              // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
              wx.startRecord()
            }
          })
        }
      }
    })
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        that.setData({
          userlongitude: res.longitude,
          userlatitude: res.latitude,
          beiuserlongitude: res.longitude,
          beiuserlatitude: res.latitude,
        })
        console.log("用户位置", res.longitude, res.latitude,)
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/?location=' + res.latitude + ',' + res.longitude +'&key='+that.data.miyao,
          data: {
            userId: app.globalData.userId,
          },
          header: {
            'Content-Type': 'application/json'
          },
          dataType: 'json',
          method: 'get',
          success:function(resb){
            console.log("自己位置的地区", resb,)
            if (resb.data.result.address_component.district == undefined || resb.data.result.address_component.district == null || resb.data.result.address_component.district==''){
              that.setData({
                iamhere: resb.data.result.address_component.city,
              })
            }else{
              that.setData({
                iamhere: resb.data.result.address_component.district,
              })
            }
          },
        })
      }
    })
    wx.getSystemInfo({
      success: function (res) {
        console.log("手机信息！！！", res, res.windowWidth / 100 * 90)
        that.setData({
          controls: [
            {
              id: 0,
              iconPath: '../../imgs/menu.png',
              position: {
                // left: res.windowWidth - 45,
                // top: res.windowHeight - res.windowHeight / 100 * 55,
                left: 5,
                top: res.windowHeight - res.windowHeight / 100 * 55,
                width: 32,
                height: 32
              },
              clickable: true
            },
            {
              id: 3,
              iconPath: '../../imgs/ding.png',
              position: {
                left: 5,
                top: res.windowHeight - res.windowHeight / 100 * 45,
                width: 32,
                height: 32
              },
              clickable: true
            },
          ]
        });
      }
    })

    wx.request({
      url: testhost + '/gourmetrouteline/getAll',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (reback) {
        if (reback.data.code==1){
          wx.showModal({
            title: '温馨提示',
            content: reback.data.msg,
          })
        }else{
          // reback.data.data.sort(that.sortNumber2("lineId"))
          that.setData({
            foodmap: reback.data.data,
            zfoodmap: reback.data.data,
          })
          // let ds = that.distance(that.data.foodmap[0].latitude, that.data.markers[i].longitude, that.data.userlatitude, that.data.userlongitude);
          console.log("美食地图的返回数据", that.data.foodmap);
          wx.getLocation({
            type: 'wgs84',
            success: function (res) {
              if (options.cubtabline != null) {
                console.log("真的？ＡＤＡＳ啊", options.cubtabline)
                that.setData({
                  menutab: parseInt(options.cubtabline),
                })
                that.foralinefood(options.cubtabline);
              }else{
                if (that.data.foodmap[0].shopInfo.length != 0) {
                  let jiebidian;
                  let bidianc = '';
                  if (that.data.foodmap[0].shopInfo[0].newMenu) {
                    for (let k = 0, lenk = that.data.foodmap[0].shopInfo[0].newMenu.length; k < lenk; k++) {
                      bidianc += that.data.foodmap[0].shopInfo[0].newMenu[k].name + ','
                    }
                  }

                  if (bidianc.length>35){
                    jiebidian = bidianc.substring(0, 35) + "...";
                  }else{
                    jiebidian = bidianc;
                  }
                  console.log("第一家店铺", that.data.foodmap[0].shopInfo[0])
                  that.setData({
                    shopname: that.data.foodmap[0].shopInfo[0].name,
                    zhaopai: jiebidian,
                    haveding: (that.data.foodmap[0].shopInfo[0].appointment==0 ? false:true),
                    juli: that.newdistance(that.data.foodmap[0].shopInfo[0].lat, that.data.foodmap[0].shopInfo[0].lng, res.latitude, res.longitude),
                    shopimg: that.data.foodmap[0].shopInfo[0].logo,
                    shopId: that.data.foodmap[0].shopInfo[0].shopId,
                    shoparr: that.data.foodmap[0].shopInfo[0],
                  })
                  that.loadthatfoodall(function () {
                    console.log("首次进来的加载havetanshopid", that.data.havetanshopid, that.data.havetanshopid.indexOf(that.data.shopId), that.data.shopId)
                    if (that.data.havetanshopid.indexOf(that.data.shopId) != -1) {
                      that.setData({
                        havetan: true,
                      })
                    } else {
                      that.setData({
                        havetan: false,
                      })
                    }
                    that.forallfood(false);
                    console.log("首次进来的加载havetanshopid", that.data.havetan)
                  });
                } else {
                  that.setData({
                    showtwo: true,
                  })
                }
              }
            }
          })

          // if (options.cubtabline != null) {
          //   that.setData({
          //     menutab: parseInt(options.cubtabline),
          //     markers: [],
          //   })
          //   console.log("真的？ＡＤＡＳ啊", options.cubtabline)
          //   for (let i = 0; i < that.data.foodmap[options.cubtabline].shopInfo.length; i++) {
          //     wx.request({
          //       url: host + 'notify/navigation',
          //       data: {
          //         address: that.data.foodmap[options.cubtabline].shopInfo[i].instruction,
          //       },
          //       header: {
          //         'content-type': 'application/json'
          //       },
          //       method: 'get',
          //       dataType: '',
          //       success: function (res) {
          //         if (res.data.data.lat != null) {
          //           let info = { iconPath: '/pages/index3/loc.png', id: parseInt(that.data.foodmap[options.cubtabline].shopInfo[i].shopId), longitude: res.data.data.lng, latitude: res.data.data.lat, width: 30, height: 36, namesz: that.data.foodmap[options.cubtabline].shopInfo[i].name, alpha: 1, image: that.data.foodmap[options.cubtabline].shopInfo[i].logo, borderRadius: 50, shoparr: that.data.foodmap[options.cubtabline].shopInfo[i], menu: that.data.foodmap[options.cubtabline].shopInfo[i].menu};
          //           // thismarkers.push(info);
          //           that.data.markers.push(info);
          //           // console.log(info);
          //           that.setData({
          //             markers: that.data.markers,
          //           })
          //         }
          //       },
          //     });
          //   }
          // }
        }
      }
    });
    // console.log("options.cubtabline", options.cubtabline)
    //登陆！！！
    // wx.getSetting({
    //   success(res) {
    //     if (!res.authSetting['scope.userInfo']) {
    //       wx.authorize({
    //         scope: 'scope.userInfo',
    //         success() {
    //           var userinfo = wx.getStorageSync("userinfo_key")
    //             , nickName = '测试昵称'
    //             , headImgUrl = 'xxx.com'
    //             ;
    //           wx.login({
    //             success: function (res) {
    //               if (res.code) {
    //                 var code = res.code
    //                 wx.request({
    //                   url: host + 'xcx/xcxLogin',
    //                   data: {
    //                     userId: app.globalData.userId,
    //                     code: code,
    //                     nickName: nickName,
    //                     headImgUrl: headImgUrl
    //                   },
    //                   success: function (res) {
    //                     var result = res.data.data
    //                     console.log('123123123123', result)
    //                     var openId = result.openId
    //                     nickName = app.globalData.userInfo.nickName
    //                     headImgUrl = app.globalData.userInfo.avatarUrl
    //                     // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
    //                     wx.request({
    //                       url: host + 'distribution/developByXcx',
    //                       data: {
    //                         userId: app.globalData.userId,
    //                         openId: openId,
    //                         nickName: nickName,
    //                         headImgUrl: headImgUrl,
    //                         enjoyClientId: options.enjoyClientId
    //                       },
    //                       dataType: 'json',
    //                       method: 'get',
    //                       success: function (res) {
    //                         console.log('分销数据xxxxxxxxxxxxxxxxxxxx', openId);
    //                       },
    //                       fail: function (res) { }
    //                     })
    //                   },
    //                   fail: function () {

    //                   }
    //                 })
    //               } else {
    //                 console.log('登陆失败');
    //               }
    //             }
    //           })
    //         }
    //       })
    //     }
    //   }
    // })
    //登陆！！！


    // 美食地图优惠劵加入
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('原来的优惠劵！！！', res.data.data);
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].sillShow = parseInt(res.data.data[i].sillShow)
          res.data.data[i].moneyNumShow = parseInt(res.data.data[i].moneyNumShow)
        }
        that.setData({
          coulist: res.data.data,
        })
        console.log('优惠劵！！！', that.data.coulist);
        if (that.data.coulist == '') {
          console.log("优惠劵为空！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！")
        }
      },
      fail: function (res) { }
    })
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        console.log('我的优惠劵！！！', that.data.mycoulist);
      },
      fail: function (res) { }
    })
    // 美食地图优惠劵加入
  },
  setAreaData: function (p, c, d) {
    var p = p || 0 // provinceSelIndex
    var c = c || 0 // citySelIndex
    var d = d || 0 // districtSelIndex
    // 设置省的数据
    var province = area['100000']
    var provinceName = [];
    var provinceCode = [];
    for (var item in province) {
      provinceName.push(province[item])
      provinceCode.push(item)
    }
    this.setData({
      provinceName: provinceName,
      provinceCode: provinceCode
    })
    // 设置市的数据
    var city = area[provinceCode[p]]
    var cityName = [];
    var cityCode = [];
    for (var item in city) {
      cityName.push(city[item])
      cityCode.push(item)
    }
    this.setData({
      cityName: cityName,
      cityCode: cityCode
    })
    // 设置区的数据
    var district = area[cityCode[c]]
    var districtName = [];
    var districtCode = [];
    for (var item in district) {
      districtName.push(district[item])
      districtCode.push(item)
    }
    this.setData({
      districtName: districtName,
      districtCode: districtCode
    })
  },
  changeArea: function (e) {
    p = e.detail.value[0]
    c = e.detail.value[1]
    d = e.detail.value[2]
    this.setAreaData(p, c, d)
  },
  showDistpicker: function () {
    this.setData({
      showDistpicker: true
    })
  },
  distpickerCancel: function () {
    var that=this;
    that.setData({
      showDistpicker: false,
      iamhere: that.data.districtName[that.data.districtSelIndex],
    })
    
    console.log("查询中心！！！", that.data.districtName[that.data.districtSelIndex], that.data.provinceName[that.data.provinceSelIndex], that.data.cityName[that.data.citySelIndex] )
    wx.request({
      url: 'https://apis.map.qq.com/ws/district/v1/search?&keyword=' + that.data.districtName[that.data.districtSelIndex] + '&key='+that.data.miyao,
      data: {},
      header: {
        'Content-Type': 'application/json'
      },
      dataType: 'json',
      method: 'get',
      success: function (resb) {
        console.log("查询中心！！！", resb.data.result[0][0].location, resb)
        that.setData({
          userlongitude: resb.data.result[0][0].location.lng,
          userlatitude: resb.data.result[0][0].location.lat,
          mapscale:11,
        })
      },
    })
  },
  distpickerSure: function () {
    this.setData({
      provinceSelIndex: p,
      citySelIndex: c,
      districtSelIndex: d,

    })
    this.distpickerCancel()
    console.log(this.data.districtName[this.data.districtSelIndex])
  },
  clickmenu:function(e){
    // console.log(e);
    var that=this;

    // var thismarkers=[];
    that.setData({
      markers: [],
      beiyongmarkers:[],
      menutab: e.target.dataset.index,
    })
    console.log("哎呀",e.target.dataset.index)
    that.forthemarkers(e.target.dataset.index);
    // setTimeout(function () { console.log(that.data.markers)},1000)
    // that.setData({
    //   menutab: e.target.dataset.index,
    //   markers: thismarkers,
    // })
  },
  sortNumber: function (property){
    return function (a, b) {
      let value1 = a[property];
      let value2 = b[property];
      return value1 - value2;
    }
  },
  sortNumber2: function (property) {
    return function (a, b) {
      let value1 = a[property];
      let value2 = b[property];
      return value2 - value1;
    }
  },
  forallfood: function (isbei){
    var that=this;
    var linezu=[];
    that.data.markers = [];
    // console.log("第一次加载！", that.data.foodmap, that.data.zfoodmap)
    if (isbei){
      console.log('zfoodmap',that.data.zfoodmap);
      for (let j = 0; j < that.data.zfoodmap.length; j++) {
        for (let i = 0; i < that.data.zfoodmap[j].shopInfo.length; i++) {
          
          if (that.data.optionsIsType == 1) {
            if (that.data.zfoodmap[j].shopInfo[i].recommend == 1) {
              let forlng2 = that.data.zfoodmap[j].shopInfo[i].lng;
              let forlat2 = that.data.zfoodmap[j].shopInfo[i].lat;
              
              let mustOrder = '';

              if (that.data.zfoodmap[j].shopInfo[i].newMenu) {
                for (let k = 0, lenk = that.data.zfoodmap[j].shopInfo[i].newMenu.length; k < lenk; k++ ) {
                  mustOrder += that.data.zfoodmap[j].shopInfo[i].newMenu[k].name + ','
                }
              }
              console.log('22222', mustOrder);
              let info = {
                iconPath: '/imgs/loc.png',
                id: parseInt(that.data.zfoodmap[j].shopInfo[i].shopId),
                longitude: forlng2,
                latitude: forlat2,
                width: 30,
                height: 36,
                alpha: 1,
                image: that.data.zfoodmap[j].shopInfo[i].logo,
                borderRadius: 50,
                shoparr: that.data.zfoodmap[j].shopInfo[i],
                menu: mustOrder,
                juli: that.newdistance(forlat2, forlng2, that.data.userlatitude, that.data.userlongitude),
                havetan: (that.data.havetanshopid.indexOf(that.data.zfoodmap[j].shopInfo[i].shopId) == -1 ? false : true),
                lineidx: j,
                shopidx: i,
                smenu: mustOrder.substring(0, 35) + "...",
              };
              if (that.data.zfoodmap[j].shopInfo[i].lineIdArr.indexOf(",") != -1 && that.data.isfrist) {
                let shanarr = {
                  shoparr: that.data.zfoodmap[j].shopInfo[i],
                  shanarrs: that.data.zfoodmap[j].shopInfo[i].lineIdArr.replace(that.data.zfoodmap[j].shopInfo[i].lineId + ",", "").split(","),
                };
                linezu.push(shanarr);
              }
              if (j == that.data.zfoodmap.length - 1 && i == that.data.zfoodmap[j].shopInfo.length - 1 && that.data.isfrist) {
                for (let z = 0; z < linezu.length; z++) {
                  for (let m = 0; m < that.data.zfoodmap.length; m++) {
                    for (let s = 0; s < linezu[z].shanarrs.length; s++) {
                      if (linezu[z].shanarrs[s] == that.data.zfoodmap[m].lineId) {
                        that.data.zfoodmap[m].shopInfo.push(linezu[z].shoparr);
                        break;
                      }
                    }
                  }
                }
                that.setData({
                  isfrist: false,
                })
                console.log("只是重新弄后的！", that.data.foodmap)
              }

              that.data.markers.push(info);
              that.data.markers.sort(that.sortNumber("juli"))
            }
          } else {
            let forlng2 = that.data.zfoodmap[j].shopInfo[i].lng;
            let forlat2 = that.data.zfoodmap[j].shopInfo[i].lat;
            let mustOrder = '';

            if (that.data.zfoodmap[j].shopInfo[i].newMenu) {
              for (let k = 0, lenk = that.data.zfoodmap[j].shopInfo[i].newMenu.length; k < lenk; k++) {
                mustOrder += that.data.zfoodmap[j].shopInfo[i].newMenu[k].name + ','
              }
            }

            console.log('22222', mustOrder);
            let info = {
              iconPath: '/imgs/loc.png',
              id: parseInt(that.data.zfoodmap[j].shopInfo[i].shopId),
              longitude: forlng2,
              latitude: forlat2,
              width: 30,
              height: 36,
              alpha: 1,
              image: that.data.zfoodmap[j].shopInfo[i].logo,
              borderRadius: 50,
              shoparr: that.data.zfoodmap[j].shopInfo[i],
              menu: mustOrder,
              juli: that.newdistance(forlat2, forlng2, that.data.userlatitude, that.data.userlongitude),
              havetan: (that.data.havetanshopid.indexOf(that.data.zfoodmap[j].shopInfo[i].shopId) == -1 ? false : true),
              lineidx: j,
              shopidx: i,
              smenu: mustOrder.substring(0, 35) + "...",
            };
            if (that.data.zfoodmap[j].shopInfo[i].lineIdArr.indexOf(",") != -1 && that.data.isfrist) {
              let shanarr = {
                shoparr: that.data.zfoodmap[j].shopInfo[i],
                shanarrs: that.data.zfoodmap[j].shopInfo[i].lineIdArr.replace(that.data.zfoodmap[j].shopInfo[i].lineId + ",", "").split(","),
              };
              linezu.push(shanarr);
            }
            if (j == that.data.zfoodmap.length - 1 && i == that.data.zfoodmap[j].shopInfo.length - 1 && that.data.isfrist) {
              for (let z = 0; z < linezu.length; z++) {
                for (let m = 0; m < that.data.zfoodmap.length; m++) {
                  for (let s = 0; s < linezu[z].shanarrs.length; s++) {
                    if (linezu[z].shanarrs[s] == that.data.zfoodmap[m].lineId) {
                      that.data.zfoodmap[m].shopInfo.push(linezu[z].shoparr);
                      break;
                    }
                  }
                }
              }
              that.setData({
                isfrist: false,
              })
              console.log("只是重新弄后的！", that.data.foodmap)
            }

            that.data.markers.push(info);
            that.data.markers.sort(that.sortNumber("juli"))
          }
        }
      }
    }else{
      
      for (let j = 0; j < that.data.foodmap.length; j++) {
        for (let i = 0; i < that.data.foodmap[j].shopInfo.length; i++) {

          if (that.data.optionsIsType == 1) {

            if (that.data.foodmap[j].shopInfo[i].recommend == 1) {
              let forlng2 = that.data.foodmap[j].shopInfo[i].lng;
              let forlat2 = that.data.foodmap[j].shopInfo[i].lat;
              let mustOrder = '';
              
              if (that.data.foodmap[j].shopInfo[i].newMenu) {
                for (let k = 0, lenk = that.data.foodmap[j].shopInfo[i].newMenu.length; k < lenk; k++) {
                  mustOrder += that.data.foodmap[j].shopInfo[i].newMenu[k].name + ','
                }
              }
             

              console.log('22222', mustOrder);
              let info = {
                iconPath: '/imgs/loc.png',
                id: parseInt(that.data.foodmap[j].shopInfo[i].shopId),
                longitude: forlng2,
                latitude: forlat2,
                width: 30,
                height: 36,
                alpha: 1,
                image: that.data.foodmap[j].shopInfo[i].logo,
                borderRadius: 50,
                shoparr: that.data.foodmap[j].shopInfo[i],
                menu: mustOrder,
                juli: that.newdistance(forlat2, forlng2, that.data.userlatitude, that.data.userlongitude),
                havetan: (that.data.havetanshopid.indexOf(that.data.foodmap[j].shopInfo[i].shopId) == -1 ? false : true),
                lineidx: j,
                shopidx: i,
                smenu: mustOrder.substring(0, 35) + "...",
              };
              if (that.data.foodmap[j].shopInfo[i].lineIdArr.indexOf(",") != -1 && that.data.isfrist) {
                let shanarr = {
                  shoparr: that.data.foodmap[j].shopInfo[i],
                  shanarrs: that.data.foodmap[j].shopInfo[i].lineIdArr.replace(that.data.foodmap[j].shopInfo[i].lineId + ",", "").split(","),
                };
                linezu.push(shanarr);
              }
              if (j == that.data.foodmap.length - 1 && i == that.data.foodmap[j].shopInfo.length - 1 && that.data.isfrist) {
                for (let z = 0; z < linezu.length; z++) {
                  for (let m = 0; m < that.data.foodmap.length; m++) {
                    for (let s = 0; s < linezu[z].shanarrs.length; s++) {
                      if (linezu[z].shanarrs[s] == that.data.foodmap[m].lineId) {
                        that.data.foodmap[m].shopInfo.push(linezu[z].shoparr);
                        break;
                      }
                    }
                  }
                }
                that.setData({
                  isfrist: false,
                })
                console.log("只是重新弄后的！", that.data.foodmap)
              }
              that.data.markers.push(info);
              that.data.markers.sort(that.sortNumber("juli"));
            }
          } else {
            let forlng2 = that.data.foodmap[j].shopInfo[i].lng;
            let forlat2 = that.data.foodmap[j].shopInfo[i].lat;
            let mustOrder = '';
            if (that.data.foodmap[j].shopInfo[i].newMenu) {
              for (let k = 0, lenk = that.data.foodmap[j].shopInfo[i].newMenu.length; k < lenk; k++) {
                mustOrder += that.data.foodmap[j].shopInfo[i].newMenu[k].name + ','
              }
            }

            console.log('22222', mustOrder);
            let info = {
              iconPath: '/imgs/loc.png',
              id: parseInt(that.data.foodmap[j].shopInfo[i].shopId),
              longitude: forlng2,
              latitude: forlat2,
              width: 30,
              height: 36,
              alpha: 1,
              image: that.data.foodmap[j].shopInfo[i].logo,
              borderRadius: 50,
              shoparr: that.data.foodmap[j].shopInfo[i],
              menu: mustOrder,
              juli: that.newdistance(forlat2, forlng2, that.data.userlatitude, that.data.userlongitude),
              havetan: (that.data.havetanshopid.indexOf(that.data.foodmap[j].shopInfo[i].shopId) == -1 ? false : true),
              lineidx: j,
              shopidx: i,
              smenu: mustOrder.substring(0, 35) + "...",
            };
            if (that.data.foodmap[j].shopInfo[i].lineIdArr.indexOf(",") != -1 && that.data.isfrist) {
              let shanarr = {
                shoparr: that.data.foodmap[j].shopInfo[i],
                shanarrs: that.data.foodmap[j].shopInfo[i].lineIdArr.replace(that.data.foodmap[j].shopInfo[i].lineId + ",", "").split(","),
              };
              linezu.push(shanarr);
            }
            if (j == that.data.foodmap.length - 1 && i == that.data.foodmap[j].shopInfo.length - 1 && that.data.isfrist) {
              for (let z = 0; z < linezu.length; z++) {
                for (let m = 0; m < that.data.foodmap.length; m++) {
                  for (let s = 0; s < linezu[z].shanarrs.length; s++) {
                    if (linezu[z].shanarrs[s] == that.data.foodmap[m].lineId) {
                      that.data.foodmap[m].shopInfo.push(linezu[z].shoparr);
                      break;
                    }
                  }
                }
              }
              that.setData({
                isfrist: false,
              })
              console.log("只是重新弄后的！", that.data.foodmap)
            }
            that.data.markers.push(info);
            that.data.markers.sort(that.sortNumber("juli"));
          }

        }
      }
    }
    that.setData({
      markers: that.data.markers,
      beiyongmarkers: that.data.markers,
    })
    // console.log("zzzz2", that.data.markers)
    // that.data.foodmap[0].shopInfo.push(ssss)
    // console.log(that.data.foodmap)
  },
  foralinefood: function (index){
    var that=this;
    that.setData({
      markers: [],
    })
    if (that.data.foodmap[index].shopInfo.length != 0) {
      let jiebidian;
      if (that.data.foodmap[index].shopInfo[0].menu.length>35){
        jiebidian=that.data.foodmap[index].shopInfo[0].menu.substring(0, 35) + "...";
      }else{
        jiebidian = that.data.foodmap[index].shopInfo[0].menu;
      }
      that.setData({
        shopname: that.data.foodmap[index].shopInfo[0].name,
        zhaopai: jiebidian,
        haveding: (that.data.foodmap[index].shopInfo[0].username == '' ? false : true),
        juli: that.newdistance(that.data.foodmap[index].shopInfo[0].lat, that.data.foodmap[index].shopInfo[0].lng, that.data.beiuserlatitude, that.data.beiuserlongitude),
        shopimg: that.data.foodmap[index].shopInfo[0].logo,
        shopId: that.data.foodmap[index].shopInfo[0].shopId,
        shoparr: that.data.foodmap[index].shopInfo[0],
        shoparrlineidx: index,
        shoparrshopidx: 0,
        showtwo: false,
      })
    } else {
      that.setData({
        showtwo: true,
      })
    }
    for (let i = 0; i < that.data.foodmap[index].shopInfo.length; i++) {

      if (that.data.optionsIsType == 1) {

        if (that.data.foodmap[index].shopInfo[i].recommend == 1) {
          let forlng = that.data.foodmap[index].shopInfo[i].lng;
          let forlat = that.data.foodmap[index].shopInfo[i].lat;

          let mustOrder = '';
          if (that.data.foodmap[index].shopInfo[i].newMenu) {
            for (let k = 0, lenk = that.data.foodmap[index].shopInfo[i].newMenu.length; k < lenk; k++) {
              mustOrder += that.data.foodmap[index].shopInfo[i].newMenu[k].name + ','
            }
          }

          console.log('22222', mustOrder);

          let info = {
            iconPath: '/imgs/loc.png',
            id: parseInt(that.data.foodmap[index].shopInfo[i].shopId),
            longitude: forlng,
            latitude: forlat,
            width: 30,
            height: 36,
            alpha: 1,
            image: that.data.foodmap[index].shopInfo[i].logo,
            borderRadius: 50,
            shoparr: that.data.foodmap[index].shopInfo[i],
            menu: mustOrder,
            juli: that.newdistance(forlat, forlng, that.data.userlatitude, that.data.userlongitude),
            havetan: (that.data.havetanshopid.indexOf(that.data.foodmap[index].shopInfo[i].shopId) == -1 ? false : true),
            lineidx: index, 
            shopidx: i,
            smenu: mustOrder.substring(0, 35) + "...",
          };
          that.data.markers.push(info);
          that.data.markers.sort(that.sortNumber("juli"))
        }

      } else {
        let forlng = that.data.foodmap[index].shopInfo[i].lng;
        let forlat = that.data.foodmap[index].shopInfo[i].lat;

        let mustOrder = '';
        if (that.data.foodmap[index].shopInfo[i].newMenu) {
          for (let k = 0, lenk = that.data.foodmap[index].shopInfo[i].newMenu.length; k < lenk; k++) {
            mustOrder += that.data.foodmap[index].shopInfo[i].newMenu[k].name + ','
          }
        }

        let info = {
          iconPath: '/imgs/loc.png',
          id: parseInt(that.data.foodmap[index].shopInfo[i].shopId),
          longitude: forlng,
          latitude: forlat,
          width: 30,
          height: 36,
          alpha: 1,
          image: that.data.foodmap[index].shopInfo[i].logo,
          borderRadius: 50,
          shoparr: that.data.foodmap[index].shopInfo[i],
          menu: mustOrder,
          juli: that.newdistance(forlat, forlng, that.data.userlatitude, that.data.userlongitude),
          havetan: (that.data.havetanshopid.indexOf(that.data.foodmap[index].shopInfo[i].shopId) == -1 ? false : true),
          lineidx: index, 
          shopidx: i, 
          smenu: mustOrder.substring(0, 35) + "...",
        };
        that.data.markers.push(info);
        that.data.markers.sort(that.sortNumber("juli"))
      }
    }
    that.setData({
      markers: that.data.markers,
      beiyongmarkers: that.data.markers,
    })
    console.log("这是点击线路后的markers", that.data.markers)
  },
  forthemarkers:function(index){
    var that=this;
    that.setData({
      markers: [],
    })
    console.log("点击了线路后打印id！!", parseInt(index))
    if(index!=-1){
      that.foralinefood(index);
    }else{
      that.forallfood(true);
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.mapCtx = wx.createMapContext('foodmap');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },
  
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})