// pages/order/order.js
var testhost = "https://menu.honqb.com";
var app = getApp();
var host = "https://menu.honqb.com/";
var menuhost ="https://menu.honqb.com";
Page({
  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    testhost: testhost,
    choosecb:-1,
    startdata:0,
    starttime:0,
    chosedata: 0,
    chosetime: 0,
    enddata:0,
    showmodal:false,
    meishilist:[],
    num:'',
    pople: '',
    phone: '',
    remark: '',
    shopcommodityId:0,
    shopId: 0,
    nofood: false,
    wenxintishi:'',
    tothedetail:false,
    isqinga:true,
    interviteId:0,
    shopaddress:'',
    shopname:'',
    xiajia:false,
    lineidx:0,
    shopidx:0,
    choosewei:'',
    multiArray: [['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24'], ['00', '30']],
    multiIndex: [1, 0],
  },
  bindPickerChange: function (e) {
    // console.log('picker发送选择改变1，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },
  bindMultiPickerChange: function (e) {
    var that=this;
    // console.log('picker发送选择改变2，携带值为', e.detail.value)
    // { { multiArray[0][multiIndex[0]] } }:{ { multiArray[1][multiIndex[1]] } }
    let multiIndex = e.detail.value;
    that.setData({
      chosetime: that.data.multiArray[0][multiIndex[0]] + ":" + that.data.multiArray[1][multiIndex[1]],
      multiIndex: e.detail.value,
    })
    if (that.contrasttime(that.data.chosedata + ' ' + that.data.multiArray[0][multiIndex[0]] + ":" + that.data.multiArray[1][multiIndex[1]] + ":00") < 7200) {
      wx.showModal({
        title: '温馨提示',
        content: '选择的时间必须在当前时间的2小时后',
        success: function (res) {}
      })
      return;
    }else{
      that.setData({
        chosetime: that.data.multiArray[0][multiIndex[0]] + ":" + that.data.multiArray[1][multiIndex[1]],
        multiIndex: e.detail.value,
      })
    }
    console.log(that.data.chosetime);
  },
  choosewei:function(e){
    // console.log(e.target.dataset.on);
    if (e.target.dataset.on != undefined && e.target.dataset.on != -1){
      this.setData({
        choosewei: e.target.dataset.on,
      })
    }
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带formId数据为：', e.detail.formId);
    var formId = e.detail.formId;
    var userinfo = wx.getStorageSync("userinfo_key");
    
    wx.request({
      url: host + 'xcx/markFormId',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        formId: formId,
      },
      success: function (res) {
        console.log(res);
      }
    })
  },
  totreatDetail:function(e){
    var that=this;
    console.log("我要去哪儿？", that.data.tothedetail);
    if (that.data.tothedetail){
      console.log("去详情的");
      if (that.data.interviteId == 0) {
        console.log("interviteId")
        return;
      } else {
        console.log("我没传过去吗？", that.data.shopcommodityId, that.data.interviteId)
        wx.redirectTo({
          url: '../treatDetail/treatDetail?shopId=' + that.data.shopId + '&interviteId=' + that.data.interviteId + '&name=' + that.data.shopname + '&shopCommodityId=' + that.data.shopcommodityId + '&address=' + that.data.shopaddress,
        })
      }
    }else{
      console.log("去流程的");
      wx.redirectTo({
        url: '../subscribe/subscribe?shopId=' + that.data.shopId + '&appointmentid=' + that.data.appointmentid,
      })
    }
  },
  num:function(e){
    // console.log(e.detail.value);
    this.setData({
      num: e.detail.value,
    })
  },
  pople: function (e) {
    // console.log(e.detail.value)
    this.setData({
      pople: e.detail.value,
    })
  },
  phone: function (e) {
    this.setData({
      phone: e.detail.value,
    })
  },
  remark: function (e) {
    this.setData({
      remark: e.detail.value,
    })
  },
  checkboxclick:function(e){
    var that=this;
    if (that.data.choosecb == e.currentTarget.dataset.idx){
      that.setData({
        choosecb: -1,
        shopcommodityId:0,
      })
    }else{
      that.setData({
        choosecb: e.currentTarget.dataset.idx,
        shopcommodityId: parseInt(e.currentTarget.dataset.shopcommodityid),
      })
    }
    console.log(e.currentTarget.dataset.idx, that.data.shopcommodityId, e.currentTarget.dataset)
  },
  sendyuyue:function(afun){
    var that=this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: testhost + '/appointment/apply',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
        data: {
          name: that.data.pople,
          phone: that.data.phone,
          menu: that.data.foodId,
          num: that.data.num,
          dinnerTime: that.data.chosedata + " " + that.data.chosetime,
          shopId: that.data.shopId,
          remark: that.data.remark,
          positionNeed: (that.data.choosewei == 0 ? '位置不限' : (that.data.choosewei == 1 ? '尽量包间' : '必须包间')),
        }
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          that.setData({
            showmodal: false,
          })
          wx.showModal({
            title: res.data.msg,
            content: '',
          })
          console.log("预约的出错！", res)
          return;
        } else {
          console.log("预约的提交成功！",res)
          that.setData({
            appointmentid:res.data.data,
          })
          return afun();
        }
      },
    })
  },
  tonewtreatdetail: function (e) {
    var that = this;
    if (that.contrasttime(that.data.chosedata + ' ' + that.data.chosetime + ":00") < 7200) {
      wx.showModal({
        title: '温馨提示',
        content: '选择的时间必须在当前时间的2小时后',
        success: function (res) { }
      })
      return;
    } else if (that.data.num==''){
      wx.showModal({
        title: '温馨提示',
        content: '请填写用餐人数',
        success: function (res) { }
      })
      return;
    }
    // 有没有请客菜的判断
    if (that.data.meishilist!=0){
      console.log("有请客菜的")
      if (that.data.choosecb != -1) {
        that.sendintervite(function(){
          if (!that.data.xiajia){
            that.sendyuyue(function () {
              that.setData({
                nofood: true,
                showmodal: true,
                tothedetail: true,
                wenxintishi: '亲~，您的订座信息已经提交商家，在个人中心可以查看我的预约，邀请好友一起用餐吧，祝您用餐愉快！',
              })
            })
          }
        });
      } else {
        that.setData({
          showmodal: true,
          wenxintishi: '亲~，您没有选择特惠菜式哦！',
        })
      }
    }else{
      console.log("没有有请客菜的")
      that.sendyuyue(function(){
        that.setData({
          nofood: true,
          showmodal: true,
          wenxintishi: '亲~，您的订座信息已经提交商家，在个人中心可以查看我的预约，祝您用餐愉快！',
        })
      })
    }
    // wx.navigateTo({
    //   url: '../treatDetail/treatDetail',
    // })
  },
  noneedfood:function(e){
    var that = this;
    that.sendyuyue(function(){
      wx.redirectTo({
        url: '../subscribe/subscribe?shopId=' + that.data.shopId + '&appointmentid=' + that.data.appointmentid, 
      })
    });
  },
  needfood: function (e) {
    var that = this;
    that.setData({
      showmodal: false,
    })
  },
  bindDateChange:function(e){
    console.log(e.detail.value)
    if (this.contrasttime(e.detail.value + ' ' + this.data.chosetime + ":00") < 7200) {
      wx.showModal({
        title: '温馨提示',
        content: '选择的时间必须在当前时间的2小时后',
        success: function (res) { }
      })
    }else{
      this.setData({
        chosedata: e.detail.value,
      })
    }
  },
  bindTimeChange: function (e) {
    console.log(e.detail.value, this.contrasttime(this.data.chosedata + ' ' + e.detail.value + ":00"))
    if (this.contrasttime(this.data.chosedata + ' ' + e.detail.value + ":00") < 7200) {
      wx.showModal({
        title: '温馨提示',
        content: '选择的时间必须在当前时间的2小时后',
        success: function (res) {}
      })
    }else{
      this.setData({
        chosetime: e.detail.value,
      })
    }
  },
  contrasttime: function (picktime) {
    let nowDate = new Date();
    let yue;
    let ri;
    if (nowDate.getMonth() + 1 < 10) {
      yue = "0" + String(nowDate.getMonth() + 1);
    } else {
      yue = (nowDate.getMonth() + 1);
    }
    if (nowDate.getDate() + 1 < 10) {
      ri = "0" + nowDate.getDate();
    } else {
      ri = nowDate.getDate();
    }
    let nowdata = nowDate.getFullYear() + '-' + yue + '-' + ri + ' ' + this.addmun(nowDate.getHours()) + ":" + this.addmun(nowDate.getMinutes()) + ":" + this.addmun(nowDate.getSeconds());
    let choosedata = picktime;
    let nowdatas = nowdata.substring(0, 10).split('-');
    let choosedatas = choosedata.substring(0, 10).split('-');
    nowdata = nowdatas[1] + '-' + nowdatas[2] + '-' + nowdatas[0] + ' ' + nowdata.substring(10, 19);
    choosedata = choosedatas[1] + '-' + choosedatas[2] + '-' + choosedatas[0] + ' ' + choosedata.substring(10, 19);
    let a = (Date.parse(choosedata) - Date.parse(nowdata));
    return a / 1000;
  },
  addmun: function (time) {
    if (time.toString().length < 2) {
      return '0' + time;
    } else {
      return time;
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  // 10079
  onLoad: function (options) {
    var that=this;
    var newdata=new Date();  
    wx.setNavigationBarTitle({
      title: options.name,
    })

    that.setData({
      shopname: options.name,
      shopaddress: options.address,
      shopId: options.shopId,
      lineidx: options.lineidx,
      shopidx: options.shopidx,
    })
    console.log("shop2传过来的options", options)

    console.log("进来后的options.shopId", options.shopId, that.data.shopId)
    // wx.request({
    //   url: testhost + '/gourmetfood/getAll',
    //   data: {
    //     userId: app.globalData.userId,
    //   },
    //   dataType: 'json',
    //   method: 'get',
    //   success: function (res) {
    //     if (res.data.code != 0) {
    //       wx.showModal({
    //         title: '提示',
    //         content: res.data.msg,
    //       })
    //     } else {
    //       let meishilist = [];
    //       for (let i = 0; i < res.data.data.length; i++) {
    //         if (that.data.shopId == res.data.data[i].shopId) {
    //           meishilist.push(res.data.data[i])
    //         }
    //       }
    //       that.setData({
    //         meishilist: meishilist,
    //       })
    //       console.log("米兔", that.data.meishilist);
    //     }
    //   },
    // })
    wx.request({
      url: menuhost+'/intervitecommodity/getMenu',
      // url: testhost+'/intervitecommodity/getMenu',
      data: {
        shopId: options.shopId,
      },
      dataType: 'json',
      method: 'get',
      success:function(res){
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
        }else{
          for (let a = 0; a < res.data.data.length;a++){
            res.data.data[a].sales = parseInt(res.data.data[a].price / res.data.data[a].oldPrice * 10)
          }
          that.setData({
            meishilist: res.data.data,
          })
          console.log("请客菜的", that.data.meishilist)
        }
      },
    })
    // let nowyue=()
    // console.log("当天月份天数", that.getCountDays());
    let nowdaynum = that.getCountDays();
    let endmonth;
    let endday;
    if (that.getCountDays() - newdata.getMonth() + 1 < 7) {
      endmonth = that.addmun(newdata.getMonth() + 2);
      endday = '0' + (7 - nowdaynum - newdata.getDate());
      console.log("if", endmonth + endday)
    }else{
      endmonth = that.addmun(newdata.getMonth() + 1);
      endday = that.addmun(newdata.getDate()+7);
      console.log("else", endmonth + endday)
    }
    that.setData({
      startdata: newdata.getFullYear() + "-" + that.addmun(newdata.getMonth() + 1) + "-" + that.addmun(newdata.getDate()),
      chosedata: newdata.getFullYear() + "-" + that.addmun(newdata.getMonth() + 1) + "-" + that.addmun(newdata.getDate()),
      multiIndex: [newdata.getHours()-1, (newdata.getMinutes()>30 ? 0 : 1)],
      enddata: newdata.getFullYear() + "-" + endmonth + "-" + endday,
      starttime: that.addmun(newdata.getHours()) + ":" + that.addmun(newdata.getMinutes()),
      chosetime: that.addmun(newdata.getHours()) + ":" + that.addmun(newdata.getMinutes()),
    });
  },
  getCountDays:function(e){
    var curDate = new Date();
    /* 获取当前月份 */
    var curMonth = curDate.getMonth();
    /*  生成实际的月份: 由于curMonth会比实际月份小1, 故需加1 */
    
    console.log(curDate)
    curDate.setMonth(curMonth + 1);
    // curDate.setMonth(curMonth + 2);
    console.log(curDate.getMonth())

    /* 将日期设置为0, 这里为什么要这样设置, 我不知道原因, 这是从网上学来的 */
    curDate.setDate(0);
    /* 返回当月的天数 */

    return curDate.getDate();
  },
  //发送邀请！
  sendintervite: function (afun) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    // console.log(that.data.shopcommodityId, userinfo.openid, userinfo.nickName, userinfo.avatarUrl, that.data.startdata + " " + that.data.starttime, userinfo.clientId);
    if (that.data.isqinga) {
      // console.log()
      wx.request({
        url: menuhost + '/intervite/initIntervite',
        data: {
          userId: app.globalData.userId,
          shopCommodityId: that.data.shopcommodityId,
          dinnerTime: that.data.chosedata + " " + that.data.chosetime,
          remark: that.data.remark,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          shopId: that.data.shopId,
        },
        method: 'get',
        success: function (res) {
          console.log("A版请求后的返回interviteId", res.data.data);
          if (res.data.code == 1) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
            that.setData({
              xiajia:true,
            })
            return;
          } else {
            console.log("请客的！！",res)
            that.setData({
              interviteId: res.data.data,
            })
            return afun();
          }
        }
      })
    } else {
      wx.request({
        url: testhost + '/intervite/initIntervite',
        data: {
          userId: app.globalData.userId,
          shopCommodityId: that.data.shopCommodityId,
          remark: that.data.remarkb,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
        },
        method: 'get',
        success: function (res) {
          console.log("b版请求后的返回intervitedid", res);
          if (res.data.code == 1) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
            that.setData({
              makesure: false,
            })
            return;
          } else {
            that.setData({
              interviteId: res.data.data,
              isfirst: 0,
            })
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})