// components/countdown.js
/**
 * 倒计时组件
 */
function GetRandomNum(Min, Max) {
  var Range = Max - Min;
  var Rand = Math.random();
  return (Min + Math.round(Rand * Range));
}
let times = null,
    secStr = 0,
    sec = 0,
    msStr = 0,
    ms = 0,
    mg = 0;
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    durationInit: {
      type: Number,
      value: 0,
      observer: function (newVal) {  //监控duration初始值变动(看有没有外部传入新的时间)
        console.log('newVal',newVal);

        if (newVal == 1) {
          this.timest()
        } else if (newVal == 0 ) {
          this.clearInterval();
        } else if (newVal == 2 ) {
          this.setData({
            isGameType: false
          });
        } else if (newVal == 3) {
          this.setData({
            isGameType: true
          })
        }
      }
    },
    isBtns:{
      type: Number,
      value: 0,
      observer: function(newval) {
        this.setData({
          isBtns: newval
        })
      }
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    isBtns:0,
    secStr_s: 0,
    secStr_g: 0,
    msStr_s: 0,
    msStr_g: 0,
    msStr_gg: 0,
    isGameType: true,
  },
  intervalId: null, //计时器Id,不需要渲染，放外面，免得影响性能
  ready: function () {
    
  },
  /**
   * 组件销毁了要清除计时
   */
  detached() {
    clearInterval(times);
  },

  /**
   * 组件的方法列表
   */
  methods: {
    clearInterval: function() {
      clearInterval(times);
    },
    onTap: function() {
      var that = this;

      var num = GetRandomNum(1, 9);
      console.log('随机数', num)

      this.setData({
        msStr_gg: num
      });

      var myEventDetail = {
        secStr_s: that.data.secStr_s,
        secStr_g: that.data.secStr_g,
        msStr_s: that.data.msStr_s,
        msStr_g: that.data.msStr_g,
        msStr_gg: that.data.msStr_gg
      } // detail对象，提供给事件监听函数
      var myEventOption = {} // 触发事件的选项
      this.triggerEvent('myevent', myEventDetail, myEventOption)
    },
    timest: function() {
      let that = this;
      secStr = 0;
      sec = 0;
      msStr = 0;
      ms = 0;
      mg = 0;
      times = null;

      times = setInterval(function () {
        ms++;
        mg++;
        if (mg == 9) {
          mg = 0;
        }

        if (ms == 10) {
          msStr++;
          ms = 0;
        }
        if (msStr == 10) {
          sec++;
          msStr = 0;
        }

        if (sec == 10) {
          secStr++;
          sec = 0;
        }

        that.setData({
          secStr_s: secStr,
          secStr_g: sec,
          msStr_s: msStr,
          msStr_g: ms,
          msStr_gg: mg
        });
      }, 10);
    }
  }
})