const formatTime = date => {
  const year = date.getFullYear()
  const month = date.getMonth() + 1
  const day = date.getDate()
  const hour = date.getHours()
  const minute = date.getMinutes()
  const second = date.getSeconds()

  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

// 检测登陆
function login(data, next) {
  console.log("e", data)
  if (data.detail.userInfo) {
    console.log("允许")
    var userinfo = wx.getStorageSync("userinfo_key");
    userinfo.nickName = data.detail.userInfo.nickName;
    userinfo.avatarUrl = data.detail.userInfo.avatarUrl;
    console.log("userinfo", userinfo);
    wx.setStorageSync("userinfo_key", userinfo);
    next();
  } else {
    console.log("拒绝")
    return false;
  }
}

function getOpenId(host, userId, next) {
  // 获取
  wx.login({
    success: res => {
      var code = res.code;
      if (code) {
        wx.request({
          url: host + 'clientlogin/newLogin',
          data: { code: code, userId: userId },
          method: 'get',
          header: {
            'content-type': 'application/json'
          },
          success: function (res) {
            var data = wx.getStorageSync("userinfo_key")
            console.log("wx.getStorageSync", data)
            if (!data.nickName || data.nickName == "") {
              var userinfo = {
                "openid": res.data.data.openId,
                "clientId": res.data.data.clientId,
                "nickName": '',
                "avatarUrl": ''
              }
              console.log("res", res.data.data, userinfo, userinfo.openid)
              next();
            }
          },
        })
      } else {
        console.log('获取用户登录失败：' + res.errMsg);
      }
    }
  })
}

module.exports = {
  formatTime: formatTime,
  login: login,
  getOpenId: getOpenId,
}
