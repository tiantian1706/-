
var app = getApp()


var config = {
    appid:"",

    host: app.globalData.host
}

module.exports = config
