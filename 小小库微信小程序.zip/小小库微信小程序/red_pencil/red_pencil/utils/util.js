function formatTime(date) {
  var year = date.getFullYear()
  var month = date.getMonth() + 1
  var day = date.getDate()

  var hour = date.getHours()
  var minute = date.getMinutes()
  var second = date.getSeconds()


  return [year, month, day].map(formatNumber).join('/') + ' ' + [hour, minute, second].map(formatNumber).join(':')
}

function formatNumber(n) {
  n = n.toString()
  return n[1] ? n : '0' + n
}

// 检测登陆
function login(data, next) {
  console.log("e", data)
  if (data.detail.userInfo) {
    console.log("允许")
    var userinfo = wx.getStorageSync("userinfo_key");
    userinfo.nickName = data.detail.userInfo.nickName;
    userinfo.avatarUrl = data.detail.userInfo.avatarUrl;
    console.log("userinfo", userinfo);
    wx.setStorageSync("userinfo_key", userinfo);
    next();
  } else {
    console.log("拒绝")
    return false;
  }
}

function getOpenId(host, userId, next) {
  // 获取
  setTimeout(function(){
    wx.login({
      success: res => {
        var code = res.code;
        if (code) {
          wx.request({
            url: host + 'clientlogin/newLogin',
            data: { code: code, userId: userId },
            method: 'get',
            header: {
              'content-type': 'application/json'
            },
            success: function (res) {
              var data = wx.getStorageSync("userinfo_key")
              console.log("wx.getStorageSync", data)
              if (!data.nickName || data.nickName == "") {
                var userinfo = {
                  "openid": res.data.data.openId,
                  "clientId": res.data.data.clientId,
                  "nickName": '',
                  "avatarUrl": ''
                }
                console.log("res", res.data.data, userinfo, userinfo.openid)
                wx.setStorageSync("userinfo_key", userinfo);
                next();
              }
            },
          })
        } else {
          console.log('获取用户登录失败：' + res.errMsg);
        }
      }
    })
  }, 500)
}

// 建立分销
function getDistribution(host, userid, openid, storeid) {
  wx.request({
    url: host + 'store/develop',
    data: {
      userId: userid,
      openId: openid,
      nickName: "",
      headImgUrl: "",
      storeId: storeid,
    },
    dataType: 'json',
    method: 'get',
    success: function (res) {
      console.log("门店登陆扫码转发进来", res)      
    },
    fail: function (res) { }
  })
}

module.exports = {
  formatTime: formatTime,
  login: login,
  getOpenId: getOpenId,
  getDistribution: getDistribution,
}
