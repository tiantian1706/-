// pages/waitsend/waitsend.js

var app = getApp()
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,

    //进行中产品
    exchangeing: [
      {
        imgsrc: "../../imgs/24.png",
        title: "SUPOR/苏泊尔 CFXB40FC8155-75智能电饭煲正品电饭锅3人-4人家用",
        price: "96.00",
        num: "5",
        dates: "2017-08-06",
      }
    ],
    //收货人
    daipay: [
      {
        imgsrc: "../../imgs/68.png",
        name: "小福君",
        numbs: "556955363636",
        nums: "3",
        tele: "1880008888",
        address: "广东省广州市天河区幸福路290号搜索幸福小区23栋340室",
        send: "1",
      }
    ],
    // 添加确定收货人好友
    daiwait: [
      {
        imgsrc: "../../imgs/67.png",
        name: "侠诗君s",
        numbs: "556954485555",
        nums: "2",
        tele: "13300001188",
        address: "广东省广州市天河区幸福路290号搜索幸福小区23栋340室",
        send: "1",
      }
    ],
    host: app.globalData.host,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})
