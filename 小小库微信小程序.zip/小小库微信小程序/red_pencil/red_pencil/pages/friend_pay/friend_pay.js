// pages/waitsend/waitsend.js
var util = require('../../utils/util.js')
var app = getApp();
var shopCommodityId = ""
var host = app.globalData.host;

var current_commodity_tag = []
var current_guige = [];
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    sales:1,

    //进行中产品
    product_list: {},
    tagInfo: [],

    orderId:"",
    isShow:true,
    showLoading: true,
  },

  changeNumberJia: function (e) {
    var that = this;


    var sales = that.data.sales;

    if(sales <= 1){
      return
    }

    that.setData({
      sales: --sales
    })

  },

  changeNumberJian: function (e) {
    var that = this;

    var sales = that.data.sales;
    that.setData({
      sales: ++sales
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    shopCommodityId = opt.shopCommodityId
    var that = this;

    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    console.log(opt.shopCommodityId);
    that.loadData(opt.shopCommodityId, function (result) {
      console.log("商品", result);
      that.setData({
        product_list: result.data.data.commodity,
        tagInfo: result.data.data.tagInfo
      }, function(){
        that.setData({
          showLoading: false
        }, function () {
          wx.hideLoading();
        })
      })


      for (var i = 0; i < that.data.tagInfo.length; i++) {
        var selected = that.data.tagInfo[i].selected;

        current_commodity_tag.push(selected[0])

      }

      


    })
  },
  guige_choose: function (e) {
    console.log("子类索引 ", e.currentTarget.id)
    console.log("父类索引", e.currentTarget.dataset.fatherindex)
    var that = this;

    var temp1 = e.currentTarget.dataset.fatherindex;
    var temp2 = e.currentTarget.id;
    var a = current_commodity_tag;
    a[temp1] = that.data.tagInfo[temp1].selected[temp2];
    current_commodity_tag = a
    console.log(a);
    current_guige[temp1] = temp2;
    that.setData({
      guige: current_guige
    })
  },

  find_friend_pay: function(){
    console.log("开始下单")

    this.setData({
      isShow:false
    })

    this.createOrder()
  },

//下单
  createOrder: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")

    var tag_array = []
    for (var i = 0; i < current_commodity_tag.length; i++) {
      var item = current_commodity_tag[i].shopCommoditySpecTabTagId;
      tag_array.push(item)
    }
    var tag = tag_array.join(",")

    console.log("商品规格",tag)

    console.log("购买商品的数量",that.data.sales)

    wx.request({
      url: host+'order/createXcxOrder',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        shopCommodityId: shopCommodityId,
        quantity: that.data.sales,
        tag: tag

      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        var order_id = res.data.data

        that.setData({
          orderId:order_id
        })
      }
    })
  },

  loadData: function (condition, cb) {
    wx.request({
      url: host + 'commodity/get',
      data: {
        userId: app.globalData.userId,
        shopCommodityId: condition
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {

    console.log("商品数量",this.data.sales)

    var that = this;
    var nickName = wx.getStorageSync("userinfo_key").nickName;

    var totalMoney = this.data.product_list.priceShow * this.data.sales

    return {
      title: '孤单的七夕 求真爱路过',
      path: 'pages/help_pay/help_pay?nickName=' + nickName + "&orderId="+this.data.orderId,
      success: function (res) {
        // 转发成功
        wx.showModal({
          title: '提示',
          content: '转发朋友成功',
          success: function (res) {
            if (res.confirm) {
              wx.redirectTo({
                url: '../waitpay/waitpay?orderId=' + that.data.orderId + "&nickName=" + nickName,
              })
            } else if (res.cancel) {
              wx.redirectTo({
                url: '../waitpay/waitpay?orderId=' + that.data.orderId + "&nickName=" + nickName,
              })
            }
          }
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },



})
