// pages/storepage/tixian/tixian.js
var app = getApp()
var host = app.globalData.host;
var pageindex = 0;
var pageSize = 10;
var condition = {};
var util = require('../../utils/util.js');

Page({

  /**
  * 页面的初始数据
  */
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    imgUrls: [],
    imageUrl: app.globalData.url,
    showlibao: false,
    product_list:[],
    main_con: [],
    showLoading:true,
    classifyAllData: [],
    classifyAllDataL: 0,
    groupShow: false,
    groupTitleShow: false,
    groupData: [],
    groupImage: '',
    groupTitle: '',
    couponShow: false,
    couponTitleShow: false,
    couponData: [],
    couponImage: '',
    couponTitle: '',
    getListData:[],
    indexId: -1,
    classifyShow: false,
    classifyDatas:[],
    classifyIndexId:0,
    rightData:[],
    canCouponsData:[],
    GroupProduct:[],
    shopid:-1,
  },
  bannerImg: function () {
    var that = this;
    wx.request({
      url: host + 'banner/xcxBannerList',
      data: {
        userId: app.globalData.userId,
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        var imgUrls = [];
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].type == "1") {
            imgUrls.push(res.data.data[i])
          }
        }
        that.setData({
          imgUrls: imgUrls
        })
        console.log("轮播", that.data.imgUrls)
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  closelibao: function (e) {
    this.setData({
      showlibao: false,
    })
  },
  tomorecoupon: function (e) {
    wx.navigateTo({
      url: '../couponmy/couponmy',
    })
  },

  // 获取推荐商品
  getList: function () {
    var that = this;
    var tjArray = [];
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: 500,
        pageIndex: pageindex,
        condition: condition,
        userId: app.globalData.userId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })

          return;
        }
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].foryou == 1) {
            tjArray.push(res.data.data[i])
          }
        }

        that.setData({
          getListData: tjArray
        });
      }
    })
  },

  //时间
  contrasttime: function (picktime) {
    let nowDate = new Date();
    if (picktime.length < 12) {
      picktime += " 23:59:59"
      console.log(picktime)
    }

    var endTime = picktime
    var arr = endTime.split(/[- : \/]/);
    var date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
    var setTime = Date.parse(new Date(date))
    var nowTime = Date.parse(new Date())
    var disTime = setTime - nowTime

    return disTime / 1000;
  },
  //时间

  // 根据条件加载列表
  loadData: function () {
    var that = this;
    wx.request({
      url: host + 'commodityindex/xcxGetCommodityIndex',
      data: {
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("res", res.data.data)
        that.getList();
        var product_listData = [];
        for(var i=0;i<res.data.data.length;i++){
          if (res.data.data[i].type=="1"){
            product_listData.push(res.data.data[i])
          }
        }
        that.setData({
          product_list: product_listData
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    });

    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("优惠券res", res.data.data);
        var canCouponsData = [];
        if (res.data.data.length > 0) {
          for (let i = 0; i < res.data.data.length; i++) {
            if (res.data.data[i].deadLine != "") {
              if (that.contrasttime(res.data.data[i].deadLine) > 0) {
                canCouponsData.push(res.data.data[i]);
              }
            } else {
              if (res.data.data[i].useMethod == "1") {
                if (that.contrasttime(res.data.data[i].endTime) > 0) {
                  canCouponsData.push(res.data.data[i]);
                }
              } else if (res.data.data[i].useMethod == "2") {
                canCouponsData.push(res.data.data[i]);
              }
            }
            if (canCouponsData.length>0){
              console.log("canCouponsData", canCouponsData)
              that.setData({
                showlibao: true,
                canCouponsData: canCouponsData,
              })
            }
          }
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });

  },
  productList: function (e) {
    var shopcommodityid = e.currentTarget.dataset.shopcommodityid;
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopcommodityid
    });
  },

  // 分类
  classifyGo: function (e) {
    var that = this,
      index = e.currentTarget.id,
      goData = that.data.classifyAllData[index].child,
      shopCommodityClassifyId = that.data.classifyAllData[index].shopCommodityClassifyId;
    console.log(goData)
    wx.navigateTo({
      url: '../classify/classify?data=' + JSON.stringify(goData)
    })
  },
  classifyData: function () {
    var that = this;
    wx.request({
      url: host + 'commodityclassify/getAlls',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        console.log("分类", res.data.data);
        that.setData({
          classifyAllData: res.data.data,
          classifyAllDataL: res.data.data.length
        })

        if (that.data.shopid>-1) {
          that.setData({
            indexId: that.data.shopid,
            classifyShow: true,
            classifyDatas: that.data.classifyAllData[that.data.shopid].child,
            classifyIndexId: 0,
          })
          that.classifyIndexData(that.data.classifyAllData[that.data.shopid].child[0].shopCommodityClassifyId)
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  // 优惠券入口
  getCoupon: function () {
    var that = this;
    wx.request({
      url: host + 'shopcouponsimage/get',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("优惠券", res.data.data)
        that.setData({
          couponData: res.data.data,
          couponImage: res.data.data.image,
          couponTitle: res.data.data.title
        })
        if (that.data.couponTitle) {
          that.setData({
            couponShow: true,
            couponTitleShow: true,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  couponGo: function () {
    wx.navigateTo({
      url: '../couponmy/couponmy'
    })
  },

  // 拼团
  getGroup: function () {
    var that = this;
    wx.request({
      url: host + 'groupimage/get',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("拼团", res.data.data)
        that.setData({
          groupData: res.data.data,
          groupImage: res.data.data.image,
          groupTitle: res.data.data.title
        })
        if (that.data.groupTitle) {
          that.setData({
            groupShow: true,
            groupTitleShow: true,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  groupGo: function () {
    wx.navigateTo({
      url: '../groupIndex/groupIndex'
    })
  },

  // 分组
  _data_activity_Ajax: function () {
    var that = this;
    wx.request({
      url: host + 'commoditygroup/xcxGetGroup',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        that.setData({
          main_con: res.data.data,
          host: host
        })

        console.log(res);
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  maincon_btn: function (e) {
    var that = this;
    var idIndex = e.currentTarget.id;
    var a_Index = this.data.main_con[idIndex];
    wx.navigateTo({
      url: '../activityMain/activityMain?activityMain=' + a_Index["shopCommodityGroupId"] + '&index=' + idIndex
    })
  },

  /**
  * 生命周期函数--监听页面加载
  */
  onLoad: function (options) {
    var that = this;
    var scene = decodeURIComponent(options.scene);
    var userinfo = wx.getStorageSync("userinfo_key");
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("scene", scene)

    if (options.scene) {
      if (userinfo.openid) {
        util.getDistribution(host, app.globalData.userId, userinfo.openid, scene)
      } else {
        util.getOpenId(host, app.globalData.userId, function () {
          userinfo = wx.getStorageSync("userinfo_key");
          util.getDistribution(host, app.globalData.userId, userinfo.openid, scene)
        })
      }
    }

    if (options.shopid){
      that.setData({
        shopid: options.shopid
      })
    }
    that.loadData();
    that.bannerImg();
    that.classifyData();
    that.getCoupon();
    that.getGroup();
    that._data_activity_Ajax(); 
    that.GroupProductGo();
  },

  // 新版分类
  classifyChange:function(e){
    console.log(e.currentTarget.id)
    var that = this;
    that.setData({
      indexId: e.currentTarget.id,
      classifyShow:true,
      classifyDatas: that.data.classifyAllData[e.currentTarget.id].child,
      classifyIndexId:0,      
    })
    that.classifyIndexData(that.data.classifyAllData[e.currentTarget.id].child[0].shopCommodityClassifyId)    
  },
  classifyIndexData:function(id){
    var that = this;
    that.showLoadGo();
    wx.request({
      url: host + 'commodity/getByClassifyId',
      data: {
        shopCommodityClassifyId: id
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log("分类", ops.data.data);
        that.setData({
          rightData: ops.data.data,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
      },
      fail: function (ops) { },
      complete: function (ops) { }
    })
  },
  classifyIndexGo:function(e){
    var that = this;
    that.setData({
      classifyIndexId: e.currentTarget.id
    })
    that.classifyIndexData(e.currentTarget.dataset.indexid);
  },

  //搜索
  inputGo: function (e) {
    var that = this;
    that.setData({
      inputText: e.detail.value
    })
  },
  searchGo: function () {
    var that = this;
    if (that.data.inputText) {
      wx.navigateTo({
        url: '../search/search?inputText=' + that.data.inputText,
      })
    } else {
      wx.showModal({
        title: '提示',
        content: '请输入搜索内容'
      })
      return
    }
  },

  // 加载中
  showLoadGo:function(){
    var that = this;    
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if(parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    }
  },

  // 首页
  indexShow:function(){
    var that = this;
    that.setData({
      classifyShow: false,
      classifyIndexId: 0,
      indexId:-1,
    })
  },

  // 优惠券
  couling: function (e) {
    var that = this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e,function(){
      console.log(e.currentTarget.dataset.couponsid);
      var userinfo = wx.getStorageSync("userinfo_key");
      wx.request({
        url: host + 'shopcoupons/receive',
        data: {
          couponsId: e.currentTarget.dataset.couponsid,
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            wx.showModal({
              title: '温馨提示',
              content: '领取成功!',
            })
          }
        },
      })
    })    
  },

  // 拼团
  GroupProductGo: function () {
    var that = this;
    wx.request({
      url: host + 'group/getGroupProduct',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("拼团", res.data.data)
        that.setData({
          GroupProduct: res.data.data,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  GetDateDiff: function (startDate, endDate) {
    var date1 = new Date(Date.parse(startDate));  //开始时间  
    var date2 = new Date(Date.parse(endDate));    //结束时间  
    var date3 = date2.getTime() - new Date(date1).getTime();   //时间差的毫秒数        

    //------------------------------  

    //计算出相差天数  
    var days = Math.floor(date3 / (24 * 3600 * 1000))

    //计算出小时数  

    var leave1 = date3 % (24 * 3600 * 1000)    //计算天数后剩余的毫秒数  
    var hours = Math.floor(leave1 / (3600 * 1000))
    //计算相差分钟数  
    var leave2 = leave1 % (3600 * 1000)        //计算小时数后剩余的毫秒数  
    var minutes = Math.floor(leave2 / (60 * 1000))
    //计算相差秒数  
    var leave3 = leave2 % (60 * 1000)      //计算分钟数后剩余的毫秒数  
    var seconds = Math.round(leave3 / 1000)
    var millisecond = leave3 % (60 * 1000)      //计算秒钟数后剩余的毫秒数  
    console.log(" 相差 " + days + "天 " + hours + "小时 " + minutes + " 分钟" + seconds + " 秒" + millisecond + "毫秒")
  },

  Gogroup: function (e) {
    var that = this;
    var myDate = new Date()
    var index = e.currentTarget.id;
    var GroupProduct = that.data.GroupProduct[index];
    var shopCommodityId = GroupProduct.shopCommodityId;
    var groupId = GroupProduct.groupId
    var successNum = GroupProduct.successNum
    var num = GroupProduct.num
    var priceShow = GroupProduct.priceShow
    var endTime = GroupProduct.endTime
    var createTime = myDate.toLocaleString()
    var createTimeOne = createTime.replace("/", "-")
    var createTimeTwo = createTimeOne.replace("/", "-")
    var str = createTimeTwo;
    var arr = str.split("");
    arr.splice(11, 2);
    str = arr.join("");
    console.log("时间", endTime, createTime, createTimeTwo, "截取后", str)
    that.GetDateDiff(str, endTime)
    wx.navigateTo({
      url: '../groupDetail/groupDetail?groupId=' + groupId + "&shopCommodityId=" + shopCommodityId + "&successNum=" + successNum + "&num=" + num + "&priceShow=" + priceShow + "&endTime=" + endTime
    })
  },


  /**
  * 生命周期函数--监听页面初次渲染完成
  */
  onReady: function () {

  },

  /**
  * 生命周期函数--监听页面显示
  */
  onShow: function () {
  },

  /**
  * 生命周期函数--监听页面隐藏
  */
  onHide: function () {

  },

  /**
  * 生命周期函数--监听页面卸载
  */
  onUnload: function () {

  },

  /**
  * 页面相关事件处理函数--监听用户下拉动作
  */
  onPullDownRefresh: function () {

  },

  /**
  * 页面上拉触底事件的处理函数
  */
  onReachBottom: function () {

  },

  /**
  * 用户点击右上角分享
  */
  onShareAppMessage: function () {
    var that = this;
    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, decodeURIComponent(logid));
    if (logindex == 1){
      var link = 'pages/indexss/indexss?scene=' + logid
    }else{
      var link = 'pages/indexss/indexss'
    }
    return {
      title: '',
      path: link,
    }
  }
})