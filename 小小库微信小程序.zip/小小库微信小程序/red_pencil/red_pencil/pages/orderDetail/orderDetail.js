// pages/orderDetail/orderDetail.js

var orderId = ""
var nickName = ""
var app = getApp()
var host = app.globalData.url;


Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    showLoading: true,
    //产品
    exchangeing: {},
    shopName:"",
    shopAddress:"",
    latitude: '',
    longitude: '',
    userinfo:{},
    contact:"",
    order:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    wx.hideShareMenu()
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    orderId = opt.orderId;
    nickName = opt.nickName;
    if (opt.nickName){
      that.setData({
        order:true
      })
    }
    console.log('接收上页传的参数', opt);
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("userinfo", userinfo);
    that.setData({
      userinfo: userinfo
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.request({
      url: host+'/order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }else{
          console.log("waitpay订单详情", res.data.data)
          var _data = res.data.data
          that.setData({
            exchangeing: res.data.data,
            shopName: res.data.data.storeInfo.title,
            contact: res.data.data.storeInfo.contact,
            shopAddress: res.data.data.storeInfo.address,
          }, function () {
            that.setData({
              showLoading: false
            }, function () {
              wx.hideLoading();
              })
          })
        }
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      },
    })
  },

  // 定位
  didian: function () {
    var that = this
    that.tude();
  },
  tude: function () {
    var that = this
    wx.request({
      url: host + '/notify/navigation',
      data: {
        address: that.data.shopAddress
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })

        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        console.log("执行了吗")
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          address: that.data.shopAddress
        })
      },
      fail: function (res) { console.log("执行了吗1", res) },
    })
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})