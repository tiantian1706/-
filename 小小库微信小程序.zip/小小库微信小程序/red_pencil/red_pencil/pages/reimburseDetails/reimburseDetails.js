// pages/reimburseDetails/reimburseDetails.js
var app = getApp()
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    reimburseOrderId: null,
    reimburse: {},
    myRefundStatusName: '',
    myRefundStatusTitle: "",
    reimburseDail: {}
  },

  /**
   * 生命周期函数--监听页面加载
   */
  reimburseDetailsAjax: function(){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'orderback/getByOrderId',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        orderId: that.data.reimburseOrderId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      success: function (res) {
        console.log('提交数据', res)
        var state = res.data.data.state;
        if (state == 1) {
          that.setData({
            myRefundStatusName: '退款申请中',
            myRefundStatusTitle: '您的退款申请已提交，等待商家审核'
          })
        }

        if (state == 2) {
          that.setData({
            myRefundStatusName: '退款中',
            myRefundStatusTitle: '您的退款申请商家已同意，等待商家退款'
          })
        }

        if (state == 3) {
          that.setData({
            myRefundStatusName: '退款已完成',
            myRefundStatusTitle: '商家已将退款资金提交微信处理，通常情况下，退款金额会原路退回您的付款方式，微信零钱会在30分钟内到账，银行卡会在1-3个工作中内到账，请留意查看'
          })
        }

        if (state == 4) {
          that.setData({
            myRefundStatusName: '退款被拒绝',
            myRefundStatusTitle: '您的退款申请被商家拒绝，拒绝理由' + res.data.data.backReason +  '，请及时联系商家客服处理'
          })
        }

        if (state == 5) {
          that.setData({
            myRefundStatusName: '退款已关闭',
            myRefundStatusTitle: '您的退款已关闭，售后请联系客服处理'
          })
        }

        that.setData({
          reimburse: res.data.data
        })
      }
    })
  },
  reimburseDetails_top_btn1: function(){
    var that = this;
    wx.navigateTo({
      url: '../reimburse/reimburse?backId=' + that.data.reimburse.backId + '&image=' + that.data.reimburseDail.image + '&title=' + that.data.reimburseDail.title + '&description=' + that.data.reimburseDail.description + '&orderNo=' + that.data.reimburseDail.orderNo,
    })
  },
  reimburseDetails_top_btn2: function(){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'orderback/close',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        orderId: that.data.reimburseOrderId,
        backId: that.data.reimburse.backId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      success: function(res) {
        console.log('返回的数据',res)
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }

        wx.showModal({
          title: '提示',
          content: '关闭成功',
          success: function(res) {
            if (res.confirm) {
              wx.request({
                url: host + 'orderback/getByOrderId',
                method: 'get',
                data: {
                  userId: app.globalData.userId,
                  orderId: that.data.reimburseOrderId,
                  openId: userinfo.openid,
                  nickName: userinfo.nickName,
                  headImgUrl: userinfo.avatarUrl,
                },
                success: function (res) {
                  console.log('提交数据', res)
                  var state = res.data.data.state;
                  that.setData({
                    reimburse: res.data.data
                  })
                }
              })
            }
          }
        })
      }
    })
  },
  onLoad: function (options) {
    var that = this;

    that.setData({
      reimburseOrderId: options.orderId,
      reimburseDail: options
    });

    that.reimburseDetailsAjax();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})