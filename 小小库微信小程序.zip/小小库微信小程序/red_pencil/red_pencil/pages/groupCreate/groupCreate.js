// pages/createOrder/createOrder.js
var app = getApp()
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hide: false,
    host: app.globalData.host,
    orderData: {},
    tagInfoTab_con: {},
    showLoading: true,
    labaUrl: app.globalData.host + "data/upload/image/xcx/laba.png",
    zhifuUrl: app.globalData.host + "data/upload/image/xcx/zhifu.png",
    groupId:0,
    cntype:0,
    groupTopId:0,
    joinBuy:"",
    tagArr:"",
    priceShow:"",
    zhifuUrl: app.globalData.host + "data/upload/image/xcx/zhifu.png",
    host: app.globalData.url,
    id: true,
    write: false,
    shoudong: false,
    address: false,
    addressCon: [],
    userName:"",
    telNumber:"",
    detailInfo:"",
    addressView: [],
    btnClick:true,
  },
  writeShow: function () {
    var that = this;
    that.setData({
      write: true
    })
  },
  writeHide: function () {
    var that = this;
    that.setData({
      write: false,
      shoudong: false
    })
  },
  shoudong: function () {
    var that = this;
    wx.navigateTo({
      url: '../address_single/address_single',
    })
  },
  dizi: function () {
    var that = this
    wx.chooseAddress({
      success: function (res) {
        console.log("地址",res)
        console.log(res.userName)
        console.log(res.postalCode)
        // console.log(res.provinceName)
        // console.log(res.cityName)
        // console.log(res.countyName)
        console.log(res.detailInfo)
        console.log(res.nationalCode)
        console.log(res.telNumber)
        wx.setStorageSync('address', res);
        that.setData({
          addressCon: res,
          userName: res.userName,
          telNumber: res.telNumber,
          provinceName: res.provinceName,
          cityName: res.cityName,
          countyName: res.countyName,
          detailInfo: res.provinceName + res.cityName + res.countyName + res.detailInfo,
          id: false,
          address: true,
          write: false,
          shoudong: false
        })
        console.log("微信地址", that.data.addressCon, that.data.detailInfo)
      }
    })

  },
  formSubmit: function (e) {
    var that = this
    console.log("填了些什么", e.detail.value)
    if (e.detail.value.userName.length == 0 || e.detail.value.telNumber.length == 0 ||
      e.detail.value.detailInfo.length == 0) {
      wx.showModal({
        title: '提示',
        content: "请完善收件人地址",
        success: function (res) {
        }
      })
    } else {
      that.setData({
        addressCon: e.detail.value,
        userName: e.detail.value.userName,
        telNumber: e.detail.value.telNumber,
        detailInfo: e.detail.value.detailInfo,
        write: false,
        id: false,
        address: true,
        shoudong: false,
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    console.log("这是传的options!!!!!", options)
    that.setData({
      cntype: options.type,
      orderData: options,
      groupId: options.groupId,
      groupTopId: options.groupTopId,
    }, function () {
      that.setData({
        showLoading: false
      }, function () {
        wx.hideLoading();
      })
    })

    console.log('初始化对象', that.data.orderData);
    console.log('规格', that.data.tagInfoTab_con);
    if (options.joinBuy=="1"){
      that.setData({
        tagArr: options.tagArr,
        priceShow: options.priceShow        
      })
    }else{
      var tagInfoTab_con = JSON.parse(options.tagInfoTab_con)
      var tag = [];
      for (var i = 0; i < tagInfoTab_con.length; i++) {
        tag.push(tagInfoTab_con[i].title)
      }
      var guige = tag.join(",")
      that.setData({
        tagArr: guige,
        priceShow: that.data.orderData.priceShow        
      })
      console.log("规格", tag, tagInfoTab_con,guige)
    }
  },
  payment: function () {
    var that = this;

    that.setData({
      btnClick: false,
    })

    if (that.data.addressCon.length == 0) {
      wx.showModal({
        title: '提示',
        content: '地址不能为空',
      })

      that.setData({
        btnClick: true,
      })

      return;
    }
    that.createOrder(that.data.orderData.shopCommodityId)
  },
  createOrder: function (shopCommodityId) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    console.log("sss", that.data.groupId)
    console.log("规格规格", that.data.tagArr)
    console.log("地址", that.data.addressCon, that.data.detailInfo, that.data.addressCon.provinceName + that.data.addressCon.cityName + that.data.addressCon.countyName + that.data.detailInfo)
    if (that.data.cntype!=2){
      wx.request({
        url: app.globalData.host + 'grouporder/fightGroups',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: {
            name: that.data.addressCon.userName,
            phone: that.data.addressCon.telNumber,
            address: that.data.addressCon.provinceName + that.data.addressCon.cityName + that.data.addressCon.countyName+that.data.detailInfo,
            type: 1,
            groupId: that.data.groupId,
            tag: that.data.tagArr,
          },
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          var order_id = res.data.data
          console.log('hq', res)
          if (res.data.code!=0){
            var text = res.data.msg
            wx.showModal({
              title: '提示',
              content: text,
            })

            that.setData({
              btnClick: true,
            })

            return;
          }
          wx.request({
            url: app.globalData.host + 'grouporder/wxjspay',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              orderId: order_id
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            success: function (res) {

              var result = res.data.data;

              if (res.data.code != 0) {
                var text = res.data.msg
                wx.showModal({
                  title: '提示',
                  content: text,
                })

                that.setData({
                  btnClick: true,
                })

                return;
              }

              wx.requestPayment({
                userId: app.globalData.userId,
                timeStamp: result.timeStamp,
                nonceStr: result.nonceStr,
                package: result.package,
                signType: result.signType,
                paySign: result.paySign,
                success: function (res) {
                  console.log('传参', res, shopCommodityId)
                  wx.navigateTo({
                    // url: '../groupJoin/groupJoin?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId + "&groupId=" + that.data.groupId + "&tagInfoTab_con=" + JSON.stringify(that.data.tagInfoTab_con) + "&name=" + that.data.orderData.name + "&priceShow=" + that.data.orderData.priceShow + "&sales=" + that.data.orderData.sales + "&icon=" + that.data.orderData.icon + '&num=' + that.data.orderData.num + '&successNum=' + that.data.orderData.successNum + '&invite=' + "1",
                    url:'../groupOrder/groupOrder'
                  })
                },
                fail: function (res) {

                  that.setData({
                    btnClick: true,
                  })

                },
                compelete: function (res) {

                }
              })
              
            }
          })


        }
      })
    }else{
      wx.request({
        url: app.globalData.host + 'grouporder/fightGroups',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: {
            name: that.data.addressCon.userName,
            phone: that.data.addressCon.telNumber,
            address: that.data.addressCon.provinceName + that.data.addressCon.cityName + that.data.addressCon.countyName + that.data.detailInfo,
            type: 2,
            groupTopId: that.data.groupTopId,
            tag: that.data.tagArr,
            groupId: that.data.groupId,
          },
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          console.log('规格', that.data.tagInfoTab_con)

          var order_id = res.data.data
          console.log('hq', res)
          if (res.data.code != 0) {
            var text = res.data.msg
            wx.showModal({
              title: '提示',
              content: text,
            })
            return;
          }
          if (res.data.code==0){
            wx.request({
              url: app.globalData.host + 'grouporder/wxjspay',
              data: {
                userId: app.globalData.userId,
                openId: userinfo.openid,
                nickName: userinfo.nickName,
                headImgUrl: userinfo.avatarUrl,
                orderId: order_id
              },
              header: {
                'content-type': 'application/json'
              },
              method: 'get',
              success: function (res) {

                var result = res.data.data;

                wx.requestPayment({
                  userId: app.globalData.userId,
                  timeStamp: result.timeStamp,
                  nonceStr: result.nonceStr,
                  package: result.package,
                  signType: result.signType,
                  paySign: result.paySign,
                  success: function (res) {
                    console.log('传参', res, shopCommodityId)
                    wx.navigateTo({
                      // url: '../groupJoin/groupJoin?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId + "&groupId=" + that.data.groupId + "&tagInfoTab_con=" + JSON.stringify(that.data.tagInfoTab_con) + "&name=" + that.data.orderData.name + "&priceShow=" + that.data.orderData.priceShow + "&sales=" + that.data.orderData.sales + "&icon=" + that.data.orderData.icon + '&num=' + that.data.orderData.num + '&successNum=' + that.data.orderData.successNum +'&invite='+"1" ,
                      url: '../groupOrder/groupOrder'
                    })
                  },
                  fail: function (res) {
                  },
                  compelete: function (res) {

                  }
                })
              }
            })
          }else{
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          }
        }
      })
    }
  },
  ruleBox: function () {
    this.setData({
      hide: true
    })
  },
  hideBox: function () {
    this.setData({
      hide: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var address = wx.getStorageSync('address');
    console.log("有没有东西",address)

    that.setData({
      addressView: address,
      addressCon: address,
      userName: address.userName,
      telNumber: address.telNumber,
      detailInfo: address.detailInfo,
      provinceName: address.provinceName,
      cityName: address.cityName,
      countyName: address.countyName
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})