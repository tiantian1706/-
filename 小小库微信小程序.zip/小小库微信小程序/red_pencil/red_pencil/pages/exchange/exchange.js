var config = require('../../config')
var app = getApp();
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,

    // 我的订单列表
    myorder: [],

    //进行中
    exchangeing: [
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "12",
        dates: "2017-08-06",
        send: [
          {
            imgsrc: "../../imgs/67.png",
            num: "7",
          },
          {
            imgsrc: "../../imgs/68.png",
            num: "4",
          },
          {
            imgsrc: "../../imgs/69.png",
            num: "4",
          }
        ]
      },
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "15",
        dates: "2017-08-06",
        send: [
          
        ]
      },
    ],
    // 已经兑换
    exchangecom: [
      // {
      //   imgsrc: "../../imgs/23.png",
      //   title: "Midea/美的 MB-WFS3018Q电饭煲锅3L升家用智能迷你多功能1-2-4人团购",
      //   price: "99.00",
      //   num: "11",
      //   dates: "2017-08-06",
      //   send: [
      //     {
      //       imgsrc: "../../imgs/67.png",
      //       num: "7",
      //     },
      //     {
      //       imgsrc: "../../imgs/69.png",
      //       num: "4",
      //     }
      //   ]
      // }
      
    ],
    
    dingdUrl: app.globalData.host+"data/upload/image/xcx/dingd-00.png"
      
  },


  onLoad: function () {
    var that = this;

    /** 
     * 获取系统信息
     */
    wx.getSystemInfo({

      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }

    });

    //请求我的订单：

    // 用户信息
    var userinfo = wx.getStorageSync("userinfo_key")

    var openid = userinfo.openid

    wx.request({
      url: app.globalData.host+'order/myExchangeList',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        //  var a = res.data.data.slice(0,20);
        console.log("可以赠送的订单", res )
        that.setData({
          myorder: res.data.data
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })

  },

  enterDetail: function (e) {
    var that = this;
    
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];

    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var headImgUrl = wx.getStorageSync("userinfo_key").headImgUrl;
    wx.navigateTo({
      url: '../exchangedetail/exchangedetail?orderId=' + order.orderId + "&nickName=" + nickName + "&priceShow=" + order.priceShow,
    })

    console.log("订单索引", e.currentTarget.id)
    console.log("order", order)
  },

  /** 
     * 滑动切换tab 
     */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  }
})
