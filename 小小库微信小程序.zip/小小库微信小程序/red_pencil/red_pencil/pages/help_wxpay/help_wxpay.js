var app = getApp();
var orderId = ""
var openId = ""
var userInfo = {

}
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
      df_money:0,
      showLoading: true,
  },

  input_df_money: function(e){
    this.setData({
      df_money: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    orderId = options.orderId;
    console.log(orderId)

  },

  getDFUserInfo: function(cb){
    wx.login({
      success: function (res) {

        var code = res.code
        wx.getUserInfo({
          success: function (res) {
            
            typeof cb == "function" && cb(res.userInfo, code)

          }
        })
      }
    })
  },

  df_pay: function(){
    
    var that = this;

    if (parseFloat(that.data.df_money) <= 0){
      console.log("代付金额为0")
      return
    }


    that.getDFUserInfo(function (userinfo, code) {

      userInfo = userinfo

      userInfo.code = code

      console.log("代付人的信息", userInfo)

      wx.request({
        url: host+'xcx/login',
        data: {
          userId: app.globalData.userId,
          code: code,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          console.log("openid", res)
          openId = res.data.data.openId

          userInfo.openId = openId

          console.log("代付人在支付的时候的信息", userInfo)

          wx.request({
            url: host+'order/xcxotherPay',
            data: {
              userId: app.globalData.userId,
              openId: openId,
              nickName: userInfo.nickName,
              headImgUrl: userInfo.avatarUrl,
              price: that.data.df_money,
              orderId: orderId

            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            success: function (res) {
              console.log("代付结果", res)

              var df_order_id = res.data.data

              wx.request({
                url: host+'order/xcxPay',
                data: {
                  userId: app.globalData.userId,
                  openId: userInfo.openId,
                  nickName: userInfo.nickName,
                  headImgUrl: userInfo.avatarUrl,
                  orderId: df_order_id
                },
                header: {
                  'content-type': 'application/json'
                },
                method: 'get',
                success: function (res) {
                  console.log("需要支付的信息", res)
                  var result = res.data.data;
                  console.log('123123',result);
                  console.log('提示', res.data.msg)
                  if (!result) {
                    wx.showModal({
                      title: '提示',
                      content: res.data.msg,
                      success: function (res) {
                        if (res.confirm) {
                          wx.navigateBack({

                          })
                        } else if (res.cancel) {
                          wx.navigateBack({

                          })
                        }
                      }
                    })
                  } else {

                    wx.requestPayment({
                      timeStamp: result.timeStamp,
                      nonceStr: result.nonceStr,
                      package: result.package,
                      signType: result.signType,
                      paySign: result.paySign,
                      success: function (res) {
                        console.log(res)
                        wx.navigateBack({

                        })
                      },
                      fail: function (res) {

                      },
                      compelete: function (res) {

                      }
                    })
                  }
                }
              })


            }
          })

        }
      })
    })


    



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    that.setData({
      showLoading: false
    }, function () {
      wx.hideLoading();
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})