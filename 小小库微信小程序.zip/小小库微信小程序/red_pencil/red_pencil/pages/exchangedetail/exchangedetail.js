
var orderId = ""
var nickName = ""
var app = getApp()
var host = app.globalData.url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.url,
    // alsdkmmwmmx: '',
    /** 
        * 页面配置 
        */
    winWidth: 0,
    qrcode_show: null,
    sales:1,
    sendFriend: true,
    sendTheir: true,
    winHeight: 0,
    QRCode: {}, // 二维码
    // tab切换的第几个页面  
    currentTab: 0,
    exchangeing_quantity: {},
    
    //产品
    exchangeing: {},

    //收货人
    daipay: [

    ],
    // 没有填地址
    daiwait: [

    ],
    addressInfo: {
      userName:1,
      postalCode:2,
      provinceName:3,
      ccityName:4,
      countyName:5,
      detailInfo:6,
      nationalCode:7,
      telNumber:8
    },

    is_send:false,
    is_send2: false,
    is_send3: false,
    is_send4: false,
    send_quantity:0,
    is_show_py:false,
    sy_quantity:0,
    duihuanma:"",
    Greetings: '请给好友留言~',
    Greetings_value: '' ,
    Greetings_value_con: '',
    qrcode_show1: true,
    qrcode_show2: false,
    // 物流信息
    logisticsData: {},
    ToSendTheirBtn: false,
    disitem: false,
    quxiao:false,
    panduan:false,
    received: 0,
    showLoading: true,
  },

  check: function () {
    this.setData({
      disitem: !this.data.disitem
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {

    wx.hideShareMenu()
    var that = this;

    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    
    orderId = opt.orderId;
    nickName = opt.nickName;
    console.log('接收上页传的参数',opt);

    that.setData({
      Greetings_value: '您的好友' + nickName + '给您送来一份心意',
    })
  },
  // 打开二维码弹出层
  qrcode_wrapper_show: function(e){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var exchangeing = that.data.exchangeing.list;
    var idxs = e.currentTarget.dataset.idx;
    for (var i = 0, lens = exchangeing.length; i < lens; i++) {
      console.log('打开二维码弹出层',e, exchangeing[i].code, exchangeing[i].qrcode);
      if (idxs == i) {
        setTimeout(function () {
          wx.navigateTo({
            url: '../filladdress/filladdress?quantity=' + that.data.sales + '&qrcode=' + exchangeing[idxs].qrcode + '&duihuanma=' + exchangeing[idxs].code + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&receive=' + exchangeing[idxs].receive + '&fafa=' + 8,
            success: function (ops) {
              console.log('跳转二维码页面成功的回调', ops)
            },
            fail: function (ops) {
              console.log('跳转二维码页面失败的回调', ops)
            }
          })
        }, 50)
      }
    }
  },
  // // 隐藏二维码弹出层
  // qrcode_hide: function(){
  //   this.setData({
  //     qrcode_show: false
  //   })
  // },
  bindTextAreaBlur: function(event){
    var that = this;
    console.log(event)
    that.setData({
      Greetings_value_con: event.detail.value
    });
    console.log(this.data.Greetings_value_con)
  },

  send_commodity : function(e){
    var that = this
    if (parseInt(that.data.sy_quantity) == 0) {
      console.log("已经没有商品可以赠送了")
      wx.showModal({
        title: '提示',
        content: '可送产品数量为0，请继续购买',
        success: function (res) {
          if (res.confirm) {
            console.log("跳转")
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          } else if (res.cancel) {
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          }
        }
      })
      return
    }
     this.setData({
       is_send:!this.data.is_send,
       is_send2: !this.data.is_send2,
       sendFriend: false,
       sendTheir: false,
       quxiao:true,
       panduan:true
     })
  },

  inputQuantity: function(e){
    console.log(e);
    if (parseInt(this.data.exchangeing.quantity) < parseInt(e.detail.value)){

      console.log("赠送数量大于购买数量")
      wx.showModal({
        title: '提示',
        content: '赠送数量大于购买数量',
        success: function (res) {
        }
      })
    }

    this.setData({
      send_quantity: e.detail.value,
    })
  },
 // 确定送给别人
  confrim_send: function(){
    var that = this;
    that.setData({
      is_show_py: true,
      is_send2: false,
      is_send: false,
      sendFriend: false,
      sendTheir: false,
      quxiao:false,
      Greetings_value_con: that.data.Greetings_value_con
    })

    if (parseInt(that.data.sy_quantity) == 0) {
      console.log("已经没有商品可以赠送了")
      wx.showModal({
        title: '提示',
        content: '可送产品数量为0，请继续购买',
        success: function (res) {
          if (res.confirm) {
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          } else if (res.cancel) {
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          }
        }
      })
      return
    }

    if (parseInt(this.data.sales) < 1) {
      console.log("赠送数量小于1")
      return
    }

    
    that._confirmCommonality(function (res){
      console.log("资格码", res)
      that.setData({
        duihuanma: res.data.data.code,
        is_show_py: true,
        QRCode: res.data.data.qrcode,
      })
    })
    // var sendUserInfo = wx.getStorageSync("userinfo_key")
    // // 获取兑换码
    // wx.request({
    //   url: host+'/orderreceive/sendToFriend',
    //   data: {
    //     userId: userId,
    //     openId: sendUserInfo.openid,
    //     nickName: sendUserInfo.nickName,
    //     headImgUrl: sendUserInfo.avatarUrl,
    //     orderId: orderId,
    //     quantity: that.data.sales
    //   },
    //   header: {
    //     'content-type': 'application/json'
    //   },
    //   method: 'get',
    //   success: function (res) {
    //     console.log("资格码", res)
    //     that.setData({
    //       duihuanma: res.data.data.code,
    //       is_show_py: true,
    //       QRCode: res.data.data.qrcode,
    //     })
    //   }
    // })
  },
  // 确定送给自己
  ToSendTheirBtn_click: function(){
    var that = this;
    if (parseInt(that.data.sy_quantity) == 0) {
      console.log("已经没有商品可以赠送了")
      wx.showModal({
        title: '提示',
        content: '可送产品数量为0，请继续购买',
        success: function (res) {
          if (res.confirm) {
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          } else if (res.cancel) {
            wx.reLaunch({
              url: '../indexss/indexss',
            })
          }
        }
      })
      return
    }

    if ((parseInt(this.data.sales) < 1) || (parseInt(this.data.sales) == 0)) {
      wx.showModal({
        title: '提示',
        content: '填写数量不正确'
      })
      return
    }
    this._confirmCommonality(function (res){
        var sendUserInfo = wx.getStorageSync("userinfo_key")
        var clientId = sendUserInfo.clientId
        console.log('自己的对象', sendUserInfo)
        that.setData({
          duihuanma: res.data.data.code,
          QRCode: res.data.data.qrcode,
        })
        console.log('送出去的数量', that.data.received)
        wx.navigateTo({
          url: '../filladdress/filladdress?quantity=' + that.data.sales + '&qrcode=' + that.data.QRCode + '&duihuanma=' + that.data.duihuanma + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(sendUserInfo) + '&clientId=' + clientId +'&lala=' + 6,
        })
        that.setData({
          ToSendTheirBtn:false,
          is_send2:false,
          is_send4:false,
          sendFriend:true,
          sendTheir:true,
          quxiao: false,
          sales: 1,
        })
    })
    // var sendUserInfo = wx.getStorageSync("userinfo_key")
    // // 获取兑换码
    // wx.request({
    //   url: host+'/orderreceive/sendToFriend',
    //   data: {
    //     userId: userId,
    //     openId: sendUserInfo.openid,
    //     nickName: sendUserInfo.nickName,
    //     headImgUrl: sendUserInfo.avatarUrl,
    //     orderId: orderId,
    //     quantity: that.data.sales
    //   },
    //   header: {
    //     'content-type': 'application/json'
    //   },
    //   method: 'get',
    //   success: function (res) {
    //     console.log("资格码", res)
    //     that.setData({
    //       duihuanma: res.data.data.code,
    //       QRCode: res.data.data.qrcode,
    //     })

    //     wx.navigateTo({
    //       url: '../filladdress/filladdress?quantity=' + that.data.sales + '&qrcode=' + that.data.QRCode + '&duihuanma=' + that.data.duihuanma + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(sendUserInfo)
    //     })
    //   }
    // })
  },
  // 确定按钮的公共函数
  _confirmCommonality: function (cb){
    var that = this;
    var sendUserInfo = wx.getStorageSync("userinfo_key")
    // 获取兑换码
    wx.request({
      url: host+'/orderreceive/sendToFriend',
      data: {
        userId: app.globalData.userId,
        openId: sendUserInfo.openid,
        nickName: sendUserInfo.nickName,
        headImgUrl: sendUserInfo.avatarUrl,
        orderId: orderId,
        quantity: that.data.sales
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        console.log("资格码", res)
        cb(res)
      }
    })
  },
  send_commodity_myself: function (){ 
      console.log("送给自己")
      var that = this;
      that.setData({
        ToSendTheirBtn: true,
        is_send4: true,
        is_send: false,
        is_send3: false,
        sendFriend: false,
        sendTheir: false,
        quxiao: true,
      })
      if (parseInt(that.data.sy_quantity) == 0) {
        console.log("已经没有商品可以赠送了")

        wx.showModal({
          title: '提示',
          content: '可送产品数量为0，请继续购买',
          success: function (res) {
            if (res.confirm) {
              wx.reLaunch({
                url: '../indexss/indexss',
              })
            } else if (res.cancel) {
              wx.reLaunch({
                url: '../indexss/indexss',
              })
            }
          }
        })

        that.setData({
          is_send2: false
        })
      }
  },
  quxiao:function(){
    var that = this
    that.setData({
      quxiao:false,
      ToSendTheirBtn:false,
      is_send:false,
      is_send2:false,
      is_send3:false,
      is_send4:false,
      sendTheir:true,
      sendFriend:true,
      panduan:false,
      sales: 1,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.request({
      url: host+'/order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      method: 'get',
      success: function (res) {

        console.log("waitpay订单详情", res.data.data)
        var _data = res.data.data
        that.setData({
          exchangeing: res.data.data
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })

        var ys_quantity = 0

        for (var i = 0; i < that.data.exchangeing.list.length; i++) {
          var item = that.data.exchangeing.list[i]
          ys_quantity += parseInt(item.quantity)
          console.log(item.quantity)
        }

        

        console.log("已送数量", ys_quantity)

        that.setData({
          sy_quantity: that.data.exchangeing.quantity - ys_quantity,
          received: ys_quantity
        })

        // var pages = getCurrentPages();
        // var prevPage = pages[pages.length - 2];
        // prevPage.setData({
        //   sy_quantity: that.data.exchangeing.quantity - ys_quantity
        // })
        // console.log('获取页面栈', pages)
        if (_data.list != '') {
          that.logistics_ajax(_data.list[0].expressNo, _data.list[0].expressName)
        }
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })
  },
  logistics_ajax: function (_expressNo, _expressName) {
    var that = this;
    wx.request({
      url: host+'/express/searchLogisticsInfo',
      data: {
        userId: app.globalData.userId,
        expressNo: _expressNo,
        expressName: _expressName
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log('打印物流信息', ops.data.data);
        that.setData({
          logisticsData: ops.data.data
        })
      },
      fail: function (ops) { 
        console.log(报错, ops)
      },
      complete: function (ops) { }
    });
  },
  // 数量-
  changeNumberJia: function () {
    var that = this;
    var sales = that.data.sales;
    if (sales > 1) {
      that.setData({
        sales: --sales
      })
    }
  },
  // 数量+
  changeNumberJian: function () {
    var that = this;
    var sales = that.data.sales;
    var exchangeing_quantity = that.data.exchangeing.quantity;
    if (sales == exchangeing_quantity || sales == that.data.sy_quantity) {
      return;
    } else {
      that.setData({
        sales: ++sales,
      })
    }
  },
  ruleBox: function () {
    var that = this
    that.setData({
      hide: true
    })
    if (that.data.panduan==true){
      this.setData({
        is_send2:false
      })
    }
  },
  hideBox: function () {
    var that = this    
    this.setData({
      hide: false
    })
    if (that.data.panduan == true) {
      this.setData({
        is_send2: true
      })
    }
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  onShareAppMessage: function(){

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var clientId = userinfo.clientId;
    return {
      title: this.data.Greetings_value_con,
      path: 'pages/filladdress/filladdress?quantity=' + this.data.sales + '&qrcode=' + this.data.QRCode + '&duihuanma=' + this.data.duihuanma + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&clientId=' + clientId,
      imageUrl: host + this.data.exchangeing.image,
      success: function (res) {
        // 转发成功
        console.log("转发", res)
        // that.setData({
        //   is_send: true,
        //   is_show_py: false,
        // })
        that.setData({
          is_send: false,
          is_show_py: false,
          is_send2: false,
          sendFriend: true,
          sendTheir: true,
          quxiao: false
        }) 
        console.log(that.data.is_send)
        wx.showModal({
          title: '提示',
          content: '赠送成功',
          success: function (res) {
          }
        })
      },
      fail: function (res) {
        // that.setData({
        //   is_show_py: false,
        //   is_send: true
        // })
      }
    }

    console.log(this.data.Greetings_value);
  }
})
