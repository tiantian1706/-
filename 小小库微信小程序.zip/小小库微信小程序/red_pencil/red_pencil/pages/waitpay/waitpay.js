
var app = getApp()

var host = app.globalData.host;
var orderId = ""
var nickName = ""
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    nickName: "",
    publishDate: "",
    yf_money: "0",
    sy_money: "0",
    sales: 1,
    //待付款
    product_list:
    {

    },
    product_list_priceShow: {},
    tagInfo: [],
    daipay: [
      // {
      //   imgsrc: "../../imgs/68.png",
      //   name: "小福君",
      //   price: "100",
      //   dates: "2017-08-06 18:22"
      // },
      // {
      //   imgsrc: "../../imgs/67.png",
      //   name: "大侠君s",
      //   price: "190",
      //   dates: "2017-08-04 18:22"
      // }
    ],
    is_need_share:false,
    showLoading: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    var that = this
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    orderId = opt.orderId
    nickName = opt.nickName
    console.log('待付款',opt);
  },



  loadOrderData: function (nickName,cb) {
    var that = this;
    wx.request({
      url: host+'order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        console.log("waitpay订单详情", res)

        var product_list = {
          icon: res.data.data.image,
          introduction: res.data.data.title,
          priceShow: (res.data.data.price / 100 / res.data.data.quantity).toFixed(2),
        }

        var sales = res.data.data.quantity;
        that.setData({
          product_list_priceShow: (product_list.priceShow * sales).toFixed(2)
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        var publishDate = res.data.data.createTime;


        var helpList = res.data.data.helpOrderList;
        var yf_money = 0
        for (var i = 0; i < helpList.length; i++) {
          var item = helpList[i];
          var s_price = parseInt(item.price)
          yf_money += s_price
        }

        var sy_money = parseInt(res.data.data.price) - yf_money

        if(sy_money <= 0){
          that.setData({
            publishDate: publishDate,
            nickName: nickName,
            sales: sales,
            product_list: product_list,
            helpList: helpList,
            yf_money: yf_money / 100,
            sy_money: sy_money / 100,
            is_need_share: false
          })
        }else {
          that.setData({
            publishDate: publishDate,
            nickName: nickName,
            sales: sales,
            product_list: product_list,
            helpList: helpList,
            yf_money: yf_money / 100,
            sy_money: sy_money / 100,
            is_need_share:true
          })
        }

        cb()

      }
    })

  },

  helpPay: function () {



  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.loadOrderData(nickName, function () {

    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.loadOrderData(nickName,function(){
      wx.stopPullDownRefresh()
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
    var nickName = wx.getStorageSync("userinfo_key").nickName;

    var totalMoney = this.data.product_list.priceShow * this.data.sales

    return {
      title: '',
      path: 'pages/help_pay/help_pay?nickName=' + nickName + "&orderId=" + orderId,
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})