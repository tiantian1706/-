// pages/receive/receive.js

var app = getApp()
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showLoading: true,
    ordermoneylogData:{},
    ordermoneylogDataL:0,
    currentdate: "",
    hasnum:"",
    redWrapShow:false,
    scorePriceShow:0,
    days:0,
  },

  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  // 获取当前时间
  getNowFormatDate:function () {
    var date = new Date();
    var seperator1 = "-";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var strDate = date.getDate();
    if(month >= 1 && month <= 9) {
      month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
      strDate = "0" + strDate;
    }
    var currentdate = year + seperator1 + month + seperator1 + strDate;

    this.setData({
      currentdate: currentdate
    })

    return currentdate;
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
    var that = this;
    wx.hideShareMenu()
    wx.request({
      url: host +'ordermoneyconfig/get',
      data: {
        userId:app.globalData.userId
      },
      header: {},
      method: 'GET',
      dataType: 'json',
      responseType: 'text',
      success: function(res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }
        that.setData({
          scorePriceShow: res.data.data.scorePriceShow
        })
      },
      fail: function(res) {},
      complete: function(res) {},
    })
    that.ordermoneylog();

  },

  ordermoneylog:function(){
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'ordermoneylog/myList',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("执行了一个接口", res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }

        var ordermoneylogData = res.data.data;
        that.getNowFormatDate();

        for (var i = 0; i < res.data.data.length; i++) {
          var loglength = ordermoneylogData[i].log.length;
          ordermoneylogData[i].loglength = loglength;
          ordermoneylogData[i].modifyTime = ordermoneylogData[i].modifyTime.slice(0, 10);
          if (ordermoneylogData[i].modifyTime == that.data.currentdate && ordermoneylogData[i].loglength > 0 && (ordermoneylogData[i].day - ordermoneylogData[i].dis) > 0){
            ordermoneylogData[i].days = parseInt(ordermoneylogData[i].day - (ordermoneylogData[i].dis + 1))
          }else{
            ordermoneylogData[i].days = parseInt(ordermoneylogData[i].day - ordermoneylogData[i].dis)
          }
        };

        console.log("ordermoneylogData", ordermoneylogData)

        that.setData({
          ordermoneylogData: ordermoneylogData,
          ordermoneylogDataL: ordermoneylogData.length,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })

      },
      fail: function (res) { }
    })
  },

  close: function () {
    var that = this;
    that.setData({
      redWrapShow: false
    })
    that.ordermoneylog();
  },

  logidGet:function(e){
    console.log("e", e.currentTarget.dataset.logid)
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'ordermoneylog/receiveEveryDay',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        logId: e.currentTarget.dataset.logid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("执行了一个接口", res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }

        that.setData({
          redWrapShow: true,
          hasnum: res.data.data,
        })

      },
      fail: function (res) { }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})