// pages/groupIndex/groupIndex.js
var app = getApp();
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    showLoading: true,
    imagesUrl: app.globalData.url,
    groupImage: "",
    GroupProduct: [],
    GroupProductL: 0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  indexGo:function(){
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  getGroup: function () {
    var that = this;
    wx.request({
      url: host + 'groupimage/get',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("拼团", res.data.data)
        that.setData({
          groupData: res.data.data,
          groupImage: res.data.data.image,
          groupTitle: res.data.data.title
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    that.getGroup();
    wx.request({
      url: host + 'group/getGroupProduct',
      data: {
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        that.setData({
          GroupProduct: res.data.data,
          GroupProductL: res.data.data.length,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
        console.log("拼团商品", that.data.GroupProduct)
      },
      fail: function (res) { },
      complete: function (res) { }
    });

  },
  GetDateDiff:function (startDate,endDate){  
    var date1 = new Date(Date.parse(startDate));  //开始时间  
    var date2 = new Date(Date.parse(endDate));    //结束时间  
    var date3 = date2.getTime() - new Date(date1).getTime();   //时间差的毫秒数        

    //------------------------------  

    //计算出相差天数  
    var days = Math.floor(date3 / (24 * 3600 * 1000))

    //计算出小时数  

    var leave1 = date3 % (24 * 3600 * 1000)    //计算天数后剩余的毫秒数  
    var hours = Math.floor(leave1 / (3600 * 1000))
    //计算相差分钟数  
    var leave2 = leave1 % (3600 * 1000)        //计算小时数后剩余的毫秒数  
    var minutes = Math.floor(leave2 / (60 * 1000))
    //计算相差秒数  
    var leave3 = leave2 % (60 * 1000)      //计算分钟数后剩余的毫秒数  
    var seconds = Math.round(leave3 / 1000)
    var millisecond = leave3 % (60 * 1000)      //计算秒钟数后剩余的毫秒数  
    console.log(" 相差 " + days + "天 " + hours + "小时 " + minutes + " 分钟" + seconds + " 秒" + millisecond+"毫秒") 
  },
  Gogroup:function(e){
    var that = this;
    var myDate = new Date()
    var index = e.currentTarget.id;
    var GroupProduct = that.data.GroupProduct[index];
    var shopCommodityId = GroupProduct.shopCommodityId;
    var groupId = GroupProduct.groupId
    var successNum = GroupProduct.successNum
    var num = GroupProduct.num
    var priceShow = GroupProduct.priceShow
    var endTime = GroupProduct.endTime
    var createTime = myDate.toLocaleString()
    var createTimeOne = createTime.replace("/", "-")
    var createTimeTwo = createTimeOne.replace("/","-")
    var str = createTimeTwo;
    var arr = str.split("");
    arr.splice(11, 2);
    str = arr.join("");
    console.log("时间", endTime, createTime, createTimeTwo, "截取后",str)
    that.GetDateDiff(str,endTime)
    wx.navigateTo({
      url: '../groupDetail/groupDetail?groupId=' + groupId + "&shopCommodityId=" + shopCommodityId + "&successNum=" + successNum + "&num=" + num + "&priceShow=" + priceShow + "&endTime=" + endTime
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})