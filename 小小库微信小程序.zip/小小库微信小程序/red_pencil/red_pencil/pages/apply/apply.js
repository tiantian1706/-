// pages/apply/apply.js

var app = getApp()
var host = app.globalData.host;  
var applyData = {};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    shopName:"",
    address:"",
    name:"",
    contact:"",
    agentId: "",
  },
  shopNameGo: function (e) {
    var that = this;
    that.setData({
      shopName: e.detail.value,
    })
  },
  addressGo: function (e) {
    var that = this;
    that.setData({
      address: e.detail.value
    })
  },
  nameGo: function (e) {
    var that = this;
    that.setData({
      name: e.detail.value
    })
  },
  contactGo: function (e) {
    var that = this;
    that.setData({
      contact: e.detail.value,
    })
  },

  goApply:function(){
    var that = this;
    if (that.data.shopName == "" || that.data.address == "" || that.data.name == "" || that.data.contact == ""){
          wx.showModal({
            title: '温馨提示',
            content: '请完善信息',
          })
    }else{
      applyData = {
        shopName: that.data.shopName,
        address: that.data.address,
        name: that.data.name,
        contact: that.data.contact,
        agentId: that.data.agentId,
      }
      that.getapply(applyData)
    }
  },

  getapply: function (datas) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var dsd = datas;
    console.log("data", datas);
    setTimeout(function(){
      wx.request({
        url: host + 'storeapply/apply',
        data: {
          data: datas,
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          }else{
            wx.showModal({
              title: '温馨提示',
              content: '您的申请已经提交，商家会及时联系您',
              success:function(){
                wx.reLaunch({
                  url: '../indexss/indexss',
                })
              },
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    },500);
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var scene = decodeURIComponent(options.scene);
    console.log("scene", scene);
    that.setData({
      agentId: scene,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})