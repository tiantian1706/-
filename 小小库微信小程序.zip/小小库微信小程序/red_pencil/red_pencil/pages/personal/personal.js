// pages/orderDetail/orderDetail.js

var app = getApp()
var host = app.globalData.host;
var tutu = app.globalData.urlImg;
var util = require('../../utils/util.js');

// 用户信息
Page({

  /**
  * 页面的初始数据
  */
  data: {
    host: host,
    tutu: tutu,
    // bgmsrc: app.globalData.url + "/data/upload/image/chexiaomi/555.png",
    bgmsrc: "../../images/555.jpg",
    avatarUrl:"",
    nickName:"",
    serviceModel: false,
    serviceModel_s: false,
    mydaifukuan: "",
    mydaifahuo: "",
    mydaishouhuo:"",
    zitidaifukuan: "",
    zitidaishiyong:"",
    showLoading: true,
    groupShow: false,
    groupOrderNotPay: 0,
    groupOrderByIng: 0,
    groupOrderNotSend: 0,
    groupOrderNotReceive: 0,
    loginNo: true,
    phoneXs: "",
    shopLogo: "",
    shopName: "",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.hideShareMenu()
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    that.phoneAjax();
  },
  serviceShow: function () {
    var that = this;
    that.setData({
      serviceModel: true,
      serviceModel_s: true
    })
  },
  serviceModel_s_sj: function () {
    var that = this;

    that.setData({
      serviceModel: false,
      serviceModel_s: false
    })
  },

  // 获取电话
  phoneAjax: function () {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      success: function (res) {
        console.log(res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }
        that.setData({
          phoneXs: res.data.data.contact,
          shopLogo: res.data.data.shopLogo,
          shopName: res.data.data.shopName,
        })
      }
    })
  },
  phone: function () {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phoneXs,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },

  getGroup: function () {
    var that = this;
    wx.request({
      url: host + 'groupimage/get',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("拼团", res, that.data.myorder)
        that.setData({
          groupTitle: res.data.data.title
        })
        if (that.data.groupTitle != "") {
          that.setData({
            groupShow: true,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  getGroupOrderState: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + 'grouporder/orderState',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        var notPay = res.data.data.allState.stateByNotPay
        var byIng = res.data.data.allState.stateByIng
        var notSend = res.data.data.allState.stateByNotSend
        var notReceive = res.data.data.allState.stateByNotReceive
        console.log("拼团红点报数", res.data.data.allState);
        that.setData({
          groupOrderNotPay: notPay,
          groupOrderByIng: byIng,
          groupOrderNotSend: notSend,
          groupOrderNotReceive: notReceive,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  //授权登陆
  getUserInfo: function (e) {
    console.log("e", e)
    app.globalData.userInfo = e.detail.userInfo    
    util.login(e, function () {
      wx.reLaunch({
        url: '../personal/personal',
      })
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    
    that.setData({
      avatarUrl: userinfo.avatarUrl,
      nickName: userinfo.nickName,
    });

    if (!userinfo.avatarUrl || userinfo.avatarUrl == "") {
      console.log("未登录")
      that.setData({
        showLoading: false,
      })
      wx.hideLoading();
      return;
    } else {
      that.setData({
        loginNo: false,
      })   
      wx.request({
        url: host + 'order/myXcxOrderLists',
        data: {
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid
        },
        success: function (res) {
          console.log(res);
          if (res.data.code != 0) {
            wx.showModal({
              title: '提示',
              content: res.data.msg,
            });
            return;
          }
          console.log("订单",res);

          that.getGroup();
          that.getGroupOrderState();

          var myorder = [];
          var myorderZiti = [];

          for (var i = 0; i < res.data.data.length; i++) {
            var item = res.data.data[i];
            console.log(item.helpOrderId)
            if (item.helpOrderId == "0" && item.type != "1") {
              myorder.push(item)
            }
          }

          for (var i = 0; i < res.data.data.length; i++) {
            var item = res.data.data[i];
            console.log(item.helpOrderId)
            if (item.helpOrderId == "0" && item.type == "1") {
              myorderZiti.push(item)
            }
          }

          // 我的订单
          var mydaifu = [];
          var mydaifahuo = [];
          var mydaishouhuo = [];
          for (var i = 0; i < myorder.length; i++) {
            var item = myorder[i];
            if (item.state == 1 || item.state == 7) {
              mydaifu.push(item)
            }
            if (item.state == 2) {
              mydaifahuo.push(item)
            }
            if (item.state == 3) {
              mydaishouhuo.push(item)
            }
          }

          // 自提订单
          var zitidaifu = [];
          var zitidaiquhuo = [];
          for (var i = 0; i < myorderZiti.length; i++) {
            var item = myorderZiti[i];
            if (item.state == 1) {
              zitidaifu.push(item)
            }
            if (item.state == 2) {
              zitidaiquhuo.push(item)
            }
          }

          that.setData({
            mydaifukuan: mydaifu.length,
            mydaifahuo: mydaifahuo.length,
            mydaishouhuo: mydaishouhuo.length,
            zitidaifukuan: zitidaifu.length,
            zitidaishiyong: zitidaiquhuo.length,
          },that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          }))

        }
      })
      
    }

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})