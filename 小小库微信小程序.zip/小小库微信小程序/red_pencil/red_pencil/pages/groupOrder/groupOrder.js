//获取应用实例  
var app = getApp();

var config = require('../../config')
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    imageUrl: app.globalData.url,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,
    showLoading: true,
    LinkButton: {},
    myorder: [],
    fukuan: [],
    pintuan: [],
    fahuo: [],
    finsh: [],
    allLength: 0,
    fukuanLength: 0,
    pintuanLength: 0,
    fahuoLength: 0,
    shouhuoLength: 0,
    finshLength: 0,
    payAgainMain: '立即支付',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opc) {
    wx.hideShareMenu()
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    if (opc.currentTab != 0 && opc.currentTab!=null){
      that.setData({
        currentTab: opc.currentTab,
      })
    }
    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });
    that.getOrder();
  },
  getOrder: function () {
    var that = this;
    // 用户信息
    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo)

    var openid = userinfo.openid

    wx.request({
      url: host + 'grouporder/myOrder',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("我的订单！", res)
        var allorder = []
        ,   fukuan = []
        ,   pintuan = []
        ,   fahuo = []
        ,   shouhuo = []
        ,   finsh = [];

        for (var i = 0; i < res.data.data.length; i++) {
          var item = res.data.data[i];
          console.log(item.helpOrderId)
          if (item.state == "1") {
            fukuan.push(item)
          } else if (item.state == "2") {
            pintuan.push(item)
          } else if (item.state == "3") {
            fahuo.push(item)
          } else if (item.state == "4") {
            shouhuo.push(item)
          } else if (item.state == 5 || item.state == 7 || item.state == 8){
            finsh.push(item)
          }
          if (item.state != "6"){
            allorder.push(item)
          }
        }

        that.setData({
          myorder: res.data.data,
          fukuan: fukuan,
          pintuan: pintuan,
          fahuo: fahuo,
          shouhuo: shouhuo,
          finsh: finsh,
          allLength: allorder.length,
          fukuanLength: fukuan.length,
          pintuanLength: pintuan.length,
          fahuoLength: fahuo.length,
          shouhuoLength: shouhuo.length,
          finshLength: finsh.length,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
        console.log("我的订单", that.data.myorder)
      },
      fail: function (res) { },
      complete: function (res) { },
    })

  },

  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  jumpToJion: function (e) {
    var that = this;
    console.log('ashi', e)
    var index = e.currentTarget.dataset.id;
    console.log("groupId", e.currentTarget, that.data.myorder[index].groupId);
    var oderData = that.data.myorder[index]
    wx.navigateTo({
      url: '../groupJoin/groupJoin?title=' + oderData.title + '&sales=' + oderData.sales + '&priceShow=' + oderData.priceShow + '&shopCommodityId=' + oderData.shopCommodityId + '&tagInfoTab_con=' + JSON.stringify(oderData.qrcodeInfo) + '&image=' + oderData.image + '&groupId=' + oderData.groupId + '&num=' + oderData.num + '&groupTopId=' + oderData.groupTopId + '&successNum=' + oderData.successNum + '&disNum=' + oderData.disNum + '&oderData=' + JSON.stringify(oderData) + '&inviteOder=' + 1,
    })
  },
  jumpToDetail: function (e) {
    var that = this;
    console.log('ashi', e)
    var index = e.currentTarget.dataset.id;
    console.log("groupId", e.currentTarget, that.data.myorder[index].groupId);
    wx.navigateTo({
      // url: '../groupDetail/groupDetail',
      url: '../groupDetail/groupDetail?groupId=' + that.data.myorder[index].groupId + "&shopCommodityId=" + that.data.myorder[index].shopCommodityId + "&priceShow=" + that.data.myorder[index].priceShow + "&successNum=" + that.data.myorder[index].successNum + "&num=" + that.data.myorder[index].num,
    })
  },
  jumpToLogistics: function () {
    wx.navigateTo({
      url: '../groupLogistics/groupLogistics',
    })
  },
  btnShare: function () {

  },
  cancel: function (e) {
    var that = this;

    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo)

    var openid = userinfo.openid

    console.log('ashi', e)
    var index = e.currentTarget.dataset.id;
    console.log("groupOrderId", e.currentTarget, that.data.myorder[index].groupOrderId);
    wx.showModal({
      title: '提示',
      content: '确定删除订单吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.request({
            url: host + 'grouporder/orderCancel',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              orderId: that.data.myorder[index].groupOrderId
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            dataType: '',
            success: function (res) {
              that.getOrder();
            },
            fail: function (res) { },
            complete: function (res) { },
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  nowPay: function (e) {
    var that = this;

    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo)

    var openid = userinfo.openid

    console.log('ashi', e)
    var index = e.currentTarget.dataset.id;
    console.log("groupOrderId", e.currentTarget, that.data.myorder[index].groupOrderId);
    wx.request({
      url: host + 'grouporder/repay',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        orderId: that.data.myorder[index].groupOrderId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        console.log("立即付款", res)
        var result = res.data.data;

        wx.requestPayment({
          userId: app.globalData.userId,
          timeStamp: result.timeStamp,
          nonceStr: result.nonceStr,
          package: result.package,
          signType: result.signType,
          paySign: result.paySign,
          success: function (res) {
            that.getOrder();
          },
          fail: function (res) {

          },
          compelete: function (res) {

          }
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  sure: function (e) {
    var that = this
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("个人信息", userinfo)
    console.log("e", e)
    wx.showModal({
      title: '提示',
      content: '是否确认收货？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.request({
            url: host + 'grouporder/receiveOrder',
            dataType: 'json',
            method: 'get',
            data: {
              userId: app.globalData.userId,
              orderId: e.currentTarget.dataset.orderid,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl
            },
            success: function (res) {
              console.log('取消订单', res)
              if (res.data.code == 0) {
                wx.showModal({
                  title: '提示',
                  content: '已确认收货'
                })
                that.getOrder();
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  /** 滑动切换tab  
  */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    console.log('监听页面初次渲染完成');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    console.log('从子页面获取的数据', that.data.sy_quantity)
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    console.log("下拉")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {

    var that = this;
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var userinfo = wx.getStorageSync("userinfo_key");

    console.log('ashi', e)
    var index = e.target.dataset.id;
    console.log("groupId", e.target, that.data.myorder[index].groupId);
    var oderData = that.data.myorder[index]


    // var totalMoney = this.data.product_list.priceShow * this.data.sales
    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res, oderData)
      }
    })
    return {
      title: "快来" + oderData.priceShow + "元拼" + oderData.title,
      path: 'pages/groupJoin/groupJoin?title=' + oderData.title + '&sales=' + oderData.sales + '&priceShow=' + oderData.priceShow + '&shopCommodityId=' + oderData.shopCommodityId + '&tagInfoTab_con=' + JSON.stringify(oderData.qrcodeInfo) + '&image=' + oderData.image + '&groupId=' + oderData.groupId + '&num=' + oderData.num + '&groupTopId=' + oderData.groupTopId + '&successNum=' + oderData.successNum + '&disNum=' + oderData.disNum + '&oderShare=' + 1 + '&oderData=' + JSON.stringify(oderData),
      imageUrl: host + oderData.image,
      success: function (res) {
      },
      fail: function (res) {
        // 转发失败
      }
    }

  }
})

