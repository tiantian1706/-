// pages/couponmy/couponmy.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    url: url,
    coulists: [],
    mycoulist: [],
    showlist: [],
    showLoading: true,
    shopName: "",
  },
  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  todetail: function (er) {
    var that = this;
    // console.log(er.currentTarget.dataset.idx)
    wx.navigateTo({
      url: '../coupondetail/coupondetail?juanarr=' + JSON.stringify(this.data.showlist[er.currentTarget.dataset.idx]),
    })
  },
  lingqu: function (e) {
    var that = this;
    // 用户登陆
    console.log("e", e)
    app.globalData.userInfo = e.detail.userInfo
    if (e.detail.userInfo) {
      console.log("允许")
      var userinfo = wx.getStorageSync("userinfo_key");
      userinfo.nickName = e.detail.userInfo.nickName;
      userinfo.avatarUrl = e.detail.userInfo.avatarUrl;
      console.log("userinfo", userinfo);
      wx.setStorageSync("userinfo_key", userinfo);
      wx.request({
        url: host + 'shopcoupons/receive',
        data: {
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid,
          couponsId: e.currentTarget.dataset.couponsid,
        },
        dataType: 'json',
        method: 'get',
        success: function (rr) {
          if (rr.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: rr.data.msg,
            })
          } else {
            console.log(rr);
            that.couponmyData();
          }
        }
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var allcou = options.allcou;

    console.log("userinfo", userinfo)

    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };


    that.setData({
      allcou: allcou
    });

    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          shopName: res.data.data.shopName,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })

    that.couponmyData();

  },

  addDate: function (date, days) {
    var dates = date.slice(0, 10)
    var day = parseInt(days)
    console.log("date.slice(0,10)", date.slice(0, 10), dates, days, day)
    var d = new Date(dates);
    d.setDate(d.getDate() + day);
    var m = d.getMonth() + 1;
    return d.getFullYear() + '-' + m + '-' + d.getDate();
  },
  //时间
  contrasttime: function (picktime) {
    let nowDate = new Date();
    if (picktime.length < 12) {
      picktime += " 23:59:59"
    }

    var endTime = picktime
    var arr = endTime.split(/[- : \/]/);
    var date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
    var setTime = Date.parse(new Date(date))
    var nowTime = Date.parse(new Date())
    var disTime = setTime - nowTime

    return disTime / 1000;
  },
  //时间

  couponmyData: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        for (let i = 0; i < res.data.data.length; i++) {
          res.data.data[i].sillShow = parseInt(res.data.data[i].sillShow)
          res.data.data[i].moneyNumShow = res.data.data[i].moneyNumShow
        }
        that.setData({
          coulists: res.data.data,
        })
        console.log('优惠劵总列表！！！', that.data.coulists);
        // 我的优惠劵！！
        wx.request({
          url: host + 'shopcoupons/myCoupons',
          data: {
            userId: app.globalData.userId,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            openId: userinfo.openid,
          },
          dataType: 'json',
          method: 'get',
          success: function (ress) {
            for (let i = 0; i < ress.data.data.length; i++) {
              ress.data.data[i].sillShow = parseInt(ress.data.data[i].sillShow)
              ress.data.data[i].moneyNumShow = ress.data.data[i].moneyNumShow
            }
            that.setData({
              mycoulist: ress.data.data,
            })
            console.log('我的优惠劵！！！', that.data.mycoulist);
            if (that.data.allcou != undefined && that.data.allcou == 1) {
              for (let i = 0; i < ress.data.data.length; i++) {
                console.log("时间", that.contrasttime(ress.data.data[i].deadLine))
                if (ress.data.data[i].deadLine != "") {
                  if (that.contrasttime(ress.data.data[i].deadLine) > 0) {
                    that.data.showlist.push(ress.data.data[i]);
                  }
                } else if (ress.data.data[i].deadLine == "") {
                  if (ress.data.data[i].useMethod == "1") {
                    if (that.contrasttime(ress.data.data[i].endTime) > 0) {
                      that.data.showlist.push(ress.data.data[i]);
                    }
                  } else if (ress.data.data[i].useMethod == "2") {

                    ress.data.data[i].deadLineTime = "使用期至：" + that.addDate(ress.data.data[i].createTime, ress.data.data[i].day)

                    if (that.contrasttime(that.addDate(ress.data.data[i].createTime, ress.data.data[i].day)) > 0) {
                      that.data.showlist.push(ress.data.data[i]);
                    }
                  }
                }
              }


              var showlistLen = that.data.showlist.length;

              console.log('长度', showlistLen);


              that.setData({
                showlist: that.data.showlist,
              }, function () {
                that.setData({
                  showLoading: false
                }, function () {
                  wx.hideLoading()
                })
              })
            } else {
              // that.data.coulists[0]["isling"] = "isling";
              var canCouponsData = [];

              for (let i = 0; i < that.data.coulists.length; i++) {
                console.log("时间", that.contrasttime(that.data.coulists[i].deadLine))

                for (let j = 0; j < that.data.mycoulist.length; j++) {
                  if (that.data.coulists[i].couponsId == that.data.mycoulist[j].oldCouponsId) {
                    console.log("isling", that.data.coulists[i])
                    that.data.coulists[i]["isling"] = true;
                    break;
                  } else {
                    that.data.coulists[i]["isling"] = false;
                  }
                }

                if (that.data.coulists[i].deadLine != "") {
                  that.data.coulists[i]["deadLine"] = that.data.coulists[i]["deadLine"].substring(0, 10);
                  if (that.contrasttime(that.data.coulists[i].deadLine) > 0) {
                    canCouponsData.push(that.data.coulists[i]);
                  }
                } else {
                  if (that.data.coulists[i].useMethod == "1") {
                    if (that.contrasttime(that.data.coulists[i].endTime) > 0) {
                      canCouponsData.push(that.data.coulists[i]);
                    }
                  } else if (that.data.coulists[i].useMethod == "2") {
                    that.data.coulists[i].deadLineTime = "领取后" + that.data.coulists[i].day + "天内有效"
                    canCouponsData.push(that.data.coulists[i]);
                  }
                }
              }
              that.setData({
                showlist: canCouponsData,
              }, function () {
                that.setData({
                  showLoading: false
                }, function () {
                  wx.hideLoading()
                })
              })
              console.log("这里是外面点进来的！", that.data.showlist)
            }
          },
          fail: function (res) { }
        })
        // 我的优惠劵！！
      },
      fail: function (res) { }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;

    wx.removeStorageSync('showlistLen');
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */

  onShareAppMessage: function (e) {
    var that = this;
    var couponShareData = [];
    console.log("转发的e", e.target.dataset.couponsid)
    console.log("我的优惠券", that.data.mycoulist)
    for (var i = 0; i < that.data.mycoulist.length; i++) {
      if (that.data.mycoulist[i].couponsId == e.target.dataset.couponsid) {
        couponShareData = that.data.mycoulist[i]
      }
    }

    console.log("转发优惠券数据", couponShareData, that.data.shopName)
    var userinfo = wx.getStorageSync("userinfo_key");

    return {
      title: "您的好友" + userinfo.nickName + "送您一张" + that.data.shopName + "的优惠券，请点击收下",
      imageUrl: "../../images/cupback.png",
      path: 'pages/couponmyShare/couponmyShare?couponShareData=' + JSON.stringify(couponShareData),
      success: function (res) {
        // 转发成功
        console.log('转发成功', res)
      },
      fail: function (res) {
        // 转发失败
      }
    }

  }

})