// pages/redpacket/redpacket.js

var app = getApp()
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showLoading: true,
    one:true,
    two:false,
    myRecordData:{},
    balance: 0,
    getMoney: 0,
    disMoney: 0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.hideShareMenu()
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'client/getClientInfoByXcx',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      dataType: 'json',
      method: 'get',
      success: function (resd) {
        console.log("执行了一个接口", resd);
        if (resd.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: resd.data.msg,
          });
          return;
        }

        console.log("res", resd)

        wx.request({
          url: host + 'ordermoneylog/myRecord',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl
          },
          dataType: 'json',
          method: 'get',
          success: function (res) {
            console.log("执行了一个接口", res);
            if (res.data.code != 0) {
              wx.showModal({
                title: '提示',
                content: res.data.msg,
              });
              return;
            }

            var myRecordData = res.data.data
            var length = myRecordData.length;
            var balance = 0;
            var getMoney = 0;
            var disMoney = 0;
            if (length > 0) {
              for (var i = 0; i < length; i++) {
                if (myRecordData[i].num > 0) {
                  getMoney += parseFloat(myRecordData[i].num)
                }
                if (myRecordData[i].num < 0) {
                  disMoney += parseFloat(myRecordData[i].num)
                }
              };
              disMoney = Math.abs(disMoney);
              balance = Math.abs(getMoney - disMoney);
            }
            console.log("getMoney", balance, getMoney, disMoney)
            that.setData({
              myRecordData: res.data.data,              
              balance: resd.data.data.score,
              getMoney: getMoney,
              disMoney: disMoney,
            }, function () {
              that.setData({
                showLoading: false
              }, function () {
                wx.hideLoading();
              })
            })

          },
          fail: function (res) { }
        })

      },
      fail: function (res) { }
    })

  },

  pitchGo:function(e){
    var that = this;
    var index = e.currentTarget.dataset.index;
    if (index == "1") {
      that.setData({
        one: true,
        two: false,        
      })
    };
    if (index == "2") {
      that.setData({
        one: false,        
        two: true
      })
    };
  },

  integralGo:function(){
    wx.navigateTo({
      url: '../integralShop/integralShop',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})