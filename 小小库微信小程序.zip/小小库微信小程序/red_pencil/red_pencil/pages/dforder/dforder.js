//获取应用实例  

var config = require('../../config')
var app = getApp();
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,

    //待付款
    waitpay: [
      {
        imgsrc: "../../imgs/22.png",
        title: "有礼有节2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "816.00",
        num: "12",
        dates: "2017-08-06"
      },
      {
        imgsrc: "../../imgs/23.png",
        title: "2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "910.00",
        num: "1",
        dates: "2017-08-06"
      }
    ],
    // 待发货
    waitsend: [
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "1",
        dates: "2017-08-06"
      }
    ],
    // 我的订单列表
    myorder: [],
    dingdOneUrl: app.globalData.host + "data/upload/image/xcx/dingd-02.png",
    dingdTwoUrl: app.globalData.host +"data/upload/image/xcx/dingd-01.png",
    dingdFourUrl: app.globalData.host +"data/upload/image/xcx/dingd-04.png",
    dingdFiveUrl: app.globalData.host +"data/upload/image/xcx/dingd-03.png"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that = this;

    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });


    // 用户信息
    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo)

    var openid = userinfo.openid

    wx.request({
      url: app.globalData.host+'order/myXcxOrderLists',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        // console.log(res.data.data)
        var myorder = []
        for (var i = 0; i < res.data.data.length; i++) {
          var item = res.data.data[i];
          console.log(item.helpOrderId)
          if (item.helpOrderId != "0") {
            myorder.push(item)
          }
        }
        console.log("我的订单", myorder)

        that.setData({
          myorder: myorder
        })
      },
      fail: function (res) { },
      complete: function (res) { },
    })


  },


  /** 滑动切换tab 
  */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },


  jumpToDF: function (e) {
    console.log("代付订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];
    console.log("代付订单", order)

    var nickName = wx.getStorageSync("userinfo_key").nickName

    wx.navigateTo({
      url: '../waitpay/waitpay?orderId=' + order.orderId + "&nickName=" + nickName,
    })
  },


  jumpToDFH: function (e) {
    console.log("代发货订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];
    console.log("代发货订单", order)
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    wx.navigateTo({
      url: '../exchangedetail/exchangedetail?orderId=' + order.orderId + "&nickName=" + nickName,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    console.log("下拉")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

