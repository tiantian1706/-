// pages/strawDetail/strawDetail.js

var app = getApp()
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    detailData:[], 
    contentData:[],
    imageUrl: app.globalData.url,
    likeImg:"",
    likeIf:0,
    userCompanyArticleId:"",
    laudNum:0,
    shopCommodityId:0,
    shareNum:0,
    product_list:[],
    showLoading:true,
  },

  // 商品详情
  detail: function (id) {
    var that = this;
    wx.request({
      url: host + 'commodity/get',
      data: {
        shopCommodityId: id
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        that.setData({
          product_list: res.data.data.commodity,
        }, that.setData({
          showLoading: false
        }, function () {
          wx.hideLoading()
        }))
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 文章详情
  article: function (id) {
    var that = this;
    wx.request({
      url: host + 'article/getArticleByUserId',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        var detailData = [];
        for(var i = 0;i<res.data.data.data.length;i++){
          if (res.data.data.data[i].userCompanyArticleId == id) {  
            detailData = res.data.data.data[i];
          }
        };
        if (detailData.content == "") {

          var content = []

        } else {
          var content = JSON.parse(detailData.content)
        }
        console.log("detailData", detailData, content)
        that.setData({
          articleData: detailData,
          contentData: content,
          laudNum: detailData.laudNum,
          shopCommodityId: detailData.shopCommodityId,
          shareNum: detailData.shareNum,
        })   
        if (detailData.shopCommodityId>0){
          that.detail(detailData.shopCommodityId);
        }else{
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  // 点赞
  likeGo:function(){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")    
    wx.request({
      url: host + 'laud/laud',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        userCompanyArticleId: that.data.userCompanyArticleId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        var laudNum = parseInt(that.data.laudNum);
        if (that.data.likeIf == 0){
          that.setData({
            likeImg: "../../images/like02.png",
            likeIf: 1,
            laudNum: laudNum+1
          })
        } else if (that.data.likeIf == 1){
          that.setData({
            likeImg: "../../images/like01.png",
            likeIf: 0,
            laudNum: laudNum-1
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  // 是否点赞
  likeIfGo: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + 'laud/getResult',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        userCompanyArticleId: that.data.userCompanyArticleId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        that.setData({
          likeIf: res.data.data,
        })
        if (res.data.data == 0) {
          that.setData({
            likeImg: "../../images/like01.png",
          })
        } else if (res.data.data == 1){
          that.setData({
            likeImg: "../../images/like02.png",
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  // 详情
  detailGo:function(e){
    var shopcommodityid = e.currentTarget.dataset.shopcommodityid;
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopcommodityid
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log(options);
    that.setData({
      userCompanyArticleId:options.id,
    })
    that.article(options.id);
    that.likeIfGo();
    that.readFhare('readNum');
  },

  // 转发阅读
  readFhare:function(whotext){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + 'article/shareAndRead',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        articleId: that.data.userCompanyArticleId,
        filed: whotext,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }
        console.log("转发成功res", res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;    
    return {
      title: '',
      path: 'pages/strawDetail/strawDetail?id=' + that.data.userCompanyArticleId,
      success: function (res) {
        // 转发成功

        console.log("转发成功")
        that.readFhare('shareNum');
        var shareNum = parseInt(that.data.shareNum);
        that.setData({
          shareNum: shareNum+1
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})