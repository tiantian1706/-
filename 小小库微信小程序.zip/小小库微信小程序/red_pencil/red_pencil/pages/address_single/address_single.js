var area = require('../../data/area')
var p = 0, c = 0, d = 0
Page({
  data:{
    provinceName:[],
    provinceCode: [],
    provinceSelIndex: '',
    cityName: [],
    cityCode: [],
    citySelIndex: '',
    districtName: [],
    districtCode: [],
    districtSelIndex: '',
    showMessage: false,
    messageContent: '',
    showDistpicker: false,
    address_dz: {},
    countyText:true
  },
  onLoad:function(options){
    // 载入时要显示再隐藏一下才能显示数据，如果有解决方法可以在issue提一下，不胜感激:-)
    // 初始化数据

    var that = this;
    var address = wx.getStorageSync('address');
    this.setData({
      address_dz: address
    })
    this.setAreaData()
  },
  setAreaData: function(p, c, d){
    var p = p || 0 // provinceSelIndex
    var c = c || 0 // citySelIndex
    var d = d || 0 // districtSelIndex
    // 设置省的数据
    var province = area['100000']
    var provinceName = [];
    var provinceCode = [];
    for (var item in province) {
      provinceName.push(province[item])
      provinceCode.push(item)
    }
    this.setData({
      provinceName: provinceName,
      provinceCode: provinceCode
    })
    // 设置市的数据
    var city = area[provinceCode[p]]
    var cityName = [];
    var cityCode = [];
    for (var item in city) {
      cityName.push(city[item])
      cityCode.push(item)
    }
    this.setData({
      cityName: cityName,
      cityCode: cityCode
    })
    // 设置区的数据
    var district = area[cityCode[c]]
    var districtName = [];
    var districtCode = [];
    for (var item in district) {
      districtName.push(district[item])
      districtCode.push(item)
    }
    this.setData({
      districtName: districtName,
      districtCode: districtCode
    })
    if (this.data.districtName.length>0){
      this.setData({
        countyText:true
      })
    }else{
      this.setData({
        countyText:false
      })
    }
  },
  changeArea: function(e) {
    p = e.detail.value[0]
    c = e.detail.value[1]
    d = e.detail.value[2]
    this.setAreaData(p, c, d)
  },
  showDistpicker: function() {
    this.setData({
      showDistpicker: true
    })
  },
  distpickerCancel: function() {
    this.setData({
      showDistpicker: false
    })
  },
  distpickerSure: function() {
    this.setData({
      provinceSelIndex: p,
      citySelIndex: c,
      districtSelIndex: d
    })
    this.distpickerCancel()
  },
  savePersonInfo: function(e) {
    var data = e.detail.value
    var telRule = /^1[3|4|5|7|8]\d{9}$/, nameRule = /^[\u2E80-\u9FFF]+$/
    if (data.userName == '') {
      this.showMessage('请输入姓名')
    } else if (!nameRule.test(data.userName)) {
      this.showMessage('请输入中文名')
    } else if (data.telNumber == '') {
      this.showMessage('请输入手机号码')
    } else if (!telRule.test(data.telNumber)) {
      this.showMessage('手机号码格式不正确')
    } else if (data.provinceName == '') {
      this.showMessage('请选择所在地区')
    } else if (data.cityName == '') {
      this.showMessage('请选择所在地区')
    } else if (data.detailInfo == '') {
      this.showMessage('请输入详细地址')
    } else {
      this.showMessage(' 保存成功')
      console.log(data);

      wx.setStorageSync('address', data);

      var pages = getCurrentPages();

      var prevPage = pages[pages.length - 2];

      
      console.log(prevPage)
      prevPage.setData({
          addressData: data,
          addressInfo: data,
          write: false,
          id: false,
          address:true,
          addressCon: data,
          userName: data.userName,
          telNumber: data.telNumber,
          detailInfo: data.provinceName + data.cityName + data.countyName + data.detailInfo,
          addressInfo_userName: data.userName,
          addressInfo_telNumber: data.telNumber,
          addressInfo_provinceName: data.provinceName,
          addressInfo_cityName: data.cityName,
          addressInfo_countyName: data.countyName,
          addressInfo_detailInfo: data.detailInfo,
          addsepon: true
      })

      wx.navigateBack({
        data: 1
      })
    }
  },
  showMessage: function(text) {
    var that = this
    that.setData({
      showMessage: true,
      messageContent: text
    })
    setTimeout(function(){
      that.setData({
        showMessage: false,
        messageContent: ''
      })
    }, 3000)
  }
})