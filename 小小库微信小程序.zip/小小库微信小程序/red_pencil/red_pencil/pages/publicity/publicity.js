// pages/publicity/publicity.js
var app = getApp();
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: app.globalData.url,
    clock: '',
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    imgUrls:[],
    second:'',
    secondHtml:'',
    tiaoguo:true,
  },
  active: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  secondGo:function(){
    var that = this
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("sadjsajkl", res.data.data.countDown)
        var time = res.data.data.countDown;
        if(time==0){
          that.setData({
            secondHtml: "跳过"
          })
        }
        if(time!=0){
          var interval = setInterval(function () {
            var sum = time--;
            console.log(sum)
            that.setData({
              second: sum,
              secondHtml: sum + " s",
              tiaoguo:false,
            })
            if (that.data.second == 0) {
              clearInterval(interval);
              wx.reLaunch({
                url: '../indexss/indexss',
              })
            }
          }, 1000)
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });

  },
  detailGo:function(e){
    var index = e.currentTarget.id;
    console.log(e)
    var shopCommodityId = e.currentTarget.dataset.shopcommodityid
    console.log(shopCommodityId)
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopCommodityId
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */

  
  onLoad: function (options) {
    var that = this
    that.secondGo()
    wx.request({
      url: host + 'activitybanner/xcxBannerList',
      data: {
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("sadjsajkl", res.data.data)
        var length = res.data.data.length
        if (length==0){
          that.active();
        }
        that.setData({
          imgUrls: res.data.data,
          host: host,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})
