// pages/groupJoin/groupJoin.js
var app = getApp();
var host = app.globalData.host;
var util = require('../../utils/util.js')

Page({
  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    imageUrl: app.globalData.url,
    diNum: 2,
    num:false,
    btnText: "立即参团",
    btnType: "",
    teamdetail: [], 
    title: '',
    price: '',
    orderData: {},
    successNum: '',
    img: '',
    groupTopId:0,
    groupTop:[],
    sales:'',
    groupPrice:'',
    groupId:'',
    disNum:"",
    codeType:"",
    codeShow:false,
    latitude: '',
    longitude: '',
    shopAddress:'',
    codeUrl:'',
    redeem:'',
    createTime:'',
    tag:"",
    index:"",
    oderData:{},
    groupNow:false,
    inviteOder:false,
    look:false,
    noLook:false,
    text:"",
    shopCommodityId: "",
    hours: "",
    minutes: "",
    second: "",
    getInfo:[],
    logisticsInfo:[],
    waitShow: true,
    logisticsShow: false,
    showLoading: true
  },
  goIndex: function () {
    wx.reLaunch({
      url: '../indexs/indexs',
    })
  },
  goBuy: function (e) {
    var that=this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      wx:wx.navigateTo({
        url: '../groupCreate/groupCreate?name=' + that.data.title + '&sales=' + that.data.sales + '&priceShow=' + that.data.price + '&shopCommodityId=' + that.data.shopCommodityId + '&icon=' + that.data.img + '&groupId=' + that.data.groupId + '&type=2' + '&groupTopId=' + that.data.groupTopId + '&joinBuy=' + "1" + '&tagArr=' + that.data.tag ,
        success: function(res) {

        },
        fail: function(res) {},
        complete: function(res) {},
      })
    })
  },
  inviteGo: function () {
    console.log("邀请好友")
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("sjshs55454ksh", options);
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    that.setData({
      groupTopId: options.groupTopId,
      diNum:parseInt(options.successNum),
    })
    if (options.oderShare=="1"){
      that.setData({
        oderData: JSON.parse(options.oderData)
      })
    }else{
      that.setData({
        oderData: options
      }) 
    }
    wx.request({
      url: host + 'group/get',
      data: {
        groupId: options.groupId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {

        that.setData({
          groupTop: res.data.data,
        })
        console.log("groupTop!!", res.data.data)
      },
      fail: function (res) { },
      complete: function (res) { },
    })

    wx.request({
      url: host + 'grouptop/getDetailTop',
      data: {
        groupTopId: options.groupTopId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: "该拼团已结束",
            success: function (res) {
              that.goIndex()
            }
          })
          return;
        }
        that.timeGo(res.data.data);
        console.log("倒计时时间", that.data.timeGo)
        console.log("时间们", that.data.hours, that.data.minutes, that.data.second)
        console.log("团队详情:", res.data.data)
        var userinfo = wx.getStorageSync("userinfo_key")
        var idAll = []
        var memberList = res.data.data.memberList
        var idLength = memberList.length
        for (var i = 0; i < idLength; i++) {
          idAll.push(memberList[i].clientId)
        }
        console.log()
        var idArr = idAll.join(",")
        var haveId = idArr.indexOf(userinfo.clientId)
        console.log("是否有参团", haveId)
        var Notime = "2"
        if (that.data.hours <= 0 && that.data.minutes <= 0 && that.data.second <= 0 ){
          Notime = "1"
          that.setData({
            num: false,
          })
        }
        if (haveId == -1){
          if (res.data.data.disNum <= 0) {
            that.setData({
              btnText: "我也要开团",
              text:"拼团结束",
              noLook: true,
              num: false,           
            })
          } else if (res.data.data.disNum > 0 && Notime == "1") {
            console.log("拼团结束")
            that.setData({
              btnText: "重新开团",
              text: "拼团结束",
              noLook: true,
              num: false,
            })
          } else{
            that.setData({
              text: "等待成团",
              btnText: "立即参团",
              num:true,
              groupNow: true,
            })
          }
        }else{
          if (res.data.data.disNum <= 0) {
            that.setData({
              btnText: "查看物流",
              text:"拼团成功",
              look: true,
              num: false,
            })
          } else if(res.data.data.disNum > 0 && Notime == "1"){
            console.log("拼团结束")            
            that.setData({
              btnText: "重新开团",
              text: "拼团结束",
              noLook: true,
              num:false,
            })
          } else{
            console.log("等待成团")
            that.setData({
              btnText: "邀请好友",
              text: "等待成团",
              inviteOder: true,
              num: true,
            })
          }
          // if (res.data.data.disNum > 0 && Notime == "2")
          // if (res.data.data.disNum > 0 && Notime == "1"){
          //   console.log("拼团结束")            
          //   that.setData({
          //     btnText: "重新开团",
          //     text: "拼团结束",
          //     noLook: true,
          //     num:false,
          //   })
          // }else{
          //   that.setData({
          //     text: "等待成团",              
          //     num: true,
          //     inviteOder: true,
          //   })
          // }

        };
        that.setData({
          teamdetail: res.data.data,
          title: options.title,
          price: options.priceShow,
          successNum: options.successNum,
          img: options.image,
          sales: options.sales,
          groupId: options.groupId,
          shopCommodityId: options.shopCommodityId,
          tag: res.data.data.tag,
          disNum: res.data.data.disNum, 
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
        console.log("差人为什么出不来",that.data.disNum)
      }
    })
  },
  headline: function () {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('地址', res);
        that.setData({
          shopName: res.data.data.shopName,
          shopAddress: res.data.data.shopAddress
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  codeHave: function (e) {
    var that = this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      var userinfo = wx.getStorageSync("userinfo_key")      
      that.headline();
      wx.request({
        url: host + 'grouporderqrcode/getQrcode',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          groupTopId: that.data.groupTopId
        },
        dataType: 'json',
        method: 'get',
        success: function (res) {
          console.log("二维码",res)
          that.setData({
            codeShow: true,
            getInfo: res.data.data,
            logisticsInfo: res.data.data.logisticsInfo,
            redeem:res.data.data.code,
            codeUrl: res.data.data.qrcode,
            createTime: res.data.data.createTime,
          })
          var expressName = res.data.data.logisticsInfo.expressName;
          var expressNo = res.data.data.logisticsInfo.expressNo;
          if (expressName && expressNo) {
            console.log("都有");
            that.setData({
              waitShow: false,
              logisticsShow: true,
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      })

    })
  },
  codehide: function () {
    var that = this;
    that.setData({
      codeShow: false,
    })
  },
  tude: function () {
    var that = this
    wx.request({
      url: host + 'notify/navigation',
      data: {
        address: that.data.shopAddress
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        that.setData({
          latitude: res.data.data.lat,
          longitude: res.data.data.lng
        })
        console.log(res)
        console.log("latitude000", that.data.latitude)
        that.getTude();
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  getTude: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        // var latitude = res.latitude
        // var longitude = res.longitude
        wx.openLocation({
          latitude: that.data.latitude,
          longitude: that.data.longitude,
          scale: 28,
          name: that.data.shopName,
          address: that.data.shopAddress
        })
      }
    })
  },
  didian: function () {
    var that = this
    that.tude();
  },
  againBuy:function(){
    var that = this;
    wx.navigateTo({
      // url: '../groupDetail/groupDetail',
      url: '../groupDetail/groupDetail?groupId=' + that.data.groupId + "&shopCommodityId=" + that.data.shopCommodityId + "&priceShow=" + that.data.price + "&successNum=" + that.data.successNum + '&num=' + that.data.oderData.num
    })
  },
  // 倒计时
  timeGo: function (data) {
    var that = this;
    var teamdetail = data;
    var endTime = teamdetail.endTime
    var arr = endTime.split(/[- : \/]/);
    var date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
    var setTime = Date.parse(new Date(date))
    console.log("兼容问题", date, setTime)
    var nowTime = Date.parse(new Date())
    var disTime = setTime - nowTime
    console.log(endTime, "的时间戳", setTime, "现在的时间戳", nowTime, "相隔的时间戳", disTime)    
    
    var hours = Math.floor(disTime / (3600 * 1000))
    console.log("间隔多少小时",hours)  
    
    var leave1 = disTime % 3600000
    console.log("去小时之后余下的毫秒",leave1)
    
    var minutes = Math.floor(leave1 / (60000))
    console.log("间隔多少分钟", minutes)
    
    var leave2 = leave1 % 60000
    console.log("去分钟之后余下的毫秒", leave2)

    var second = leave2 / 1000
    console.log("间隔多少秒", second)
    
    var leave3 = leave2 % 1000
    console.log("去秒之后余下的毫秒", leave3)

    console.log(hours + "小时" + minutes + "分" + second + "秒")

    if (disTime<=0){
      num:false
    }
    that.setData({
      hours: hours,
      minutes: minutes,
      second: second,
      timeGo: hours + "小时" + minutes + "分" + second + "秒"
    })
    var i = setInterval(function () {
      if (hours > 0) {
        second--;
        if (second == 0) {
          second = 59;
          minutes--;
        }
        if (minutes == 0) {
          minutes = 59;
          hours--;
        }
        if (hours == 0) {
          hours = 0;
        }
      } else if (hours == 0 && minutes > 0){
        second--;
        if (second == 0) {
          second = 59;
          minutes--;
        }
        if (minutes == 0) {
          minutes=0;
        }
      } else if (hours == 0 && minutes == 0){
        second--;
        if (second == 0){
          second=0;
          clearInterval(i);
        }
      }
      that.setData({
        hours: hours,
        minutes: minutes,
        second: second,
        timeGo: hours + "小时" + minutes + "分" + second + "秒"
      })
    },1000)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  btnShare: function () {

  },
  onShareAppMessage: function () {
    var that = this;
    var oderData = that.data.oderData
    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res, oderData)
      }
    })
    return {
      title: "快来" + oderData.priceShow + "元拼" + oderData.title,
      path: 'pages/groupJoin/groupJoin?title=' + oderData.title + '&sales=' + oderData.sales + '&priceShow=' + oderData.priceShow + '&shopCommodityId=' + oderData.shopCommodityId + '&tagInfoTab_con=' + JSON.stringify(oderData.qrcodeInfo) + '&image=' + oderData.image + '&groupId=' + oderData.groupId + '&num=' + oderData.num + '&groupTopId=' + oderData.groupTopId + '&successNum=' + oderData.successNum + '&disNum=' + oderData.disNum + '&oderShare=' + 1 + '&oderData=' + JSON.stringify(oderData),
      imageUrl: host + oderData.image,
      success: function (res) {
      },
      fail: function (res) {
        // 转发失败
      }
    }

  }
})
