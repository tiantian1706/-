
var app = getApp()

var util = require('../../utils/util.js');
var WxParse = require('../../wxParse/wxParse.js');
var wezrender = require('../../lib/wezrender');
var pageindex = 1;
var host = app.globalData.host;
var urlImg = app.globalData.urlImg;
var flag = true;
var select_flag = false;

Page({
  data: {
    product_detail: '商品详情',
    discountPriceInfo: {},
    select: false,
    activeIndex: -1,
    tagInfoTab_con: [],
    tagInfoTab_guige: [],
    indicatorDots: false,
    autoplay: true,
    interval: 3000,
    sales: 1,
    guige: '',
    guigecontainer: '',
    isShow: true,
    productSelect: false,
    shopCommodityId: '',
    mypay_con: '',
    laudUrl: null,
    likeImage2: host + "data/upload/image/xcx/cofe03.png",
    likeImage1: host + "data/upload/image/xcx/cofe02.png",
    host: host,
    pay: [
      {
        title: '立即购买'
      },
      {
        title: '朋友代付'
      }
    ],
    animationData: {},
    animationData2: {},
    dispalyModel: false,
    dispalyModelClasShow: false,
    product_list: {},
    tagInfo: {},
    numInfo: {},
    dispalyMode_bottom_btn: '',
    product_list_priceShow_hj: '',
    product_list_priceShow: {},
    product_list_priceShow2: {},
    product_list_priceShow3: {},
    product_list_priceShow4: {},
    product_list_priceShow5: {},
    product_list_priceShow6: {},
    sadasx: false,
    sadjcnxz: '',
    xiangqing: true,
    inventorys: {},
    showLoading: true,
    enjoyClientId: '',
    codeUrl: app.globalData.url,
    mycode: '',
    mycodeUrl: '',
    code_wrap_model: false,
    coulist: [],
    urlImg: urlImg,
    serviceModel: false,
    serviceModel_s: false,
    sceneId: 0,
    logid: 0,
    coulistLength: 0,
    bookingTime: "",
    discountData: {},
  },
  formSubmit: function (e) {
    console.log('form发生了submit事件，携带formId数据为：', e.detail.formId);
    var formId = e.detail.formId;
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + 'xcx/markFormId',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        formId: formId
      },
      success: function (res) {
        console.log(res);
      }
    })
  },
  tocoulist: function (e) {
    var that = this;
    console.log(e.currentTarget.dataset.tcouponsid, that.data.mycoulist)
    wx.navigateTo({
      url: '../coupondetail/coupondetail?juanarr=' + JSON.stringify(that.data.coulist[e.currentTarget.dataset.idx]),
    })
  },
  couling: function (e) {
    var that = this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      console.log(e.currentTarget.dataset.couponsid);
      var userinfo = wx.getStorageSync("userinfo_key");
      wx.request({
        url: host + 'shopcoupons/receive',
        data: {
          couponsId: e.currentTarget.dataset.couponsid,
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            wx.showModal({
              title: '温馨提示',
              content: '领取成功!',
            })
          }
        },
      })
    })
  },
  //时间
  contrasttime: function (picktime) {
    let nowDate = new Date();
    if (picktime.length < 12) {
      picktime += " 23:59:59"
    }

    var endTime = picktime
    var arr = endTime.split(/[- : \/]/);
    var date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
    var setTime = Date.parse(new Date(date))
    console.log("兼容问题", date, setTime)
    var nowTime = Date.parse(new Date())
    var disTime = setTime - nowTime

    return disTime / 1000;

  },
  addmun: function (time) {
    if (time.toString().length < 2) {
      return '0' + time;
    } else {
      return time;
    }
  },
  //时间

  // 点击遮罩层关闭弹出层
  dispalyModelClass: function () {
    this.setData({
      dispalyModel: false,
      dispalyModelClasShow: false,
      codeShow: false,
    })
  },
  serviceModel_s_sj: function () {
    var that = this;

    that.setData({
      serviceModel: false,
      serviceModel_s: false
    })
  },
  // 获取电话
  phoneAjax: function () {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      success: function (res) {
        console.log(res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }
        that.setData({
          phoneXs: res.data.data.contact
        })
      }
    })
  },
  phone: function () {
    var that = this;
    wx.makePhoneCall({
      phoneNumber: that.data.phoneXs,
      success: function (ops) {
        console.log('打电话成功回调', ops)
      },
      fail: function (ops) {
        console.log('打电话失败回调', ops)
      }
    })
  },
  serviceShow: function () {
    var that = this;

    that.setData({
      serviceModel: true,
      serviceModel_s: true
    })
  },

  // 跳转首页
  JumpPage: function () {
    console.log('跳转首页')
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  codeshow: function () {
    var that = this;

    that.setData({
      code_wrap_model: true,
      codeShow: true
    })

    wx.showLoading({
      title: '图片生成中',
    })

    const quImagesUrl = that.data.codeUrl + that.data.product_list.icon[0];

    wx.downloadFile({
      url: quImagesUrl,
      success: function (res) {
        wx.saveFile({
          tempFilePath: res.tempFilePath,
          success: function (res) {
            var savedFilePath = res.savedFilePath;

            wx.downloadFile({
              url: that.data.mycode,
              success: function (res) {
                wx.saveFile({
                  tempFilePath: res.tempFilePath,
                  success: function (res) {
                    var savedFilePath2 = res.savedFilePath;
                    try {
                      var res = wx.getSystemInfoSync()
                      console.log(res.windowWidth)
                      console.log(res.windowHeight)
                      const quWidth = (res.windowWidth * (80 / 100)) + 1;
                      const quHeight = (res.windowHeight * (80 / 100)) + 1;
                      const quHeight_xh = quHeight - quWidth;
                      const quWidthQuHeight_xh = quWidth + quHeight_xh / 2;

                      const zrCanvas = wezrender.zrender.init('code');
                      var sadg = wx.getSystemInfoSync();
                      var xiangsu = sadg.pixelRatio;
                      var image_zr = new wezrender.graphic.Image({
                        style: {
                          x: 0,
                          y: 0,
                          image: savedFilePath,
                          width: quWidth,
                          height: quWidth
                        }
                      });

                      zrCanvas.add(image_zr);

                      var image_zr2 = new wezrender.graphic.Image({
                        style: {
                          x: quWidth - ((quHeight / 5.5) + (quWidth / 20)),
                          y: quWidth + 10,
                          image: savedFilePath2,
                          width: quHeight / 5.5,
                          height: quHeight / 5.5,
                        }
                      });

                      zrCanvas.add(image_zr2);

                      console.log(that.data.product_list.title.split(''))
                      // 


                      function string_jiequ(aryLen, num_s) {
                        var titleLen = aryLen.split('');
                        var title_box = ''
                        for (var i = 0; i < num_s; i++) {

                          title_box += titleLen[i];

                        }

                        if (titleLen.length > num_s) {
                          title_box = title_box + '...'
                        } else {
                          title_box = aryLen;
                        }

                        return title_box;
                      }

                      console.log(string_jiequ(that.data.product_list.title, 10));
                      var text = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 20,
                          text: string_jiequ(that.data.product_list.title, 10),
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '14px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text);

                      var text2 = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 47,
                          text: '￥' + that.data.product_list.priceShow,
                          width: 300,
                          height: 300,
                          fill: 'red',
                          textFont: '18px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text2);

                      var text3 = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 68,
                          text: '到店价：￥' + (that.data.product_list.oldPrice / 100).toFixed(2),
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '14px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text3);
                      function insertStr(str, tar, n, m) {
                        var x = '';

                        var str = str.split('');

                        if (str.length == 0) return;

                        for (var i = n; i < str.length; i += m) {
                          str[i] += tar
                        }

                        x = str.join("");

                        return x;
                      }


                      var string_boxs = string_jiequ(that.data.product_list.introduction, 14);

                      var sdfg = '\n';


                      console.log('文字分段', insertStr(string_boxs, sdfg, 5, 5));
                      if (that.data.product_list.introduction) {
                        var text4 = new wezrender.graphic.Text({
                          style: {
                            x: 10,
                            y: quWidth + 90,
                            text: '推荐理由：' + insertStr(string_boxs, sdfg, 5, 11),
                            width: 300,
                            height: 300,
                            fill: '#000000',
                            textFont: '14px Microsoft Yahei',
                          }
                        });
                        zrCanvas.add(text4);
                      }



                      var text5 = new wezrender.graphic.Text({
                        style: {
                          x: quWidth - ((quHeight / 5.5) + (quWidth / 10)),
                          y: quWidth + quHeight / 5.5 + 30,
                          text: '长按识别小程序码购买',
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '12px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text5);

                      const ctx = wx.createCanvasContext('code');

                      // ctx.drawImage(that.data.mycodeUrl2, 0, 0, quWidth, quWidth);
                      // ctx.save();
                      var sdf = quHeight / 5.5;


                      ctx.setFillStyle('#ffffff');
                      ctx.fillRect(0, quWidth, quWidth, quHeight_xh);
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo(5, quWidth + 63);
                      ctx.lineTo(140, quWidth + 66);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo(quWidth - (sdf + 0), (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, ((quWidth + 15) + (sdf)) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 0)) - 20, (quWidth + 25));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, (quWidth + 25) - 20);
                      ctx.lineTo(quWidth - (sdf + 0), (quWidth + 25) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 10)) + sdf - 20, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 15) + (sdf) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 10)) + sdf - 20, (quWidth + 5));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 5));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 5) + 20);
                      ctx.stroke();
                      ctx.save();
                      ctx.draw();

                      setTimeout(function () {

                        console.log('像素', xiangsu)
                        wx.canvasToTempFilePath({
                          fileType: 'jpg',
                          quality: 1,
                          canvasId: 'code',
                          destWidth: quWidth * xiangsu,
                          destHeight: quHeight * xiangsu,
                          success: function (res) {
                            that.setData({
                              mycodeUrl: res.tempFilePath
                            })
                            console.log("canvas", res.tempFilePath);

                            wx.previewImage({
                              urls: [res.tempFilePath],
                              success: function (res) {
                                console.log('成功')
                                wx.hideLoading();
                                that.setData({
                                  codeShow: false,
                                  code_wrap_model: false
                                })
                              }
                            })
                          },
                          complete: function fail(e) {
                            console.log(e.errMsg);
                          }
                        })
                      }, 800)
                    } catch (e) {
                      // Do something when catch error
                    }

                  }
                });
              }
            })

          }
        })
      }
    })
  },
  // 数量-
  changeNumberJia: function () {
    var that = this;
    var sales = that.data.sales;
    var discountPriceInfo = that.data.discountPriceInfo;

    for (var i = 0, len = discountPriceInfo.length; i < len; i++) {
      if (discountPriceInfo[i][1] == (sales - 1)) {
        console.log("看这里1", sales)
        that.setData({
          product_list_priceShow6: discountPriceInfo[i][2]
        })
      }
      var slen = discountPriceInfo.length;
      var num;
      if (discountPriceInfo[i][1] == (sales - 1)) {

        num = (100 / slen) * (i + 1)
        console.log("执行到了1", (sales - 1))
        console.log('份1', i)
        console.log('份数1', slen)
        that.setData({
          sadjcnxz: num
        }, function () {

        })
      }
      console.log('ss1', (sales - 1), discountPriceInfo[i][1])
    }
    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })

    this.animation = animation

    animation.width(that.data.sadjcnxz + '%').step()
    if (sales > 1) {
      that.setData({
        sales: --sales,
        animationData2: animation.export(),
        product_list_priceShow2: (that.data.product_list_priceShow6 * sales).toFixed(2),
        product_list_priceShow3: (that.data.product_list_priceShow4 * sales).toFixed(2),
        product_list_priceShow5: (that.data.product_list_priceShow * sales).toFixed(2),
      })
    } else {
      return;
    }
  },
  // 数量+
  changeNumberJian: function () {
    var that = this;
    var sales = that.data.sales;

    var discountPriceInfo = that.data.discountPriceInfo;
    var sadjcnxz = that.data.sadjcnxz;
    // console.log(sadjcnxz)

    var animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease'
    })

    this.animation = animation
    // width: { { sadjcnxz } }%
    animation.width(that.data.sadjcnxz + '%').step()
    that.setData({
      sales: ++sales,
      animationData2: animation.export()
    })
    console.log('测试原价', that.data.product_list_priceShow6)

    for (var i = 0, len = discountPriceInfo.length; i < len; i++) {
      if ((discountPriceInfo[i][0]) == sales) {
        console.log("看这里2", sales)
        that.setData({
          product_list_priceShow6: discountPriceInfo[i][2]
        })
      }

      if ((discountPriceInfo[i][1]) == (sales)) {
        var slen = discountPriceInfo.length;
        var num = (100 / slen) * (i + 2);
        console.log("执行到了2", sales)
        console.log('份2', i)
        console.log('份数2', slen)
        that.setData({
          sadjcnxz: num
        })
      }
      console.log('ss2', sales, discountPriceInfo[i][1])
    }

    that.setData({
      product_list_priceShow2: (that.data.product_list_priceShow6 * sales).toFixed(2),
      product_list_priceShow3: (that.data.product_list_priceShow4 * sales).toFixed(2),
      product_list_priceShow5: (that.data.product_list_priceShow * sales).toFixed(2),
    })
  },
  //点击跳到自己购买和找人支付的页面
  productPay: function (e) {
    var that = this;
    var idIndex = e.currentTarget.id;
    var shopCommodityId = that.data.shopCommodityId;
    console.log(idIndex);
    console.log(shopCommodityId);

    if (idIndex == 0) {
      that.setData({
        dispalyModel: true,
        dispalyModelClasShow: true,
        dispalyMode_bottom_btn: '确认购买',
        mypay_con: 'mypay'
      });

      var animation = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease'
      })

      this.animation = animation

      animation.opacity(1).step()

      this.setData({
        animationData: animation.export()
      })
    } else if (idIndex == 1) {
      that.setData({
        dispalyModel: true,
        dispalyModelClasShow: true,
        dispalyMode_bottom_btn: '请人代付',
        mypay_con: 'mypay2'
      });
      var animation = wx.createAnimation({
        duration: 500,
        timingFunction: 'ease'
      })

      this.animation = animation

      animation.opacity(1).step()

      this.setData({
        animationData: animation.export()
      })
    }
  },
  // 关闭弹出层
  dispalyMode_tan_clear: function () {
    var that = this;
    that.setData({
      dispalyModel: false,
      dispalyModelClasShow: false
    })
  },
  mypay: function (e) {
    var that = this;
    app.globalData.userInfo = e.detail.userInfo
    util.login(e, function () {
      var product_list = that.data.product_list;
      console.log("自己下单", that.data.tagInfo, product_list)
      if (!(that.data.tagInfo == '')) {
        if (!that.data.sadasx) {
          wx.showModal({
            title: '提示',
            content: '商品规格不能为空'
          })
          return
        }
      }

      if (product_list.inventory <= 0) {
        wx.showModal({
          title: '提示',
          content: '商品库存不足'
        })
        return
      }

      if (product_list.limitBuy > 0 && that.data.sales > product_list.limitBuy) {
        wx.showModal({
          title: '提示',
          content: '本商品每人限购' + product_list.limitBuy + '件'
        })
        return
      }

      if (that.data.sales > product_list.inventory) {
        wx.showModal({
          title: '提示',
          content: '无法购买，原因：购买数量大于库存'
        })
      } else {
        wx.navigateTo({
          url: '../createOrder2/createOrder2?name=' + that.data.product_list.title + '&sales=' + that.data.sales + '&priceShow=' + that.data.product_list_priceShow + that.data.sales + '&price=' + that.data.product_list.price + '&shopCommodityId=' + that.data.shopCommodityId + '&tagInfoTab_con=' + JSON.stringify(that.data.tagInfoTab_con) + '&icon=' + that.data.product_list.icon[0] + '&backMoney=' + that.data.product_list.backMoney + '&scoreType=' + that.data.product_list.scoreType + '&scorePercent=' + that.data.product_list.scorePercent
        })
      }
    })
  },
  mypay2: function () {
    var that = this;
    console.log('请人代付');
    if (!(that.data.tagInfo == '')) {
      if (!that.data.sadasx) {
        wx.showModal({
          title: '提示',
          content: '商品规格不能为空'
        })
        return
      }
    }
    this.setData({
      isShow: false
    })
    this.createOrder2(this.data.shopCommodityId)
  },
  // 规格选择尺码
  tagInfoTab: function (e) {

    console.log(this.data.sadasx);
    console.log("父类索引", e.currentTarget.dataset.fatherindex);
    var that = this;

    var f_index = e.currentTarget.dataset.fatherindex;
    var z_index = e.currentTarget.id;

    var tagInfo_tab = that.data.tagInfo
    var tagInfoLen = that.data.tagInfo.length
    for (var i = 0, len = tagInfo_tab.length; i < len; i++) {
      var tagInfo_tab_i = tagInfo_tab[i].selected;
      for (var j = 0, c_len = tagInfo_tab_i.length; j < c_len; j++) {
        console.log('测试2', tagInfo_tab_i[j])
      }
    }

    var tagInfoTab_con = that.data.tagInfoTab_con;
    var tagInfoTab_guige = that.data.tagInfoTab_guige;

    var s_L = tagInfoTab_con;

    s_L[f_index] = that.data.tagInfo[f_index].selected[z_index];
    tagInfoTab_con = s_L;

    tagInfoTab_guige[f_index] = z_index;
    console.log(tagInfoTab_guige)
    that.setData({
      guige: tagInfoTab_guige
    });

    var tagInfoTab_con_len = tagInfoTab_con.length
    console.log('测试长度', tagInfoTab_con_len)
    console.log('测试长度2', tagInfoLen)
    console.log('测试长度3', tagInfoTab_guige.length)

    for (var m = 0; m < tagInfoTab_con_len; m++) {
      console.log('ces', tagInfoTab_con[m])
      for (var l = 0; l < tagInfoTab_con[m].length; l++) {
        if (tagInfoTab_con[m][l] == 'undefined') {
          console.log(1)
          that.data.sadasx = true
        }
      }
    }

    if (!(tagInfoTab_con_len != tagInfoLen)) {
      that.data.sadasx = true
    }
    console.log('cxz', tagInfoTab_con, that.data.numInfo)
    var numInfos = that.data.numInfo;
    var tagInfos = that.data.tagInfo;
    var shopCommoditySpecTabIds = [];
    var sw = []
    for (var i = 0, len = tagInfos.length; i < len; i++) {
      shopCommoditySpecTabIds.push(tagInfos[i].shopCommoditySpecTabId)
    }

    for (var i = 0, len = shopCommoditySpecTabIds.length; i < len; i++) {
      console.log('shopCommoditySpecTabIds', shopCommoditySpecTabIds[i]);
    }

    for (var i = 0, len = tagInfoTab_con.length; i < len; i++) {
      sw.push(tagInfoTab_con[i].shopCommoditySpecTabTagId)
      console.log(sw)
    }
    var xkjd = [];
    var osd = -1;
    for (var i = 0, len = numInfos.length; i < len; i++) {
      var selectTag = numInfos[i].selectTag
      var sdx = []
      for (var k in selectTag) {
        sdx.push(selectTag[k])
      }
      xkjd.push(sdx)
    }
    for (var i = 0, len = xkjd.length; i < len; i++) {
      console.log(xkjd[i].sort())
      console.log('规格', sw)
      if ((xkjd[i].sort()).toString() == (sw.sort()).toString()) {
        osd = i;
      }
    }


    if (osd != -1) {
      var osds = numInfos[osd].priceShow
      var ims = numInfos[osd].inventory
      that.setData({
        product_list_priceShow: osds,
        inventorys: ims,
      }, function () {
        console.log('哈哈哈哈')
      })
    } else {
      that.setData({
        product_list_priceShow: that.data.product_list.priceShow
      }, function () {
        console.log('耶耶耶爷爷')
      })
    }
    console.log(numInfos[osd])
    console.log(osd)
  },
  onLoad: function (opt) {
    var that = this;
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    that.phoneAjax();

    console.log("初始化", opt)
    var scene = decodeURIComponent(opt.scene);
    var sceneArray = scene.split(",");
    console.log("不知道是什么鬼东西", scene, sceneArray);
    if (opt.scene) {
      if (scene.indexOf(",") > 0) {
        var sceneText = scene.split(",")
        var sceneOne = sceneText[0]
        that.setData({
          shopCommodityId: sceneOne,
          sceneId: sceneText[1],
        })
      } else {
        that.setData({
          shopCommodityId: scene,
          sceneId: 0
        })
      }
    } else {
      that.setData({
        shopCommodityId: opt.shopCommodityId,
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");
    that.setData({
      enjoyClientId: opt.enjoyClientId,
    })

    console.log('事件对象', opt);
    console.log('别人点进来的数据', that.data.enjoyClientId);

    if (opt.logid) {
      that.setData({
        sceneId: opt.logid,
      })
    }

    console.log("that.data.sceneId", that.data.sceneId)
    console.log("opt.logid", opt.logid)

    if (opt.logid || (opt.scene && that.data.sceneId != 0)) {

      if (userinfo.openid) {
        util.getDistribution(host, app.globalData.userId, userinfo.openid, that.data.sceneId)
      } else {
        util.getOpenId(host, app.globalData.userId, function () {
          userinfo = wx.getStorageSync("userinfo_key");
          util.getDistribution(host, app.globalData.userId, userinfo.openid, that.data.sceneId)
        })
      }

    }

    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, logid);
    if (logindex == 1) {
      that.setData({
        logid: logid
      })
    }
    wx.request({
      url: host + 'xcx/getXcxQrCode',
      data: {
        userId: app.globalData.userId,
        shopCommodityId: that.data.shopCommodityId,
        enjoyClientId: that.data.logid
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('二维码', res.data.data);
        that.setData({
          mycode: that.data.codeUrl + res.data.data
        })
        console.log("二维码", that.data.mycode)
      },
      fail: function (res) { }
    })

    that.setData({
      product_list_priceShow5: (that.data.product_list_priceShow * that.data.sales).toFixed(2)
    })

    console.log("我们不一样", opt.shopCommodityId)
    console.log("有啥不一样", that.data.shopCommodityId)

    that.loadData(that.data.shopCommodityId, function (result) {
      var detail = result.data.data.commodity.detail;
      var res = detail.replace(/src="/g, 'src="' + app.globalData.url);
      var bookingTime = result.data.data.commodity.bookingTime.slice(0, 10);
      WxParse.wxParse('res', 'html', res, that, 0);

      that.setData({
        product_list: result.data.data.commodity,
      })

      that.canCoupons();

      that.setData({
        bookingTime: bookingTime,
        inventorys: result.data.data.commodity.inventory,
        tagInfo: result.data.data.tagInfo,
        numInfo: result.data.data.numInfo,
        product_list_priceShow: result.data.data.commodity.priceShow,
        product_list_priceShow2: result.data.data.commodity.priceShow,
        product_list_priceShow3: result.data.data.commodity.priceShow,
        product_list_priceShow4: result.data.data.commodity.priceShow,
        product_list_priceShow5: result.data.data.commodity.priceShow,
        product_list_priceShow6: result.data.data.commodity.priceShow,
        discountPriceInfo: result.data.data.commodity.discountPriceInfo
      }, function () {
        that.setData({
          showLoading: false
        }, function () {
          wx.hideLoading();
        })
      })
      console.log('商品详情', that.data.product_list, that.data.product_list_priceShow);
      if (detail.length == 0) {
        that.setData({
          xiangqing: false
        })
      }
    })
    // 我的优惠劵！！！
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          mycoulist: res.data.data,
        })
        console.log('我的优惠劵！！！', that.data.mycoulist);
      },
      fail: function (res) { }
    })
    // 我的优惠劵！！！
  },
  canCoupons: function () {

    // 优惠劵列表！！！
    var that = this;
    wx.request({
      url: host + 'shopcoupons/canCoupons',
      data: {
        userId: app.globalData.userId,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.data == '') {
          console.log("优惠劵为空！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！")
        } else {
          var haha = [];
          for (let i = 0; i < res.data.data.length; i++) {

            console.log('!!!!!!!!!!!优惠劵！！！！！！！！！！！', res.data.data)

            res.data.data[i].sillShow = parseInt(res.data.data[i].sillShow)
            res.data.data[i].moneyNumShow = res.data.data[i].moneyNumShow

            if (that.contrasttime(res.data.data[i].deadLine) > 0) {
              if (res.data.data[i].shopCommodityId == '') {
                haha.push(res.data.data[i])
              } else {
                console.log("优惠券优惠券优惠券", res.data.data[i].shopCommodityId)
                var arr = res.data.data[i].shopCommodityId.split(',');
                //检测是不是数组的实例
                console.log(arr);//true
                for (var t = 0; t < arr.length; t++) {
                  if (arr[t] == that.data.product_list.shopCommodityId) {
                    haha.push(res.data.data[i]);
                  }
                }
              }
            }
          }
          that.setData({
            coulist: haha,
            coulistLength: haha.length
          })
          console.log('!!!!!!!!!!!优惠劵！！！', that.data.coulist);
        }
      },
      fail: function (res) { }
    })
    // 优惠劵列表！！！
  },
  loadData: function (condition, cb) {
    wx.request({
      url: host + 'commodity/get',
      data: {
        shopCommodityId: condition
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
    this.likeIf()
  },
  laud: function (res) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    var shopCommodityId = that.data.shopCommodityId;
    wx.request({
      url: host + 'laud/laud',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        shopCommodityId: shopCommodityId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        console.log(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  likeIf: function (res) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    var shopCommodityId = that.data.shopCommodityId;
    wx.request({
      url: host + 'laud/getResult',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        shopCommodityId: shopCommodityId,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        var data = res.data.data
        console.log(data)
        if (data == 0) {
          that.setData({
            laudUrl: true
          })
        } else {
          that.setData({
            laudUrl: false
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  like: function () {
    var that = this;
    that.laud();

    that.setData({
      laudUrl: !that.data.laudUrl
    }, function () {
      that.loadData(that.data.shopCommodityId, function (result) {
        that.setData({
          product_list: result.data.data.commodity,
        })
      })
    });
  },
  createOrder2: function (shopCommodityId) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")

    var tag_array = [];

    var tagInfoTab_con = that.data.tagInfoTab_con;
    for (var i = 0; i < tagInfoTab_con.length; i++) {
      var item = tagInfoTab_con[i].shopCommoditySpecTabTagId;
      tag_array.push(item)
    }
    var tag = tag_array.join(",")

    console.log("商品规格", tag)

    console.log("购买商品的数量", that.data.sales)

    wx.request({
      url: host + 'order/xcxcreateXcxOrder',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        shopCommodityId: shopCommodityId,
        quantity: that.data.sales,
        tag: tag
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        var order_id = res.data.data

        console.log(res)

        that.setData({
          orderId: order_id
        })
      }
    })
  },
  dianzhan: function (e) {
    console.log("点我", e)
  },
  /**
 * 用户点击右上角分享
 */
  onShareAppMessage: function (res) {

    console.log("商品数量", this.data.sales)

    var that = this;
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.updateShareMenu({
      withShareTicket: true,
      success: function (res) {
        console.log('转发事件详情', res)
      }
    })

    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, logid);
    if (logindex == 1) {
      var link = 'pages/productDetail/productDetail?nickName=' + nickName + "&shopCommodityId=" + that.data.shopCommodityId + "&enjoyClientId=" + userinfo.clientId + "&logid=" + logid
    } else {
      var link = 'pages/productDetail/productDetail?nickName=' + nickName + "&shopCommodityId=" + that.data.shopCommodityId + "&enjoyClientId=" + userinfo.clientId
    }
    return {
      title: '',
      path: link,
      success: function (res) {
        // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  onHide: function () {
    this.likeIf()
    this.laud()
  },
  onReady: function () {

  }
})
