// pages/brokerage/brokerage.js
var app = getApp()
var url = app.globalData.url;
var host = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bgmsrc: app.globalData.url+"/data/upload/image/xcx/info.png",
    userInfo: {

    },
    host: app.globalData.url,
    first:true,
    second:false,
    distributionorder: {},
    withdraw: {},
    client: {},
    moneyZhong: {},
    showLoading: true,
  },

  one:function(){
    this.setData({
      first:true,
      second:false
    })
  },
  two:function(){
    this.setData({
      first:false,
      second:true
    })
  },
  withdraw:function(){
    var that = this;
    var withdraw = that.data.withdraw;
    var balance = that.data.client.balance
    console.log("withdraw", balance)
    if (balance/100<1){
      wx.showModal({
        title: '',
        content: '可提现余额不足1元',
        success: function (res) {
        }
      })
    }else{
      
      if (withdraw.length == 0) {
        wx.navigateTo({
          url: '../withdraw/withdraw'
        })
      } else {
        wx.navigateTo({
          url: '../withdraw/withdraw?name=' + this.data.withdraw[0].name + '&phone=' + this.data.withdraw[0].phone + '&bank=' + this.data.withdraw[0].bank + '&bankAcount=' + this.data.withdraw[0].bankAcount
        })
      }
    }

    // if (withdraw.length == 0) {
    //   wx.navigateTo({
    //     url: '../withdraw/withdraw'
    //   })
    // } else {
    //   wx.navigateTo({
    //     // url: '../withdraw/withdraw?name=' + this.data.withdraw[0].name + '&phone=' + this.data.withdraw[0].phone + '&bank=' + this.data.withdraw[0].bank + '&bankAcount=' + this.data.withdraw[0].bankAcount
    //     url: '../withdraw/withdraw'
    //   })
    // }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('监听页面加载')
    var that = this;
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    console.log('监听页面初次渲染完成');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
    var that = this;
    
    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("页面onShow")

    wx.request({
      url: host + '/distributionorder/myRecordByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {

        that.setData({
          distributionorder: res.data.data
        })
        console.log('佣金收入列表', res.data.data)
      },
      fail: function (res) { }
    });

    wx.request({
      url: host + '/client/getClientInfoByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {

        that.setData({
          client: res.data.data
        })
        console.log('我的佣金数据', res.data.data)
      },
      fail: function (res) { }
    });

    wx.request({
      url: host + '/withdraw/myRecord',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {

        that.setData({
          withdraw: res.data.data
        }, function(){
          
          that.setData({
            showLoading: false
          }, function(){
            wx.hideLoading()
          })
        })
        console.log('提现金额', res.data.data)
        if (res.data.data == '') {
          that.setData({
            moneyZhong: "0"
          })
        }
        var numMber = 0;
        for (var i = 0, len = res.data.data.length; i < len; i++) {
          console.log("sdkjd", res.data.data[i].money, res.data.data)
          numMber += Number(res.data.data[i].money)

          if (numMber == null){
            that.setData({
              moneyZhong: "0"
            })
          }else{
            that.setData({
              moneyZhong: numMber
            })
          }
        }
      },
      fail: function (res) { }
    });

    console.log('监听页面显示')
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log('监听页面卸载')
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})