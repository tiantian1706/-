//获取应用实例  

var config = require('../../config')

var app = getApp();
var host = app.globalData.host;
// 用户信息
var userinfo = wx.getStorageSync("userinfo_key")

console.log("用户信息", userinfo)

var openid = userinfo.openid

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,

    //待付款
    waitpay: [
      {
        imgsrc: "../../imgs/22.png",
        title: "有礼有节2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "816.00",
        num: "12",
        dates: "2017-08-06"
      },
      {
        imgsrc: "../../imgs/23.png",
        title: "2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "910.00",
        num: "1",
        dates: "2017-08-06"
      },
    ],
    LinkButton: {},
    // 待发货
    waitsend: [
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "1",
        dates: "2017-08-06"
      }
    ],
    // 我的订单列表
    myorder: [],
    allorder: 0,
    funkaun: 0,
    fahuo: 0,
    shouhuo: 0,
    wancheng: 0,
    shouhou: 0,
    showLoading: true,
    refundShow: true,
    refundHide: false
  },

  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opc) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    if (opc.currentTab != 0 && opc.currentTab != null) {
      that.setData({
        currentTab: opc.currentTab,
      })
    }
    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });

    that.getOrderData()

  },
  reimburse: function (e) {
    console.log(e)
    var that = this;
    var index = e.currentTarget.dataset.index;
    wx.navigateTo({
      url: '../reimburse/reimburse?orderId=' + that.data.myorder[index].orderId + '&image=' + that.data.myorder[index].image + '&title=' + that.data.myorder[index].title + '&description=' + that.data.myorder[index].description + '&orderNo=' + that.data.myorder[index].orderNo + '&priceShow=' + that.data.myorder[index].priceShow,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  reimburseDetails: function (e) {
    console.log(e)
    var that = this;
    var index = e.currentTarget.dataset.index;
    wx.navigateTo({
      url: '../reimburseDetails/reimburseDetails?orderId=' + that.data.myorder[index].orderId + '&image=' + that.data.myorder[index].image + '&title=' + that.data.myorder[index].title + '&description=' + that.data.myorder[index].description + '&orderNo=' + that.data.myorder[index].orderNo + '&priceShow=' + that.data.myorder[index].priceShow,
    })
  },
  payAgain: function (e) {
    var that = this;
    console.log('重新支付', e.currentTarget.dataset.orderid)
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log(userinfo)
    wx.request({
      url: host + 'order/xcxRePay',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        orderId: orderId,
        code: userinfo.code,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {

        var order_id = res.data.data

        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }
        console.log('hq', res)

        wx.request({
          url: host + 'order/xcxxcxPay',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            orderId: order_id
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          success: function (res) {

            var result = res.data.data;

            wx.requestPayment({
              userId: app.globalData.userId,
              timeStamp: result.timeStamp,
              nonceStr: result.nonceStr,
              package: result.package,
              signType: result.signType,
              paySign: result.paySign,
              success: function (res) {
                wx.showToast({
                  title: '支付成功',
                  icon: 'success',
                  duration: 1000
                });
                that.getOrderData();
              },
              fail: function (res) {

              },
              compelete: function (res) {

              }
            })
          }
        })
      },
      fail: function (res) {

      }
    })
  },
  cancellationOfOrder: function (e) {
    var that = this;
    console.log('取消订单')
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.showModal({
      title: '提示',
      content: '确定删除订单吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')

          wx.request({
            url: host + 'order/delOrderByXcx',
            dataType: 'json',
            method: 'get',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              orderId: orderId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl
            },
            success: function (res) {
              console.log('取消订单', res)
              if (res.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: res.data.msg,
                })

                return;
              }
              if (res.data.code == 0) {
                wx.showModal({
                  title: '提示',
                  content: '删除成功'
                })
                that.getOrderData();
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  getOrderData: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'order/myXcxOrderLists',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })

          return;
        }

        var myorder = []
        , funkaun = []
        , fahuo = []
        , shouhuo = []
        , wancheng = []
        , shouhou = [];

        for (var i = 0; i < res.data.data.length; i++) {
          var item = res.data.data[i];
          console.log(item.helpOrderId)
          if (item.helpOrderId == "0" && (item.type == "2" || item.type == "3")) {
            myorder.push(item)
            if (item.state == 7 || item.state == 1) {
              funkaun.push(item)
            }
            if (item.state == 2) {
              fahuo.push(item)
            }
            if (item.state == 3) {
              shouhuo.push(item)
            }
            if (item.state == 5) {
              wancheng.push(item)
            }
            if (item.state == 8) {
              shouhou.push(item)
            }
          }
        }


        that.setData({
          myorder: myorder,
          allorder: myorder.length,
          funkaun: funkaun.length,
          fahuo: fahuo.length,
          shouhuo: shouhuo.length,
          wancheng: wancheng.length,
          shouhou: shouhou.length,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        console.log("我的订单", that.data.myorder)
      },
      fail: function (res) { },
      complete: function (res) { },
    })

  },
  /** 滑动切换tab 
  */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },


  jumpToDF: function (e) {
    var that = this;
    console.log("代付订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = that.data.myorder[index];
    console.log("代付订单", order)

    var nickName = wx.getStorageSync("userinfo_key").nickName

    if (that.data.myorder[index].scoreType==2){
      wx.navigateTo({
        url: '../productDetail2/productDetail2?shopCommodityId=' + order.shopCommodityId + "&nickName=" + nickName,
      })
    }else{
      wx.navigateTo({
        url: '../productDetail/productDetail?shopCommodityId=' + order.shopCommodityId + "&nickName=" + nickName,
      })
    }
  },


  jumpToDFH: function (e) {
    console.log("代发货订单索引", e.currentTarget.dataset.helplist)
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];
    var helplist = e.currentTarget.dataset.helplist;
    console.log("代发货订单", order)
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    wx.navigateTo({
      url: '../exchangedetail2/exchangedetail2?orderId=' + order.orderId + "&nickName=" + nickName + '&myself=' + order.myself + '&helplist=' + helplist,
    })
  },

  sure: function (e) {
    var that = this
    var userinfo = wx.getStorageSync("userinfo_key");    
    wx.showModal({
      title: '提示',
      content: '是否确认收货？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')
          wx.request({
            url: host + 'order/confirmReceive',
            dataType: 'json',
            method: 'get',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              orderId: e.currentTarget.dataset.orderid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl
            },
            success: function (res) {
              console.log('取消订单', res)
              if (res.data.code == 0) {
                wx.showModal({
                  title: '提示',
                  content: '已确认收货'
                })
                that.getOrderData();
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.getOrderData()
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    console.log("下拉")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  another: function (e) {

    console.log('事件对象', e)

    var shopcommodityid_d = e.currentTarget.dataset.shopcommodityid;
    var orderId = e.currentTarget.dataset.orderid;
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    wx.navigateTo({
      url: '../waitpay/waitpay?shopCommodityId=' + shopcommodityid_d + '&orderId=' + orderId + '&nickName=' + nickName,
    })
  },
  onShareAppMessage: function (res) {
    var that = this;
    console.log('分享', res)
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    var orderId = res.target.dataset.orderid
    var imageHrml = res.target.dataset.image
    return {
      title: '您的好友' + nickName + '希望购买以下商品，希望您帮他代付（一份也是爱）',
      path: 'pages/help_pay/help_pay?orderId=' + orderId + "&nickName=" + nickName,
      imageUrl: host + imageHrml,
      success: function (res) {
        // 转发成功
        wx.showModal({
          title: '提示',
          content: '转发朋友成功',
          success: function (res) {
            console.log('转发朋友成功', res);
            if (res.confirm) {
              wx.redirectTo({
                url: '../waitpay/waitpay?orderId=' + orderId + "&nickName=" + nickName,
              })
            } else if (res.cancel) {
              wx.redirectTo({
                url: '../waitpay/waitpay?orderId=' + orderId + "&nickName=" + nickName,
              })
            }
          }
        })
      },
      fail: function (res) {
        // 转发失败
      }
    }
  }
})