// pages/reimburse/reimburse.js
var app = getApp()
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    reimburseTypeModel: false,
    imagesUrl: app.globalData.url,
    tuikuanType: [
      {
        name: '仅退款',
        title: '未收到货（包含未签收）,或卖家协商同意前提下'
      },
      {
        name: '退货退款',
        title: '已收到货，需要退换已收到的货物，请先联系客服'
      }
    ],
    indexs: null,
    reimburseTypeMain: '',
    reimburseTypeMainBox: '',
    reimburseTypeIndex: '',
    reimburseOrderId: null,
    reimburse: {}
  },
  /**
   * 生命周期函数--监听页面加载
   */
  reimburseMiddleShow: function(){
    var that = this;
    that.setData({
      reimburseTypeModel: true
    })
  },
  reimburseTypeModelHide: function() {
    var that = this;
    that.setData({
      reimburseTypeModel: false,
      reimburseTypeMainBox: that.data.reimburseTypeMain
    })
  },
  tuikuanTypeSuan: function(e){
    console.log(e.currentTarget.dataset.indexs);
    var that = this;
    var indexs = e.currentTarget.dataset.indexs;
    that.setData({
      indexs: indexs,
      reimburseTypeMain: that.data.tuikuanType[indexs].name,
      reimburseTypeIndex: indexs + 1
    });
  },
  formSubmit: function(e){
    console.log('提交表单',e);
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var data = {
      type: that.data.reimburseTypeIndex,
      money: e.detail.value.money,
      reason: e.detail.value.cause,
      contact: e.detail.value.phone
    }

    if (that.data.reimburse.backId) {
      wx.request({
        url: host + 'orderback/reApply',
        method: 'get',
        data: {
          userId: app.globalData.userId,
          backId: that.data.reimburse.backId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: data
        },
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '提示',
              content: res.data.msg,
            });

            return;
          }

          wx.showModal({
            title: '提示',
            content: '提交成功',
            success: function(res) {
              if (res.confirm) {
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
          console.log('提交数据', res)
        }
      })
    } else {
      wx.request({
        url: host + 'orderback/apply',
        method: 'get',
        data: {
          userId: app.globalData.userId,
          orderId: that.data.reimburseOrderId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: data
        },
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '提示',
              content: res.data.msg,
            });

            return;
          }

          wx.showModal({
            title: '提示',
            content: '提交成功',
            success: function (res) {
              if (res.confirm) {
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
          console.log('提交数据', res)
        }
      })
    }
  },
  onLoad: function (options) {
    var that = this;
    console.log('接收的参数', options);

    that.setData({
      reimburseOrderId: options.orderId,
      reimburse: options
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})