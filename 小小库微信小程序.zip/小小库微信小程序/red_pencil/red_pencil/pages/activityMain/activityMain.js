
var app = getApp();
Page({
  data: {
    shopCommodityGroupId: '',
    product_list: [],
    product_listL:0,
    headrTitle: '中秋送心意',
    host: app.globalData.host,
    main_con: [],
    showLoading: true,
  },
  onLoad: function(ops){
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    console.log(ops.index)
    that.setData({
      shopCommodityGroupId: ops.activityMain
    });
    that.activityMainAjax(ops.activityMain);
    that.activity_ajax(ops.index);
  },
  productList: function (e) {
    var index = e.currentTarget.id;
    var item = this.data.product_list[index];
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + item["shopCommodityId"]
    })
  },
  activity_ajax: function (vsi){
    var that = this;
    wx.request({
      url: app.globalData.host + 'commoditygroup/xcxGetGroup',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      header: {
        'content-type': 'application/json'
      },
      success: function(res){
        that.setData({
          main_con: res.data.data[vsi]
        })
        wx.setNavigationBarTitle({ title: res.data.data[vsi].title })
      },
      fail: function(res){},
      complete: function(res){}
    })
  },
  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  activityMainAjax: function (condition) {
    var that = this;
    wx.request({
      url: app.globalData.host + 'commodity/xcxGetCommodityByGroupId',
      data: {
        shopCommodityGroupId: condition
      },
      header: {
        'content-type': 'application/json'
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          product_list: res.data.data,
          product_listL:res.data.data.length,
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        console.log(res);
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  }
})