// pages/maidan/maidan.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    money: "",
    stop:true,
    showLoading: true,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    that.headline()
  },

  headline: function (cb) {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          shopName: res.data.data.shopName,
          shopLogo: url + res.data.data.shopLogo,
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  money:function(e){
    var that = this
    var value = e.detail.value
    if (value == ""){
      that.setData({
        stop: true
      })
    } else {
      that.setData({
        stop: false
      })
    }
    that.setData({
      money: value
    })
    console.log(that.data.money)
  },
  payBill: function (e) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    console.log(userinfo)

    wx.request({
      url: host+'bill/createBill',
      data: {
        userId: app.globalData.userId,
        price: that.data.money,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      success: function (res) {
        var billId = res.data.data
        wx.request({
          url: host+'bill/billPay',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            billId: billId,
          },
          success: function (res) {
            var result = res.data.data
            wx.requestPayment({
              'timeStamp': result.timeStamp,
              'nonceStr': result.nonceStr,
              'package': result.package,
              'signType': result.signType,
              'paySign': result.paySign,
              'success': function (res) { },
              'fail': function (res) { },
              'complete': function (res) { }
            })
          },
        })
      }
    })
  }
})