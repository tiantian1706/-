// commodityclassifyList.js
var app = getApp()
var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    product_list:[

    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    // opt.shopCommodityId
    console.log(opt.shopCommodityClassifyId)
    var that = this;
    that.loadData(opt.shopCommodityClassifyId, function (result) {
      console.log(result);
      that.setData({
        product_list: result.data.data,
      })
    })
  },
  loadData: function (condition, cb) {
    wx.request({
      url: host + 'commodityclassify/getAllClassifyInfo',
      data: {
        userId: app.globalData.userId,
        shopCommodityId: condition
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
})