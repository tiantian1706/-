// pages/createOrder2/createOrder2.js
var app = getApp()
var host = app.globalData.host;
var urlImg = app.globalData.url;
var oldImg = app.globalData.urlImg
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hide: false,
    host: app.globalData.host,
    imageUrl: app.globalData.url,
    oldImg: oldImg,
    urlImg: urlImg,
    orderData: {},
    tagInfoTab_con: {},
    showLoading: true,
    labaUrl: oldImg + "/data/upload/image/xcx/xuzhi.png",
    zhifuUrl: app.globalData.host + "data/upload/image/xcx/zhifu.png",
    coulists: [],
    showlist: [],
    mycoulist: [],
    showjuan: false,
    chooseswitch: 0,
    zuizhongjine: 0,
    jianmoney: '',
    qiei: 0,
    write: false,
    shoudong: false,
    myName: "",
    myAddress: "",
    myPhone: "",
    addressCon: [],
    getNameText: "",
    getPhoneText: "",
    buyPhoneText: "",
    codeIf: false,
    getCodeData: {},
    addressView: [],
    myself: "",
    yanse: false,
    btnClick: true,
    // 抵扣币
    deductText: "",
    backMoney: 0,
    deductShow: false,
    discountData: {},
    discountShow: false,
    deductMoney: 0,
    userdeduct: false,
    score: 0,
    scoreType: 0,
  },
  //时间
  contrasttime: function (picktime) {
    let nowDate = new Date();
    if (picktime.length < 12) {
      picktime += " 23:59:59"
    }

    var endTime = picktime
    var arr = endTime.split(/[- : \/]/);
    var date = new Date(arr[0], arr[1] - 1, arr[2], arr[3], arr[4], arr[5]);
    var setTime = Date.parse(new Date(date))
    var nowTime = Date.parse(new Date())
    var disTime = setTime - nowTime

    return disTime / 1000;
  },
  addmun: function (time) {
    if (time.toString().length < 2) {
      return '0' + time;
    } else {
      return time;
    }
  },
  //时间
  //选择地址的
  writeShow: function () {
    this.setData({
      write: true,
      shoudong: false
    })
  },
  dizi: function () {
    var that = this
    wx.chooseAddress({
      success: function (res) {
        console.log(res.userName)
        console.log(res.postalCode)
        // console.log(res.provinceName)
        // console.log(res.cityName)
        // console.log(res.countyName)
        console.log(res.detailInfo)
        console.log(res.nationalCode)
        console.log(res.telNumber)
        wx.setStorageSync('address', res);
        that.setData({
          addressCon: res,
          userName: res.userName,
          telNumber: res.telNumber,
          provinceName: res.provinceName,
          cityName: res.cityName,
          countyName: res.countyName,
          detailInfo: res.provinceName + res.cityName + res.countyName + res.detailInfo,
          id: false,
          address: true,
          write: false,
          shoudong: false
        })
      }
    })
  },
  shoudong: function () {
    wx.navigateTo({
      url: '../address_single/address_single',
    })
  },
  writeHide: function () {
    this.setData({
      write: false,
      shoudong: false
    })
  },
  // 选择地址的
  closejuanb: function (er) {
    this.setData({
      showjuan: false,
      deductShow: false,
    })
  },
  nahuo: function (e) {
    // this.data.
    // console.log(e.target.dataset.na)
    var that = this;
    var ji = e.target.dataset.na
    this.setData({
      qiei: ji,
    })
  },
  showjuanb: function (er) {
    this.setData({
      showjuan: true,
    })
  },
  switch1Change: function (ee) {
    var that = this;
    var index = that.data.chooseswitch;
    var jianmoney = that.data.jianmoney;
    var zuizhongjine = that.data.zuizhongjine;
    that.setData({
      chooseswitch: ee.currentTarget.dataset.idx,
    })
    switch (parseInt(ee.currentTarget.dataset.jutype)) {
      case 1:
        console.log("类型1满减卷", that.data.mycoulist[ee.currentTarget.dataset.idx]);
        // that.data.orderData.priceShow
        // that.data.mycoulist[ee.currentTarget.dataset.idx].sill
        that.setData({
          jianmoney: (that.data.orderData.priceShow * that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 ? "未满" + that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 + '元' : '减' + that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 100 + '元'),
          zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales) - (that.data.orderData.priceShow * that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 ? 0 : that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 100),
        })
        if (that.data.orderData.priceShow * that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100) {
          that.showerr("未满" + that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 + '元');
          that.setData({
            chooseswitch: index,
            jianmoney: jianmoney,
            zuizhongjine: zuizhongjine,
          })
        }
        console.log("js计算的！", that.data.jianmoney, that.data.zuizhongjine)
        break;
      case 2:
        console.log("类型2现金卷", that.data.mycoulist[ee.currentTarget.dataset.idx]);
        that.setData({
          jianmoney: '减' + that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 100 + '元',
          zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales) - that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 100,
        })
        if ((that.data.orderData.priceShow * that.data.orderData.sales) <= that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 100) {
          that.showerr("购买产品总价低于或等于优惠金额");
          that.setData({
            chooseswitch: index,
            jianmoney: jianmoney,
            zuizhongjine: zuizhongjine,
          })
        }
        console.log("js计算的！", that.data.jianmoney, that.data.zuizhongjine)
        break;
      case 3:
        console.log("类型3折扣卷", that.data.mycoulist[ee.currentTarget.dataset.idx]);
        var texjian = ((that.data.orderData.priceShow * that.data.orderData.sales) * (1 - that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 1000)).toFixed(2).toString();
        that.setData({
          jianmoney: (that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 ? "未满" + that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 + '件' : '减' + texjian + '元'),
          zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales) - (that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 ? 0 : (that.data.orderData.priceShow * that.data.orderData.sales) * (1 - that.data.mycoulist[ee.currentTarget.dataset.idx].moneyNum / 1000)),
        })
        if (that.data.orderData.sales < that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100) {
          that.showerr("未满" + that.data.mycoulist[ee.currentTarget.dataset.idx].sill / 100 + '件');
          that.setData({
            chooseswitch: index,
            jianmoney: jianmoney,
            zuizhongjine: zuizhongjine,
          })
        }
        console.log("js计算的！", that.data.jianmoney, that.data.zuizhongjine)
        break;
    }
  },
  nouser: function (e) {
    var that = this;
    that.setData({
      chooseswitch: -1,
      jianmoney: '未使用优惠劵',
      zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales),
    })
  },
  showerr: function (text) {
    wx.showModal({
      title: '温馨提示',
      content: text,
    })
  },
  // 是否扫店铺二维码进入小程序：若为data空，就不是，不能到店自提
  goCode: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    wx.request({
      url: host + 'store/checkStoreMember',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          var resLength = Object.getOwnPropertyNames(res.data.data).length;
          console.log("扫码进来", res.data.data, resLength);
          if (resLength > 1) {
            that.setData({
              codeIf: true,
              getCodeData: res.data.data,
            })
          } else {
            that.setData({
              qiei: 1,
            })
          }
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },

  // 抵扣币
  deductGo: function () {
    var that = this;
    that.setData({
      deductShow: true
    })
  },

  // 使用抵扣币
  userdeductGo: function () {
    var that = this;
    var num = (that.data.discountData.maxDiscount / 100).toFixed(2);
    that.setData({
      userdeduct: true,
      deductText: '减' + num + '元',
      deductMoney: num,
      score: 1,
    })
  },

  // 不使用抵扣币
  nodeduct: function () {
    var that = this;
    that.setData({
      userdeduct: false,
      deductText: '未使用红包',
      deductMoney: 0,
      score: 0,
    })
  },

  // 抵扣币

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    var that = this;
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");
    var address = wx.getStorageSync('address');
    console.log("商品详情!!!!!!!!!!!!!!!!：", options, address);
    if (options.scoreType == "2") {
      that.setData({
        qiei: 1
      })
    }
    that.setData({
      orderData: options,
      tagInfoTab_con: JSON.parse(options.tagInfoTab_con),
      backMoney: options.backMoney,
      scoreType: options.scoreType,
    }, function () {
      that.setData({
        showLoading: false
      }, function () {
        wx.hideLoading();
      })
    })

    // 红包抵扣
    var tag_array = [];
    var tagInfoTab_con = that.data.tagInfoTab_con;
    for (var i = 0; i < tagInfoTab_con.length; i++) {
      var item = tagInfoTab_con[i].shopCommoditySpecTabTagId;
      tag_array.push(item)
    }
    var tag = tag_array.join(",")

    wx.request({
      url: host + 'order/getByDeduction',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        shopCommodityId: that.data.orderData.shopCommodityId,
        quantity: that.data.orderData.sales,
        tag: tag
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("执行了一个接口", res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          });
          return;
        }
        that.setData({
          discountData: res.data.data,
        })

        console.log("有可用的红包吗？", that.data.backMoney, that.data.discountData)

        // if (that.data.backMoney > 0 && that.data.discountData.maxDiscount > 0) {
        if (that.data.discountData.maxDiscount > 0) {
          var num = (that.data.discountData.maxDiscount / 100).toFixed(2);
          that.setData({
            discountShow: true,
            deductText: "减" + num + "元",
            deductMoney: num,
            userdeduct: true,
            score: 1,
          })
        } else {
          that.setData({
            discountShow: false,
            deductText: "无可用红包"
          })
        }

      },
      fail: function (res) { }
    })

    // 红包抵扣


    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {

          var haha = [];

          for (let i = 0; i < res.data.data.length; i++) {

            if (that.contrasttime(res.data.data[i].deadLine) > 0) {
              if (res.data.data[i].shopCommodityId == '') {
                haha.push(res.data.data[i])
              } else {
                console.log("优惠券优惠券优惠券", res.data.data[i].shopCommodityId)
                var arr = res.data.data[i].shopCommodityId.split(',');
                //检测是不是数组的实例
                console.log(arr);//true
                for (var t = 0; t < arr.length; t++) {
                  if (arr[t] == that.data.orderData.shopCommodityId) {
                    haha.push(res.data.data[i]);
                  }
                }
              }
            }

          }

          that.setData({
            mycoulist: haha,
          })

          // 优惠券列表判断

          var nouseData = [];
          var useData = [];

          if (haha.length > 0) {
            for (var i = 0; i < haha.length; i++) {
              if (haha[i].type == "2" || haha[i].type == "1") {
                haha[i].moneyEnd = haha[i].moneyNum / 100
              } else {
                haha[i].moneyEnd = that.data.orderData.priceShow * that.data.orderData.sales * (1 - haha[i].moneyNum / 1000)
              }
            }
            console.log('我的优惠劵！！！', that.data.mycoulist, haha.length, that.data.orderData.priceShow * that.data.orderData.sales);

            for (var i = 0; i < haha.length; i++) {
              if (haha[i].type == 1) {
                if ((that.data.orderData.priceShow * that.data.orderData.sales) < (haha[i].sill / 100)) {
                  nouseData.push(haha[i])
                } else {
                  if ((that.data.orderData.priceShow * that.data.orderData.sales) > haha[i].moneyEnd) {
                    useData.push(haha[i])
                  }
                }
              } else {
                if (that.data.orderData.sales < (haha[i].sill / 100)) {
                  nouseData.push(haha[i])
                } else {
                  if ((that.data.orderData.priceShow * that.data.orderData.sales) > haha[i].moneyEnd) {
                    useData.push(haha[i])
                  }
                }
              }
            }

            var ary = useData;

            if (ary.length > 0) {
              var maxN = ary[0].moneyEnd;
              var minN = ary[0].moneyEnd;
              if (ary.length > 0) {
                for (var i = 0; i < ary.length; i++) {
                  var cur = ary[i].moneyEnd;
                  cur > maxN ? maxN = cur : null;
                  cur < minN ? minN = cur : null;
                }
              }

              var maxData = [];

              for (var i = 0; i < ary.length; i++) {
                if (ary[i].moneyEnd == maxN) {
                  maxData.push(ary[i])
                }
              }

              var whoIndex = 0;
              for (var i = 0; i < haha.length; i++) {
                if (haha[i].couponsId == maxData[0].couponsId) {
                  whoIndex = i;
                }
              }

              console.log("不能使用", nouseData, "可使用", useData, "mycoulist", that.data.mycoulist, "haha", haha, 'maxN', maxN, 'minN', minN, "maxData", maxData, "whoIndex", whoIndex)
            }

          }

          // 优惠券列表判断

          if (haha.length > 0) {
            if (useData.length > 0 && that.data.scoreType == 1) {
              that.setData({
                chooseswitch: whoIndex,
                jianmoney: '减' + maxData[0].moneyEnd.toFixed(2) + "元",
                zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales) - maxData[0].moneyEnd,
                yanse: false,
              })
            } else {
              that.setData({
                chooseswitch: -1,
                jianmoney: '有可用优惠劵',
                zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales),
                yanse: false,
              })
            }
          } else {
            that.setData({
              chooseswitch: -1,
              jianmoney: '无可用优惠劵',
              yanse: true,
              zuizhongjine: (that.data.orderData.priceShow * that.data.orderData.sales),
            })
          }

        }
      },
      fail: function (res) { }
    })
    console.log('初始化对象', that.data.orderData);
    console.log('规格', that.data.tagInfoTab_con)
  },
  payment: function () {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.request({
      url: host + 'client/getClientInfoByXcx',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log("执行了一个接口", res);
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: resd.data.msg,
          });
          return;
        }

        that.setData({
          scoreDis: res.data.data.score - that.data.orderData.scorePercent / 100 * that.data.orderData.sales
        })

        if (that.data.scoreDis>0){
          that.setData({
            btnClick: false,
          })

          var couponsId;
          if (that.data.chooseswitch == -1) {
            couponsId = 0;
            console.log("点击后的oldCouponsId", couponsId)
          } else {
            couponsId = that.data.mycoulist[that.data.chooseswitch].couponsId;
            console.log("点击后的oldCouponsId", couponsId)
          }

          that.createOrder(that.data.orderData.shopCommodityId, couponsId)
        }else{
          wx.showModal({
            title: '提示',
            content: '您的酷币不足~',
          })
        }
      }
    })

  },
  getName: function (e) {
    var that = this;
    that.setData({
      getNameText: e.detail.value
    })
  },
  getPhone: function (e) {
    var that = this;
    that.setData({
      getPhoneText: e.detail.value
    })
  },
  buyPhone: function (e) {
    var that = this;
    that.setData({
      buyPhoneText: e.detail.value
    })
  },
  createOrder: function (shopCommodityId, oldCouponsId) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    var tag_array = [];
    var tagInfoTab_con = that.data.tagInfoTab_con;
    for (var i = 0; i < tagInfoTab_con.length; i++) {
      var item = tagInfoTab_con[i].shopCommoditySpecTabTagId;
      tag_array.push(item)
    }
    var tag = tag_array.join(",")

    if (that.data.qiei == 0) {
      if (that.data.getNameText == "" || that.data.getPhoneText == "") {
        wx.showModal({
          title: '提示',
          content: '请完善取货人信息',
        })

        that.setData({
          btnClick: true,
        })

        return;
      } else {
        wx.setStorageSync("getNameText", that.data.getNameText)
        wx.setStorageSync("getPhoneText", that.data.getPhoneText)
        that.setData({
          myself: "1",
          myName: that.data.getNameText,
          myAddress: "",
          myPhone: that.data.getPhoneText,
        })
      }
    }
    if (that.data.qiei == 1) {
      if (that.data.addressCon.length == 0) {
        wx.showModal({
          title: '提示',
          content: '请填写收货地址',
        })

        that.setData({
          btnClick: true,
        })

        return;
      } else {
        that.setData({
          myself: "1",
          myName: that.data.addressCon.userName,
          myAddress: (that.data.addressCon.provinceName || '') + (that.data.addressCon.cityName || '') + (that.data.addressCon.countyName || '') + that.data.addressCon.detailInfo,
          myPhone: that.data.addressCon.telNumber,
        })
      }
    }
    if (that.data.qiei == 2) {
      if (that.data.buyPhoneText == "") {
        wx.showModal({
          title: '提示',
          content: '请填写购买人联系方式',
        })

        that.setData({
          btnClick: true,
        })

        return;
      } else {
        wx.setStorageSync("buyPhoneText", that.data.buyPhoneText)
        that.setData({
          myself: "2",
          myName: "",
          myAddress: "",
          myPhone: that.data.buyPhoneText,
        })
      }
    }

    var ruhe = parseInt(that.data.qiei) + 1

    var postData = {
      shopCommodityId: shopCommodityId,
      quantity: that.data.orderData.sales,
      tag: tag,
      couponsId: oldCouponsId,
      type: ruhe,
      name: that.data.myName,
      address: that.data.myAddress,
      phone: that.data.myPhone,
      myself: that.data.myself,
      score: that.data.score,
    }

    console.log("postData", postData, ruhe, that.data.orderData.price, "myself", that.data.myself, "qiei",that.data.qiei)

    if (that.data.orderData.price>0){
      console.log("有钱")

      wx.request({
        url: app.globalData.host + 'order/xcxCreateXcxOrderByScore',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: postData,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {

          var order_id = res.data.data
          console.log('hq', res)

          wx.request({
            url: app.globalData.host + 'order/xcxxcxPay',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              orderId: order_id
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            success: function (res) {

              var result = res.data.data;
              if (res.data.code != 0) {
                var text = res.data.msg
                wx.showModal({
                  title: '提示',
                  content: text,
                })
                that.setData({
                  btnClick: true,
                })
                return;
              }

              wx.requestPayment({
                userId: app.globalData.userId,
                timeStamp: result.timeStamp,
                nonceStr: result.nonceStr,
                package: result.package,
                signType: result.signType,
                paySign: result.paySign,
                success: function (res) {
                  console.log("微信支付了")                  
                  if (that.data.qiei == 0) {
                    wx.redirectTo({
                      url: '../myorder/myorder?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId,
                    })
                  }
                  if (that.data.qiei == 1) {
                    wx.redirectTo({
                      url: '../myorder2/myorder2?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId,
                    })
                  }
                  if (that.data.qiei == 2) {
                    wx.redirectTo({
                      url: '../exchangedetail2/exchangedetail2?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId,
                    })
                  }
                },
                fail: function (res) {
                  console.log("微信支付，用户点击了取消")
                  that.setData({
                    btnClick: true,
                  })
                },
                compelete: function (res) {

                }
              })
            }
          })
        }
      })

    }else{
      console.log("没钱")

      wx.request({
        url: app.globalData.host + 'order/xcxCreateXcxOrderByNotMoney',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          data: postData,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function (res) {
          if (res.data.code != 0) {
            var text = res.data.msg
            wx.showModal({
              title: '提示',
              content: text,
            })
            that.setData({
              btnClick: true,
            })
            return;
          }
          var order_id = res.data.data
          wx.redirectTo({
            url: '../myorder2/myorder2?orderId=' + order_id + "&nickName=" + userinfo.nickName + "&shopCommodityId=" + shopCommodityId,
            success: function (res) {
              that.setData({
                btnClick: true,
              })
            },            
          })
        }
      })
    }
  },
  ruleBox: function () {
    this.setData({
      hide: true
    })
  },
  hideBox: function () {
    this.setData({
      hide: false
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var phone_key = wx.getStorageSync('phone_key');
    console.log('Storage——phone', phone_key);
    var address = wx.getStorageSync('address');
    var buyPhoneTextHave = wx.getStorageSync('buyPhoneText');
    var getPhoneTextHave = wx.getStorageSync('getPhoneText');
    var getNameTextHave = wx.getStorageSync('getNameText');
    console.log("有没有东西", address)

    that.setData({
      telephone: phone_key,
      addressView: address,
      addressCon: address,
      userName: address.userName,
      telNumber: address.telNumber,
      detailInfo: address.detailInfo,
      provinceName: address.provinceName,
      cityName: address.cityName,
      countyName: address.countyName,
    })
    if (buyPhoneTextHave) {
      that.setData({
        buyPhoneText: buyPhoneTextHave,
      })
    }
    if (getPhoneTextHave || getNameTextHave) {
      that.setData({
        getPhoneText: getPhoneTextHave,
        getNameText: getNameTextHave,
      })
    }
    that.goCode();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})