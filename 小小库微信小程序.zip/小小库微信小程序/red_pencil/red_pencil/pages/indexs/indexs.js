// pages/indexs/indexs.js
// var config = request('../../config');
var app = getApp();
var host = app.globalData.host;
var pagesize = 10;
var pageindex = 0;
var userId = 10365;


var condition = {};
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [],
    host: "",
    index: '',
    headrTitle: '中秋送心意',
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    product_list: [],
    main_con: [],
    jiazaizhong: ''
  },

  // 根据条件加载列表
  loadData: function (page_index, condition, cb){
    wx.request({
      url: host + 'commodityindex/xcxGetCommodityIndex',
      data: {
        pageSize: pagesize,
        pageIndex: page_index,
        condition: condition,
        userId: userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function(res) {
        cb(res)
      },
      fail: function(res) {},
      complete: function(res) {}
    });
  },
  _data_lunbo_Ajax:function(){
    var that = this;
    wx.request({
      url: host+'banner/xcxBannerList',
      data: {
        userId: userId
      },
      method: 'get',
      dataType: 'json',
      success: function(res) {
        that.setData({
          imgUrls: res.data.data
        })
        console.log(res)
      },
      fail: function(res) {},
      complete: function(res) {}
    })
  },
  _data_activity_Ajax: function(){
    var that = this;
    wx.request({
      url: host+'commoditygroup/xcxGetGroup',
      data: {
        userId: userId
      },
      method: 'get',
      dataType: 'json',
      success: function(res) {
        that.setData({
          main_con: res.data.data,
          host: host
        })

        console.log(res);
      },
      fail: function(res) {},
      complete: function(res){}
    })
  },
  initData: function(){
    var that = this;
    that.loadData(pageindex, condition, function (result) {
      console.log(result)
      that.setData({
        product_list: result.data.data,
        host: host
      })
     
    });
  },
  maincon_btn: function(e){
    var that = this;
    var idIndex = e.currentTarget.id;
    var a_Index = this.data.main_con[idIndex];
    wx.navigateTo({
      url: '../activityMain/activityMain?activityMain=' + a_Index["shopCommodityGroupId"] + '&index=' + idIndex
    })
  },
  productList: function(e){
    var index = e.currentTarget.id;
    var item = this.data.product_list[index];
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + item["shopCommodityId"]
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.initData();
    this._data_lunbo_Ajax();
    this._data_activity_Ajax();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  loadMore: function(condition, cb){
    var that = this;

    if (pagesize * pageindex > length) {
      return;
    } else {
      pageindex++;
      that.loadData(pageindex, condition, function (result){
        cb(result)
      })
    }
  },
  onReachBottom: function () {
    console.log('加载中。。。。');
    var that = this;
    that.loadMore(condition, function(){
      var p_list = that.data.product_list;
      that.loadData(pageindex, condition, function(result){
        var pList = p_list.concat(result.data.data);
        that.setData({
          product_list: pList
        })
      })
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})