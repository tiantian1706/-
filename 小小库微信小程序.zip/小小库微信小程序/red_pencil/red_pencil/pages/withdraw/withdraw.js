// pages/withdraw/withdraw.js
var app = getApp()

var host = app.globalData.host;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    _data: {
      name: "",
      phone:"",
      bank: "",
      bankAcount: "",
      money: ""
    },
    showLoading: true,
    accountRecord: {},
    moneyZhong: {},
    qian:"",
    host:host,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    console.log('页面参数',options)
    that.setData({
      accountRecord: options
    })
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + '/distribution/getByClientIdByXcx',
      dataType: 'json',
      method: 'get',
      data:{
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        data: that.data._data
      },
      success: function(res) {
        console.log(res.data.data)
      },
      fail: function(res) {
      }
    })

    wx.request({
      url: host + '/client/getClientInfoByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      success: function (res) {
        console.log(res.data.data)
        that.setData({
          moneyZhong: res.data.data.balance
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
      },
      fail: function (res) {

      }
    })

    var money = that.data.moneyZhong
  },
  formSubmit: function(e){
    var that = this
    console.log(e.detail.value);

    that.setData({
      _data: e.detail.value
    })
    
    var data = that.data._data;
    var name = data.name;
    var phone = data.phone;
    var bank = data.bank;
    var bankAcount = data.bankAcount;
    var money = data.money
    if (name.length == 0 || phone.length == 0 || bank.length == 0 || bankAcount.lenght == 0 || money.lenght == 0){
          wx.showModal({
            title: '',
            content: '请完善个人信息',
            success: function (res) {
              return;
            }
          })
        }else{
            var userinfo = wx.getStorageSync("userinfo_key")
            if (that.data.qian < 1) {
              wx.showModal({
                title: '',
                content: '请输入正确的提现金额',
                success: function (res) {
                }
              })
              return false
            } else {
              wx.request({
                url: host + '/withdraw/drawByXcx',
                dataType: 'json',
                method: 'get',
                data: {
                  userId: app.globalData.userId,
                  openId: userinfo.openid,
                  nickName: userinfo.nickName,
                  headImgUrl: userinfo.avatarUrl,
                  data: that.data._data
                },
                success: function (res) {
                  console.log("dfsafsaf", res.data.code)
                  if (res.data.code !== 0){
                    wx.showModal({
                      title: '',
                      content: '余额不足',
                      success: function (res) {
                      }
                    })
                  }else{
                    that.setData({
                      yes:true
                    })
                  }
                },
                fail: function (res) {}
              })
          }
      }
    console.log('saxmz', this.data._data)
  },
  money:function(e){
    this.setData({
      qian: e.detail.value
    })
  },
  guanbi:function(){
    this.setData({
      yes:false
    })
  },
  shuaxing:function(){
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key")
    wx.request({
      url: host + '/client/getClientInfoByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
      },
      success: function (res) {
        console.log(res.data.data)
        that.setData({
          moneyZhong: res.data.data.balance,
          yes: false          
        })
      },
      fail: function (res) {

      }
    })
    wx.navigateBack();    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})