// pages/indexs/indexss.js
// var config = request('../../config');
var app = getApp();
var host = app.globalData.host;
var pagesize = 50;
var pageindex = 0;
var condition = {};
Page({

  /**
   * 页面的初始数据
   */
  data: {
    imgUrls: [],
    host: "",
    scrollTop: 0,
    hidden: true,
    scrollHeight: 0,
    index: '',
    headrTitle: '中秋送心意',
    indicatorDots: true,
    autoplay: true,
    interval: 3000,
    duration: 1000,
    product_list: [],
    jiazaizhong: '',
    headrTitle: '',
    showLoading: true,
    pagenum: 0,
    setNum: 0,
    migUrl: app.globalData.host,
  },

  // 根据条件加载列表
  loadData: function (page_index, condition, cb) {
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: pagesize,
        pageIndex: page_index,
        condition: condition,
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  _data_lunbo_Ajax: function () {
    var that = this;
    wx.request({
      url: host+'banner/xcxBannerList',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        that.setData({
          imgUrls: res.data.data
        })
        console.log(res)
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  headline: function () {
    var that = this;
    wx.request({
      url: host + 'user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log("标题", ops)
        that.setData({
          headrTitle: ops.data.data.discoveryTitle
        })
      },
      fail: function (ops) { },
      complete: function (ops) { }
    })
  },
  initData: function () {
    var that = this;
    that.loadData(pageindex, condition, function (result) {
      console.log(result)

      that.setData({
        product_list: result.data.data,
        host: host
      })
    });
  },
  // maincon_btn: function (e) {
  //   var that = this;
  //   var idIndex = e.currentTarget.id;
  //   var a_Index = this.data.main_con[idIndex];
  //   wx.navigateTo({
  //     url: '../activityMain/activityMain?activityMain=' + a_Index["shopCommodityGroupId"] + '&index=' + idIndex
  //   })
  // },
  productList: function (e) {
    var index = e.currentTarget.id;
    var item = this.data.product_list[index];
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + item["shopCommodityId"]
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;

    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key");

    console.log('自己的数据', userinfo.clientId)
    console.log('别人点进来的数据', options.enjoyClientId)

    wx.request({
      url: host + 'distribution/developByXcx',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        enjoyClientId: options.enjoyClientId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('分销数据', res);
      },
      fail: function (res) { }
    });

    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.userInfo']) {
          wx.authorize({
            scope: 'scope.userInfo',
            success() {
              var userinfo = wx.getStorageSync("userinfo_key")
                , nickName = '测试昵称'
                , headImgUrl = 'xxx.com'
                ;

              wx.login({
                success: function (res) {
                  if (res.code) {
                    var code = res.code
                    wx.request({
                      url: host+'xcx/xcxLogin',
                      data: {
                        userId: app.globalData.userId,
                        code: code,
                        nickName: nickName,
                        headImgUrl: headImgUrl
                      },
                      success: function (res) {
                        var result = res.data.data
                        console.log('123123123123', result)
                        var openId = result.openId
                        nickName = app.globalData.userInfo.nickName
                        headImgUrl = app.globalData.userInfo.avatarUrl
                        // 用户已经同意小程序使用录音功能，后续调用 wx.startRecord 接口不会弹窗询问
                        // wx.showModal({
                        //   title: '别人点进来的数据',
                        //   content: '123123123',
                        // })
                        // console.log('try:+++++', app.globalData.userInfo)
                        wx.request({
                          url: host + 'distribution/developByXcx',
                          data: {
                            userId: app.globalData.userId,
                            openId: openId,
                            nickName: nickName,
                            headImgUrl: headImgUrl,
                            enjoyClientId: options.enjoyClientId
                          },
                          dataType: 'json',
                          method: 'get',
                          success: function (res) {
                            console.log('分销数据xxxxxxxxxxxxxxxxxxxx', openId);
                          },
                          fail: function (res) { }
                        })
                      },
                      fail: function () {

                      }
                    })
                  } else {
                    console.log('登陆失败');
                  }
                }
              })
            }
          })
        }
      }
    })
    this.initData();
    this._data_lunbo_Ajax();
    // this._data_activity_Ajax();
    this.headline();
    
    wx.getSystemInfo({
      success: function(res) {
        console.log('获取设备信息', res)
        that.setData({
          scrollHeight: res.windowHeight
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.setData({
      hidden: false,
      pagenum: 0,
    })
    console.log("自定义数字", that.data.pagenum)    
    that.loadData(0 ,condition, function (ops) {
      that.setData({
        hidden: true,
        product_list: ops.data.data
      }, function () {
        that.setData({
          showLoading: false
        }, function () {
          wx.hideLoading();
        })
      })
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    var that = this;
    wx.stopPullDownRefresh()
    console.log('刷新')
    that.setData({
      hidden: false,
      pagenum:0,
    })
    that.loadData(0, condition, function (ops) {
      that.setData({
        hidden: true,
        product_list: ops.data.data
      })
    })
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  loadMore: function (condition, cb) {
    var that = this;
    that.data.pagenum++;
    pageindex = pagesize * that.data.pagenum

    that.setData({
      setNum: pageindex
    })
    that.loadData(pageindex, condition, function (result) {
      cb(result)
    })

    // if (pageindex > pagesize) {
    //   return false;
    // } else {
    //   // pageindex++;
    //   pagenum++;
    //   pageindex = pagesize*pagenum
    //   that.loadData(pageindex, condition, function (result) {
    //     cb(result)
    //   })
    // }
  },
  onReachBottom: function () {
    console.log('加载中。。。。');
    var that = this;
    that.loadMore(condition, function () {
      var p_list = that.data.product_list;
      that.loadData(pageindex, condition, function (result) {
        var pList = p_list.concat(result.data.data);
        that.setData({
          product_list: pList
        })
      })
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    var that = this;
      var userinfo = wx.getStorageSync("userinfo_key")
      console.log(userinfo)
      console.log('转发事件回调',e)
      return {
        title: that.data.enjoyTitle,
        path: 'pages/find/find?enjoyClientId=' + userinfo.clientId,
        success: function (res) {
          // 转发成功
          console.log('转发成功',res)
        },
        fail: function (res) {
          // 转发失败
        }
      }
  },
})
