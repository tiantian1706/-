var orderId = ""
var nickName = ""
var app = getApp()
var host = app.globalData.url;
var urlImg = app.globalData.urlImg;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.url,
    // alsdkmmwmmx: '',
    /** 
        * 页面配置 
        */
    winWidth: 0,
    sendFriend: true,
    sendTheir: true,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,
    exchangeing_quantity: {},
    modalBox_btn_opposite_one: true, 
    modalBox_btn_opposite_two: false,
    //产品
    exchangeing: {},
    modalBoxShow: true,
    modalBoxHide: false,
    //收货人
    self: '',
    daipay: [

    ],
    // 没有填地址
    daiwait: [

    ],

    is_send:false,
    is_send2: false,
    send_quantity:0,
    is_show_py:false,
    sy_quantity:0,
    duihuanma:"",
    Greetings: '填写给好友的祝福语~',
    Greetings_value: '' ,
    Greetings_value_con: '',
    modalBox: null,  // 模态框变量
    // 物流信息
    logisticsData: {},
    ToSendTheirBtn: false,
    disitem: null,
    a:false,
    b:false,
    bodyHide:'',
    sales: 1,
    zijiname: {},
    jiziImages: {},
    zhongjian:false,
    showLoading: true,
    // helpList: {},
    orderState: false,
    hahaexpressNo:"",
    hahaexpressName:"",
    refunded:false,
  },

  check: function (e) {
    // this.setData({
    //   disitem: !this.data.disitem
    // })
    var that = this;
    console.log(e)
    var checkId = e.currentTarget.dataset.checkid
    console.log(checkId)
    this.setData({
      a: !that.data.a,
      disitem: checkId
    })
    
    // var exchangeingList = that.data.exchangeing.list
    // for (var i = 0, len = exchangeingList.length; i < len; i++){
    //   if (checkId == i) {
    //     this.setData({
    //       disitem: that.data.a
    //     })
    //   }
    // }

  },
  detaildel: function() {
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + that.data.exchangeing.shopCommodityId,
    })
  },
  // 数量-
  changeNumberJia: function () {
    var that = this;
    var sales = that.data.sales;
    if (sales > 1) {
      that.setData({
        sales: --sales
      })
    }
  },
  // 数量+
  changeNumberJian: function () {
    var that = this;
    var sales = that.data.sales;
    var exchangeing_quantity = that.data.exchangeing.quantity;
    if (sales == exchangeing_quantity || sales == that.data.sy_quantity) {
      return;
    } else {
      that.setData({
        sales: ++sales,
      })
    }
  },
  records: function(e){
    console.log('代付记录事件对象',e);
    var orderId = e.currentTarget.dataset.orderid;
    var sendUserInfo = wx.getStorageSync("userinfo_key");
    wx.navigateTo({
      url: '../PaymentRecords/PaymentRecords?orderId=' + orderId + '&nickName=' + sendUserInfo.nickName,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    var sendUserInfo = wx.getStorageSync("userinfo_key")
    orderId = opt.orderId;
    nickName = opt.nickName;
    console.log('接收上页传的参数',opt)
    that.setData({
      Greetings_value: '您的好友' + nickName + '给您送来一份心意',
      // myself: opt.myself,
      Greetings_value_con: '您的好友' + nickName + '给您送来一份心意',
      zijiname: sendUserInfo.nickName,
      jiziImages: sendUserInfo.avatarUrl,
      // helpList: opt.helplist
    })
  },
  // 关闭模态框
  modaBox_clear: function() {
    this.setData({
      modalBox:null
    })
  },
  // 打开模态框
  modaBox_clear_K: function(e) {
    var out = e.currentTarget.dataset.out;
    this.setData({
      modalBox: out
    })
  },

  modalBox_btn: function(){
    this.setData({
      Greetings_value_con: this.data.Greetings_value_con,
      modalBox_btn_opposite_one: false,
      modalBox_btn_opposite_two: true
    })
    console.log(this.data.Greetings_value_con)
  },

  bindTextAreaBlur: function(event){
    var that = this;
    console.log(event)
    that.setData({
      Greetings_value_con: event.detail.value
    });
    console.log(this.data.Greetings_value_con)
  },

  send_commodity : function(e){
    var that = this
    if (parseInt(that.data.sy_quantity) == 0) {
      console.log("已经没有商品可以赠送了")
      wx.showModal({
        title: '提示',
        content: '可送产品数量为0，请继续购买',
        success: function (res) {
          if (res.confirm) {
            console.log("跳转")
            wx.reLaunch({
              url: '../indexs/indexs',
            })
          } else if (res.cancel) {
            wx.reLaunch({
              url: '../indexs/indexs',
            })
          }
        }
      })
      return
    }
     this.setData({
       is_send:!this.data.is_send,
       is_send2: true,
       sendFriend: false,
       sendTheir: false,
       quxiao: true,
       zhongjian: true,
     })
  },

  inputQuantity: function(e){
    console.log(e);
    if (parseInt(this.data.exchangeing.quantity) < parseInt(e.detail.value)){

      console.log("赠送数量大于购买数量")
      wx.showModal({
        title: '提示',
        content: '赠送数量大于购买数量',
        success: function (res) {
        }
      })
    }

    this.setData({
      send_quantity: e.detail.value,
    })
  },

  confrim_send: function(){
    var that = this;
    that.setData({
      is_show_py: true,
      is_send2: true,
      is_send: false,
      sendFriend: false,
      sendTheir: false,
      Greetings_value_con: that.data.Greetings_value_con
    })

    if (parseInt(that.data.sy_quantity) == 0) {
      console.log("已经没有商品可以赠送了")
      wx.showModal({
        title: '提示',
        content: '可送产品数量为0，请继续购买',
        success: function (res) {
          if (res.confirm) {
            wx.reLaunch({
              url: '../indexs/indexs',
            })
          } else if (res.cancel) {
            wx.reLaunch({
              url: '../indexs/indexs',
            })
          }
        }
      })
      return
    }

    if (parseInt(this.data.sales) < 1) {
      console.log("赠送数量小于1")
      return
    }

    var sendUserInfo = wx.getStorageSync("userinfo_key")
    // 获取兑换码

    console.log('传入的数量',that.data.sales)
    wx.request({
      url: host + '/orderreceive/sendToFriend',
      data: {
        userId: app.globalData.userId,
        openId: sendUserInfo.openid,
        nickName: sendUserInfo.nickName,
        headImgUrl: sendUserInfo.avatarUrl,
        orderId: orderId,
        quantity: that.data.sales
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '提示',
            content: res.data.msg,
          })
          return;
        }
        console.log("资格码", res)
        that.setData({
          duihuanma: res.data.data,
          is_show_py: true,
          quxiao: false,
          is_send2: false,
          is_send4: false,          
        })
      }
    })
  },
  // 确定送给自己
  ToSendTheirBtn_click: function(){
      var that = this;
      if (parseInt(that.data.sy_quantity) == 0) {
        console.log("已经没有商品可以赠送了")
        wx.showModal({
          title: '提示',
          content: '可送产品数量为0，请继续购买',
          success: function (res) {
            if (res.confirm) {
              wx.reLaunch({
                url: '../indexs/indexs',
              })
            } else if (res.cancel) {
              wx.reLaunch({
                url: '../indexs/indexs',
              })
            }
          }
        })
        return
      }

      if ((parseInt(this.data.sales) < 1) || (parseInt(this.data.sales) == 0)) {
        wx.showModal({
          title: '提示',
          content: '填写数量不正确'
        })
        return
      }

      wx.chooseAddress({

        success: function (res) {


          console.log(res.userName)
          console.log(res.postalCode)
          console.log(res.provinceName)
          console.log(res.cityName)
          console.log(res.countyName)
          console.log(res.detailInfo)
          console.log(res.nationalCode)
          console.log(res.telNumber)

          that.setData({
            addressInfo: res
          })

          var sendUserInfo = wx.getStorageSync("userinfo_key")
          // 获取兑换码
          wx.request({
            url: host + '/orderreceive/addMyself',
            data: {
              userId: app.globalData.userId,
              quantity: that.data.sales,
              openId: sendUserInfo.openid,
              nickName: sendUserInfo.nickName,
              headImgUrl: sendUserInfo.avatarUrl,
              orderId: orderId,
              name: that.data.addressInfo.userName,
              phone: that.data.addressInfo.telNumber,
              address: that.data.addressInfo.provinceName + that.data.addressInfo.cityName + that.data.addressInfo.countyName + that.data.addressInfo.detailInfo,
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            success: function (res) {
              console.log("送给自己返回信息", that.data)
              that.setData({
                sendFriend: true,
                sendTheir: true,
                is_send2: false,
                is_send4: false,
                quxiao: false,
                is_send: false,
                ToSendTheirBtn: false
              })
            }, fail: function (res) {

            },
            complete: function (res) {

            }
          })
        }
      })
  },
  send_commodity_myself: function (){
      console.log("送给自己")
      var that = this;
      that.setData({
        ToSendTheirBtn: true,
        is_send2: false,
        is_send4: true,
        is_send: false,
        sendFriend: false,
        sendTheir: false,
        quxiao:true,
      })
      if (parseInt(that.data.sy_quantity) == 0) {
        console.log("已经没有商品可以赠送了")

        wx.showModal({
          title: '提示',
          content: '可送产品数量为0，请继续购买',
          success: function (res) {
            if (res.confirm) {
              wx.reLaunch({
                url: '../indexs/indexs',
              })
            } else if (res.cancel) {
              wx.reLaunch({
                url: '../indexs/indexs',
              })
            }
          }
        })
      }
  },
  quxiao:function(){
    var that = this
    that.setData({
      sendFriend:true,
      sendTheir:true,
      is_send2:false,
      is_send4: false,
      quxiao:false,
      is_send:false,
      ToSendTheirBtn:false,
      zhongjian:false
    })
  },
  ruleBox:function(){
    var that = this
    that.setData({
      hide:true,
      is_send2:false,
    })
  },
  hideBox:function(){
    var that = this
    that.setData({
      hide: false
    })
    if(that.data.zhongjian==true){
      that.setData({
        is_send2: true
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this
    wx.request({
      url: host + '/order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      method: 'get',
      success: function (res) {
        var sendUserInfo = wx.getStorageSync("userinfo_key")
        var _data = res.data.data
        var refunded = res.data.data.list
        console.log("waitpay订单详情", res.data.data, _data)        
        if (_data.state == '2' || _data.state == '3' || _data.state == '5' ){
          that.setData({
            orderState:true,
          })
        }
        that.setData({
          exchangeing: res.data.data,
          myself: res.data.data.myself,
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        // if (that.data.myself == '2') {

        //   // 获取兑换码
        //   wx.request({
        //     url: 'https://xcx.honqb.com/orderreceive/sendToFriend',
        //     data: {
        //       userId: app.globalData.userId,
        //       openId: sendUserInfo.openid,
        //       nickName: sendUserInfo.nickName,
        //       headImgUrl: sendUserInfo.avatarUrl,
        //       orderId: orderId,
        //       quantity: that.data.sales
        //     },
        //     header: {
        //       'content-type': 'application/json'
        //     },
        //     method: 'get',
        //     success: function (res) {
        //       console.log("资格码1", res)
        //       that.setData({
        //         duihuanma: res.data.data,
        //       })
        //     }
        //   })
        // }
        var ys_quantity = 0

        for (var i = 0; i < that.data.exchangeing.list.length; i++) {
          var item = that.data.exchangeing.list[i]
          ys_quantity += parseInt(item.quantity)
          console.log(item.quantity)
        }

        console.log("已送数量", ys_quantity, refunded)

        that.setData({
          sy_quantity: that.data.exchangeing.quantity - ys_quantity
        })
        if (_data.expressName != "1") {
          that.logistics_ajax(_data.expressNo, _data.expressName)
        }
        if (_data.myself=="1"){
          that.logistics_ajax(refunded[0].expressNo, refunded[0].expressName)
        }
        
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })
  },
  logistics_ajax: function (_expressNo, _expressName) {
    var that = this;
    wx.request({
      url:  host + '/express/searchLogisticsInfo',
      data: {
        userId: app.globalData.userId,
        expressNo: _expressNo,
        expressName: _expressName
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log('打印物流信息', ops.data.data,);
        that.setData({
          logisticsData: ops.data.data,
          hahaexpressNo: ops.data.data.expressNo,
          hahaexpressName: ops.data.data.expressName,
          // hahalogisticsData: ops.data.data.logisticsData,
        })
      },
      fail: function (ops) { 
        console.log('报错', ops)
      },
      complete: function (ops) { }
    });
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    var that = this
    wx.request({
      url:  host + '/order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      method: 'get',
      success: function (res) {

        console.log("waitpay订单详情", res.data.data, res.data.data.expressInfo.expressName, res.data.data.expressInfo.expressNo)
        var _data = res.data.data
        that.setData({
          exchangeing: res.data.data,
          hahaexpressName: res.data.data.expressInfo.expressName,
          hahaexpressNo: res.data.data.expressInfo.expressNo,
        })
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (e) {
    console.log('转发对象', e.target.dataset);
    var MessageIdx = e.target.dataset.idx;
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, logid);
    if (MessageIdx == 'a') {
      console.log('哈哈哈', that.data.duihuanma)      
      if (logindex == 1) {
        var linkOne = 'pages/filladdress2/filladdress2?quantity=' + that.data.sales + '&duihuanma=' + that.data.duihuanma + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&clientId=' + userinfo.clientId + "&scene=" + logid;
      }else{
        var linkOne = 'pages/filladdress2/filladdress2?quantity=' + that.data.sales + '&duihuanma=' + that.data.duihuanma + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&clientId=' + userinfo.clientId;
      }
      return {
        title: that.data.Greetings_value_con,
        path: linkOne,
        imageUrl: urlImg + '/data/upload/image/xcx/liwuBg.jpg',
        success: function (res) {
          // 转发成功
          console.log("转发1", res)
          that.setData({
            sendFriend: true,
            sendTheir: true,
            is_show_py: false
          }) 
          console.log(that.data.is_send)
          wx.showModal({
            title: '提示',
            content: '赠送成功',
            success: function (res) {

            }
          })
        },
        fail: function (res) {
          that.setData({
            is_show_py: false,
            is_send: true
          })
        }
      }
      console.log(this.data.Greetings_value)
    }
    var exchangeingList = that.data.exchangeing.list,
      exchangeingListLen = exchangeingList.length;

    for (var i = 0; i < exchangeingListLen; i++) {
      console.log('获取列表兑换码Id', i)

      if (e.target.dataset.idx == ('b'+ i)) {
        console.log('我是再次转发');
        console.log('获取列表兑换码', exchangeingList[i].code)
        if (logindex == 1) {
          var linkTwo = 'pages/filladdress2/filladdress2?quantity=' + that.data.sales + '&duihuanma=' + exchangeingList[i].code + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&clientId=' + userinfo.clientId + "&scene=" + logid;
        } else {
          var linkTwo = 'pages/filladdress2/filladdress2?quantity=' + that.data.sales + '&duihuanma=' + exchangeingList[i].code + '&orderId=' + orderId + '&userinfo=' + JSON.stringify(userinfo) + '&shopCommodityId=' + that.data.exchangeing.shopCommodityId + '&clientId=' + userinfo.clientId;
        }
        return {
          title: that.data.Greetings_value_con,
          path: linkTwo,
          imageUrl: urlImg + '/data/upload/image/xcx/liwuBg.jpg',
          success: function (res) {
            // 转发成功
            console.log("转发2", res)
            console.log(that.data.is_send)
            
            wx.showModal({
              title: '提示',
              content: '赠送成功',
              success: function (res) {
                that.setData({
                  modalBox: null
                })
              }
            })
          },
          fail: function (res) {

          }
        }
      }
    }
  }
})
