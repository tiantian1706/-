//获取应用实例  
var app = getApp();

var config = require('../../config')
var host = app.globalData.host;
var newUrl = app.globalData.newUrl;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: app.globalData.host,
    imagesUrl: app.globalData.url,
    /** 
        * 页面配置 
        */
    winWidth: 0,
    winHeight: 0,
    // tab切换的第几个页面  
    currentTab: 0,
    showLoading: true,
    //待付款
    waitpay: [
      {
        imgsrc: "../../imgs/22.png",
        title: "有礼有节2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "816.00",
        num: "12",
        dates: "2017-08-06"
      },
      {
        imgsrc: "../../imgs/23.png",
        title: "2018传家日历创意简约小清桌面台历手绘中国撕历预售",
        price: "910.00",
        num: "1",
        dates: "2017-08-06"
      },
    ],
    LinkButton: {},
    // 待发货
    waitsend: [
      {
        imgsrc: "../../imgs/23.png",
        title: "MAK/米奇粽子 福意棕600g高档礼盒装端午节佳节送礼送亲友朋友团购",
        price: "49.00",
        num: "1",
        dates: "2017-08-06"
      }
    ],
    // 我的订单列表
    myorder: [],
    payAgainMain: '立即支付',
    newUrl: newUrl,
    lengthall: 0,
    lengthfukuan: 0,
    lengthshiyong: 0,
    lengthfinsh: 0,
  },

  indexGo: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  getOrderInfo:function(){
    var that = this;
    // 用户信息
    var userinfo = wx.getStorageSync("userinfo_key")

    console.log("用户信息", userinfo)

    var openid = userinfo.openid

    wx.request({
      url: host + 'order/myXcxOrderLists',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {

        if (res.data.code != 0) {
          var text = res.data.msg
          wx.showModal({
            title: '提示',
            content: text,
          })
          return;
        }

        var myorder = []
        ,   fukuan = []
        ,   shiyong = []
        ,   finsh = [];

        for (var i = 0; i < res.data.data.length; i++) {
          var item = res.data.data[i];
          console.log(item.helpOrderId)
          if (item.helpOrderId == "0" && item.type == "1") {
            myorder.push(item)
            if (item.state == 7 || item.state == 1) {
              fukuan.push(item)
            }
            if (item.state == 2) {
              shiyong.push(item)
            }
            if (item.state == 5) {
              finsh.push(item)
            }
          }
        }

        that.setData({
          myorder: myorder,
          lengthall: myorder.length,
          lengthfukuan: fukuan.length,
          lengthshiyong: shiyong.length,
          lengthfinsh: finsh.length,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
        console.log("我的订单", that.data.myorder)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (onptions) {
    wx.hideShareMenu()
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (onptions.currentTab!=null){
      that.setData({
        currentTab: onptions.currentTab,
      })
    }
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    /** 
     * 获取系统信息 
     */
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winWidth: res.windowWidth,
          winHeight: res.windowHeight
        });
      }
    });

    that.getOrderInfo();
    
  },
  payAgain: function(e){
    var that = this;
    console.log('重新支付', e.currentTarget.dataset.orderid)
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log(userinfo)
    wx.request({
      url: host + 'order/xcxRePay',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        orderId: orderId,
        code: userinfo.code,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {

        var order_id = res.data.data
        console.log('hq', res)

        wx.request({
          url:  host + 'order/xcxxcxPay',
          data: {
            userId: app.globalData.userId,
            openId: userinfo.openid,
            nickName: userinfo.nickName,
            headImgUrl: userinfo.avatarUrl,
            orderId: order_id
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          success: function (res) {

            var result = res.data.data;

            wx.requestPayment({
              userId: app.globalData.userId,
              timeStamp: result.timeStamp,
              nonceStr: result.nonceStr,
              package: result.package,
              signType: result.signType,
              paySign: result.paySign,
              success: function (res) {
                wx.showToast({
                  title: '支付成功',
                  icon: 'success',
                  duration: 1000
                });
                that.getOrderInfo();
              },
              fail: function (res) {

              },
              compelete: function (res) {

              }
            })
          }
        })
      },
      fail: function(res) {

      }
    })
  },
  cancellationOfOrder: function(e){
    var that = this;
    console.log('取消订单')
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.showModal({
      title: '提示',
      content: '确定删除订单吗？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定')

          wx.request({
            url: host + 'order/delOrderByXcx',
            dataType: 'json',
            method: 'get',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              orderId: orderId,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl
            },
            success: function (res) {
              console.log('取消订单', res)

              if (res.data.code == 0) {
                wx.showModal({
                  title: '提示',
                  content: '删除成功'
                })
                that.getOrderInfo();
              }
            }
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
    
  },
  /** 滑动切换tab  
  */
  bindChange: function (e) {

    var that = this;
    that.setData({ currentTab: e.detail.current });

  },
  /** 
   * 点击tab切换 
   */
  swichNav: function (e) {

    var that = this;

    if (this.data.currentTab === e.target.dataset.current) {
      return false;
    } else {
      that.setData({
        currentTab: e.target.dataset.current
      })
    }
  },


  jumpToDF: function(e){
    var that = this;
    console.log("代付订单索引",e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = that.data.myorder[index];
    var shopCommodityId = order.shopCommodityId
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopCommodityId
    })
  },


  jumpToDFH: function(e){
    console.log("代发货订单索引", e.currentTarget.id)
    var index = e.currentTarget.id;
    var order = this.data.myorder[index];
    console.log("代发货订单", order)
    var nickName = wx.getStorageSync("userinfo_key").nickName;
    // wx.navigateTo({
    //   url: '../exchangedetail/exchangedetail?orderId=' + order.orderId + "&nickName=" + nickName,
    // })
    
    //自取订单详情 
    wx.navigateTo({
      url: '../orderDetail/orderDetail?orderId=' + order.orderId + "&nickName=" + nickName,
    })
  },

  // 点击使用
  employGo:function(e){
    var that = this;
    console.log('取消订单')
    var orderId = e.currentTarget.dataset.orderid;
    var userinfo = wx.getStorageSync("userinfo_key");

    wx.showModal({
      title: '提示',
      content: '确定已到店取货？',
      success: function (res) {
        if (res.confirm) {
          console.log('用户点击确定');
          wx.request({
            url: host + 'order/confirmReceive',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              orderId: orderId,
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            dataType: '',
            success: function (res) {
              if (res.data.code != 0) {
                wx.showModal({
                  title: '温馨提示',
                  content: res.data.msg,
                })
              } else {
                wx.redirectTo({
                  url: '../myorder/myorder?currentTab=3',
                })
                console.log("确认已取货", res)
              }
            },
            fail: function (res) { },
            complete: function (res) { }
          });

        }
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    console.log('监听页面初次渲染完成');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    wx.stopPullDownRefresh()
    console.log("下拉")
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})

