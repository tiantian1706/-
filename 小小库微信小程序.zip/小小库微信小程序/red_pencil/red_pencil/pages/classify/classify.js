// pages/classify/classify.js

var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    url: url,
    classifyData: [
    ],
    rightData:[],
    indexNew:"0",
    showLoading: true,
  },
  pitch:function(e){
    var that = this,
    index = e.currentTarget.dataset.index,
    shopCommodityClassifyId = e.currentTarget.dataset.shopcommodityclassifyid;
    console.log(e, index, shopCommodityClassifyId); 
    this.setData({
      indexNew: index
    });
    that.getRightData(shopCommodityClassifyId)
  },
  getRightData: function (index) {
    var that = this;
    wx.request({
      url: host + 'commodity/getByClassifyId',
      data: {
        shopCommodityClassifyId: index
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log("分类", ops.data.data);
        that.setData({
          rightData: ops.data.data,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
      },
      fail: function (ops) { },
      complete: function (ops) { }
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var data = JSON.parse(options.data);
    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    console.log("默认", data)
    that.setData({
      classifyData:data,
    });
    that.getRightData(that.data.classifyData[0].shopCommodityClassifyId);
    console.log("分类", that.data.rightData)
  },

  productList: function (e) {
    var shopCommodityId = e.currentTarget.dataset.shopcommodityid;
    console.log(e,shopCommodityId)
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopCommodityId
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})