// pages/distribution/distribution.js
var app = getApp()
var url = app.globalData.url;
var host = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    bgmsrc: app.globalData.url+"/data/upload/image/xcx/info.png",
    userInfo: {

    },
    first: true,
    second: false,
    distribution: {},
    distribution2: {},
    usnxname: '',
    iconicon: false,
    icon: false,
    icon2: false,
    showLoading: true,
    degree:false,
    vUrl: app.globalData.url+"/data/upload/image/xcx/v.png"
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;

    that.levels();

    var res = wx.getSystemInfoSync();
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion);
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var userinfo = wx.getStorageSync("userinfo_key")
    console.log(userinfo)
    that.setData({
      userInfo: userinfo
    });

    wx.request({
      url: host + '/distribution/myAlliesByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function(res) {
      
        that.setData({
          distribution: res.data.data
        })
        if (that.data.distribution.first.member == '1') {
          console.log('我是会员')
          that.setData({
            icon: true
          });

          console.log(that.data.icon)
        } else {
          that.setData({
            icon: false
          })
        }
        // for (var i = 0, len = that.data.distribution.first.length; i < len; i++) {
        //   console.log('判断是否是会员',that.data.distribution.first[i].member)
        //   if (that.data.distribution.first[i].member == '1') {
        //     console.log('我是会员')
        //     that.setData({
        //       icon: true
        //     });

        //     console.log(that.data.icon)
        //   } else {
        //     that.setData({
        //       icon: false
        //     })
        //   }
        // }


        for (var i = 0, len = that.data.distribution.second.length; i < len; i++) {
          console.log(that.data.distribution.second[i].member)
          if (that.data.distribution.second[i].member == '1') {
            that.setData({
              icon2: true
            })
          } else {
            that.setData({
              icon2: false
            })
          }
        }
        
        console.log(that.data.distribution)
      },
      fail: function(res){}
    })


    wx.request({
      url: host + '/distribution/getByClientIdByXcx',
      dataType: 'json',
      method: 'get',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl
      },
      success: function (res) {


        that.setData({
          distribution2: res.data.data
        }, function(){
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })

        if (that.data.distribution2 == 1) {
          that.setData({
            usnxname: '团长',
            iconicon: true
          })
        }
        if (that.data.distribution2 == 0) {
          that.setData({
            usnxname: '普通用户'
          })
        }
        console.log('盟友数据',that.data.distribution2)
      },
      fail: function (res) { }
    })
  },
  one:function(){
    this.setData({
      first: true,
      second:false
    })
  },
  two:function(){
    this.setData({
      first: false,
      second: true
    })
  },
  levels:function(){
    var that = this
    wx.request({
      url: host + '/distribution/getConfigByUserId',
      dataType: 'json',
      data: {
        userId: app.globalData.userId,
      },
      method: 'get',
      success: function (res) {
        if (res.data.data.degree == 2){
          that.setData({
            degree: true
          })
        }
      },
      fail: function (res) {

      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    console.log('监听页面初次渲染完成');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})