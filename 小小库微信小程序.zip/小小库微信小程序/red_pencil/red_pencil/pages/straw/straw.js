// pages/straw/straw.js

var app = getApp()
var host = app.globalData.host;
var pageindex = 0;
var pageSize = 10;
var condition = {};
var util = require('../../utils/util.js')


Page({

  /**
   * 页面的初始数据
   */
  data: {
    indicatorDots: false,
    autoplay: true,
    interval: 3000,
    imgUrls: [],
    imageUrl: app.globalData.url,
    classifyAllData: [],
    classifyAllDataL: 0,
    articleTopData: [],
    articleBottomData: [],
    articleTopDataL: 0,
    articleBottomDataL: 0,
    getListData:[],
    showLoading: true,    
  },

  searchGo: function () {
    var that = this;
    wx.navigateTo({
      url: '../search/search',
    })
  },

  // 根据条件加载列表
  loadData: function () {
    var that = this;
    wx.request({
      url: host + 'commodityindex/xcxGetCommodityIndex',
      data: {
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        console.log("首页产品", res.data.data)
        var product_listData = [];
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].type == "2") {
            product_listData.push(res.data.data[i])
          }
        }
        that.setData({
          product_list: product_listData
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },

  // 跳详情页
  shopdetailGo:function(e){
    var shopcommodityid = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopcommodityid
    });
  },


  // 轮播图
  bannerImg: function () {
    var that = this;
    wx.request({
      url: host + 'banner/xcxBannerList',
      data: {
        userId: app.globalData.userId,
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        var imgUrls = [];
        for (var i = 0; i < res.data.data.length;i++){
          if (res.data.data[i].type=="2"){
            imgUrls.push(res.data.data[i])
          }
        }
        that.setData({
          imgUrls: imgUrls
        })
        console.log("轮播", that.data.imgUrls)
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  // 分类
  classifyData: function () {
    var that = this;
    wx.request({
      url: host + 'commodityclassify/getAlls',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        var classifyAllData = [];        
        if (res.data.data.length>0){
          console.log("分类", res.data.data);
          for (var i = 0; i < 4; i++) {
            classifyAllData.push(res.data.data[i])
          }
        }
        that.setData({
          classifyAllData: classifyAllData,
          classifyAllDataL: res.data.data.length
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },

  classifyGo:function(e){
    console.log("e", e.currentTarget.dataset.shopid)
    console.log("e", e.currentTarget.id)
    wx.reLaunch({
      url: '../indexss/indexss?shopid=' + e.currentTarget.id,
    })
  },

  moreGo:function(){
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },

  // 文章列表
  article:function(){
    var that = this;
    wx.request({
      url: host + 'article/getArticleByUserId',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        var articleTopData = [];
        var articleBottomData = [];
        if (res.data.data.data.length > 2) {
          for (var i = 0; i < 2; i++) {
            articleTopData.push(res.data.data.data[i])
          }
          for (var i = 2; i < res.data.data.data.length; i++) {
            articleBottomData.push(res.data.data.data[i])
          }
        }else{
          articleTopData = res.data.data.data;
        }
        that.setData({
          articleTopData: articleTopData,
          articleBottomData: articleBottomData,
          articleTopDataL: articleTopData.length,
          articleBottomDataL: articleBottomData.length,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  // 文章详情
  detailGo:function(e){
    console.log(e.currentTarget.dataset.id)
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../strawDetail/strawDetail?id='+id,
    })
  },

  // 获取推荐商品
  getList: function () {
    var that = this;
    var tjArray = [];
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: 500,
        pageIndex: pageindex,
        condition: condition,
        userId: app.globalData.userId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })

          return;
        }
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].foryou == 1) {
            tjArray.push(res.data.data[i])
          }
        }

        that.setData({
          getListData: tjArray
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        });
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var res = wx.getSystemInfoSync();
    var scene = decodeURIComponent(options.scene);
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("scene", scene, userinfo)

    if (options.scene) {
      if (userinfo.openid) {
        util.getDistribution(host, app.globalData.userId, userinfo.openid, scene)
      } else {
        util.getOpenId(host, app.globalData.userId, function () {
          userinfo = wx.getStorageSync("userinfo_key");
          util.getDistribution(host, app.globalData.userId, userinfo.openid, scene)
        })
      }
    }

    that.bannerImg();
    that.loadData();
    that.classifyData();
    that.getList();    
  },

  productList: function (e) {
    var shopcommodityid = e.currentTarget.dataset.shopcommodityid;
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + shopcommodityid
    });
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    that.article();  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, decodeURIComponent(logid));
    if (logindex == 1) {
      var link = 'pages/straw/straw?scene=' + logid
    } else {
      var link = 'pages/straw/straw'
    }
    return {
      title: '',
      path: link,
    }
  }
})