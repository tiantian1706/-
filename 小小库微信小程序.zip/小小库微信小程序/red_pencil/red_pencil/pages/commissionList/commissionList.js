// pages/commissionList/commissionList.js

var util = require('../../utils/util.js');
var wezrender = require('../../lib/wezrender');

var app = getApp()
var host = app.globalData.host;
var pageindex = 0;
var pageSize = 10;
var condition = {};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    getListData: [],    
    classifyAllData: [],
    classifyAllDataL: 0,
    indexId: -1,
    classifyShow: false,
    classifyDatas: [],
    classifyIndexId: 0,
    imageUrl: app.globalData.url,
    showLoading: true,
    logindex:0,
    codeUrl: app.globalData.url,
    mycode: '',
    mycodeUrl: '',
    code_wrap_model: false,
  },

  // 获取推荐商品
  getList: function () {
    var that = this;
    var tjArray = [];
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: 500,
        pageIndex: pageindex,
        condition: condition,
        userId: app.globalData.userId
      },
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })

          return;
        }
        for (var i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].foryou == 1) {
            tjArray.push(res.data.data[i])
          }
        }

        that.setData({
          getListData: tjArray
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        });
      }
    })
  },

  // 分类
  classifyGo: function (e) {
    var that = this,
      index = e.currentTarget.id,
      goData = that.data.classifyAllData[index].child,
      shopCommodityClassifyId = that.data.classifyAllData[index].shopCommodityClassifyId;
    console.log(goData)
    wx.navigateTo({
      url: '../classify/classify?data=' + JSON.stringify(goData)
    })
  },
  classifyData: function () {
    var that = this;
    wx.request({
      url: host + 'commodityclassify/getAlls',
      data: {
        userId: app.globalData.userId
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        console.log("分类", res.data.data);
        that.setData({
          classifyAllData: res.data.data,
          classifyAllDataL: res.data.data.length
        })

        if (that.data.shopid > -1) {
          that.setData({
            indexId: that.data.shopid,
            classifyShow: true,
            classifyDatas: that.data.classifyAllData[that.data.shopid].child,
            classifyIndexId: 0,
          })
          that.classifyIndexData(that.data.classifyAllData[that.data.shopid].child[0].shopCommodityClassifyId)
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  classifyChange: function (e) {
    console.log(e.currentTarget.id)
    var that = this;
    that.setData({
      indexId: e.currentTarget.id,
      classifyShow: true,
      classifyDatas: that.data.classifyAllData[e.currentTarget.id].child,
      classifyIndexId: 0,
    })
    that.classifyIndexData(that.data.classifyAllData[e.currentTarget.id].child[0].shopCommodityClassifyId)
  },
  classifyIndexData: function (id) {
    var that = this;
    that.showLoadGo();
    wx.request({
      url: host + 'commodity/getByClassifyId',
      data: {
        shopCommodityClassifyId: id
      },
      dataType: 'json',
      method: 'get',
      success: function (ops) {
        console.log("分类", ops.data.data);
        that.setData({
          rightData: ops.data.data,
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
      },
      fail: function (ops) { },
      complete: function (ops) { }
    })
  },
  classifyIndexGo: function (e) {
    var that = this;
    that.setData({
      classifyIndexId: e.currentTarget.id
    })
    that.classifyIndexData(e.currentTarget.dataset.indexid);
  },

  // 加载中
  showLoadGo: function () {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    }
  },

  // 首页
  indexShow: function () {
    var that = this;
    that.setData({
      classifyShow: false,
      classifyIndexId: 0,
      indexId: -1,
    })
  },



  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    }

    var logindex = wx.getStorageSync("logindex");
    var logid = wx.getStorageSync("logid");
    console.log("本地储存", logindex, logid);
    if (logindex) {
      that.setData({
        logindex: logindex
      })
    }
    if (logindex == 1) {
      that.setData({
        logid: logid
      })
    }
    console.log("logindex",that.data.logindex)
    that.classifyData();
    that.getList();
  },

  pitch:function(e){
    var that = this;
    console.log("e", e.currentTarget.dataset.shopcommodityid)
    wx.request({
      url: host + 'xcx/getXcxQrCode',
      data: {
        userId: app.globalData.userId,
        shopCommodityId: e.currentTarget.dataset.shopcommodityid,
        enjoyClientId: that.data.logid
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        console.log('二维码', res.data.data);
        that.setData({
          mycode: that.data.codeUrl + res.data.data
        })
        console.log("二维码", that.data.mycode)
        wx.request({
          url: host + 'commodity/get',
          data: {
            shopCommodityId: e.currentTarget.dataset.shopcommodityid,
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            console.log("产品详情",res.data.data.commodity)
            that.codeshow(res.data.data.commodity)
          },
          fail: function (res) { },
          complete: function (res) { },
        })
      },
      fail: function (res) { }
    })
  },

  // 生成二维码
  codeshow: function (productData) {
    var that = this;

    that.setData({
      code_wrap_model: true,
      codeShow: true
    })

    wx.showLoading({
      title: '图片生成中',
    })

    const quImagesUrl = that.data.codeUrl + productData.icon[0];

    wx.downloadFile({
      url: quImagesUrl,
      success: function (res) {
        wx.saveFile({
          tempFilePath: res.tempFilePath,
          success: function (res) {
            var savedFilePath = res.savedFilePath;

            wx.downloadFile({
              url: that.data.mycode,
              success: function (res) {
                wx.saveFile({
                  tempFilePath: res.tempFilePath,
                  success: function (res) {
                    var savedFilePath2 = res.savedFilePath;
                    try {
                      var res = wx.getSystemInfoSync()
                      console.log(res.windowWidth)
                      console.log(res.windowHeight)
                      const quWidth = (res.windowWidth * (80 / 100)) + 1;
                      const quHeight = (res.windowHeight * (80 / 100)) + 1;
                      const quHeight_xh = quHeight - quWidth;
                      const quWidthQuHeight_xh = quWidth + quHeight_xh / 2;

                      const zrCanvas = wezrender.zrender.init('code');
                      var sadg = wx.getSystemInfoSync();
                      var xiangsu = sadg.pixelRatio;
                      var image_zr = new wezrender.graphic.Image({
                        style: {
                          x: 0,
                          y: 0,
                          image: savedFilePath,
                          width: quWidth,
                          height: quWidth
                        }
                      });

                      zrCanvas.add(image_zr);

                      var image_zr2 = new wezrender.graphic.Image({
                        style: {
                          x: quWidth - ((quHeight / 5.5) + (quWidth / 20)),
                          y: quWidth + 10,
                          image: savedFilePath2,
                          width: quHeight / 5.5,
                          height: quHeight / 5.5,
                        }
                      });

                      zrCanvas.add(image_zr2);

                      console.log(productData.title.split(''))
                      // 


                      function string_jiequ(aryLen, num_s) {
                        var titleLen = aryLen.split('');
                        var title_box = ''
                        for (var i = 0; i < num_s; i++) {

                          title_box += titleLen[i];

                        }

                        if (titleLen.length > num_s) {
                          title_box = title_box + '...'
                        } else {
                          title_box = aryLen;
                        }

                        return title_box;
                      }

                      console.log(string_jiequ(productData.title, 10));
                      var text = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 20,
                          text: string_jiequ(productData.title, 10),
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '14px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text);

                      var text2 = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 47,
                          text: '￥' + productData.priceShow,
                          width: 300,
                          height: 300,
                          fill: 'red',
                          textFont: '18px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text2);

                      var text3 = new wezrender.graphic.Text({
                        style: {
                          x: 10,
                          y: quWidth + 68,
                          text: '到店价：￥' + (productData.oldPrice / 100).toFixed(2),
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '14px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text3);
                      function insertStr(str, tar, n, m) {
                        var x = '';

                        var str = str.split('');

                        if (str.length == 0) return;

                        for (var i = n; i < str.length; i += m) {
                          str[i] += tar
                        }

                        x = str.join("");

                        return x;
                      }


                      var string_boxs = string_jiequ(productData.introduction, 14);

                      var sdfg = '\n';


                      console.log('文字分段', insertStr(string_boxs, sdfg, 5, 5));
                      if (productData.introduction) {
                        var text4 = new wezrender.graphic.Text({
                          style: {
                            x: 10,
                            y: quWidth + 90,
                            text: '推荐理由：' + insertStr(string_boxs, sdfg, 5, 11),
                            width: 300,
                            height: 300,
                            fill: '#000000',
                            textFont: '14px Microsoft Yahei',
                          }
                        });
                        zrCanvas.add(text4);
                      }



                      var text5 = new wezrender.graphic.Text({
                        style: {
                          x: quWidth - ((quHeight / 5.5) + (quWidth / 10)),
                          y: quWidth + quHeight / 5.5 + 30,
                          text: '长按识别小程序码购买',
                          width: 350,
                          height: 300,
                          fill: '#000000',
                          textFont: '12px Microsoft Yahei',
                        }
                      });
                      zrCanvas.add(text5);

                      const ctx = wx.createCanvasContext('code');

                      // ctx.drawImage(that.data.mycodeUrl2, 0, 0, quWidth, quWidth);
                      // ctx.save();
                      var sdf = quHeight / 5.5;


                      ctx.setFillStyle('#ffffff');
                      ctx.fillRect(0, quWidth, quWidth, quHeight_xh);
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo(5, quWidth + 63);
                      ctx.lineTo(140, quWidth + 66);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo(quWidth - (sdf + 0), (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, ((quWidth + 15) + (sdf)) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 0)) - 20, (quWidth + 25));
                      ctx.lineTo((quWidth - (sdf + 0)) - 20, (quWidth + 25) - 20);
                      ctx.lineTo(quWidth - (sdf + 0), (quWidth + 25) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 10)) + sdf - 20, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 15) + (sdf));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 15) + (sdf) - 20);
                      ctx.stroke();
                      ctx.save();

                      ctx.setStrokeStyle('#666666');
                      ctx.moveTo((quWidth - (sdf + 10)) + sdf - 20, (quWidth + 5));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 5));
                      ctx.lineTo((quWidth - (sdf + 10)) + sdf, (quWidth + 5) + 20);
                      ctx.stroke();
                      ctx.save();
                      ctx.draw();

                      setTimeout(function () {

                        console.log('像素', xiangsu)
                        wx.canvasToTempFilePath({
                          fileType: 'jpg',
                          quality: 1,
                          canvasId: 'code',
                          destWidth: quWidth * xiangsu,
                          destHeight: quHeight * xiangsu,
                          success: function (res) {
                            that.setData({
                              mycodeUrl: res.tempFilePath
                            })
                            console.log("canvas", res.tempFilePath);

                            wx.previewImage({
                              urls: [res.tempFilePath],
                              success: function (res) {
                                console.log('成功')
                                wx.hideLoading();
                                that.setData({
                                  codeShow: false,
                                  code_wrap_model: false
                                })
                              }
                            })
                          },
                          complete: function fail(e) {
                            console.log(e.errMsg);
                          }
                        })
                      }, 800)
                    } catch (e) {
                      // Do something when catch error
                    }

                  }
                });
              }
            })

          }
        })
      }
    })
  },

  dispalyModelClass: function () {
    this.setData({
      dispalyModel: false,
      dispalyModelClasShow: false,
      codeShow: false,
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})