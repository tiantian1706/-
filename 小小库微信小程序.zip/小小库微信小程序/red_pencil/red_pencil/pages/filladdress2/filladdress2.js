var app = getApp()

var util = require('../../utils/util.js')
var orderId = ""
var openId = ""
var quantity = 1
var host = app.globalData.host;
var urlImg = app.globalData.urlImg;
var sendUserInfo = {

}

var reciveUserInfo = {

}
Page({

  /**
   * 页面的初始数据
   */
  data: {
    urlImg: urlImg,
    exchangeing: {},
    host: app.globalData.url,
    userInfo: {},
    duihuanma: "",
    address: {
      name: "收件人",
      tele: "联系电话",
      province: "省份/自治区",
      city: "市",
      area: "县/区",
      all: "收货地址",
    },
    touxiangImage: {},
    addressInfo: {
      userName: "",
      telNumber: "",
      provinceName: "",
      cityName: "",
      countyName: "",
      detailInfo: ""
    },
    addressInfo_userName: {},
    addressInfo_telNumber: {},
    addressInfo_provinceName: {},
    addressInfo_cityName: {},
    addressInfo_countyName: {},
    addressInfo_detailInfo: {},
    drawDownImage: {},
    Stamped: {}, // 图片盖章
    shopCommodityIds: {},
    first: true,
    second: false,
    thirdly: false,
    guige: true,
    showLoading: true,
    furl_sd: false,
    addressHide: false,
    filladdress_btn1: true,
    filladdress_btn2: false,
    filladdress_btn3: false,
    furl_modal_box: false,
    expressInfo_box: {},
    iSimageChu: true,
    imageChu: urlImg + '/data/upload/image/xcx/liwuBg.jpg',
    addsepon: false
  },

  // 跳转到商品详情页
  // JumpJumpDetails: function () {
  // //   wx.navigateTo({
  // //     url: '../productDetail/productDetail?shopCommodityId=' + this.data.shopCommodityIds
  // //   })
  // // },
  fromReset: function () {
    var that = this;

    that.setData({
      addressHide: false
    })
  },
  furl: function (e) {
    var that = this;
    util.login(e, function () {
      that.setData({
        furl_sd: true,
        furl_modal_box: true
      })
    })
  },
  addressShow: function () {
    var that = this;
    wx.navigateTo({
      url: '../address_single/address_single',
    })
  },
  deladd: function () {
    var that = this;
    that.setData({
      furl_sd: false,
      furl_modal_box: false
    })
  },
  furlcheckTheLogistics: function(){
    var that = this;

    wx.navigateTo({
      url: '../checkTheLogistics/checkTheLogistics?expressInfo=' + that.data.expressInfo_box,
    })
  },
  exchangeingAjax: function (){
    var that = this;

    wx.request({
      url: host + 'order/getXcxOrderByOrderId',
      data: {
        userId: app.globalData.userId,
        orderId: orderId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        console.log("filladdress订单详情", res)
        that.setData({
          exchangeing: res.data.data,
        })
        if (that.data.exchangeing.description.length == 0) {
          that.setData({
            guige: false
          })
        }
      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })

  },
  /**c vvvvvd
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };
    
    // 建立分销关系
    var userinfo = wx.getStorageSync("userinfo_key");
    if (opt.clientId) {
      if (userinfo.openid) {
        util.getDistribution(host, app.globalData.userId, userinfo.openid, opt.clientId)
      } else {
        util.getOpenId(host, app.globalData.userId, function () {
          userinfo = wx.getStorageSync("userinfo_key");
          util.getDistribution(host, app.globalData.userId, userinfo.openid, opt.clientId)
        })
      }
    };

    orderId = opt.orderId;
    quantity = opt.quantity
    sendUserInfo = JSON.parse(opt.userinfo)

    that.setData({
      duihuanma: opt.duihuanma,
      shopCommodityIds: opt.shopCommodityId,
      // quantity: quantity
      userInfo: sendUserInfo,
    })
    console.log('aaaaa', opt)
    that.exchangeingAjax();
    wx.request({
      url: host + 'orderreceive/checkReceiveCode',
      data: {
        userId: app.globalData.userId,
        receiveCode: that.data.duihuanma
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        var myinfo = wx.getStorageSync("userinfo_key")

        console.log("测试盖章", res.data.data)
        console.log("自己的id", myinfo.clientId)

        that.setData({
          Stamped: res.data.data.use,
          quantity: res.data.data.quantity,
          expressInfo_box: JSON.stringify(res.data.data.expressInfo)
        }, function () {
          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading();
          })
        })
        if (that.data.Stamped == 0) {
          console.log('imagse',that.data.exchangeing)
          if (res.data.data.clientId == myinfo.clientId) {
            that.setData({
              first: false,
              second: true,
              thirdly: false,
              filladdress_btn1: false,
              filladdress_btn2: true,
              iSimageChu: false,
              filladdress_btn3: false
            })
          } else {
            that.setData({
              first: false,
              second: false,
              thirdly: true,
              filladdress_btn1: false,
              filladdress_btn2: false,
              filladdress_btn3: true
            })
          }
        }

      },
      fail: function () {
        console.log("接口调用失败的回调函数")
      }
    })
  },
  


  getDFUserInfo: function (cb) {
    wx.login({
      success: function (res) {

        var code = res.code
        wx.getUserInfo({
          success: function (res) {

            typeof cb == "function" && cb(res.userInfo, code)

          }
        })
      }
    })
  },

  choose_address: function () {
    var that = this;
    wx.chooseAddress({

      success: function (res) {

        console.log(res.userName)
        console.log(res.postalCode)
        console.log(res.provinceName)
        console.log(res.cityName)
        console.log(res.countyName)
        console.log(res.detailInfo)
        console.log(res.nationalCode)
        console.log(res.telNumber)

        that.setData({
          addressInfo: res
        })

        wx.showModal({
          title: '请确认收货信息',
          content: '收件人: ' + res.userName + '\n' +
          '联系电话: ' + res.telNumber + '\n' +
          '收货地址: ' + res.provinceName +
          res.cityName +
          res.countyName +
          res.detailInfo,
          success: function (res) {
            if (res.confirm) {
              console.log('用户点击确定');

              that.formSubmitAjax(function (res) {
                that.setData({
                  drawDownImage: res.data.msg,
                })
                console.log("recive_user使用资格码后，返回信息", res)
                if (res.data.code != 0) {
                  wx.showModal({
                    title: '提示',
                    content: res.data.msg,
                  })
                }

                if (!res.data.data && res.data.msg.length == 0) {
                  wx.showModal({
                    title: '提示',
                    content: "恭喜您，地址添加成功，商品将尽快发出！",
                    success: function (res) {
                      that.exchangeingAjax();
                      that.setData({
                        iSimageChu: false,
                        first: false,
                        second: true,
                        thirdly: false,
                        filladdress_btn1: false,
                        filladdress_btn2: true,
                        furl_sd: false,
                        furl_modal_box: false
                      })
                    }
                  })
                }
              })

            } else if (res.cancel) {
              console.log('用户点击取消')
            }
          }
        })
      }
    })
  },
  formSubmitAjax: function (cb) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");    
    wx.request({
      url: host + 'orderreceive/exchange',
      data: {
        userId: app.globalData.userId,
        openId: userinfo.openid,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        receiveCode: that.data.duihuanma,
        name: that.data.addressInfo.userName || that.data.addressInfo_userName,
        phone: that.data.addressInfo.telNumber || that.data.addressInfo_telNumber,
        address: (that.data.addressInfo.provinceName || that.data.addressInfo_provinceName) +
        (that.data.addressInfo.cityName || that.data.addressInfo_cityName) +
        (that.data.addressInfo.countyName || that.data.addressInfo_countyName) +
        (that.data.addressInfo.detailInfo || that.data.addressInfo_detailInfo),
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      success: function (res) {

        cb(res)

      }
    })
  },
  formSubmit: function (e) {
    console.log(e.detail.value)
    this.setData({
      addressInfo_userName: e.detail.value.addressInfo_userName,
      addressInfo_telNumber: e.detail.value.addressInfo_telNumber,
      addressInfo_provinceName: e.detail.value.addressInfo_provinceName,
      addressInfo_cityName: e.detail.value.addressInfo_cityName,
      addressInfo_countyName: e.detail.value.addressInfo_countyName,
      addressInfo_detailInfo: e.detail.value.addressInfo_detailInfo
    })


    var that = this;

    if (that.data.addressInfo_userName.length == 0 || that.data.addressInfo_telNumber.length == 0 || that.data.addressInfo_detailInfo.length == 0) {
      wx.showModal({
        title: '提示',
        content: "请完善收件人地址",
        success: function (res) {
        }
      })
    } else {

      wx.showModal({
        title: '请确认收货信息',
        content: '收件人: ' + that.data.addressInfo_userName + '\n' +
                 '联系电话: ' + that.data.addressInfo_telNumber + '\n' +
                 '收货地址: ' + that.data.addressInfo_detailInfo,
        success: function(res) {
          if (res.confirm) {
            that.formSubmitAjax(function (res) {
              that.setData({
                drawDownImage: res.data.msg,
              })
              console.log("recive_user使用资格码后，返回信息", res)
              if (res.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: res.data.msg,
                })
              }

              if (!res.data.data && res.data.msg.length == 0) {
                wx.showModal({
                  title: '提示',
                  content: "恭喜您，地址添加成功，商品将尽快发出！",
                  success: function (res) {
                    that.exchangeingAjax();
                    that.setData({
                      iSimageChu: false,
                      first: false,
                      second: true,
                      thirdly: false,
                      addressHide: false,
                      filladdress_btn1: false,
                      filladdress_btn2: true,
                      furl_sd: false,
                      furl_modal_box: false
                    })
                  }
                })
              }
            })
          } else if (res.cancel) {

          }
        }
      })
    }
  },
  present: function () {
    wx.reLaunch({
      url: '../indexss/indexss',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    console.log(this.data.drawDownImage)
    if (this.data.drawDownImage == '该码已经失效') {
      console.log('a')
    }
    this.setData({
      addressInfo_userName: that.data.addressInfo.userName,
      addressInfo_telNumber: that.data.addressInfo.telNumber,
      addressInfo_provinceName: that.data.addressInfo.provinceName,
      addressInfo_cityName: that.data.addressInfo.cityName,
      addressInfo_countyName: that.data.addressInfo.countyName,
      addressInfo_detailInfo: that.data.addressInfo.detailInfo
    })
    console.log('啥东西层选择',that.data.addsepon)
    if (that.data.addsepon) {
      wx.showModal({
        title: '请确认收货信息',
        content: '收件人: ' + that.data.addressInfo_userName + '\n' +
        '联系电话: ' + that.data.addressInfo_telNumber + '\n' +
        '收货地址: ' + that.data.addressInfo_provinceName +
        that.data.addressInfo_cityName +
        that.data.addressInfo_countyName +
        that.data.addressInfo_detailInfo,
        success: function (res) {
          if (res.confirm) {
            that.formSubmitAjax(function (res) {
              that.setData({
                drawDownImage: res.data.msg,
              })
              console.log("recive_user使用资格码后，返回信息", res)
              if (res.data.code != 0) {
                wx.showModal({
                  title: '提示',
                  content: res.data.msg,
                })
              }

              if (!res.data.data && res.data.msg.length == 0) {
                wx.showModal({
                  title: '提示',
                  content: "恭喜您，地址添加成功，商品将尽快发出！",
                  success: function (res) {
                    that.exchangeingAjax();
                    that.setData({
                      iSimageChu: false,
                      first: false,
                      second: true,
                      thirdly: false,
                      addressHide: false,
                      filladdress_btn1: false,
                      filladdress_btn2: true,
                      furl_sd: false,
                      furl_modal_box: false
                    })
                  }
                })
              }
            })
          } else if (res.cancel) {

          }
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})
