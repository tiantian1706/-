// pages/coupondetail/coupondetail.js
var app = getApp();
var host = app.globalData.host;
var url = app.globalData.url;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    host: host,
    url: url,
    juanarr: [],
    lijima: '立即领取',
    isling: false,
    couponid: 0,
    deadLine: "",
    showLoading: true,
  },
  linqude: function (ee) {
    // wx.navigateTo({
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    var couponid = that.data.juanarr.couponsId;
    if (!that.data.isling) {
      wx.request({
        url: host + 'shopcoupons/receive',
        data: {
          couponsId: that.data.couponid,
          userId: app.globalData.userId,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          openId: userinfo.openid,
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            wx.redirectTo({
              url: '../coupondeyi/coupondeyi?juanarr=' + JSON.stringify(that.data.juanarr),
            })
          }
        },
      })
    } else {
      wx.switchTab({
        url: '../find/find',
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    console.log("初始化", options)

    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    console.log(resSDKVersion)
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
    } else {
      that.setData({
        showLoading: false
      })
    };

    that.setData({
      juanarr: JSON.parse(options.juanarr),
      couponid: JSON.parse(options.juanarr).couponsId,
    })
    var deadLine = that.data.juanarr.deadLine.substring(0, 10);
    that.setData({
      deadLine: deadLine,
    }, function () {
      that.setData({
        showLoading: false
      }, function () {
        wx.hideLoading();
      })
    })
    // 我的优惠劵！！！
    wx.request({
      url: host + 'shopcoupons/myCoupons',
      data: {
        userId: app.globalData.userId,
        nickName: userinfo.nickName,
        headImgUrl: userinfo.avatarUrl,
        openId: userinfo.openid,
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        for (let i = 0; i < res.data.data.length; i++) {
          if (res.data.data[i].oldCouponsId == that.data.couponid) {
            that.setData({
              isling: true,
              lijima: '立即使用',
            })
            break;
          }
        }
      },
      fail: function (res) { }
    })
    // 我的优惠劵！！！
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})