// pay.js

var app = getApp();

var host = app.globalData.host;
var shopCommodityId = ""

var current_commodity_tag = []
var current_guige = [];

Page({

  /**
   * 页面的初始数据
   */
  data: {
    send: '去支付',
    total: '合计￥',
    sales:1,
    host: app.globalData.url,
    tishi: [
      {
        content: '付款完成后商品会在十个工作日内发送到指定地址',
      },
      {
        content: '代付用户二十四个小时内代付未完成则购买失败退款',
      }
    ],
    product_list: {
      // {
      //   indexImg: '',
      //   title: 'haha',
      //   introduction: 'hahaha',
      //   price: 100,
      //   sales: 12,
      //   jia: '../../images/jia.png',
      //   jian: '../../images/jian.png'
      // }
    },
    tagInfo:[]   
  },

  changeNumberJia:function(e){
    var that = this;
   
    var sales = that.data.sales;

    if(sales <= 1){
      return sales
    }

    that.setData({
      sales: --sales
    })

  },

  changeNumberJian:function(e){
    var that = this;

    var sales = that.data.sales;
    that.setData({
      sales: ++sales
    })
  },

  guige_choose: function(e){
    console.log("子类索引 ",e.currentTarget.id)
    console.log("父类索引", e.currentTarget.dataset.fatherindex)
    var that = this;

    var temp1 = e.currentTarget.dataset.fatherindex;
    var temp2 = e.currentTarget.id;
    var a = current_commodity_tag;
    a[temp1] = that.data.tagInfo[temp1].selected[temp2];
    current_commodity_tag = a
    console.log(a);
    current_guige[temp1] = temp2;
    that.setData({
      guige: current_guige
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (opt) {
    shopCommodityId = opt.shopCommodityId
    var that = this;
    console.log(opt.shopCommodityId);
    that.loadData(opt.shopCommodityId, function (result) {
      console.log("商品",result);
      that.setData({
        product_list: result.data.data.commodity,
        tagInfo:result.data.data.tagInfo
      })

      for (var i = 0 ; i < that.data.tagInfo.length; i++){
        var selected = that.data.tagInfo[i].selected;

        current_commodity_tag.push(selected[0])

      }
      
    })
  },
  loadData: function (condition, cb) {
    wx.request({
      url: host + 'commodity/get',
      data: {
        shopCommodityId: condition
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  mypay: function(){
    console.log("下单")
    var that = this;
    that.createOrder()
  },

  // 下单

  createOrder: function(){
      var that = this;
      var userinfo = wx.getStorageSync("userinfo_key")

      var tag_array = []
      for(var i = 0 ; i < current_commodity_tag.length; i++){
        var item = current_commodity_tag[i].shopCommoditySpecTabTagId;
        tag_array.push(item)
      }
      var tag = tag_array.join(",")


      wx.request({
        url: 'https://test.honqb.com/order/xcxcreateXcxOrder',
        data: {
          userId: app.globalData.userId,
          openId: userinfo.openid,
          nickName: userinfo.nickName,
          headImgUrl: userinfo.avatarUrl,
          shopCommodityId: shopCommodityId,
          quantity: that.data.sales,
          tag: tag
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        success: function(res){

          var order_id = res.data.data

          wx.request({
            url: 'https://test.honqb.com/order/xcxxcxPay',
            data: {
              userId: app.globalData.userId,
              openId: userinfo.openid,
              nickName: userinfo.nickName,
              headImgUrl: userinfo.avatarUrl,
              orderId:order_id
            },
            header: {
              'content-type': 'application/json'
            },
            method: 'get',
            success: function(res){

              var result = res.data.data;

              wx.requestPayment({
                userId: app.globalData.userId,
                timeStamp: result.timeStamp,
                nonceStr: result.nonceStr,
                package: result.package,
                signType: result.signType,
                paySign: result.paySign,
                success:function(res){
                    console.log(res)
                    wx.redirectTo({
                      url: '../exchangedetail/exchangedetail?orderId=' + order_id + "&nickName=" + userinfo.nickName ,
                    })
                },
                fail:function(res){

                },
                compelete: function(res){

                }
              })
            }
          })
        }
      })
  }
})