// pages/search/search.js

var app = getApp();
var host = app.globalData.host;
var pagesize = 500;
var pageindex = 0;
var condition = {};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    showLoading: false,
    inputText: "",
    imagesUrl: app.globalData.url,
  },

  // 根据条件加载列表
  conditionData: function (page_index, condition, cb) {
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: pagesize,
        pageIndex: page_index,
        condition: condition,
        userId: app.globalData.userId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    // var res = wx.getSystemInfoSync()
    // var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    // console.log(resSDKVersion)
    // if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
    //   wx.showLoading({
    //     title: '加载中',
    //   });
    // } else {
    //   that.setData({
    //     showLoading: false,
    //     loading: false
    //   })
    // }
    // console.log(options)
    // that.setData({
    //   inputText: options.inputText
    // })

    // that.loadData();
  },

  // 数据加载
  loadData: function () {
    var that = this;
    var searchText = {
      like_title: that.data.inputText,
    }

    console.log("搜索", searchText)

    that.conditionData(0, searchText, function (ops) {
      console.log("搜索的数据", ops)
      that.setData({
        product_list: ops.data.data,
      }, function () {
        that.setData({
          showLoading: false,
        }, function () {
          wx.hideLoading()
        })
      })
    })
  },

  //搜索
  inputGo: function (e) {
    var that = this;
    that.setData({
      inputText: e.detail.value
    })
  },
  searchGo: function () {
    var that = this;
    if (that.data.inputText) {
      var res = wx.getSystemInfoSync()
      var resSDKVersion = res.SDKVersion.replace(/\./g, '');
      console.log(resSDKVersion)
      if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
        wx.showLoading({
          title: '加载中',
        });
      }
      that.loadData();
    } else {
      wx.showModal({
        title: '提示',
        content: '请输入搜索内容'
      })
      return
    }
  },

  productList: function (e) {
    var index = e.currentTarget.id;
    var item = this.data.product_list[index];
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + item["shopCommodityId"]
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})