// pages/storepage/addbankcard/addbankcard.js

var app = getApp()
var host = app.globalData.host;
var datas = {};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    name: "",
    bank: "",
    kanum: "",
    phone:"",
    index:"",
    id:"",
    typeGo:true,
    cardid:"",
    showLoading:false,
  },
  nameF: function (e) {
    console.log(e.detail.value);
    this.setData({
      name: e.detail.value,
    })
  },
  bankF: function (e) {
    console.log(e.detail.value);
    this.setData({
      bank: e.detail.value,
    })
  },
  kanumF: function (e) {
    console.log(e.detail.value);
    this.setData({
      kanum: e.detail.value,
    })
  },
  phoneF: function (e) {
    console.log(e.detail.value);
    this.setData({
      phone: e.detail.value,
    })
  },

  // 添加银行卡
  addGo:function(){
    var that = this;
    if (that.data.name == "" || that.data.bank == "" || that.data.kanum == "" || that.data.phone == ""){
      wx.showModal({
        title: '温馨提示',
        content: '请完善信息',
      })
    }else{
      datas = {
        name: that.data.name,
        bank: that.data.bank,
        cardNo: that.data.kanum,
        phone: that.data.phone,
      };
      if (that.data.index == "1") {
        wx.request({
          url: host + "bankcard/addCardByStore",
          data: {
            storeId: that.data.id,
            data: datas,
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("数据", res);
              wx.navigateBack();              
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      } else if (that.data.index == "2") {
        wx.request({
          url: host + "bankcard/addCardByAgent",
          data: {
            agentId: that.data.id,
            data: datas,
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("数据", res)
              wx.navigateBack();
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      };
    }
  },

  // 修改银行卡
  amendGo:function(){
    var that = this;
    if (that.data.name == "" || that.data.bank == "" || that.data.kanum == "") {
      wx.showModal({
        title: '温馨提示',
        content: '请完善信息',
      })
    } else {
      datas = {
        name: that.data.name,
        bank: that.data.bank,
        cardNo: that.data.kanum,
        phone: that.data.phone
      };
      if (that.data.index == "1") {
        wx.request({
          url: host + "bankcard/modCardByStore",
          data: {
            storeId: that.data.id,
            data: datas,
            cardId: that.data.cardid
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("数据", res);
              wx.navigateBack();
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      } else if (that.data.index == "2") {
        wx.request({
          url: host + "bankcard/modCardByAgent",
          data: {
            agentId: that.data.id,
            data: datas,
            cardId: that.data.cardid            
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("数据", res)
              wx.navigateBack();
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      };
    }
  },
  loadData: function (cardid) {
    var that = this;
    if (that.data.index == "1") {
      var typeWho = 2;
    } else if (that.data.index == "2") {
      var typeWho = 1;
    };
    wx.request({
      url: host + "bankcard/myCard",
      data: {
        id: that.data.id,
        type: typeWho,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          console.log("初始化", res);
          var myCard = []
          for (var i = 0; i < res.data.data.length; i++) {
            var item = res.data.data[i];
            if (item.cardId == cardid) {
              myCard.push(item)
            }
          }
          console.log("myCard", myCard, myCard[0].name, myCard[0].bank, myCard[0].cardNo, myCard[0].phone)
          that.setData({
            name: myCard[0].name,
            bank: myCard[0].bank,
            kanum: myCard[0].cardNo, 
            phone: myCard[0].phone, 
            typeGo:false,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.hideShareMenu();
    console.log("初始化", options);
    that.setData({
      index: options.index,
      id: options.id,
    })
    if (options.cardid){
      that.setData({
        cardid: options.cardid,
      })
      // var res = wx.getSystemInfoSync()
      // var resSDKVersion = res.SDKVersion.replace(/\./g, '');
      // if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      //   wx.showLoading({
      //     title: '加载中',
      //   });
      //   that.setData({
      //     showLoading: true,
      //   })
      // } else {
      //   that.setData({
      //     showLoading: false
      //   })
      // }
      that.loadData(options.cardid);
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})