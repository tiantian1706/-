// pages/storepage/mycode/mycode.js
var wezrender = require('../../../lib/wezrender');
var app = getApp()
var url = app.globalData.url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    mycodeUrl:"",
    qrcode:"",
    url: url,
    index:"",
    codeText:"",
    headImgUrl:"",
    id:"",
    headName: "",
    shopName: "",
    title: ""
  },
  /**
   * 生命周期函数--监听页面加载
   */
  codeshow: function () {
    var that = this;

    that.setData({
      code_wrap_model: true,
      codeShow: true
    })

    wx.showLoading({
      title: '图片保存中',
    })
    var sadg = wx.getSystemInfoSync();
    console.log('sadg', sadg);
    const quImagesUrl = url + that.data.qrcode;
    console.log('二维码路径',quImagesUrl);
    wx.downloadFile({
      url: quImagesUrl,
      success: function (res) {
        console.log(';',res);
        wx.saveFile({
          tempFilePath: res.tempFilePath,
          success: function (res) {
            console.log('ssssss', res);
            var savedFilePath = res.savedFilePath;

            wx.downloadFile({
              url: that.data.headImgUrl,
              success: function (res) {
                wx.saveFile({
                  tempFilePath: res.tempFilePath,
                  success: function (res) {
                    var savedFilePath2 = res.savedFilePath;

                    try {
                      
                      var res = wx.getSystemInfoSync()
                      console.log(res.windowWidth)
                      console.log(res.windowHeight)
                      const quWidth = (res.windowWidth * (50 / 100)) + 1;
                      const quHeight = (res.windowHeight * (50 / 100)) + 1;
                      const quHeight_xh = quHeight - quWidth;
                      const quWidthQuHeight_xh = quWidth + quHeight_xh / 2;
                      const ctx = wx.createCanvasContext('code');
                      const zrCanvas = wezrender.zrender.init('code');
                      var sadg = wx.getSystemInfoSync();
                      var xiangsu = sadg.pixelRatio;
                      console.log(sadg)
                      function string_jiequ(aryLen, num_s) {
                        var titleLen = aryLen.split('');
                        var title_box = ''
                        for (var i = 0; i < num_s; i++) {

                          title_box += titleLen[i];

                        }

                        if (titleLen.length > num_s) {
                          title_box = title_box + '...'
                        } else {
                          title_box = aryLen;
                        }

                        return title_box;
                      }

                      ctx.save()
                      ctx.setFillStyle('#ffffff')
                      ctx.fillRect(0, 0, res.windowWidth, res.windowHeight)
                      ctx.save();
                      ctx.beginPath()
                      ctx.arc(95, 60, 25, 0, 2 * Math.PI)
                      console.log('执行')
                      ctx.clip()
                      console.log('执行2')
                      ctx.drawImage(savedFilePath2, 70, 34, 52, 52)
                      ctx.restore()
                      ctx.save();
                      ctx.draw()
                      
                      var text = new wezrender.graphic.Text({
                        style: {
                          x: 140,
                          y: 55,
                          text: string_jiequ(that.data.title, 10),
                          width: 300,
                          height: 300,
                          fill: '#000000',
                          textFont: '18px Microsoft Yahei',
                        }
                      });

                      zrCanvas.add(text);
                      var text2_con = '我为' + that.data.shopName  +'代言';
                      var text2 = new wezrender.graphic.Text({
                        style: {
                          x: 140,
                          y: 75,
                          text: string_jiequ(text2_con, 15),
                          width: 300,
                          height: 300,
                          fill: '#e14f5c',
                          textFont: '14px Microsoft Yahei',
                        }
                      });

                      zrCanvas.add(text2);

                      var image_zr = new wezrender.graphic.Image({
                        style: {
                          x: quWidth / 2 / 2,
                          y: quWidth / 2 + quWidth / 4,
                          image: savedFilePath,
                          width: quWidth + (quWidth/2),
                          height: quWidth + (quWidth / 2)
                        }
                      });

                      zrCanvas.add(image_zr);

                      if (that.data.index == 1) {
                        ctx.setTextAlign('center');
                        var text5 = new wezrender.graphic.Text({
                          style: {
                            x: (quWidth / 2) + (quWidth / 18),
                            y: (quWidth * 2) + (quWidth / 2),
                            text: '扫一扫或长按识别小程序码',
                            width: quWidth,
                            height: quWidth,
                            fill: '#000000',
                            textFont: '14px Microsoft Yahei',
                          }
                        });
                        zrCanvas.add(text5);

                        // ctx.setFontSize(15)
                        // ctx.setTextAlign('center')
                        // ctx.fillText('扫一扫或长按识别小程序码', quWidth, (quWidth * 2) + (quWidth / 2))
                        // ctx.draw()
                        
                      } else {
                        var image_zr2 = new wezrender.graphic.Image({
                          style: {
                            x: quWidth / 4,
                            y: quWidth + quWidth + 50,
                            image: '../../../images/wenzi.png',
                            width: quWidth + (quWidth /2),
                            height: (quWidth / 2)
                          }
                        });

                        zrCanvas.add(image_zr2);
                      }
                      
                    
                      setTimeout(function () {

                        console.log('像素', xiangsu)
                        wx.canvasToTempFilePath({
                          fileType: 'jpg',
                          quality: 1,
                          canvasId: 'code',
                          // destWidth: quWidth * xiangsu,
                          // destHeight: quHeight * xiangsu,
                          success: function (res) {
                            that.setData({
                              mycodeUrl: res.tempFilePath
                            })
                            console.log("canvas", res.tempFilePath);

                            // wx.previewImage({
                            //   urls: [res.tempFilePath],
                            //   success: function (res) {
                            //     console.log('成功')
                            //     wx.hideLoading();
                            //     that.setData({
                            //       codeShow: false,
                            //       code_wrap_model: false
                            //     })
                            //   }
                            // })

                            wx.saveImageToPhotosAlbum({
                              filePath: res.tempFilePath,
                              success(res) {
                                console.log("成功");
                                wx.hideLoading();
                              }
                            })
                          },
                          complete: function fail(e) {
                            console.log(e.errMsg);
                          }
                        })
                      }, 1000)
                    } catch (e) {
                      console.log(e);
                    }

                  }
                });
              }
            })

          }
        })
      }
    })
  },
  namehead: function() {
    var that = this;
    wx.request({
      url: that.data.url + '/user/getOtherInfo',
      data: {
        userId: app.globalData.userId
      },
      dataType: 'json',
      method: 'get',
      success: function (res) {
        that.setData({
          shopName: res.data.data.shopName,
        })
      },
      fail: function (res) { },
      complete: function (res) { }
    })
  },
  
  onLoad: function (options) {
    console.log("mycode初始化",options)
    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");

    var that = this;
    var userinfo = wx.getStorageSync("userinfo_key");
    if (options.avatarUrl) {
      that.setData({
        headImgUrl: options.avatarUrl,
        headName: options.nickName,
        title: options.title
      })
    } else {
      that.setData({
        headImgUrl: userinfo.avatarUrl,
        headName: userinfo.nickName,
        title: options.title
      })
    }
    that.setData({
      qrcode: options.qrcode,
      index: options.index,
      id: options.id,
    });

    if (that.data.index == "1") {
      that.setData({
        codeTtext: "门店Id：" + options.id
      })
    }
    if (that.data.index == "2") {
      that.setData({
        codeText: "代理商Id：" + options.id
      })
    }
    console.log("ssad", that.data.codeText, options.id);
    that.namehead();
  },
  canves:function(e){
    var that = this;
    wx.previewImage({
      urls: [url+that.data.qrcode],
      success: function (resd) {
        console.log('这里是打开图片的函数', resd)
        that.setData({
          isshowcanvas: false,
        })
      }
    })
  },
  save:function(){
    var that = this;    
    wx.downloadFile({
      url: url + that.data.qrcode,
      success: function (res) {
        let path = res.tempFilePath
        wx.saveImageToPhotosAlbum({
          filePath: path,
          success(res) {
            console.log(res);
          },
          fail(res) {
            console.log(res)
          },
          complete(res) {
            console.log(res)
          }
        })
      }, fail: function (res) {
        console.log(res)
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '推广二维码',
      path: 'pages/storepage/mycode/mycode?index=' + that.data.index + '&qrcode=' + that.data.qrcode + '&id=' + that.data.id + '&avatarUrl=' + that.data.headImgUrl + '&title=' + that.data.title,
    }
  }
})