 // pages/storepage/storemy/storemy.js

var app = getApp()
var host = app.globalData.host;


Page({

  /** 
   * 页面的初始数据
   */
  data: {
    loadData:[],
    index:"",
    id: "",
    totalBalance:"",
    balance:"",
    showLoading:true,
    qrcode:"",
    headImgUrl:"",
    whoname:"",
    host: host,
    redDot: false,
    myorderlength: 0, 
  },
  totixian:function(){
    var that = this;
    var tixian = that.data.balance;
    console.log(tixian)
    if (tixian==0){
      wx.showModal({
        title: '温馨提示',
        content: '暂无可提现佣金',
      })
      return;
    }
    wx.setStorageSync("balance", tixian);
    wx.navigateTo({
      url: '../tixian/tixian?index=' + that.data.index + '&id=' + that.data.id,
    })
  },
  todingdanlist: function (){
    var that = this;
    console.log("myorderlength", that.data.myorderlength, that.data.redDot)
    wx.setStorageSync("orderLength", that.data.myorderlength)
    that.setData({
      redDot:false
    })

    wx.navigateTo({
      url: '../dingdanlist/dingdanlist?index=' + that.data.index + '&id=' + that.data.id,
    })
  },
  tomycode: function () {
    var that = this;
    wx.navigateTo({
      url: '../mycode/mycode?qrcode=' + that.data.qrcode + '&index=' + that.data.index + '&id=' + that.data.id + '&title=' + that.data.whoname,
    })
  },
  tomystore:function(){
    var that = this;
    wx.navigateTo({
      url: '../mystore/mystore?index=' + that.data.index + '&id=' + that.data.id + '&title=' + that.data.whoname,
    })
  },
  totichenglist: function () {
    var that = this;
    wx.navigateTo({
      url: '../tichenglist/tichenglist?index=' + that.data.index + '&id=' + that.data.id + '&totalBalance=' + that.data.totalBalance,
    })
  },
  tomytixian: function () {
    var that = this;
    wx.navigateTo({
      url: '../mytixian/mytixian?index=' + that.data.index + '&id=' + that.data.id + '&balance=' + that.data.balance,
    })
  },
  tomyyongjing: function () {
    var that = this;
    wx.navigateTo({
      url: '../../commissionList/commissionList',
    })
  },
  showData:function(){
    var that = this;
    if (that.data.index == "1") {
      wx.request({
        url: host + "store/get",
        data: {
          storeId: that.data.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res);
            that.setData({
              loadData: res.data.data,
              whoname: res.data.data.title,
              totalBalance: res.data.data.totalBalance,
              balance: res.data.data.balance,
              qrcode: res.data.data.qrcode              
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    } else if (that.data.index == "2") {
      wx.request({
        url: host + "agent/get",
        data: {
          agentId: that.data.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res)
            that.setData({
              loadData: res.data.data,
              whoname: res.data.data.name,              
              totalBalance: res.data.data.totalBalance,
              balance: res.data.data.balance,
              qrcode: res.data.data.qrcode
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    };
  },

  // 修改密码
  changepassword:function(){
    var that = this;
    wx.navigateTo({
      url: '../changepassword/changepassword?id=' + that.data.id + "&index=" + that.data.index,
    })
  },

  // 订单红点提示
  redDot:function(){
    var that = this;
    var myorder = [];    
    if (that.data.index == "1") {
      wx.request({
        url: host + "order/getListByStore",
        data: {
          storeId: that.data.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res);
            for (var i = 0; i < res.data.data.length; i++) {
              var item = res.data.data[i];
              if (item.helpOrderId == "0" && item.scoreType == "1" && (item.state == '2' || item.state == '3' || item.state == '5')) {
                myorder.push(item)
              }
            }

            var orderStoreLength = wx.getStorageSync("orderStoreLength")
            if (orderStoreLength){
              console.log("有")
              if (res.data.data.length != orderStoreLength){
                that.setData({
                  redDot:true,
                  myorderlength:res.data.data.length,
                })
              }                          
            }else{
              console.log("没有")
              wx.setStorageSync("orderStoreLength", res.data.data.length)
            }

            that.setData({
              orderData: myorder
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    } else if (that.data.index == "2") {
      wx.request({
        url: host + "order/getListByAgent",
        data: {
          agentId: that.data.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res)
            for (var i = 0; i < res.data.data.length; i++) {
              var item = res.data.data[i];
              if (item.helpOrderId == "0" && item.scoreType == "1" && (item.state == '2' || item.state == '3' || item.state == '5')) {
                myorder.push(item)
              }
            }

            var orderAgentLength = wx.getStorageSync("orderAgentLength")
            if (orderAgentLength) {
              console.log("有")
              if (res.data.data.length != orderAgentLength) {
                that.setData({
                  redDot: true,
                  myorderlength: res.data.data.length,
                })
              }
            } else {
              console.log("没有")
              wx.setStorageSync("orderAgentLength", res.data.data.length)
            }

            that.setData({
              orderData: myorder
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    };
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.hideShareMenu();
    console.log("初始化",options);
    var userinfo = wx.getStorageSync("userinfo_key");
    that.setData({
      index:options.index,
      id:options.id,
      headImgUrl: userinfo.avatarUrl,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
      that.setData({
        showLoading: true,
      })
    } else {
      that.setData({
        showLoading: false
      })
    }
    that.showData();
    that.redDot();    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})