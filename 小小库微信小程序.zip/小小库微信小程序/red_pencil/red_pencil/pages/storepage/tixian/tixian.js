// pages/storepage/tixian/tixian.js
var app = getApp()
var host = app.globalData.host;
var datas = {};

Page({

  /**
   * 页面的初始数据
   */
  data: {
    imageUrl: app.globalData.url,
    haveKa:false,
    index: "",
    id: "",
    balance:"",
    getMoney:"",
    cardNum:"0",
    cardData:{},
    showLoading:true,
    cardDataNum:"",
    host:host
  },
  addbankcard:function(){
    var that = this;
    wx.navigateTo({
      url: '../addbankcard/addbankcard?index=' + that.data.index + '&id=' + that.data.id,
    })
  },
  banklist:function(){
    var that = this;    
    wx.navigateTo({
      url: '../banklist/banklist?index=' + that.data.index + '&id=' + that.data.id,
    })
  },
  moneyIn:function(e){
    var that = this;
    console.log(e.detail.value)
    that.setData({
      getMoney:e.detail.value
    })
  },
  allMoney:function(){
    var that = this;
    that.setData({
      getMoney: that.data.balance/100
    })
  },
  withdrawGo:function(){
    var that = this;
    if (that.data.getMoney == "") {
      wx.showModal({
        title: '温馨提示',
        content: '请输入提现金额',
      })
      return;
    }
    var have = Object.getOwnPropertyNames(that.data.cardData)    
    if (have.length == 0) {
      wx.showModal({
        title: '温馨提示',
        content: '请输入提现金额',
      })
      return;
    }else{

      datas = {
        name: that.data.cardData.name,
        bank: that.data.cardData.bank,
        bankAcount: that.data.cardData.cardNo,
        phone: that.data.cardData.phone,
      };
      // data(name bank bankAcount phone remark) 

      if (that.data.index == "1") {
        wx.request({
          url: host + "withdraw/drawByStore",
          data: {
            storeId: that.data.id,
            money: that.data.getMoney,
            data: datas,
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("提现", res);
              wx.showModal({
                title: '温馨提示',
                content: '您的提现已提交，请等待商家审核',
                success: function () {
                  wx.navigateBack()
                }
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      } else if (that.data.index == "2") {
        wx.request({
          url: host + "withdraw/drawByAgent",
          data: {
            agentId: that.data.id,
            money: that.data.getMoney,
            data: datas,                       
          },
          header: {
            'content-type': 'application/json'
          },
          method: 'get',
          dataType: '',
          success: function (res) {
            if (res.data.code != 0) {
              wx.showModal({
                title: '温馨提示',
                content: res.data.msg,
              })
            } else {
              console.log("提现", res);
              wx.showModal({
                title: '温馨提示',
                content: '您的提现已提交，请等待商家审核',
                success:function(){
                  wx.navigateBack()
                }
              })
            }
          },
          fail: function (res) { },
          complete: function (res) { }
        });
      }; 
    }  
  },
  loadData:function(){
    var that = this;
    if (that.data.index == "1") {
      var typeWho = 2;
    } else if (that.data.index == "2") {
      var typeWho = 1;
    };
    wx.request({
      url: host + "bankcard/myCard",
      data: {
        id: that.data.id,
        type: typeWho,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          if (res.data.data.length == "0") {
            that.setData({
              haveKa: false
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          } else if (res.data.data.length >= "1") {
            var cardDataNum = res.data.data[that.data.cardNum].cardNo
            console.log("卡号长度", cardDataNum.length);
            if (cardDataNum.length>4){
              cardDataNum = cardDataNum.substring(cardDataNum.length - 4, cardDataNum.length)
            }
            console.log("卡号", cardDataNum)
            that.setData({
              haveKa: true,
              cardData: res.data.data[that.data.cardNum],
              cardDataNum: cardDataNum
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          }
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.hideShareMenu();
    var balance = wx.getStorageSync("balance");    
    console.log("初始化", options, "balance",balance);    
    that.setData({
      index: options.index,
      id: options.id,
      balance: balance,
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
      that.setData({
        showLoading: true,
      })
    } else {
      that.setData({
        showLoading: false
      })
    }
    var cardIndex = wx.getStorageSync("cardIndex");
    if (cardIndex >= "0") {
      that.setData({
        cardNum: cardIndex
      })
    }
    that.loadData();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})