   // pages/storepage/login/login.js
var app = getApp()
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    index:"1",
    username:"",
    password:"",
    loginShow:false,
    showLoading:false,
    logindex: "0",
    logid:"",
    host: host,
    change:0,
  },
  judgeLogin:function(){
    var that = this;
    // 允许后执行
    console.log(that.data.index, that.data.username, that.data.password);
    if (that.data.username == "") {
      wx.showModal({
        title: '温馨提示',
        content: "请填写账号",
      })
      return
    }
    if (that.data.password == "") {
      wx.showModal({
        title: '温馨提示',
        content: "请填写密码",
      })
      return
    }

    // 店铺登陆
    if (that.data.index == "1") {
      var jiekou = 'store/login'
    }

    // 代理商登陆
    if (that.data.index == "2") {
      var jiekou = 'agent/login'
    }
    wx.request({
      url: host + jiekou,
      data: {
        userId: app.globalData.userId,
        username: that.data.username,
        password: that.data.password,
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        if (res.data.code != 0) {
          wx.showModal({
            title: '温馨提示',
            content: res.data.msg,
          })
        } else {
          that.setData({
            logindex: that.data.index,
            logid: res.data.data
          });
          wx.setStorageSync("logindex", that.data.logindex)
          wx.setStorageSync("logid", that.data.logid)
          wx.setStorageSync("username", that.data.username)
          wx.navigateTo({
            url: '../storemy/storemy?index=' + that.data.index + '&id=' + that.data.logid,
          })
        }
      },
      fail: function (res) { },
      complete: function (res) { }
    });
    // 允许后执行
  },
  tostoremy: function(e){
    var that = this;
    console.log("e", e)
    app.globalData.userInfo = e.detail.userInfo
    var userinfo = wx.getStorageSync("userinfo_key");
    console.log("userinfo.nickName", userinfo.nickName, userinfo)
    if (e.detail.userInfo) {
      console.log("允许")
      userinfo.nickName = e.detail.userInfo.nickName;
      userinfo.avatarUrl = e.detail.userInfo.avatarUrl;
      console.log("userinfo", userinfo);
      wx.setStorageSync("userinfo_key", userinfo);
      that.judgeLogin();
    }else{
      return
    }
  },
  usernameInput: function (e) {
    var that = this;
    that.setData({
      username: e.detail.value
    })
  },
  passwordInput:function(e){
    var that = this;
    that.setData({
      password: e.detail.value
    })
  },
  typeWho:function(e){
    var that = this;
    that.setData({
      index: e.currentTarget.dataset.index
    })
    console.log(that.data.index);    
  },
  loginGo:function(e){
    var that = this;
    console.log(e.currentTarget.dataset.id);
    that.setData({
      index: e.currentTarget.dataset.id,
      username: "",      
    });
    var haveindex = wx.getStorageSync("logindex");
    var haveid = wx.getStorageSync("logid");
    console.log("检测登陆", haveindex, haveid)
    if (haveindex == that.data.index && that.data.change == 0){
      var res = wx.getSystemInfoSync()
      var resSDKVersion = res.SDKVersion.replace(/\./g, '');
      if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
        wx.showLoading({
          title: '检测登录中',
        });
        that.setData({
          showLoading: true,
        })
      } else {
        that.setData({
          showLoading: false
        })
      }
      setTimeout(function () {
        wx.navigateTo({
          url: '../storemy/storemy?index=' + that.data.index + '&id=' + haveid,
        })
      }, 1000)
    }else{
      
      var logindex = wx.getStorageSync("logindex")
      if (that.data.change == 1 && e.currentTarget.dataset.id==logindex){
        var username = wx.getStorageSync("username")
        that.setData({
          username, username,
        })
      }

      that.setData({
        loginShow: true
      })
    }
  },
  tohide:function(){
    var that = this;
    that.setData({
      loginShow: false
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.hideShareMenu();
    console.log("onLoad",options)
    if (options.change) {
      that.setData({
        change: options.change,
      })
      var logindex = wx.getStorageSync("logindex")
      var username = wx.getStorageSync("username")
      
      console.log("logindex", logindex, "username", username)
      that.setData({
        username, username,
        index: logindex
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    wx.hideShareMenu();
    var that = this;
    that.setData({
      showLoading: false,
    });
    if (that.data.change == 0){
      that.setData({
        loginShow: false,
      })
    } else if (that.data.change == 1){
      that.setData({
        loginShow: true,
      })
    }
    wx.hideLoading();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})