// pages/storepage/mystoredetail/mystoredetail.js

var app = getApp()
var imgUrl = app.globalData.url;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: [],
    imgUrl: imgUrl
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log("初始化",options)
    var that = this;
    var data = JSON.parse(options.data)
    console.log(data)
    that.setData({
      data:data
    })
  },
  saveImg:function(){
    var that = this;
    console.log(that.data.imgUrl + that.data.data.qrcode);
    var codeUrl = that.data.imgUrl + that.data.data.qrcode;
    wx.downloadFile({
      url: codeUrl,
      success: function (res) {
        console.log(res)
        wx.saveImageToPhotosAlbum({
          filePath: res.tempFilePath,
          success(res) {
            console.log("成功");
          }
        })
      },
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})