// pages/storepage/mytixian/mytixian.js

var app = getApp()
var host = app.globalData.host;

Page({

  /**
   * 页面的初始数据
   */
  data: {
    host:host,
    mytixianData:[],
    balance:"",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    console.log("初始化",options);
    that.setData({
      balance: options.balance
    })
    if (options.index=="2"){
      var index = "1"
    }else{
      var index = "2"
    }
    wx.request({
      url: host + 'withdraw/myRecord',
      dataType: 'json',
      method: 'get',
      data: {
        type: index,
        id: options.id
      },
      success: function (res) {

        that.setData({
          withdraw: res.data.data
        }, function () {

          that.setData({
            showLoading: false
          }, function () {
            wx.hideLoading()
          })
        })
        console.log('提现金额', res.data.data)
        if (res.data.data == '') {
          that.setData({
            moneyZhong: "0"
          })
        }
        var numMber = 0;
        for (var i = 0, len = res.data.data.length; i < len; i++) {
          console.log("sdkjd", res.data.data[i].money, res.data.data)
          numMber += Number(res.data.data[i].money)

          if (numMber == null) {
            that.setData({
              moneyZhong: "0"
            })
          } else {
            that.setData({
              moneyZhong: numMber
            })
          }
        }
      },
      fail: function (res) { }
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})