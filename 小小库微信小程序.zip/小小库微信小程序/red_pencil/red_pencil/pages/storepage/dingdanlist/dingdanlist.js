// pages/storepage/dingdanlist/dingdanlist.js
var app = getApp()
var host = app.globalData.host;


Page({

  /**
   * 页面的初始数据
   */
  data: {
    orderData: [],
    myorderOne: [],
    myorderTwo: [],
    index: "",
    id: "",
    whoId:"1",
    showLoading: true,
  },

  who:function(e){
    var that = this;
    that.setData({
      whoId: e.currentTarget.dataset.id
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options);
    var that = this;
    wx.hideShareMenu();
    var res = wx.getSystemInfoSync()
    var resSDKVersion = res.SDKVersion.replace(/\./g, '');
    if (parseInt(resSDKVersion) >= app.globalData.resSDKVersionNumber) {
      wx.showLoading({
        title: '加载中',
      });
      that.setData({
        showLoading: true,
      })
    } else {
      that.setData({
        showLoading: false
      })
    }
    console.log("初始化", options);
    that.setData({
      index: options.index,
      id: options.id
    })
    if (options.index == "1") {
      wx.request({
        url: host + "order/getListByStore",
        data: {
          storeId: options.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res);
            var myorder = [];
            var myorderOne = [];
            var myorderTwo = [];

            for (var i = 0; i < res.data.data.length; i++) {
              var item = res.data.data[i];
              if (item.helpOrderId == "0" && item.scoreType == "1") {
                myorder.push(item)

                if (item.type == '1' && (item.state == '2' || item.state == '5')){
                  myorderOne.push(item)
                } else if (item.type != '1' && (item.state == '2' || item.state == '3' || item.state == '5')){
                  myorderTwo.push(item)              
                }

              }
            }

            that.setData({
              orderData: myorder,
              myorderOne: myorderOne,
              myorderTwo: myorderTwo,
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    } else if (options.index == "2") {
      wx.request({
        url: host + "order/getListByAgent",
        data: {
          agentId: options.id
        },
        header: {
          'content-type': 'application/json'
        },
        method: 'get',
        dataType: '',
        success: function (res) {
          if (res.data.code != 0) {
            wx.showModal({
              title: '温馨提示',
              content: res.data.msg,
            })
          } else {
            console.log("初始化", res)
            var myorder = [];
            var myorderOne = [];
            var myorderTwo = [];

            for (var i = 0; i < res.data.data.length; i++) {
              var item = res.data.data[i];
              if (item.helpOrderId == "0" && item.scoreType == "1") {
                myorder.push(item)

                if (item.type == '1' && (item.state == '2' || item.state == '5')) {
                  myorderOne.push(item)
                } else if (item.type != '1' && (item.state == '2' || item.state == '3' || item.state == '5')) {
                  myorderTwo.push(item)
                }

              }
            }

            that.setData({
              orderData: myorder,
              myorderOne: myorderOne,
              myorderTwo: myorderTwo,
            }, function () {
              that.setData({
                showLoading: false,
              });
              wx.hideLoading();
            })
          }
        },
        fail: function (res) { },
        complete: function (res) { }
      });
    };
  },
  goDetail:function(e){
    console.log(e.currentTarget.dataset.order);
    wx.navigateTo({
      url: '../../orderDetail/orderDetail?orderId=' + e.currentTarget.dataset.order,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})