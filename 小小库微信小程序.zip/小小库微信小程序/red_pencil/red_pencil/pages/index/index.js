//index.js
//获取应用实例

var config =  require('../../config')
var host = app.globalData.host;
var app = getApp()
var pagesize = 10;
var pageindex = 1;


//查询商品分类里面商品列表的条件
var condition = {}
//查询商品分类的条件
var commodityclassify_condition = { }
Page({
  data: {
    isShow:false,
    host:"",
    index:'首页',
    shouye:'shouye',
    activeIndex: -1,    
    activeList: '',
    hot_sales:'',
    select:true,
    product_list: [

    ],
    navbar:[

    ],
    second:[

    ],
    winWidth: 0,
    winHeight: 0,

  },

  //点击商品跳到商品的详情页
  productList: function (e) {
    var index = e.currentTarget.id;
    var item = this.data.product_list[index];
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + item["shopCommodityId"]
    })
  },

  enterHotCommodity: function(e){
    wx.navigateTo({
      url: '../productDetail/productDetail?shopCommodityId=' + this.data.hot_sales["shopCommodityId"]
    })
  },


  // 切换类目，切换类目的同时需要更换 condition
  tabClick: function (e) {
    var that = this;
    var idIndex = e.currentTarget.id; 
    var index = e.target.dataset.current;
    var currentIndex = e.target.dataset.main;
    
    //给导航条添加下划线
    if (idIndex == 'shouye'){
      condition = {
        multiOrder: 'price asc, sales desc'
      }
      that.setData({
        select: true,
        activeIndex: -1,
        activeList: -1,
        isShow:true
      }); 

      this.initData({
        multiOrder: 'price asc, sales desc'
      },function(){
        
      })     
    }else{
      that.setData({
        activeIndex: currentIndex,
        select: false,
        activeList: idIndex,
        isShow:false
      });      
    }    
     

    // 改变 condition
    // 根据condition 进行页面的刷新
    if (e.target.dataset.current === idIndex) {
      condition = {
        shopCommodityClassifyId: idIndex,
        multiOrder: 'price asc, sales desc',
      }
      commodityclassify_condition = {
        shopCommodityClassifyId: idIndex,
      }
    }else{
      commodityclassify_condition = {
      
      }
    }   
    console.log("一级父类",commodityclassify_condition)
    that.commodityclassify_second(commodityclassify_condition.shopCommodityClassifyId, function (res) {
      console.log("导航条的数据 ", res);
      that.setData({
        second: res.data.data,
      })
    })
  },  

  commodityclassifyList: function(e){
    var that = this
    var item = this.data.second[e.currentTarget.id]
      console.log("二级分类",item)

      condition = {
        shopCommodityClassifyId: item.shopCommodityClassifyId,
        multiOrder: 'price asc, sales desc'
      }

      that.initData(condition,function(){
        that.setData({
          isShow: false
        })
      })
  },


  onLoad: function () {
    console.log('onLoad');
    var that = this
    //获取导航条的数据
    that.commodityclassify(commodityclassify_condition,function(res){
      console.log("导航条的数据 " , res);
      that.setData({
        navbar:res.data.data.first,
        currentSecond: res.data.data.currentSecond,
      })
    }),

    condition = {
      multiOrder: 'price asc, sales desc'
    }
    that.initData(condition,function(){

    });
    
    // 获取设备信息
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          winHeight: res.windowWidth*0.97*0.48,
        });
        console.log(res.windowWidth * 0.97 * 0.48)
      }
    });
    
  },

  //根据导航条的内容来刷新页面
  initData: function (params,cb) {
    console.log("打印条件 ", params);
    var that = this;
    pageindex = 1

    var hot_params = {
        today:"1"
    }
    for(var key in params){
        hot_params[key] = params[key]
    }


    //获取轮播图或者首页图的内容，热销商品
    that.loadData(pageindex, hot_params, function (result) {
      console.log("导航条的内容来刷新页面" , result),
        that.setData({
          hot_sales: result.data.data[0],
          host: app.globalData.url,
          isShow:true 
        })
        cb()
    }),

    //加载所有商品列表
      that.loadData(pageindex, params, function (result) {
      console.log('加载所有商品列表',result);
      that.setData({
        product_list: result.data.data,
        host: app.globalData.url,
      })
    })
  },

  // 获取目录
  commodityclassify: function (condition,cb){
    wx.request({
      url: host + 'commodityclassify/getAllClassifyInfo',
      data: {
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: 'json',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  // 根据一级分类获取二级分类目录
  commodityclassify_second: function (shopCommodityClassifyId,cb){
    wx.request({
      url: host + 'commodityclassify/getSecondClassify',
      data: {
        shopCommodityClassifyId: shopCommodityClassifyId
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

// 根据条件加载商品列表
  loadData: function (page_index,condition,cb){
    wx.request({
      url: host + 'commodity/getList',
      data: {
        pageSize: pagesize,
        pageIndex: page_index,
        condition: condition
      },
      header: {
        'content-type': 'application/json'
      },
      method: 'get',
      dataType: '',
      success: function (res) {
        cb(res)
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  //刷新页面
  refresh: function (condition, cb) {
    var that = this;
    pageindex = 1;
    this.loadData(pageindex, condition, function (result) {
      wx.stopPullDownRefresh()
      cb(result)
    })
  },

  //加载更多
  loadMore: function (condition, cb){
    var that = this;
    if (pagesize * pageindex > length) {
      return ;
    }else{
      pageindex++;
      that.loadData(pageindex, condition, function (result) {
        cb(result)
      })
    }
  },
  onPullDownRefresh: function () {
    // Do something when pull down.
    console.log("下拉刷新")
    // var that = this;
    // this.refresh(condition, function () {
    //   that.loadData(pageindex, condition, function (result) {
    //     that.setData({
    //       product_list: result.data.data,
    //     })
    //   })        
    // })
  },

  onReachBottom: function () {
    // Do something when page reach bottom.
    console.log("滑动底部")
    var that = this;
    this.loadMore(condition, function () {
      var p_list = that.data.product_list;
      that.loadData(pageindex, condition, function (result) {
        var pList = p_list.concat(result.data.data);
          // console.log(result);
          that.setData({
            product_list: pList,
          })
      })
    })
  },
})
